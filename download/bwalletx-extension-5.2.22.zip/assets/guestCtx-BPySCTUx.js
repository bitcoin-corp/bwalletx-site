import{r as t}from"./index-DnrAIzlv.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-BPySCTUx.js.map
