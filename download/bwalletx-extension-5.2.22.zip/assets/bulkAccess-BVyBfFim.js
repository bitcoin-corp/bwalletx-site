import{gP as e}from"./main-DG-PCX7X.js";import{m as i,j as l}from"./identityText-B102YG9a.js";const n=["b0asex"],r=(a,o=n)=>{const[s,t]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!s||!o.includes(s)?!1:!t||t===l.toLowerCase()},A=(a,o=!1)=>o||e(a)||r(i(a??void 0));export{A as c};
//# sourceMappingURL=bulkAccess-BVyBfFim.js.map
