import{r as s}from"./index-DnrAIzlv.js";import{i8 as r,i9 as o}from"./main-DG-PCX7X.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-CDYeDPgI.js.map
