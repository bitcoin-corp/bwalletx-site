const t=""+new URL("tokenblaster-C_XxC5_I.png",import.meta.url).href;export{t};
//# sourceMappingURL=tokenblaster-BRbL-P_J.js.map
