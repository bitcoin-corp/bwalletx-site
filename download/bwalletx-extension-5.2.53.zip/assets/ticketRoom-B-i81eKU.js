import{e}from"./index-DGxqTQ1A.js";import{j as a}from"./main-BESfE_mz.js";const r=(o,t)=>{a(`bsv21:${o}`),t(e("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-B-i81eKU.js.map
