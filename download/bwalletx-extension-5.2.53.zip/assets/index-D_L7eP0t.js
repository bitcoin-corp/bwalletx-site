const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Cu7WufzE.js","./index-DGxqTQ1A.js","./crypto-KcxRl6yv.js","./wocLimiter-CB1baL7K.js","./wocLimiter-BZfJYSu4.css","./index-cvPtiFzg.css"])))=>i.map(i=>d[i]);
import{n as e,_ as t}from"./index-DGxqTQ1A.js";import"./crypto-KcxRl6yv.js";import"./wocLimiter-CB1baL7K.js";const a=e("Share",{web:()=>t(()=>import("./web-Cu7WufzE.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{a as Share};
//# sourceMappingURL=index-D_L7eP0t.js.map
