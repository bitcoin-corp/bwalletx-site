import{r as n}from"./wocLimiter-CB1baL7K.js";import{X as s}from"./index-DGxqTQ1A.js";const u=(e,r)=>{const t=n.useRef(r);t.current=r,n.useEffect(()=>{const o=c=>c.detail===e&&t.current();return window.addEventListener(s,o),()=>window.removeEventListener(s,o)},[e])};export{u};
//# sourceMappingURL=useTabHome-BcjAG6Nb.js.map
