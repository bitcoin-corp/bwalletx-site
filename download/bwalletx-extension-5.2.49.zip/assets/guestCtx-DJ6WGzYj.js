import{r as t}from"./index-t5CcWpUk.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-DJ6WGzYj.js.map
