const s=e=>(e??"").split(/[\s,]+/).map(i=>i.trim()).filter(Boolean),n=s(void 0),d=(e,i=n)=>i.length>0&&[e.identityPubKey,e.identityAddress].some(t=>!!t&&i.includes(t));export{d as i};
//# sourceMappingURL=studioAccess-z7EKSgpw.js.map
