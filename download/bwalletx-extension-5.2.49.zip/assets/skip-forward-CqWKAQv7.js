import{n as o}from"./crypto-CKYsQejp.js";const a=[["path",{d:"M21 4v16",key:"7j8fe9"}],["path",{d:"M6.029 4.285A2 2 0 0 0 3 6v12a2 2 0 0 0 3.029 1.715l9.997-5.998a2 2 0 0 0 .003-3.432z",key:"zs4d6"}]],r=o("skip-forward",a);export{r as S};
//# sourceMappingURL=skip-forward-CqWKAQv7.js.map
