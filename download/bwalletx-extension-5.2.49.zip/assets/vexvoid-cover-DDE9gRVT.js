const e=""+new URL("vexvoid-cover-CSvKHHAL.jpg",import.meta.url).href;export{e as v};
//# sourceMappingURL=vexvoid-cover-DDE9gRVT.js.map
