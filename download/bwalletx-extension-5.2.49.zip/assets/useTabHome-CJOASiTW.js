import{r as n}from"./index-t5CcWpUk.js";import{f4 as s}from"./index-CV906TQ8.js";const u=(e,r)=>{const t=n.useRef(r);t.current=r,n.useEffect(()=>{const o=c=>c.detail===e&&t.current();return window.addEventListener(s,o),()=>window.removeEventListener(s,o)},[e])};export{u};
//# sourceMappingURL=useTabHome-CJOASiTW.js.map
