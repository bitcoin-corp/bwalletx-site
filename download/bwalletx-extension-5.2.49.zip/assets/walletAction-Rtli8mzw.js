const n="bwallet:wallet-action";let e=null;const o=t=>{e=t;try{window.dispatchEvent(new Event(n))}catch{}},l=()=>{const t=e;return e=null,t},a=t=>(window.addEventListener(n,t),()=>window.removeEventListener(n,t));export{a as o,o as r,l as t};
//# sourceMappingURL=walletAction-Rtli8mzw.js.map
