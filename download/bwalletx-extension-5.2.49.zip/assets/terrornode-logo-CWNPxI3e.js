const o=""+new URL("terrornode-logo-CS42mIMc.webp",import.meta.url).href;export{o as t};
//# sourceMappingURL=terrornode-logo-CWNPxI3e.js.map
