import{b as a}from"./index-CV906TQ8.js";import{cl as e}from"./main-BTNHdm8v.js";const r=(o,t)=>{e(`bsv21:${o}`),t(a("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-BJdZ2aEj.js.map
