const e=""+new URL("wallet-card-Bn4OK78X.mp4",import.meta.url).href;export{e as w};
//# sourceMappingURL=wallet-card-CzVJ3dAP.js.map
