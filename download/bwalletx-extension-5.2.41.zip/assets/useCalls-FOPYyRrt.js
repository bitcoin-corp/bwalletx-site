import{r as s}from"./index-C7bJf09m.js";import{jU as e,br as o}from"./index-XZQ0ia-v.js";const c=()=>{const[t,r]=s.useState(e);return s.useEffect(()=>o(r),[]),t};export{c as u};
//# sourceMappingURL=useCalls-FOPYyRrt.js.map
