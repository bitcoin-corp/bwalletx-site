const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BsFfWmMd.js","./index-XZQ0ia-v.js","./crypto-BfwOqArZ.js","./index-C7bJf09m.js","./index-B4qM1JYa.css","./extensionMedia-Rm_l9uoo.js","./index-C15dUoCK.css"])))=>i.map(i=>d[i]);
import{ax as e,ad as t}from"./index-XZQ0ia-v.js";import"./crypto-BfwOqArZ.js";import"./index-C7bJf09m.js";import"./extensionMedia-Rm_l9uoo.js";const p=e("Share",{web:()=>t(()=>import("./web-BsFfWmMd.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{p as Share};
//# sourceMappingURL=index-BlqpG1bC.js.map
