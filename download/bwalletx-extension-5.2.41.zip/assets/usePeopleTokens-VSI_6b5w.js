import{r as t}from"./index-C7bJf09m.js";import{fetchPeopleTokens as l}from"./people-LDqM0o2c.js";const f=()=>{const[s,o]=t.useState(null);return t.useEffect(()=>{let e=!0;return l().then(r=>e&&o(r)),()=>{e=!1}},[]),s};export{f as u};
//# sourceMappingURL=usePeopleTokens-VSI_6b5w.js.map
