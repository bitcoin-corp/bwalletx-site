import{i as e}from"./sessions-jkNYT0ay.js";import{c0 as i,aJ as c,ch as l}from"./index-XZQ0ia-v.js";const n=["b0asex"],r=(a,s=n)=>{const[t,o]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!s.includes(t)?!1:!o||o===c.toLowerCase()||(l??[]).includes(o)},m=(a,s=!1)=>s||e(a)||r(i(a??void 0));export{m as c};
//# sourceMappingURL=bulkAccess-DJApJ_0r.js.map
