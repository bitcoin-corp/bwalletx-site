import{r as t}from"./index-C7bJf09m.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-DoLlSwBI.js.map
