import{t as e}from"./crypto-7zukc12_.js";const t=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}]],r=e("square",t);export{r as S};
//# sourceMappingURL=square-D7p41o7-.js.map
