import{t as e}from"./crypto-7zukc12_.js";const t=[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]],c=e("video",t);export{c as V};
//# sourceMappingURL=video-DFlaEyaN.js.map
