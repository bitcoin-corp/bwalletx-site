import{i as e}from"./sessions-BSsJtr0O.js";import{aS as i,aT as l,aU as n}from"./index-DY5eW-DN.js";const r=["b0asex"],c=(a,s=r)=>{const[t,o]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!s.includes(t)?!1:!o||o===l.toLowerCase()||(n??[]).includes(o)},m=(a,s=!1)=>s||e(a)||c(i(a??void 0));export{m as c};
//# sourceMappingURL=bulkAccess-DYu8i5DS.js.map
