import{r as n}from"./wocLimiter-CVYQRkJQ.js";import{X as s}from"./index-DY5eW-DN.js";const u=(e,r)=>{const t=n.useRef(r);t.current=r,n.useEffect(()=>{const o=c=>c.detail===e&&t.current();return window.addEventListener(s,o),()=>window.removeEventListener(s,o)},[e])};export{u};
//# sourceMappingURL=useTabHome-DDodAKjg.js.map
