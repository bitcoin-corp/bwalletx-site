import{r as s}from"./wocLimiter-CVYQRkJQ.js";import{U as r,V as o}from"./index-DY5eW-DN.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-BmHdSLRR.js.map
