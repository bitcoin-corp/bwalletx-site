import{e}from"./index-DY5eW-DN.js";import{j as a}from"./main-w-0_nNLb.js";const r=(o,t)=>{a(`bsv21:${o}`),t(e("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-CfgijEdK.js.map
