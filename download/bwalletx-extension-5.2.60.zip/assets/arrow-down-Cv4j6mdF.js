import{t as o}from"./crypto-7zukc12_.js";const e=[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]],t=o("arrow-down",e);export{t as A};
//# sourceMappingURL=arrow-down-Cv4j6mdF.js.map
