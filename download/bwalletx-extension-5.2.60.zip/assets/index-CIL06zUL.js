const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Byhyp9zj.js","./index-DY5eW-DN.js","./crypto-7zukc12_.js","./wocLimiter-CVYQRkJQ.js","./wocLimiter-Cw4eDz7L.css","./index-BbKU_OLL.css"])))=>i.map(i=>d[i]);
import{n as e,_ as t}from"./index-DY5eW-DN.js";import"./crypto-7zukc12_.js";import"./wocLimiter-CVYQRkJQ.js";const a=e("Share",{web:()=>t(()=>import("./web-Byhyp9zj.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{a as Share};
//# sourceMappingURL=index-CIL06zUL.js.map
