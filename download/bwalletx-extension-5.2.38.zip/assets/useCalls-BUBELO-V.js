import{r as s}from"./index-numRYSTi.js";import{jn as r,aU as a}from"./index-CtM9qBtB.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-BUBELO-V.js.map
