import{c as t}from"./crypto-BaEBpRme.js";const a=[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"m21 3-7 7",key:"1l2asr"}],["path",{d:"m3 21 7-7",key:"tjx5ai"}],["path",{d:"M9 21H3v-6",key:"wtvkvv"}]],i=t("maximize-2",a);export{i as M};
//# sourceMappingURL=maximize-2-u5iBLHto.js.map
