const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-De6Y0mR5.js","./index-CtM9qBtB.js","./crypto-BaEBpRme.js","./index-numRYSTi.js","./index-DU2cSw24.css","./extensionMedia-Rm_l9uoo.js","./index-D9oNvL9Y.css"])))=>i.map(i=>d[i]);
import{ai as e,_ as t}from"./index-CtM9qBtB.js";import"./crypto-BaEBpRme.js";import"./index-numRYSTi.js";import"./extensionMedia-Rm_l9uoo.js";const _=e("Share",{web:()=>t(()=>import("./web-De6Y0mR5.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-BWlsxWxW.js.map
