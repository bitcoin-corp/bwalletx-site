import{c}from"./index-BR7FEPFY.js";const o=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 6v6l4 2",key:"mmk7yg"}]],r=c("clock",o);export{r as C};
//# sourceMappingURL=clock-59vlT4lt.js.map
