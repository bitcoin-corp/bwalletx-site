import{r as t}from"./index-DraGGgen.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-Bb4MjCWE.js.map
