import{r as s}from"./index-DraGGgen.js";import{hW as r,hX as o}from"./main-DWGHwsmw.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-DFL1HX6L.js.map
