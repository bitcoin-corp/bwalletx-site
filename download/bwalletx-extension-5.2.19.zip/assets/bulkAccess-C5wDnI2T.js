import{gB as e}from"./main-DWGHwsmw.js";import{m as i,j as l}from"./identityText-CGX2zZx6.js";const n=["b0asex"],r=(a,o=n)=>{const[s,t]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!s||!o.includes(s)?!1:!t||t===l.toLowerCase()},A=(a,o=!1)=>o||e(a)||r(i(a??void 0));export{A as c};
//# sourceMappingURL=bulkAccess-C5wDnI2T.js.map
