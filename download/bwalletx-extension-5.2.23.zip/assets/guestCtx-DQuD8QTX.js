import{r as t}from"./index-BywnNTx1.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-DQuD8QTX.js.map
