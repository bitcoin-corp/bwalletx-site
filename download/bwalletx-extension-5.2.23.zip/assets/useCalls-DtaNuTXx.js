import{r as s}from"./index-BywnNTx1.js";import{i4 as r,i5 as o}from"./main-_SjjCVQW.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-DtaNuTXx.js.map
