import "./background.js";
const R = globalThis || void 0 || self;
var E;
(function(t) {
  t.Unimplemented = "UNIMPLEMENTED", t.Unavailable = "UNAVAILABLE";
})(E || (E = {}));
class x extends Error {
  constructor(e, r, n) {
    super(e), this.message = e, this.code = r, this.data = n;
  }
}
const M = (t) => {
  var e, r;
  return t?.androidBridge ? "android" : !((r = (e = t?.webkit) === null || e === void 0 ? void 0 : e.messageHandlers) === null || r === void 0) && r.bridge ? "ios" : "web";
}, z = (t) => {
  const e = t.CapacitorCustomPlatform || null, r = t.Capacitor || {}, n = r.Plugins = r.Plugins || {}, a = () => e !== null ? e.name : M(t), s = () => a() !== "web", o = (i) => {
    const c = b.get(i);
    return !!(c?.platforms.has(a()) || l(i));
  }, l = (i) => {
    var c;
    return (c = r.PluginHeaders) === null || c === void 0 ? void 0 : c.find((P) => P.name === i);
  }, u = (i) => t.console.error(i), b = /* @__PURE__ */ new Map(), L = (i, c = {}) => {
    const P = b.get(i);
    if (P)
      return console.warn(`Capacitor plugin "${i}" already registered. Cannot register plugins twice.`), P.proxy;
    const v = a(), p = l(i);
    let h;
    const G = async () => (!h && v in c ? h = typeof c[v] == "function" ? h = await c[v]() : h = c[v] : e !== null && !h && "web" in c && (h = typeof c.web == "function" ? h = await c.web() : h = c.web), h), K = (d, f) => {
      var w, g;
      if (p) {
        const m = p?.methods.find((y) => f === y.name);
        if (m)
          return m.rtype === "promise" ? (y) => r.nativePromise(i, f.toString(), y) : (y, k) => r.nativeCallback(i, f.toString(), y, k);
        if (d)
          return (w = d[f]) === null || w === void 0 ? void 0 : w.bind(d);
      } else {
        if (d)
          return (g = d[f]) === null || g === void 0 ? void 0 : g.bind(d);
        throw new x(`"${i}" plugin is not implemented on ${v}`, E.Unimplemented);
      }
    }, O = (d) => {
      let f;
      const w = (...g) => {
        const m = G().then((y) => {
          const k = K(y, d);
          if (k) {
            const S = k(...g);
            return f = S?.remove, S;
          } else
            throw new x(`"${i}.${d}()" is not implemented on ${v}`, E.Unimplemented);
        });
        return d === "addListener" && (m.remove = async () => f()), m;
      };
      return w.toString = () => `${d.toString()}() { [capacitor code] }`, Object.defineProperty(w, "name", {
        value: d,
        writable: !1,
        configurable: !1
      }), w;
    }, T = O("addListener"), U = O("removeListener"), q = (d, f) => {
      const w = T({ eventName: d }, f), g = async () => {
        const y = await w;
        U({
          eventName: d,
          callbackId: y
        }, f);
      }, m = new Promise((y) => w.then(() => y({ remove: g })));
      return m.remove = async () => {
        console.warn("Using addListener() without 'await' is deprecated."), await g();
      }, m;
    }, _ = new Proxy({}, {
      get(d, f) {
        switch (f) {
          // https://github.com/facebook/react/issues/20030
          case "$$typeof":
            return;
          case "toJSON":
            return () => ({});
          case "addListener":
            return p ? q : T;
          case "removeListener":
            return U;
          default:
            return O(f);
        }
      }
    });
    return n[i] = _, b.set(i, {
      name: i,
      proxy: _,
      platforms: /* @__PURE__ */ new Set([...Object.keys(c), ...p ? [v] : []])
    }), _;
  };
  return r.convertFileSrc || (r.convertFileSrc = (i) => i), r.getPlatform = a, r.handleError = u, r.isNativePlatform = s, r.isPluginAvailable = o, r.registerPlugin = L, r.Exception = x, r.DEBUG = !!r.DEBUG, r.isLoggingEnabled = !!r.isLoggingEnabled, r;
}, V = (t) => t.Capacitor = z(t), C = /* @__PURE__ */ V(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof R < "u" ? R : {}), A = C.registerPlugin;
class $ {
  constructor() {
    this.listeners = {}, this.retainedEventArguments = {}, this.windowListeners = {};
  }
  addListener(e, r) {
    let n = !1;
    this.listeners[e] || (this.listeners[e] = [], n = !0), this.listeners[e].push(r);
    const s = this.windowListeners[e];
    s && !s.registered && this.addWindowListener(s), n && this.sendRetainedArgumentsForEvent(e);
    const o = async () => this.removeListener(e, r);
    return Promise.resolve({ remove: o });
  }
  async removeAllListeners() {
    this.listeners = {};
    for (const e in this.windowListeners)
      this.removeWindowListener(this.windowListeners[e]);
    this.windowListeners = {};
  }
  notifyListeners(e, r, n) {
    const a = this.listeners[e];
    if (!a) {
      if (n) {
        let s = this.retainedEventArguments[e];
        s || (s = []), s.push(r), this.retainedEventArguments[e] = s;
      }
      return;
    }
    a.forEach((s) => s(r));
  }
  hasListeners(e) {
    var r;
    return !!(!((r = this.listeners[e]) === null || r === void 0) && r.length);
  }
  registerWindowListener(e, r) {
    this.windowListeners[r] = {
      registered: !1,
      windowEventName: e,
      pluginEventName: r,
      handler: (n) => {
        this.notifyListeners(r, n);
      }
    };
  }
  unimplemented(e = "not implemented") {
    return new C.Exception(e, E.Unimplemented);
  }
  unavailable(e = "not available") {
    return new C.Exception(e, E.Unavailable);
  }
  async removeListener(e, r) {
    const n = this.listeners[e];
    if (!n)
      return;
    const a = n.indexOf(r);
    a !== -1 && this.listeners[e].splice(a, 1), this.listeners[e].length || this.removeWindowListener(this.windowListeners[e]);
  }
  addWindowListener(e) {
    window.addEventListener(e.windowEventName, e.handler), e.registered = !0;
  }
  removeWindowListener(e) {
    e && (window.removeEventListener(e.windowEventName, e.handler), e.registered = !1);
  }
  sendRetainedArgumentsForEvent(e) {
    const r = this.retainedEventArguments[e];
    r && (delete this.retainedEventArguments[e], r.forEach((n) => {
      this.notifyListeners(e, n);
    }));
  }
}
const j = (t) => encodeURIComponent(t).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape), I = (t) => t.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent);
class Y extends $ {
  async getCookies() {
    const e = document.cookie, r = {};
    return e.split(";").forEach((n) => {
      if (n.length <= 0)
        return;
      let [a, s] = n.replace(/=/, "CAP_COOKIE").split("CAP_COOKIE");
      a = I(a).trim(), s = I(s).trim(), r[a] = s;
    }), r;
  }
  async setCookie(e) {
    try {
      const r = j(e.key), n = j(e.value), a = e.expires ? `; expires=${e.expires.replace("expires=", "")}` : "", s = (e.path || "/").replace("path=", ""), o = e.url != null && e.url.length > 0 ? `domain=${e.url}` : "";
      document.cookie = `${r}=${n || ""}${a}; path=${s}; ${o};`;
    } catch (r) {
      return Promise.reject(r);
    }
  }
  async deleteCookie(e) {
    try {
      document.cookie = `${e.key}=; Max-Age=0`;
    } catch (r) {
      return Promise.reject(r);
    }
  }
  async clearCookies() {
    try {
      const e = document.cookie.split(";") || [];
      for (const r of e)
        document.cookie = r.replace(/^ +/, "").replace(/=.*/, `=;expires=${(/* @__PURE__ */ new Date()).toUTCString()};path=/`);
    } catch (e) {
      return Promise.reject(e);
    }
  }
  async clearAllCookies() {
    try {
      await this.clearCookies();
    } catch (e) {
      return Promise.reject(e);
    }
  }
}
A("CapacitorCookies", {
  web: () => new Y()
});
const J = async (t) => new Promise((e, r) => {
  const n = new FileReader();
  n.onload = () => {
    const a = n.result;
    e(a.indexOf(",") >= 0 ? a.split(",")[1] : a);
  }, n.onerror = (a) => r(a), n.readAsDataURL(t);
}), Q = (t = {}) => {
  const e = Object.keys(t);
  return Object.keys(t).map((a) => a.toLocaleLowerCase()).reduce((a, s, o) => (a[s] = t[e[o]], a), {});
}, X = (t, e = !0) => t ? Object.entries(t).reduce((n, a) => {
  const [s, o] = a;
  let l, u;
  return Array.isArray(o) ? (u = "", o.forEach((b) => {
    l = e ? encodeURIComponent(b) : b, u += `${s}=${l}&`;
  }), u.slice(0, -1)) : (l = e ? encodeURIComponent(o) : o, u = `${s}=${l}`), `${n}&${u}`;
}, "").substr(1) : null, Z = (t, e = {}) => {
  const r = Object.assign({ method: t.method || "GET", headers: t.headers }, e), a = Q(t.headers)["content-type"] || "";
  if (typeof t.data == "string")
    r.body = t.data;
  else if (a.includes("application/x-www-form-urlencoded")) {
    const s = new URLSearchParams();
    for (const [o, l] of Object.entries(t.data || {}))
      s.set(o, l);
    r.body = s.toString();
  } else if (a.includes("multipart/form-data") || t.data instanceof FormData) {
    const s = new FormData();
    if (t.data instanceof FormData)
      t.data.forEach((l, u) => {
        s.append(u, l);
      });
    else
      for (const l of Object.keys(t.data))
        s.append(l, t.data[l]);
    r.body = s;
    const o = new Headers(r.headers);
    o.delete("content-type"), r.headers = o;
  } else (a.includes("application/json") || typeof t.data == "object") && (r.body = JSON.stringify(t.data));
  return r;
};
class N extends $ {
  /**
   * Perform an Http request given a set of options
   * @param options Options to build the HTTP request
   */
  async request(e) {
    const r = Z(e, e.webFetchExtra), n = X(e.params, e.shouldEncodeUrlParams), a = n ? `${e.url}?${n}` : e.url, s = await fetch(a, r), o = s.headers.get("content-type") || "";
    let { responseType: l = "text" } = s.ok ? e : {};
    o.includes("application/json") && (l = "json");
    let u, b;
    switch (l) {
      case "arraybuffer":
      case "blob":
        b = await s.blob(), u = await J(b);
        break;
      case "json":
        u = await s.json();
        break;
      default:
        u = await s.text();
    }
    const L = {};
    return s.headers.forEach((i, c) => {
      L[c] = i;
    }), {
      data: u,
      headers: L,
      status: s.status,
      url: s.url
    };
  }
  /**
   * Perform an Http GET request given a set of options
   * @param options Options to build the HTTP request
   */
  async get(e) {
    return this.request(Object.assign(Object.assign({}, e), { method: "GET" }));
  }
  /**
   * Perform an Http POST request given a set of options
   * @param options Options to build the HTTP request
   */
  async post(e) {
    return this.request(Object.assign(Object.assign({}, e), { method: "POST" }));
  }
  /**
   * Perform an Http PUT request given a set of options
   * @param options Options to build the HTTP request
   */
  async put(e) {
    return this.request(Object.assign(Object.assign({}, e), { method: "PUT" }));
  }
  /**
   * Perform an Http PATCH request given a set of options
   * @param options Options to build the HTTP request
   */
  async patch(e) {
    return this.request(Object.assign(Object.assign({}, e), { method: "PATCH" }));
  }
  /**
   * Perform an Http DELETE request given a set of options
   * @param options Options to build the HTTP request
   */
  async delete(e) {
    return this.request(Object.assign(Object.assign({}, e), { method: "DELETE" }));
  }
}
A("CapacitorHttp", {
  web: () => new N()
});
var D;
(function(t) {
  t.Dark = "DARK", t.Light = "LIGHT", t.Default = "DEFAULT";
})(D || (D = {}));
var H;
(function(t) {
  t.StatusBar = "StatusBar", t.NavigationBar = "NavigationBar";
})(H || (H = {}));
class ee extends $ {
  async setStyle() {
    this.unavailable("not available for web");
  }
  async setAnimation() {
    this.unavailable("not available for web");
  }
  async show() {
    this.unavailable("not available for web");
  }
  async hide() {
    this.unavailable("not available for web");
  }
}
A("SystemBars", {
  web: () => new ee()
});
async function te(t, e = {}, r) {
  return window.__TAURI_INTERNALS__.invoke(t, e, r);
}
const re = (t = typeof window > "u" ? void 0 : window) => !!t && typeof t == "object" && "__TAURI_INTERNALS__" in t && !!t.__TAURI_INTERNALS__, ne = "store_load", B = "store_apply", se = (t) => {
  let e = null;
  const r = () => e ??= t(ne).then((n) => new Map(Object.entries(n ?? {})));
  return {
    async get(n) {
      return (await r()).get(n) ?? null;
    },
    async set(n, a) {
      const s = await r();
      await t(B, { sets: { [n]: a }, removes: [] }), s.set(n, a);
    },
    async remove(n) {
      const a = await r();
      await t(B, { sets: {}, removes: [n] }), a.delete(n);
    },
    async keys() {
      return [...(await r()).keys()];
    }
  };
}, ae = re(), F = (t, e) => te(t, e), ie = (t = F) => {
  const e = se(t);
  return {
    async secureGet({ key: r }) {
      return { value: await e.get(r) };
    },
    async secureSet({ key: r, value: n }) {
      await e.set(r, n);
    },
    async secureRemove({ key: r }) {
      await e.remove(r);
    },
    async secureKeys() {
      return { keys: await e.keys() };
    },
    async biometricStatus() {
      const r = await t("bio_status");
      return { available: r.available, biometryType: r.biometryType };
    },
    async biometricSet({ key: r, value: n }) {
      await t("bio_set", { key: r, value: n });
    },
    async biometricGet({ key: r, reason: n }) {
      try {
        return { value: await t("bio_get", { key: r, reason: n }) };
      } catch (a) {
        const s = String(a);
        throw Object.assign(new Error(s), { code: /cancel/i.test(s) ? "cancelled" : "error" });
      }
    },
    async biometricRemove({ key: r }) {
      await t("bio_remove", { key: r });
    },
    async browserOpen({ url: r }) {
      await oe(r, t);
    }
  };
}, oe = async (t, e = F) => {
  await e("open_external", { url: t });
}, W = {
  async secureGet({ key: t }) {
    return { value: localStorage.getItem(`secure:${t}`) };
  },
  async secureSet({ key: t, value: e }) {
    localStorage.setItem(`secure:${t}`, e);
  },
  async secureRemove({ key: t }) {
    localStorage.removeItem(`secure:${t}`);
  },
  async secureKeys() {
    return {
      keys: Object.keys(localStorage).filter((t) => t.startsWith("secure:")).map((t) => t.slice(7))
    };
  },
  async biometricStatus() {
    return { available: !1, biometryType: "none" };
  },
  async biometricRemove() {
  },
  async browserOpen({ url: t }) {
    window.open(t, "_blank", "noopener");
  },
  async browserClose() {
  },
  async browserSetHidden() {
  },
  async browserRespond() {
  },
  async browserEmit() {
  },
  async audioSetSpeaker() {
  },
  async installerPackage() {
    return { installer: null };
  },
  async speechAvailable() {
    return { available: !1 };
  },
  async haptic() {
    navigator.vibrate?.(15);
  },
  async secretCopy({ text: t }) {
    return await navigator.clipboard.writeText(t), { token: "" };
  },
  async secretClear() {
  }
}, le = A("YoursNative", {
  // Desktop (Tauri): keystore, flags and biometrics go to the Rust side (desktop/ipc.ts); the rest stays web.
  web: () => ae ? { ...W, ...ie() } : W
});
C.isNativePlatform();
export {
  le as YoursNative
};
//# sourceMappingURL=native-fwRwXd1H.js.map
