const n=new Set(["vexvoid"]),e=t=>!!t&&n.has(t.trim().toLowerCase()),i=t=>e(t)?" bw-invert-on-light":"";export{i};
//# sourceMappingURL=invertOnLight-CR6zLxj-.js.map
