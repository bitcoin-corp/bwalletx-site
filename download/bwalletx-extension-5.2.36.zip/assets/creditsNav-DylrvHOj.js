const t="bwallet:credits-sheet";let n=null;const s=e=>{n=e;try{window.dispatchEvent(new Event(t))}catch{}},r=()=>{const e=n;return n=null,e},o=e=>(window.addEventListener(t,e),()=>window.removeEventListener(t,e));export{o,s as r,r as t};
//# sourceMappingURL=creditsNav-DylrvHOj.js.map
