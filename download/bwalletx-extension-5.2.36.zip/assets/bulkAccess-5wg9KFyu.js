import{gM as e}from"./main-SIZQSCam.js";import{bH as i,ba as l,bX as n}from"./index-bPcLMhQ4.js";const r=["b0asex"],c=(a,s=r)=>{const[t,o]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!s.includes(t)?!1:!o||o===l.toLowerCase()||(n??[]).includes(o)},m=(a,s=!1)=>s||e(a)||c(i(a??void 0));export{m as c};
//# sourceMappingURL=bulkAccess-5wg9KFyu.js.map
