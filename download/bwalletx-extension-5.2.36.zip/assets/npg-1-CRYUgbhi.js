const e=""+new URL("npg-1-D8l5kY63.webp",import.meta.url).href;export{e as n};
//# sourceMappingURL=npg-1-CRYUgbhi.js.map
