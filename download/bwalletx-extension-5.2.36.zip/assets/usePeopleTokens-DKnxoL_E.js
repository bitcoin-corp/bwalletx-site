import{r as t}from"./index-BLH4FYCc.js";import{fetchPeopleTokens as l}from"./people-Bokcb_Ot.js";const f=()=>{const[s,o]=t.useState(null);return t.useEffect(()=>{let e=!0;return l().then(r=>e&&o(r)),()=>{e=!1}},[]),s};export{f as u};
//# sourceMappingURL=usePeopleTokens-DKnxoL_E.js.map
