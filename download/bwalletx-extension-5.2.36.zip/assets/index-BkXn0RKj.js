const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-xQZ1UYCn.js","./index-bPcLMhQ4.js","./crypto-BxJFXG29.js","./index-BLH4FYCc.js","./index-DLljdb-I.css","./extensionMedia-Rm_l9uoo.js","./index-qOeyoI8c.css"])))=>i.map(i=>d[i]);
import{ai as e,_ as t}from"./index-bPcLMhQ4.js";import"./crypto-BxJFXG29.js";import"./index-BLH4FYCc.js";import"./extensionMedia-Rm_l9uoo.js";const _=e("Share",{web:()=>t(()=>import("./web-xQZ1UYCn.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-BkXn0RKj.js.map
