import{r as t}from"./index-BLH4FYCc.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-d55Y5Om8.js.map
