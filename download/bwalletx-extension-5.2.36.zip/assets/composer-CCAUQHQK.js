const c=["/m/ask-b","/m/chat","/m/bmail"],a=t=>c.some(s=>t===s||t.startsWith(`${s}/`)),o=["create-account","restore-account"],n=(t,s)=>t==="settings"&&!!s&&o.includes(s);export{o as A,a as h,n as i};
//# sourceMappingURL=composer-CCAUQHQK.js.map
