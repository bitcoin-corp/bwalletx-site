import{r as s}from"./index-BLH4FYCc.js";import{iX as r,aU as a}from"./index-bPcLMhQ4.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-D-UU0FBi.js.map
