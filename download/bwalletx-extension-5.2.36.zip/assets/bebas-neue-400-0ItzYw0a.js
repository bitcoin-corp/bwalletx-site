const e=""+new URL("bebas-neue-400-CoNGBGqG.woff2",import.meta.url).href;export{e as b};
//# sourceMappingURL=bebas-neue-400-0ItzYw0a.js.map
