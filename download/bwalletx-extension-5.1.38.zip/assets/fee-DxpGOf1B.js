import{F as o,O as c}from"./index-B6KRT595.js";const r=.01,a=o("192nuX6cz81MH3T2gwsam3FxYoDrvzDYpU".trim()),s=(e=a)=>e&&c(e)?e:"",n=(e,t=a)=>s(t)?Math.ceil(e*r):0,p=(e=a)=>{const t=s(e);return t?{marketplaceAddress:t,marketplaceRate:r}:{}};export{r as M,p as a,n as m};
//# sourceMappingURL=fee-DxpGOf1B.js.map
