import{e}from"./index-B4TEEkZ8.js";import{j as a}from"./main-DLPCJY5_.js";const r=(o,t)=>{a(`bsv21:${o}`),t(e("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-broaqYHd.js.map
