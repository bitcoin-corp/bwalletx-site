import{t as o}from"./crypto-fR9BYmcf.js";const r=[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]],a=o("arrow-up",r);export{a as A};
//# sourceMappingURL=arrow-up-CKFBuDhd.js.map
