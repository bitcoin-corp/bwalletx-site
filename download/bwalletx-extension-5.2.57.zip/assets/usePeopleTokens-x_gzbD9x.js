import{r as t}from"./wocLimiter-CVYQRkJQ.js";import{fetchPeopleTokens as l}from"./people-Bc5tmj5R.js";const f=()=>{const[s,o]=t.useState(null);return t.useEffect(()=>{let e=!0;return l().then(r=>e&&o(r)),()=>{e=!1}},[]),s};export{f as u};
//# sourceMappingURL=usePeopleTokens-x_gzbD9x.js.map
