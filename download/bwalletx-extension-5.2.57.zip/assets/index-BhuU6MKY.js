const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-6DlL3n4D.js","./index-BHouY2TJ.js","./crypto-fR9BYmcf.js","./wocLimiter-CVYQRkJQ.js","./wocLimiter-Cw4eDz7L.css","./index-BbKU_OLL.css"])))=>i.map(i=>d[i]);
import{n as e,_ as t}from"./index-BHouY2TJ.js";import"./crypto-fR9BYmcf.js";import"./wocLimiter-CVYQRkJQ.js";const a=e("Share",{web:()=>t(()=>import("./web-6DlL3n4D.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{a as Share};
//# sourceMappingURL=index-BhuU6MKY.js.map
