import{e}from"./index-BHouY2TJ.js";import{j as a}from"./main-C4VoO3qW.js";const r=(o,t)=>{a(`bsv21:${o}`),t(e("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-C66WkGwc.js.map
