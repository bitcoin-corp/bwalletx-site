import{r as t}from"./wocLimiter-CVYQRkJQ.js";import{fetchPeopleTokens as l}from"./people-DQHsU_2O.js";const f=()=>{const[s,o]=t.useState(null);return t.useEffect(()=>{let e=!0;return l().then(r=>e&&o(r)),()=>{e=!1}},[]),s};export{f as u};
//# sourceMappingURL=usePeopleTokens-BM7huQf5.js.map
