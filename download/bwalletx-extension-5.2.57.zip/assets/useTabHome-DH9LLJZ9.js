import{r as n}from"./wocLimiter-CVYQRkJQ.js";import{X as s}from"./index-B4TEEkZ8.js";const u=(e,r)=>{const t=n.useRef(r);t.current=r,n.useEffect(()=>{const o=c=>c.detail===e&&t.current();return window.addEventListener(s,o),()=>window.removeEventListener(s,o)},[e])};export{u};
//# sourceMappingURL=useTabHome-DH9LLJZ9.js.map
