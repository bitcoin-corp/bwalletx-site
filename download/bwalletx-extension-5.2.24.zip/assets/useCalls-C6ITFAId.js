import{r as s}from"./index-UUJpKimX.js";import{iz as r,iA as o}from"./main-CBxWEpXk.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-C6ITFAId.js.map
