import{gZ as e}from"./main-CBxWEpXk.js";import{m as i,j as l}from"./ApprovalHeroes-CUOPWxGc.js";const n=["b0asex"],r=(a,o=n)=>{const[s,t]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!s||!o.includes(s)?!1:!t||t===l.toLowerCase()},A=(a,o=!1)=>o||e(a)||r(i(a??void 0));export{A as c};
//# sourceMappingURL=bulkAccess-DzirBC31.js.map
