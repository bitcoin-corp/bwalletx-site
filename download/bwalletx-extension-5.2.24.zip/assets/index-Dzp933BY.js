const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-C4lL6kL_.js","./index-CWOIBKbA.js","./index-UUJpKimX.js","./index-BDtJ2amF.css","./index-B4WbRSy_.js","./index-Dehz_VII.css"])))=>i.map(i=>d[i]);
import{a0 as e,_ as t}from"./index-CWOIBKbA.js";import"./index-UUJpKimX.js";import"./index-B4WbRSy_.js";const _=e("Share",{web:()=>t(()=>import("./web-C4lL6kL_.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-Dzp933BY.js.map
