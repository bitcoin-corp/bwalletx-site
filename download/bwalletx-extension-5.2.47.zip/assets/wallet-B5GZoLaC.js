import{co as a,Y as s}from"./index-DEBtDp8x.js";async function t(){const e=await a({action:s.GET_BALANCE});if(!e.success)throw new Error(e.error||"Failed to get balance");return e.data??0}export{t as g};
//# sourceMappingURL=wallet-B5GZoLaC.js.map
