import{n as e}from"./crypto-BO33qVdw.js";const n=[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]],t=e("trending-up",n);export{t as T};
//# sourceMappingURL=trending-up-B_cvDNcu.js.map
