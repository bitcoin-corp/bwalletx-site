import{b as a}from"./index-DEBtDp8x.js";import{cl as e}from"./main-ajMKbjak.js";const r=(o,t)=>{e(`bsv21:${o}`),t(a("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-BiqBndB1.js.map
