import{n as o}from"./crypto-BO33qVdw.js";const r=[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]],e=o("arrow-up",r);export{e as A};
//# sourceMappingURL=arrow-up-DGp1Kj0S.js.map
