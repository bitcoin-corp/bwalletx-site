import{i as e}from"./sessions-DFTnpS2m.js";import{bm as i,aO as l,bz as n}from"./index-DEBtDp8x.js";const r=["b0asex"],c=(a,s=r)=>{const[t,o]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!s.includes(t)?!1:!o||o===l.toLowerCase()||(n??[]).includes(o)},L=(a,s=!1)=>s||e(a)||c(i(a??void 0));export{L as c};
//# sourceMappingURL=bulkAccess-D-taeefT.js.map
