const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-_RlBuuoA.js","./index-CF-YgHy7.js","./index-CzAdjc2h.js","./index-UUJpKimX.js","./index-BDtJ2amF.css","./extensionMedia-Rm_l9uoo.js","./index-CWWQEr1C.css"])))=>i.map(i=>d[i]);
import{a7 as e,_ as t}from"./index-CF-YgHy7.js";import"./index-CzAdjc2h.js";import"./index-UUJpKimX.js";import"./extensionMedia-Rm_l9uoo.js";const _=e("Share",{web:()=>t(()=>import("./web-_RlBuuoA.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-DTVp6NmP.js.map
