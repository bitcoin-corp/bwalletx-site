import{fT as r}from"./main-B1XCWdOh.js";import{g as e}from"./ApprovalHeroes-BN-huBKv.js";import{aY as i}from"./index-CF-YgHy7.js";const l=["b0asex"],n=(a,o=l)=>{const[t,s]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!o.includes(t)?!1:!s||s===i.toLowerCase()},p=(a,o=!1)=>o||r(a)||n(e(a??void 0));export{p as c};
//# sourceMappingURL=bulkAccess-C9rJJRGA.js.map
