import{r as s}from"./index-UUJpKimX.js";import{h3 as r,aG as a}from"./index-CF-YgHy7.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-BGQ9huCP.js.map
