import{r as s}from"./index-BCfd9xtL.js";import{iT as r,aU as a}from"./index-D0pzRKKP.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-_bBFfiQk.js.map
