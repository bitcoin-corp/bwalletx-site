import{c}from"./crypto-DZfDIKRG.js";const e=[["path",{d:"M12 19v3",key:"npa21l"}],["path",{d:"M19 10v2a7 7 0 0 1-14 0v-2",key:"1vc78b"}],["rect",{x:"9",y:"2",width:"6",height:"13",rx:"3",key:"s6n7sd"}]],o=c("mic",e);export{o as M};
//# sourceMappingURL=mic-BPwqPM1O.js.map
