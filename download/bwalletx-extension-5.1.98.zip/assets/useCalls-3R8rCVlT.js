import{r as s}from"./index-BJLW3vv2.js";import{hH as r,hI as o}from"./main-B20sCcy9.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-3R8rCVlT.js.map
