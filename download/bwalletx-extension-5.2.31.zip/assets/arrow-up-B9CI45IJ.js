import{c as o}from"./crypto-C0Mtv_ph.js";const r=[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]],c=o("arrow-up",r);export{c as A};
//# sourceMappingURL=arrow-up-B9CI45IJ.js.map
