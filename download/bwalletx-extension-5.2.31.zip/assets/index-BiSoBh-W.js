const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CF35Kd76.js","./index-HT711YXu.js","./crypto-C0Mtv_ph.js","./index-DvwB3iNZ.js","./index-BOs1uvky.css","./extensionMedia-Rm_l9uoo.js","./index-BKPRrgVL.css"])))=>i.map(i=>d[i]);
import{af as e,_ as t}from"./index-HT711YXu.js";import"./crypto-C0Mtv_ph.js";import"./index-DvwB3iNZ.js";import"./extensionMedia-Rm_l9uoo.js";const _=e("Share",{web:()=>t(()=>import("./web-CF35Kd76.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-BiSoBh-W.js.map
