import{r as t}from"./index-DvwB3iNZ.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-qSXI_edb.js.map
