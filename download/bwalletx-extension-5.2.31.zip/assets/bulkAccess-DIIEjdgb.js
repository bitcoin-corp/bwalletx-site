import{gt as e}from"./main-BOJMh7r8.js";import{bB as i,b4 as l}from"./index-HT711YXu.js";const n=["b0asex"],r=(a,o=n)=>{const[t,s]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!o.includes(t)?!1:!s||s===l.toLowerCase()},A=(a,o=!1)=>o||e(a)||r(i(a??void 0));export{A as c};
//# sourceMappingURL=bulkAccess-DIIEjdgb.js.map
