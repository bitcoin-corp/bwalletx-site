import{r as s}from"./index-DvwB3iNZ.js";import{it as r,aO as a}from"./index-HT711YXu.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-DuuR_lZO.js.map
