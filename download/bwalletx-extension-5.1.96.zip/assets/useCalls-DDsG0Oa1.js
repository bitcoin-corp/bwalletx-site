import{r as s}from"./index-C2axhe3s.js";import{hH as r,hI as o}from"./main-CPmNBXk5.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-DDsG0Oa1.js.map
