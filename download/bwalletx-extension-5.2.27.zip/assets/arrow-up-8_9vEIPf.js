import{c as o}from"./crypto-83b-FolX.js";const r=[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]],c=o("arrow-up",r);export{c as A};
//# sourceMappingURL=arrow-up-8_9vEIPf.js.map
