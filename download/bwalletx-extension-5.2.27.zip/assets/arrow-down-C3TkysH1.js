import{c as o}from"./crypto-83b-FolX.js";const e=[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]],c=o("arrow-down",e);export{c as A};
//# sourceMappingURL=arrow-down-C3TkysH1.js.map
