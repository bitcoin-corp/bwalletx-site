import{r as s}from"./index-UUJpKimX.js";import{ij as r,aQ as a}from"./index-DhPbQe6j.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-DrK8JBOn.js.map
