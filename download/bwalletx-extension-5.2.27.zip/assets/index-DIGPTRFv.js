const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DXnkOrNE.js","./index-DhPbQe6j.js","./crypto-83b-FolX.js","./index-UUJpKimX.js","./index-BDtJ2amF.css","./extensionMedia-Rm_l9uoo.js","./index-BlC9hmpE.css"])))=>i.map(i=>d[i]);
import{ac as e,_ as t}from"./index-DhPbQe6j.js";import"./crypto-83b-FolX.js";import"./index-UUJpKimX.js";import"./extensionMedia-Rm_l9uoo.js";const _=e("Share",{web:()=>t(()=>import("./web-DXnkOrNE.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-DIGPTRFv.js.map
