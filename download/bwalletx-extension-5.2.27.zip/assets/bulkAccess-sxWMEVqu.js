import{g0 as r}from"./main-CYXU8vJN.js";import{g as e}from"./ApprovalHeroes-CY6BALzh.js";import{b6 as i}from"./index-DhPbQe6j.js";const l=["b0asex"],n=(o,a=l)=>{const[t,s]=o.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!a.includes(t)?!1:!s||s===i.toLowerCase()},A=(o,a=!1)=>a||r(o)||n(e(o??void 0));export{A as c};
//# sourceMappingURL=bulkAccess-sxWMEVqu.js.map
