import{r as n}from"./wocLimiter-uHHeeIuD.js";import{X as s}from"./index-0pWYEnpG.js";const u=(e,r)=>{const t=n.useRef(r);t.current=r,n.useEffect(()=>{const o=c=>c.detail===e&&t.current();return window.addEventListener(s,o),()=>window.removeEventListener(s,o)},[e])};export{u};
//# sourceMappingURL=useTabHome-DIUL9MQs.js.map
