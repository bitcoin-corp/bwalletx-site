const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BR-8xqED.js","./index-0pWYEnpG.js","./crypto-CpMMdW64.js","./wocLimiter-uHHeeIuD.js","./wocLimiter-Cw4eDz7L.css","./index-D7NokxBA.css"])))=>i.map(i=>d[i]);
import{n as e,_ as t}from"./index-0pWYEnpG.js";import"./crypto-CpMMdW64.js";import"./wocLimiter-uHHeeIuD.js";const a=e("Share",{web:()=>t(()=>import("./web-BR-8xqED.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{a as Share};
//# sourceMappingURL=index-CtMxZW5m.js.map
