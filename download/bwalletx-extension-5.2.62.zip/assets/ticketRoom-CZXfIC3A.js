import{e}from"./index-0pWYEnpG.js";import{j as a}from"./main-DhNl_YMb.js";const r=(o,t)=>{a(`bsv21:${o}`),t(e("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-CZXfIC3A.js.map
