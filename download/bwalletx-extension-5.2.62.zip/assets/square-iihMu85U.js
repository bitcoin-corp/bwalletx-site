import{t as e}from"./crypto-CpMMdW64.js";const t=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}]],r=e("square",t);export{r as S};
//# sourceMappingURL=square-iihMu85U.js.map
