import{a3 as n,aA as e,aB as c,aC as o,aD as i,aE as f}from"./index-0pWYEnpG.js";const r=n?`${n}/api/themes`:"";async function l(s=fetch){try{if(!r)return[...e];const a=await s(r);if(!a.ok)return[...e];const t=c(await a.json());return t.length?t:[...e]}catch{return[...e]}}function p(s,a){const t=o(a);t?i(s,t):f(s,a)}export{p as a,l as f};
//# sourceMappingURL=catalog-B5O2_gtx.js.map
