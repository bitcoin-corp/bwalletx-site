import{r as s}from"./index-BzS4xxnF.js";import{hG as r,hH as o}from"./main-C45FyLMf.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-vH67nkM1.js.map
