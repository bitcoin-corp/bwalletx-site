import{r as t}from"./index-BgdDy8zn.js";import{fetchPeopleTokens as l}from"./people-4koS1-48.js";const f=()=>{const[s,o]=t.useState(null);return t.useEffect(()=>{let e=!0;return l().then(r=>e&&o(r)),()=>{e=!1}},[]),s};export{f as u};
//# sourceMappingURL=usePeopleTokens-DP-sztvf.js.map
