import{r as s}from"./index-BgdDy8zn.js";import{ka as r,bx as a}from"./index-CuAsuQNM.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-TxwZH4l6.js.map
