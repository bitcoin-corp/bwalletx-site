const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CG1wUUQC.js","./index-CuAsuQNM.js","./crypto-BV2NSqmP.js","./index-BgdDy8zn.js","./index-B-ccsTng.css","./extensionMedia-Rm_l9uoo.js","./index-Pw7nwDBD.css"])))=>i.map(i=>d[i]);
import{aC as e,ai as t}from"./index-CuAsuQNM.js";import"./crypto-BV2NSqmP.js";import"./index-BgdDy8zn.js";import"./extensionMedia-Rm_l9uoo.js";const p=e("Share",{web:()=>t(()=>import("./web-CG1wUUQC.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{p as Share};
//# sourceMappingURL=index-CRwzRl-N.js.map
