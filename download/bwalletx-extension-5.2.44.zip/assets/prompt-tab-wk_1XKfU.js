import{r as d,j as e,b as Ht}from"./index-BgdDy8zn.js";import{o as Fe,bm as dt,bn as pt,bo as Vt}from"./crypto-BV2NSqmP.js";import{L as Z,S as oe,X as A,bS as L,hm as le,hn as U,bT as Gt,Z as Kt,bU as ae,s as Y,gg as ut,hk as Xt,hl as Yt,h9 as Jt,ha as Zt,hb as Qt,W as st,hf as es}from"./index-CuAsuQNM.js";import{o as xe,m as je,U as ts,Y as ke,F as Be,R as ft,S as ss,z as os,X as ns,G as mt,W as J,Z as rs,y as j,x as as,n as is,v as ls,_ as Ie,N as Oe,B as T,D as $,$ as cs,a0 as ot,a1 as ds,a2 as Ae,A as xt,E as nt,V as ve,L as ps,P as us,a3 as fs,C as rt,a4 as ms,l as xs,a5 as hs,d as ht}from"./reservedBaskets-DUslPNmF.js";import{a as gs,s as gt,p as ys}from"./approvalKind-CDKN61cx.js";import"./extensionMedia-Rm_l9uoo.js";import"./originKey-Dn2ka4Hc.js";const bs=t=>{const{request:s,onResponse:n}=t,{theme:o}=Z(),{handleSelect:i,hideMenu:r}=xe(),{addSnackbar:p}=je(),[u,a]=d.useState(!1),[f,h]=d.useState(""),{chromeStorageService:b}=oe(),{permissions:l}=s,[k,g]=d.useState(()=>l.protocols.map(()=>!0));d.useEffect(()=>{i("bsv"),r()},[i,r]);const c=()=>{const E=l.protocols.filter((R,F)=>k[F]);return E.length===0?{}:{protocols:E}},v=async()=>{a(!0),h("");try{const E=await le(b);if(!E.ok){h(E.message),a(!1);return}ke(s.originator),U({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:c()}),n()}catch(E){p(E instanceof Error?E.message:String(E),"error"),a(!1)}},N=async()=>{a(!0),U({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),n()},x=E=>g(R=>R.map((F,ce)=>ce===E?!F:F)),y=s.counterpartyLabel??`${s.counterparty.slice(0,8)}...${s.counterparty.slice(-8)}`;return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ts,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Counterparty Permission"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","wants to interact with a counterparty"]})]})]}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all font-mono",style:{color:o.color.global.contrast},children:y})]}),e.jsx(L,{when:!!l.description,children:e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Purpose"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:l.description})]})}),e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),l.protocols.map((E,R)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:R<l.protocols.length-1?"1px solid rgba(255,255,255,0.04)":"none"},children:[e.jsx("input",{type:"checkbox",checked:k[R],onChange:()=>x(R),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[E.protocolID?.[1]," (level ",E.protocolID?.[0],")"]}),E.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:E.description})]})]},`proto-${R}`))]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[f&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:f}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:u?.6:1},disabled:u,onClick:v,whileHover:{scale:u?1:1.02},whileTap:{scale:u?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[u&&e.jsx(Fe,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:u?.5:1},disabled:u,onClick:N,whileHover:{scale:u?1:1.02},whileTap:{scale:u?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},yt=[{protocolID:[2,"bmintx archive"],origins:["bmintx.com","www.bmintx.com"],label:"Your private archive (bMintX)",description:"bMintX wants to lock your imported posts with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose."},{protocolID:[2,"bvideox records"],origins:["bvideox.com","www.bvideox.com"],label:"Your video records (bVideoX)",description:"bVideoX wants to lock your video records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"video",countFrom:/(\d+) private video records?/i}},{protocolID:[2,"bjobsx records"],origins:["bjobsx.com","www.bjobsx.com"],label:"Your work records (bJobsX)",description:"bJobsX wants to lock your profile records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"profile record",countFrom:/(\d+) private profile records?/i}},{protocolID:[2,"bdrivex records"],origins:["bdrivex.com","www.bdrivex.com"],label:"Your file records (bDriveX)",description:"bDriveX wants to lock your file records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"file record",countFrom:/(\d+) private file records?/i}},{protocolID:[2,"bcalx records"],origins:["bcalx.com","www.bcalx.com"],label:"Your calendar records (bCalX)",description:"bCalX wants to lock your calendar records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"calendar record",countFrom:/(\d+) private (?:calendar )?records?/i}}],vs=t=>`${t[0]}:${t[1].trim().toLowerCase()}`;new Map(yt.map(t=>[vs(t.protocolID),t]));const ws={"2:3241645161d8":{label:"BRC-29 payment",description:"An application is requesting permission to derive payment addresses for a specific recipient."},...Object.fromEntries(yt.map(t=>[`${t.protocolID[0]}:${t.protocolID[1]}`,{label:t.label,description:t.description}]))},bt=t=>t?ws[`${t[0]}:${t[1]}`]:void 0,vt=t=>bt(t)?.label??t?.[1],js=t=>{switch(t){case 0:return"Level 0 · any app";case 1:return"Level 1 · same keys for any app using this protocol";case 2:return"Level 2 · same keys for any app using this protocol with this recipient";default:return`Level ${t??0}`}},wt=t=>`${t[0]}:${t[1].trim().toLowerCase()}`,ks=new Set([2532803679,1545534606,3968644154,2559579298,983045898,2744301556,111268922,3445661247,2334321181,4156441831,3583153857,2398265928,1065214202,2451633495,1587406450,3495424783,2196479044,3172368687,3977290595,2110695608,2486468533,3947228137,3114316294,3407865888,2095595255,927149303,1269930738,2919298931,2255687340,329407381,2945469548,2194069484,2746709595].map(t=>t>>>0)),Ns=[[2,"3241645161d8"]],Ss=t=>{let s=2166136261;for(const n of new TextEncoder().encode(wt(t)))s=Math.imul(s^n,16777619)>>>0;return s>>>0};new Set(Ns.map(wt));const Es=t=>Array.isArray(t)&&t.length===2&&typeof t[0]=="number"&&typeof t[1]=="string"?[t[0],t[1]]:null,at=t=>{const s=Es(t);return!!s&&ks.has(Ss(s))},Cs=t=>{const{request:s,onResponse:n}=t,{theme:o}=Z(),i=Be(),{handleSelect:r,hideMenu:p}=xe(),{addSnackbar:u}=je(),[a,f]=d.useState(!1),[h,b]=d.useState(""),{chromeStorageService:l}=oe(),k=l.getCurrentAccountObject().account?.pubKeys?.identityPubKey??"",{permissions:g}=s,[c,v]=d.useState(()=>(g.protocolPermissions??[]).map(()=>!1)),[N,x]=d.useState(()=>(g.basketAccess??[]).map(()=>!0)),[y,E]=d.useState(()=>(g.certificateAccess??[]).map(()=>!0)),[R,F]=d.useState(!0);d.useEffect(()=>{r("bsv"),p()},[r,p]);const ce=()=>{const w={},P=(g.protocolPermissions??[]).filter((de,K)=>c[K]&&!at(de.protocolID));P.length>0&&(w.protocolPermissions=P);const D=(g.basketAccess??[]).filter((de,K)=>N[K]);D.length>0&&(w.basketAccess=D);const B=(g.certificateAccess??[]).filter((de,K)=>y[K]);return B.length>0&&(w.certificateAccess=B),w},Ne=async()=>{f(!0),b("");try{const w=await le(l);if(!w.ok){b(w.message),f(!1);return}ke(s.originator),U({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:ce()}),n()}catch(w){u(w instanceof Error?w.message:String(w),"error"),f(!1)}},Se=async()=>{f(!0),U({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),n()},_e=w=>v(P=>P.map((D,B)=>B===w?!D:D)),Q=w=>x(P=>P.map((D,B)=>B===w?!D:D)),Ee=w=>E(P=>P.map((D,B)=>B===w?!D:D));return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ft,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Permission Request"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","is requesting the following permissions"]})]})]}),e.jsx(ss,{site:os(s.originator),account:k,style:{marginBottom:12}}),e.jsx(L,{when:!!g.description,children:e.jsx("p",{className:"text-xs mb-3 leading-relaxed",style:{color:o.color.global.gray},children:g.description})}),e.jsx(L,{when:ns,children:e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-3",style:{background:"rgba(247,144,9,0.08)",border:"1px solid rgba(247,144,9,0.2)"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.06},children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pb-1",style:{color:"#F79009"},children:"Spending Authorization"}),e.jsxs("label",{className:"flex items-start gap-3 py-1 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:R,onChange:()=>F(!R),className:"mt-0.5 accent-orange-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-semibold",style:{color:"#F79009"},children:"This app wants to spend up to"}),e.jsx(mt,{sats:g.spendingAuthorization?.amount??0,price:i,size:24,align:"left",color:"#F79009",mutedColor:o.color.global.gray}),g.spendingAuthorization?.description&&e.jsxs("span",{className:"text-xs mt-1 opacity-70",style:{color:o.color.global.contrast},children:["App says: “",g.spendingAuthorization.description,"”"]})]})]})]})}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-2 mb-5",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs(L,{when:!!g.protocolPermissions?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),g.protocolPermissions?.map((w,P)=>at(w.protocolID)?e.jsxs("p",{className:"text-xs py-2",style:{color:o.color.global.gray},children:["Refused: “",w.protocolID[1],"” is used only by bWalletX itself."]},`proto-${P}`):e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:c[P],onChange:()=>_e(P),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:["Let this app sign and encrypt with your keys for “",vt(w.protocolID),"”",w.counterparty?` (shared with ${w.counterparty.slice(0,10)}…)`:""]}),e.jsxs("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:["Any app that asks for this protocol gets the same keys (level ",w.protocolID[0],")."]}),w.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:w.description})]})]},`proto-${P}`))]}),e.jsxs(L,{when:!!g.basketAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Baskets"}),g.basketAccess?.map((w,P)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:N[P],onChange:()=>Q(P),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:w.basket}),w.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:w.description})]})]},`basket-${P}`))]}),e.jsxs(L,{when:!!g.certificateAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Certificates"}),g.certificateAccess?.map((w,P)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:y[P],onChange:()=>Ee(P),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:w.type}),e.jsxs("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:[w.description," — fields: ",w.fields.join(", ")]})]})]},`cert-${P}`))]})]}),e.jsxs("div",{className:"flex flex-col gap-3",children:[h&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:h}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:a?.6:1},disabled:a,onClick:Ne,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[a&&e.jsx(Fe,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:a?.5:1},disabled:a,onClick:Se,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},Ps=2e3;async function we(t,s=Ps){let n;try{return await Promise.race([t.catch(()=>{}),new Promise(o=>{n=setTimeout(()=>o(void 0),s)})])}catch{return}finally{n&&clearTimeout(n)}}function Rs(t,s){return t?.find(n=>n.startsWith(`${s}:`))?.slice(s.length+1)}async function Ts(t,s,n=[]){const o=t.ordfs;if(typeof o?.bulkMetadata!="function")return{state:"unverified"};const i=`${s}:-2`,r=await we(o.bulkMetadata([i])),p=r?.[i]??r?.[s]??Object.values(r??{}).find(f=>!!f?.contentType);if(!p?.contentType)return{state:"unverified"};const u={contentType:p.contentType,origin:p.origin,name:typeof p.map?.name=="string"?p.map.name:void 0},a=n.find(f=>f.includes("/"));return a&&a!==p.contentType?{state:"mismatch",note:`Content type is ${p.contentType}, not ${a}`,...u}:{state:"verified",...u}}async function Is(t,s,n){const o=t.opns;if(typeof o?.getOrigin!="function")return{state:"unverified"};const i=await we(o.getOrigin(s));return i?.outpoint?i.outpoint!==n?{state:"mismatch",note:`“${s}” currently resolves to a different output`}:{state:"verified"}:{state:"unverified"}}async function As(t,s,n,o=[]){const i=t.bsv21;if(typeof i?.getTokenDetails!="function")return{state:"unverified"};const r=await we(i.getTokenDetails(s,{fresh:!0}));if(!r)return{state:"unverified"};if(r.status?.is_active===!1)return{state:"mismatch",note:"Token is not active on the overlay"};const p=r.token?.sym;if(n&&p&&n.toLowerCase()!==p.toLowerCase())return{state:"mismatch",note:`Token symbol is ${p}, not ${n}`};if(o.length>0&&typeof i.getOutputStatus=="function"){const u=await we(i.getOutputStatus(s,o));if(!u)return{state:"unverified"};const a=u.filter(f=>f.state==="spent"||f.state==="unknown");if(a.length>0)return{state:"mismatch",note:a.length===1?"A spent token output is not valid on the overlay":`${a.length} spent token outputs are not valid on the overlay`};if(u.some(f=>f.state==="queued"))return{state:"unverified"}}return{state:"verified",...p?{name:p}:{}}}async function Ds(t,s,n,o,i){if(!t||!s)return{state:"unverified"};const r=s==="purchase"||s.endsWith(".purchase"),p=s==="token-transfer"||s.startsWith("bsv21.");if(!r&&!p)return{state:"unverified"};const u={kindOrIntent:s,hasOrdfs:!!t.ordfs,hasBulk:typeof t.ordfs?.bulkMetadata=="function",inputTagSets:n.map(a=>a.tags),outputTagSets:o.map(a=>a.tags)};try{const a=[...n.map(c=>c.tags),...o.map(c=>c.tags)],f=c=>a.flatMap(v=>v.filter(N=>N.startsWith(`${c}:`)).map(N=>N.slice(c.length+1))),h=c=>{for(const v of a){const N=Rs(v,c);if(N)return N}},b=h("bsv21");if(b||s==="bsv21.purchase"||s==="token-transfer"||s.startsWith("bsv21.")){if(!b)return{state:"unverified"};const v=n.filter(x=>x.basket?.includes("bsv21")||x.tags.some(y=>y.startsWith("bsv21:"))).map(x=>x.outpoint).filter(Boolean);let N=h("sym");for(const x of n)if(x.customInstructions)try{const y=JSON.parse(x.customInstructions).sym;if(typeof y=="string"&&y.trim()){N=y.trim();break}}catch{}return await As(t,b,N,v)}const l=h("name"),k=h("origin");if(u.name=l,u.origin=k,l&&k&&o.some(c=>c.basket?.includes("opns"))||s==="opns.purchase")return!l||!k?{state:"unverified"}:await Is(t,l,k);if(!k)return u.reason="no-origin-tag",globalThis.__lastVerify=u,{state:"unverified"};const g=await Ts(t,k,f("type"));if(u.verifyOrdinal=g,g.origin&&i)try{g.contentUrl=i(g.origin)}catch(c){u.contentUrlError=String(c)}return globalThis.__lastVerify=u,g}catch(a){return u.error=String(a),globalThis.__lastVerify=u,{state:"unverified"}}}function jt(t){if(!t||typeof t!="object")return!1;const s=t;return Array.isArray(s.panels)&&typeof s.title=="string"}var $s=`
.opp-root {
  --opp-bg: #ffffff;
  --opp-fg: #111827;
  --opp-muted: #6b7280;
  --opp-card-bg: #f7f8fa;
  --opp-card-border: #eceef2;
  --opp-accent: #E5A920;
  --opp-approve-bg: #E5A920;
  --opp-approve-fg: #ffffff;
  --opp-reject-bg: #ffffff;
  --opp-reject-fg: #111827;
  --opp-reject-border: #d1d5db;
  --opp-status-bg: #FFFBE6;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #ECFDF5;
  --opp-trust-ok-fg: #059669;
  --opp-trust-warn-bg: #FFFBEB;
  --opp-trust-warn-fg: #D97706;
  --opp-trust-bad-bg: #FEF2F2;
  --opp-trust-bad-fg: #DC2626;

  font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--opp-bg);
  color: var(--opp-fg);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 480px;
  min-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
}

.opp-bottom {
  margin-top: auto;
  display: flex;
  flex-direction: column;
}

.opp-root.opp-dark {
  --opp-bg: #0F1117;
  --opp-fg: #F9FAFB;
  --opp-muted: #9ca3af;
  --opp-card-bg: #1A1D27;
  --opp-card-border: #232636;
  --opp-reject-bg: #0F1117;
  --opp-reject-fg: #F9FAFB;
  --opp-reject-border: #2D3142;
  --opp-status-bg: #2A2408;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #0A2E1F;
  --opp-trust-ok-fg: #34D399;
  --opp-trust-warn-bg: #2A2008;
  --opp-trust-warn-fg: #FBBF24;
  --opp-trust-bad-bg: #2A1215;
  --opp-trust-bad-fg: #F87171;
}

.opp-body {
  padding: 24px 20px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
}

.opp-coin {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
}

.opp-title {
  font-size: 16px;
  font-weight: 700;
  margin: 0;
  text-align: center;
}

.opp-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  margin: 0;
  text-align: center;
  line-height: 1.4;
}

.opp-status {
  background: var(--opp-status-bg);
  color: var(--opp-status-fg);
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
  margin-top: 4px;
  border: 1px solid var(--opp-card-border);
}

.opp-card {
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px;
  padding: 16px;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.opp-featured {
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px 8px;
  padding: 16px;
}

/* Subtle danger chrome for burn / destructive token ops */
.opp-featured-danger {
  border-color: rgba(220, 38, 38, 0.45);
  background: color-mix(in srgb, var(--opp-card-bg) 88%, #7f1d1d 12%);
}

.opp-featured-danger .opp-featured-title {
  color: #f87171;
}

.opp-featured-danger .opp-featured-image,
.opp-featured-danger .opp-featured-placeholder {
  border: 1px solid rgba(220, 38, 38, 0.35);
  background: rgba(127, 29, 29, 0.25);
  color: #fca5a5;
}

.opp-dark .opp-featured-danger {
  border-color: rgba(248, 113, 113, 0.4);
  background: color-mix(in srgb, var(--opp-card-bg) 85%, #450a0a 15%);
}

.opp-preview-pair {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.opp-preview-arrow {
  color: var(--opp-muted);
  font-size: 14px;
  line-height: 1;
}

.opp-preview-pair .opp-featured-image {
  width: 64px;
  height: 64px;
}

.opp-featured-image {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-featured-image-token {
  width: 48px;
  height: 48px;
  border-radius: 999px;
}

.opp-featured-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--opp-muted);
  font-size: 18px;
}

.opp-preview-opns {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
}

.opp-preview-opns-avatar {
  width: 36px;
  height: 36px;
  border-radius: 999px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-preview-opns-name {
  font-size: 11px;
  font-weight: 600;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  color: var(--opp-fg, inherit);
}

.opp-preview-text {
  margin: 0;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
  font-size: 9px;
  line-height: 1.25;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  color: var(--opp-muted);
}

.opp-preview-json {
  white-space: pre;
  overflow: auto;
}

.opp-preview-frame {
  border: 0;
  padding: 0;
  overflow: hidden;
  background: #fff;
  pointer-events: none;
}

.opp-preview-value {
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  background: rgba(229, 169, 32, 0.12);
  border: 1px solid rgba(229, 169, 32, 0.35);
  color: var(--opp-fg, inherit);
}

.opp-preview-value-icon {
  width: 32px;
  height: 32px;
  color: #E5A920;
}

/* Amount subtitles must never ellipsis — full sat counts are the point. */
.opp-featured-subtitle-text.opp-amount {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-variant-numeric: tabular-nums;
  white-space: normal;
  overflow: visible;
  text-overflow: unset;
  word-break: keep-all;
}

.opp-featured-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  flex: 1;
}

.opp-featured-title {
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.opp-featured-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.opp-featured-subtitle-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
}

.opp-featured-meta-line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  color: var(--opp-muted);
}

.opp-featured-meta-line-bare {
  align-items: center;
}

.opp-featured-meta-key {
  flex-shrink: 0;
  opacity: 0.75;
  min-width: 2.5em;
}

.opp-featured-meta-value {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  flex: 1;
}

.opp-featured-meta-value-mono {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 11px;
}

.opp-trust-wrap {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0 20px 8px;
}

.opp-trust {
  display: inline-flex;
  align-self: flex-start;
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 600;
}

.opp-trust-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-trust-note {
  padding: 10px;
  border-radius: 8px;
  font-size: 11px;
  line-height: 1.35;
}

.opp-trust-note-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-note-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-note-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.opp-row-key {
  color: var(--opp-muted);
  flex-shrink: 0;
}

.opp-row-value-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 70%;
  justify-content: flex-end;
}

.opp-row-value {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 12px;
  font-weight: 500;
  text-align: right;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.opp-copy {
  flex-shrink: 0;
  width: 22px;
  height: 22px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  border: 1px solid var(--opp-reject-border);
  background: var(--opp-bg);
  color: var(--opp-fg);
  cursor: pointer;
}

.opp-copy:hover {
  border-color: var(--opp-accent);
  color: var(--opp-accent);
}

.opp-fee-note {
  font-size: 11px;
  color: var(--opp-muted);
  line-height: 1.3;
  margin-top: -4px;
}

.opp-actions {
  display: flex;
  gap: 12px;
  padding: 20px 20px 12px;
}

.opp-button {
  flex: 1;
  padding: 0 16px;
  height: 48px;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid transparent;
  transition: opacity 120ms ease;
}

.opp-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.opp-button-reject {
  background: var(--opp-reject-bg);
  color: var(--opp-reject-fg);
  border-color: var(--opp-reject-border);
}

.opp-button-approve {
  background: var(--opp-approve-bg);
  color: var(--opp-approve-fg);
}

.opp-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 20px 16px;
  font-size: 11px;
  font-weight: 500;
  color: var(--opp-muted);
}
`;function Ls({request:t,onApprove:s,onReject:n,theme:o="auto",services:i}){const r=qs(o),p=Os(t),[u,a]=d.useState(!1),[f,h]=d.useState(),b=t.kind==="transaction"&&jt(t.payload)?t.payload:void 0;d.useEffect(()=>{if(!i||!b?.trust||!b.verify)return;let c=!0;const v=i.ordfs?.getContentUrl?.bind(i.ordfs);return Ds(i,b.verify.kind,b.verify.inputs,b.verify.outputs,v).then(N=>{c&&N&&h(N)}).catch(()=>{}),()=>{c=!1}},[i,b]);const l=f?Fs(p,f):p,k=c=>()=>{if(!u){a(!0);try{c==="approve"?s():n()}finally{a(!1)}}};d.useEffect(()=>{const c=v=>{u||(v.key==="Escape"?n():v.key==="Enter"&&s())};return window.addEventListener("keydown",c),()=>window.removeEventListener("keydown",c)},[s,n,u]);const g=`opp-root${r==="dark"?" opp-dark":""}`;return e.jsxs("div",{className:g,children:[e.jsx("style",{children:$s}),e.jsxs("div",{className:"opp-body",children:[e.jsxs("svg",{className:"opp-coin",viewBox:"0 0 100 100","aria-label":"1Sat Ordinals",children:[e.jsx("circle",{cx:"50",cy:"50",r:"50",fill:"#222"}),e.jsx("circle",{cx:"50",cy:"50",r:"40",fill:"#fff"}),e.jsx("circle",{cx:"50",cy:"50",r:"32",fill:"#E5A920"}),e.jsx("rect",{x:"47",y:"28",width:"6",height:"28",rx:"3",fill:"#fff"})]}),e.jsx("h2",{className:"opp-title",children:l.title}),e.jsx("p",{className:"opp-subtitle",children:l.subtitle}),e.jsx("div",{className:"opp-status",children:"Awaiting Approval"})]}),l.panels.map((c,v)=>{const N=c.variant??"ordinal",x=["opp-featured"];return N==="token"&&x.push("opp-featured-token"),N==="value"&&x.push("opp-featured-value"),c.tone==="danger"&&x.push("opp-featured-danger"),e.jsxs("div",{className:x.join(" "),children:[c.prior?e.jsxs("div",{className:"opp-preview-pair","aria-label":"Previous and new inscription",children:[e.jsx(De,{panel:{...c,previewKind:c.prior.previewKind,imageUrl:c.prior.imageUrl,contentUrl:c.prior.contentUrl,previewText:c.prior.previewText,prior:void 0}}),e.jsx("span",{className:"opp-preview-arrow","aria-hidden":!0,children:"→"}),e.jsx(De,{panel:c})]}):e.jsx(De,{panel:c}),e.jsxs("div",{className:"opp-featured-meta",children:[e.jsx("div",{className:"opp-featured-title",children:c.title}),c.subtitle&&e.jsxs("div",{className:"opp-featured-subtitle",children:[e.jsx("span",{className:c.amountSats!=null?"opp-featured-subtitle-text opp-amount":"opp-featured-subtitle-text",children:c.subtitle}),c.subtitleCopy&&e.jsx($e,{text:c.subtitleCopy})]}),(c.meta??[]).map(y=>e.jsxs("div",{className:`opp-featured-meta-line${y.key?"":" opp-featured-meta-line-bare"}`,children:[y.key?e.jsx("span",{className:"opp-featured-meta-key",children:y.key}):null,e.jsx("span",{className:`opp-featured-meta-value${y.key?"":" opp-featured-meta-value-mono"}`,title:y.copyValue??y.value,children:y.value}),y.copyValue&&e.jsx($e,{text:y.copyValue})]},`${y.key}:${y.value}`))]})]},`panel-${v}-${c.title}`)}),l.trust&&e.jsxs("div",{className:"opp-trust-wrap",children:[e.jsx("span",{className:`opp-trust opp-trust-${l.trust.state}`,children:Us(l.trust.state)}),l.trust.note&&e.jsx("div",{className:`opp-trust-note opp-trust-note-${l.trust.state}`,children:l.trust.note})]}),(l.rows.length>0||l.indexerFee||l.funding)&&e.jsxs("div",{className:"opp-card",children:[l.rows.map(c=>e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:c.key}),e.jsxs("span",{className:"opp-row-value-wrap",children:[e.jsx("span",{className:"opp-row-value",title:c.copyValue??c.value,children:c.value}),c.copyValue&&e.jsx($e,{text:c.copyValue})]})]},`${c.key}:${c.value}`)),l.indexerFee&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"1Sat Overlay Fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[it(l.indexerFee.sats)," sats"]})]}),l.funding?.networkFeeSats!=null&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"Network fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[it(l.funding.networkFeeSats)," sats"]})]}),l.funding?.note&&e.jsx("div",{className:"opp-fee-note",children:l.funding.note})]}),e.jsxs("div",{className:"opp-bottom",children:[e.jsxs("div",{className:"opp-actions",children:[e.jsx("button",{type:"button",className:"opp-button opp-button-reject",onClick:k("reject"),disabled:u,children:"Reject"}),e.jsx("button",{type:"button",className:"opp-button opp-button-approve",onClick:k("approve"),disabled:u,children:"Approve"})]}),e.jsx("div",{className:"opp-footer",children:e.jsx("span",{children:"Secured by 1Sat Ordinals"})})]})]})}function Os(t){if(t.kind==="transaction"&&jt(t.payload))return{title:t.payload.title,subtitle:t.payload.subtitle,panels:t.payload.panels,rows:t.payload.rows,trust:t.payload.trust,indexerFee:t.payload.indexerFee,funding:t.payload.funding};if(t.kind==="basketAccess"){const s=t.payload.baskets??[],n=s.length>0&&s.every(r=>r.scope||r.basket.startsWith("p ")),o=s.filter(r=>r.imageUrl||r.name||r.value).map(r=>({title:r.scope==="collection"?r.name?`Collection · ${r.name}`:"Collection":r.scope?r.scope:"Basket",subtitle:r.value?r.value.length>24?`${r.value.slice(0,10)}…${r.value.slice(-10)}`:r.value:r.basket,subtitleCopy:r.value,...r.imageUrl&&{previewKind:"image",contentUrl:r.imageUrl,imageUrl:r.imageUrl},tone:"default"})),i=s.flatMap(r=>r.scope==="collection"?r.description?[{key:"Access",value:r.description}]:[]:[{key:r.basket,value:r.description??"List, insert, and remove outputs"}]);return{title:n?s.length===1?s[0].scope==="collection"?"Grant Collection View":"Grant Item View":`Grant View (${s.length})`:s.length===1?"Grant Basket Access":`Grant Access to ${s.length} Baskets`,subtitle:n?`${be(t.originator)} wants to view items in your wallet`:`${be(t.originator)} wants to read and write 1Sat baskets`,panels:o,rows:i}}return t.kind==="protocol"?{title:"Protocol Access",subtitle:`${be(t.originator)} wants protocol access`,panels:[],rows:[{key:"Detail",value:t.summary||"Protocol request"}]}:{title:"Signature Request",subtitle:`${be(t.originator)} wants a signature`,panels:[],rows:[{key:"Detail",value:t.summary||"Signature request"}]}}function Fs(t,s){const n=t.panels.map((o,i)=>{if(i!==0)return o;const r=o.previewKind==="opns",p=s.contentType?Bs(s.contentType):void 0,u=r?"opns":p&&p!=="none"?p:o.previewKind,a=s.contentUrl??o.contentUrl??o.imageUrl;let f=o.subtitle;if(s.name&&!r)if(!f)f=s.name;else{const h=f.trim().split(/\s+/);h.length>=2&&(h[h.length-1]=s.name,f=h.join(" "))}return{...o,previewKind:u,...f?{subtitle:f}:{},...r?{...s.contentUrl&&!o.imageUrl?{imageUrl:s.contentUrl}:o.imageUrl?{imageUrl:o.imageUrl}:{}}:u==="image"?{imageUrl:a,contentUrl:a}:a?{contentUrl:a,imageUrl:void 0}:{}}});return{...t,panels:n,trust:{state:s.state,note:s.note}}}function Bs(t){const s=t.toLowerCase();return s==="image/svg+xml"||s==="svg"||s.endsWith("+svg")?"svg":s.startsWith("image/")?"image":s.includes("json")?"json":s.includes("html")||s==="application/xhtml+xml"?"html":s.startsWith("text/")?"text":"none"}function Ms(t){return`${t.toLocaleString("en-US")} sats`}function it(t){return t.toLocaleString("en-US")}function Us(t){return t==="verified"?"Verified":t==="mismatch"?"Mismatch":"Unverified"}function De({panel:t}){const s=t.variant??"ordinal",n=s==="token"?"opp-featured-image opp-featured-image-token":s==="value"?"opp-featured-image opp-preview-value":"opp-featured-image",o=t.previewKind??(t.imageUrl?"image":"none"),i=t.contentUrl??t.imageUrl,[r,p]=d.useState(!1);if(s==="value"){const u=t.valueIcon??"pay";return e.jsx("div",{className:n,title:t.amountSats!=null?Ms(t.amountSats):void 0,"aria-hidden":!0,children:e.jsx(zs,{kind:u})})}if(o==="opns"){const u=!!t.imageUrl&&!r;return e.jsxs("div",{className:`${n} opp-preview-opns`,"aria-hidden":!t.opnsHero,children:[u?e.jsx("img",{className:"opp-preview-opns-avatar",src:t.imageUrl,alt:"",onError:()=>p(!0)}):e.jsx("div",{className:"opp-preview-opns-avatar opp-featured-placeholder",children:"◈"}),e.jsx("span",{className:"opp-preview-opns-name",title:t.opnsHero,children:t.opnsHero??"OpNS"})]})}return o==="image"&&t.imageUrl&&!r?e.jsx("img",{className:n,src:t.imageUrl,alt:t.title,onError:()=>p(!0)}):o==="image"&&r?e.jsx("div",{className:`${n} opp-featured-placeholder`,"aria-hidden":!0,children:"▭"}):(o==="text"||o==="json"||o==="html")&&t.previewText?e.jsx("pre",{className:`${n} opp-preview-text${o==="json"?" opp-preview-json":""}`,children:t.previewText}):(o==="text"||o==="json")&&i?e.jsx(Ws,{url:i,kind:o,className:n}):(o==="html"||o==="svg")&&i?e.jsx("iframe",{className:`${n} opp-preview-frame`,src:i,title:`${t.title} preview`,sandbox:"",referrerPolicy:"no-referrer"}):e.jsx("div",{className:`${n} opp-featured-placeholder`,"aria-hidden":!0,children:s==="token"?"◎":_s(o)})}function _s(t){return t==="text"||t==="json"?"¶":t==="html"||t==="svg"?"⌂":"▭"}function zs({kind:t}){return t==="lock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V8a4 4 0 018 0v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):t==="unlock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V7.5A4 4 0 0116 7",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("path",{d:"M16 4.5v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"9",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M12 7v10M9 10.5c0-1.4 1.3-2.5 3-2.5s3 1.1 3 2.5-1.3 2.5-3 2.5-3 1.1-3 2.5 1.3 2.5 3 2.5 3-1.1 3-2.5",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})}function Ws({url:t,kind:s,className:n}){const[o,i]=d.useState(null),[r,p]=d.useState(!1);return d.useEffect(()=>{let u=!1;return i(null),p(!1),fetch(t).then(async a=>{if(!a.ok)throw new Error(String(a.status));const f=await a.text();if(!u){if(s==="json")try{i(JSON.stringify(JSON.parse(f),null,2));return}catch{}i(f.slice(0,800))}}).catch(()=>{u||p(!0)}),()=>{u=!0}},[t,s]),r?e.jsx("div",{className:`${n} opp-featured-placeholder`,"aria-hidden":!0,children:"¶"}):e.jsx("pre",{className:`${n} opp-preview-text${s==="json"?" opp-preview-json":""}`,children:o??"…"})}function $e({text:t}){const[s,n]=d.useState(!1),o=()=>{navigator.clipboard?.writeText(t).then(()=>{n(!0),window.setTimeout(()=>n(!1),1200)})};return e.jsx("button",{type:"button",className:"opp-copy",onClick:o,"aria-label":s?"Copied":"Copy full value",title:s?"Copied":"Copy",children:s?e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:e.jsx("path",{d:"M5 13l4 4L19 7",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round"})}):e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"9",y:"9",width:"11",height:"11",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M5 15V5a2 2 0 012-2h10",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})})}function qs(t){const[s,n]=d.useState(()=>t==="auto"?Hs():t);return d.useEffect(()=>{if(t!=="auto"){n(t);return}const o=window.matchMedia("(prefers-color-scheme: dark)"),i=()=>n(o.matches?"dark":"light");return i(),o.addEventListener("change",i),()=>o.removeEventListener("change",i)},[t]),s}function Hs(){return typeof window>"u"||!window.matchMedia?"light":window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function be(t){try{return new URL(t.includes("://")?t:`https://${t}`).host||t}catch{return t.length<=32?t:`${t.slice(0,14)}…${t.slice(-12)}`}}const Vs=({request:t,onResponse:s})=>{const{theme:n}=Z(),{handleSelect:o,hideMenu:i}=xe(),{apiContext:r,chromeStorageService:p}=oe(),u=r?.services;d.useEffect(()=>{o("bsv"),i()},[o,i]);const[a,f]=d.useState(""),h=d.useRef(!1),b=async g=>{if(!h.current){if(h.current=!0,g){f("");const c=await le(p);if(!c.ok){f(c.message),h.current=!1;return}}U({action:"ONE_SAT_PERMISSION_RESPONSE",requestID:t.requestID,approved:g}),s()}},k=n.color.global.walletBackground.toLowerCase()==="#000000"||/^#[01]/.test(n.color.global.walletBackground)?"dark":"light";return e.jsxs("div",{style:{width:"100%",height:"100%",overflowY:"auto",display:"flex",flexDirection:"column",alignItems:"stretch",justifyContent:"center"},children:[a&&e.jsx("p",{className:"text-xs text-center m-0 pt-2",style:{color:"#ef4444"},children:a}),e.jsx(Ls,{request:t.request,onApprove:()=>{b(!0)},onReject:()=>{b(!1)},theme:k,services:u})]})},Gs=t=>{switch(t){case"protocol":return"Protocol Permission";case"basket":return"Basket Access";case"certificate":return"Certificate Access";case"spending":return"Spending Authorization";default:return"Permission Request"}},Ks=t=>{switch(t.type){case"protocol":{const s=bt(t.protocolID);return s?s.description:`An application is requesting permission to use protocol "${t.protocolID?.[1]||"unknown"}" with security level ${t.protocolID?.[0]||0}.`}case"basket":return`An application is requesting access to basket "${t.basket||"unknown"}".`;case"certificate":return"An application is requesting access to certificate data.";case"spending":return`An application is requesting authorization to spend ${t.spending?.satoshis||0} satoshis.`;default:return"An application is requesting a permission."}},Xs=t=>{const{request:s,onResponse:n}=t,{theme:o}=Z(),i=Be(),{handleSelect:r,hideMenu:p}=xe(),{addSnackbar:u}=je(),[a,f]=d.useState(!1),[h,b]=d.useState(""),{chromeStorageService:l}=oe();d.useEffect(()=>{r("bsv"),p()},[r,p]);const k=async()=>{f(!0),b("");try{const c=await le(l);if(!c.ok){b(c.message),f(!1);return}ke(s.originator),U({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!0}),n()}catch(c){const v=c instanceof Error?c.message:String(c);u(v,"error"),f(!1)}},g=async()=>{f(!0),U({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!1}),n()};return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ft,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:Gs(s.type)}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:Ks(s)})]})]}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"12rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Origin"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.displayOriginator||s.originator})]}),e.jsxs(L,{when:s.type==="protocol"&&!!s.protocolID,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Protocol"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:vt(s.protocolID)})]}),e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.counterparty?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Security"}),e.jsx("span",{className:"text-xs",style:{color:o.color.global.contrast},children:js(s.protocolID?.[0])})]}),e.jsx(L,{when:!!s.counterparty,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.counterparty})]})})]}),e.jsx(L,{when:s.type==="basket"&&!!s.basket,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Basket"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.basket})]})}),e.jsxs(L,{when:s.type==="certificate"&&!!s.certificate,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Cert Type"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.certType})]}),e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Fields"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.fields.join(", ")})]})]}),e.jsxs(L,{when:s.type==="spending"&&!!s.spending,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.spending?.lineItems?.length?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Amount"}),e.jsx(mt,{sats:s.spending?.satoshis||0,price:i,size:24,align:"left",color:"var(--bw-accent-hi)",mutedColor:o.color.global.gray})]}),e.jsx(L,{when:!!s.spending?.lineItems?.length,children:s.spending?.lineItems?.map((c,v)=>e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:v<(s.spending?.lineItems?.length??0)-1?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:c.type}),e.jsxs("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:[c.description," (",J(c.satoshis,i).main," ·"," ",J(c.satoshis,i).sub,")"]})]},v))})]}),e.jsx(L,{when:!!s.reason,children:e.jsxs("div",{className:"flex flex-row py-2",style:{borderTop:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Reason"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.reason})]})})]}),e.jsx(L,{when:!!s.privileged,children:e.jsxs(A.div,{className:"flex items-start gap-2 rounded-xl px-3 py-2.5 mb-4",style:{background:"rgba(245,166,35,0.08)",border:"1px solid rgba(245,166,35,0.15)"},initial:{opacity:0},animate:{opacity:1},transition:{delay:.12},children:[e.jsx(Gt,{size:14,className:"mt-0.5 flex-shrink-0",style:{color:"#f5a623"}}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:"#f5a623"},children:"This is a privileged operation"})]})}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[h&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:h}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:a?.6:1},disabled:a,onClick:k,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[a&&e.jsx(Fe,{size:14,className:"animate-spin"}),"Allow"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:a?.5:1},disabled:a,onClick:g,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny"})]})]})},Ys=({request:t,onResponse:s})=>{const{theme:n}=Z(),{chromeStorageService:o}=oe(),[i,r]=d.useState(""),[p,u]=d.useState(!1),a=async b=>{if(!p){if(u(!0),r(""),b){const l=await le(o);if(!l.ok){r(l.message),u(!1);return}}U({action:"USB_CHECK_RESPONSE",requestID:t.requestID,ok:b}),s()}},f=n.color.global.gray,h=n.color.global.contrast;return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(Kt,{size:40,style:{color:h}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:h},children:"Confirm your USB key"}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:f,maxWidth:"18rem"},children:[t.originator?`${t.originator} is asking bWallet to ${t.reason}.`:`A site is asking bWallet to ${t.reason}.`," ","Insert your USB key, then confirm."]}),i&&e.jsx("p",{className:"m-0 text-xs",style:{color:"#ef4444"},children:i}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(ae,{theme:n,type:"primary",label:"Confirm USB key",disabled:p,onClick:()=>{a(!0)}}),e.jsx(ae,{theme:n,type:"secondary-outline",label:"Cancel",disabled:p,onClick:()=>{a(!1)}})]})]})},Js=t=>{const s=t.map(o=>o.requestID).sort().join(`
`);let n=2166136261;for(let o=0;o<s.length;o++)n^=s.charCodeAt(o),n=Math.imul(n,16777619)>>>0;return`${t.length}:${n.toString(16)}`},Zs=5,Qs=/e-?mail|phone|mobile|kyc|passport|licen[cs]e|birth|dob|address|ssn|national|tax|id_?number/i,ie=t=>String(t.protocolID?.[1]??"unknown"),kt=t=>Number(t.protocolID?.[0]??0),Nt=t=>!!(t.privileged||t.type==="certificate"&&(t.certificate?.fields??[]).some(s=>Qs.test(s))),Me=t=>t.type==="protocol"&&!t.privileged&&t.protocolID?.[1]==="identity key retrieval"&&(t.counterparty===void 0||t.counterparty==="self"),eo=/\b(auth|authentication|sign[- ]?in|login|log[- ]?in)\b/i,St=t=>t.type==="protocol"&&!t.privileged&&(t.counterparty==="anyone"||Me(t)||eo.test(ie(t))&&(t.counterparty===void 0||t.counterparty==="self"||t.counterparty==="anyone")),to=[[/agent history/i,"Ask b chats"],[/\b(chat|message)s?\b/i,"chats"],[/\bnotes?\b/i,"notes"],[/\b(history|private|backup|vault|encrypt)/i,"data"]],Et=t=>{if(t.type!=="protocol"||t.privileged||t.counterparty!=="self"||St(t))return;const s=ie(t);return to.find(([n])=>n.test(s))?.[1]},so="bap",oo=[1,"sigma"],Ct=t=>t.type==="protocol"&&!t.privileged&&ie(t).toLowerCase()===oo[1],Pt=t=>t.type==="basket"&&t.basket===so,lt=t=>{switch(t.type){case"protocol":{if(Me(t))return"See your public identity (the key that names you)";if(t.counterparty==="anyone")return"Prove it's you (a signature anyone can check)";if(Ct(t))return"Sign your posts and likes as you";const s=Et(t);return s?`Use keys from your wallet for your ${s}`:kt(t)===2&&t.counterparty&&t.counterparty!=="self"?`Sign and encrypt with your "${ie(t)}" keys, shared with one named person or service`:`Sign and encrypt anything with your "${ie(t)}" keys`}case"basket":return Pt(t)?"Use your public profile (name and picture) on its posts":"Keep its tickets and tokens in your wallet";case"certificate":{const s=t.certificate?.fields??[];return s.length?`See your certificate details (${s.join(", ")})`:"See your certificates"}default:return"Spend from your wallet"}},Le=t=>{const s=[];switch(t.type){case"protocol":s.push(`protocol "${ie(t)}" level ${kt(t)}`),t.counterparty&&s.push(`counterparty ${t.counterparty}`);break;case"basket":s.push(`basket "${t.basket??""}"`);break;case"certificate":s.push(`certificate ${t.certificate?.certType??""}`,`verifier ${t.certificate?.verifier??""}`);break;case"spending":s.push(`${t.spending?.satoshis??0} sats`),t.labels?.length&&s.push(`labels: ${t.labels.join(", ")}`);break}return t.privileged&&s.push("privileged"),t.reason&&s.push(`reason: ${t.reason}`),s.join(" · ")},no=t=>{const s=[];let n;for(const r of t.items){if(r.type==="spending"){const a=r.spending?.satoshis??0;!n&&!r.addedLive?n={requestID:r.requestID,satoshis:a,description:r.spending?.lineItems?.find(f=>f.description)?.description??r.reason,detail:Le(r),...r.labels?.length?{labels:[...r.labels]}:{}}:s.push({requestID:r.requestID,text:`${r.addedLive?"New: pay":"Also pay"} ${a.toLocaleString()} sats`,detail:Le(r),risky:!0,checked:!1,...r.addedLive?{isNew:!0}:{}});continue}const p=Nt(r),u=!p&&!r.addedLive&&(r.type!=="protocol"||r.counterparty==="anyone"||Me(r));s.push({requestID:r.requestID,text:r.addedLive?`New: ${lt(r)}`:lt(r),...r.addedLive?{isNew:!0}:{},detail:Le(r),risky:p,checked:u,signIn:St(r),privateLabel:Et(r)})}const o=n?s.length?"connectAndPay":"pay":"connect",i=t.items.some(Ct)||t.items.some(Pt);return{originator:t.originator,lines:s,payment:n,mode:o,...i?{purpose:"post"}:{}}},ro=(t,s,n)=>({faceTicks:new Set(t.lines.filter(o=>s||o.isNew).map(o=>o.requestID)),hidden:new Set(n?t.lines.filter(o=>!n.has(o.requestID)).map(o=>o.requestID):[])}),ao=(t,s)=>s?.hidden?.size?t.filter(n=>!s.hidden.has(n.requestID)):t,io=(t,s,n,o,i={})=>{const r={};for(const p of t.lines){if(!o&&i.hidden?.has(p.requestID))continue;const u=o||!!i.faceTicks?.has(p.requestID);if(s&&p.isNew&&n[p.requestID]===void 0)continue;const a=n[p.requestID]??(p.isNew?!1:p.checked||!p.risky&&!u);r[p.requestID]=s&&a}return t.payment&&(r[t.payment.requestID]=s),r},lo=(t,s,n,o,i={})=>({decisions:io(t,s==="allow",n,o,i),block:s==="block",mayStore:s==="allow"}),co=t=>Nt(t)||t.type==="protocol"&&t.counterparty==="anyone"?!1:t.type==="basket"?!!t.basket&&!rs(t.basket):!1,po=t=>t.items.some(s=>co(s)),uo=[.25,1,5],fo=1,me=t=>t<1?`$${t.toFixed(2)}`:Number.isInteger(t)?`$${t}`:`$${t.toFixed(2)}`,Rt=t=>{const s=t.allowNone?[0,...t.presetsUsd]:[...t.presetsUsd];return e.jsx("div",{className:"flex flex-wrap",style:{gap:8},role:"radiogroup","aria-label":"Envelope amount",children:s.map(n=>{const o=t.value===n;return e.jsx("button",{type:"button",role:"radio","aria-checked":o,disabled:t.disabled,onClick:()=>t.onChange(n),style:{minHeight:44,padding:"0 16px",borderRadius:22,border:`1.5px solid ${o?j.gold:j.chip}`,background:o?j.gold:j.chip,color:o?j.bg:j.ink,fontSize:n?16:14,fontWeight:700,cursor:"pointer"},children:n?me(n):"No envelope"},n)})})},mo=3e3,xo=t=>{const{request:s,onResponse:n,armed:o=!0}=t,{handleSelect:i,hideMenu:r}=xe(),{addSnackbar:p}=je(),{chromeStorageService:u}=oe(),a=u.getCurrentAccountObject().account,f=as(a?.addresses?.identityAddress,a?.name??"",a?.settings?.socialProfile?.displayName??"",!1),h=is(f.displayName,f.paymail,f.handle).tag,b=ls(a?.pubKeys?.identityPubKey),l=d.useMemo(()=>no(s),[s]),[k,g]=d.useState({}),[c,v]=d.useState(!1),N=d.useRef(s.items.length);d.useEffect(()=>{if(s.items.length===N.current)return;N.current=s.items.length,v(!0);const m=setTimeout(()=>v(!1),1e3);return()=>clearTimeout(m)},[s.items.length]);const x=d.useRef(!1),y=()=>{x.current||(x.current=!0,Y({action:"BUNDLE_SHEET_FREEZE",bundleID:s.bundleID}).catch(()=>{}))},E=(m,C)=>k[m]??C,[R,F]=d.useState(),[ce,Ne]=d.useState(Zs),[Se,_e]=d.useState(!0),[Q,Ee]=d.useState(0),[w,P]=d.useState(!0),D=d.useMemo(()=>po(s),[s]),[B,de]=d.useState(!0),[K,It]=d.useState(!1),[ze,At]=d.useState(!1),[We,Ce]=d.useState(!1),[Dt,qe]=d.useState("");d.useEffect(()=>{i("bsv"),r()},[i,r]),d.useEffect(()=>{Y({action:"GET_BUNDLE_ALLOWANCE",originator:s.originator}).then(m=>{!m?.success||!m.data||(F(m.data),Ne(m.data.defaultUsd))}).catch(()=>{})},[s.originator]);const _=s.mint&&l.payment&&l.lines.every(m=>!m.risky)?s.mint:void 0,He=!1,pe=!_&&l.payment&&R?.usdPerBsv?R.envelope:void 0,Ve=!!pe?.offer,he=Be(R?.usdPerBsv),ee=l.payment?J(l.payment.satoshis,he):void 0,ge=async m=>{const C=m==="allow";Ce(!0),qe("");try{if(C){const G=await le(u);if(!G.ok){qe(G.message),Ce(!1);return}}C&&ke(s.originator);const S=lo(l,m,k,ze,Pe),I=await Y({action:"BUNDLE_PERMISSION_RESPONSE",seenHash:Mt(m),bundleID:s.bundleID,decisions:S.decisions,allowanceUsd:S.mayStore&&He&&Se?ce:0,envelopeUsd:S.mayStore&&Ve?Q:0,remember:S.mayStore&&w,trustSite:!_&&S.mayStore&&w&&D&&B,block:S.block});I&&I.success===!1&&I.error&&(p(I.error,"error"),await new Promise(G=>setTimeout(G,mo))),n()}catch(S){p(S instanceof Error?S.message:String(S),"error"),Ce(!1)}},O=gs(l),te=gt(s.originator),$t=l.lines.length+(l.payment?1:0)>1,ne=l.payment?Ie(l.payment.satoshis,he):"",Lt=0,Ge=s.items.some(m=>m.reconnect),Ot=Ge?"Reconnect":_?`${_.title.split(" ")[0]} · ${ne}`:O==="post"?l.payment?`Allow & pay ${ne}`:"Allow posting":O==="private"?"Allow":O==="signin"?"Sign in":O==="pay"?l.mode==="connectAndPay"?`Connect & pay ${ne}`:`Pay ${ne}`:$t?"Allow all":"Connect",ue=We||!o||c,M=O==="careful",Ke=l.lines.filter(m=>m.risky),Xe=l.lines.filter(m=>m.isNew&&!(M&&m.risky)),[Ft,Bt]=d.useState(()=>new Set),Ye=d.useRef(null);d.useEffect(()=>{const m=Ye.current,C=m?.closest("[data-approval-scroll]");if(!M||!m||!C)return;const S=()=>{const G=C.querySelector('[data-testid="approval-choices"]'),Wt=Math.max(C.getBoundingClientRect().top,0),qt=Math.min(G?G.getBoundingClientRect().top:window.innerHeight,window.innerHeight),Te=[];C.querySelectorAll("[data-line-id]").forEach(re=>{const fe=re.getBoundingClientRect();fe.height>0&&fe.top>=Wt-1&&fe.bottom<=qt+1&&Te.push(re.dataset.lineId??"")}),Bt(re=>Te.every(fe=>re.has(fe))?re:new Set([...re,...Te]))};S();const I=setTimeout(S,700);return C.addEventListener("scroll",S,{passive:!0}),window.addEventListener("resize",S),()=>{clearTimeout(I),C.removeEventListener("scroll",S),window.removeEventListener("resize",S)}},[M,l]);const Pe=ro(l,M,M&&!ze?Ft:void 0),Je=M&&Pe.hidden.size>0,Ze=M?l.lines.filter(m=>!m.risky&&!m.isNew):[],Mt=m=>Js(m==="allow"?ao(s.items,Pe):s.items),Ut=(m,C)=>g(S=>({...S,[m]:!E(m,C)})),ye=(m,C=!1)=>e.jsxs("label",{"data-line-id":m.requestID,className:"flex items-center gap-3 cursor-pointer",style:{minHeight:44,padding:C?"10px 14px":"6px 0",borderRadius:C?14:0,background:C?j.redChip:void 0,fontSize:C?14:13},children:[e.jsx("input",{type:"checkbox",checked:E(m.requestID,m.checked),onChange:()=>Ut(m.requestID,m.checked),style:{width:18,height:18,accentColor:m.risky?j.red:j.gold,flexShrink:0}}),e.jsx("span",{style:{color:m.risky?"#FF6B6B":void 0},children:m.text})]},m.requestID),Re=(h||b)&&e.jsxs("span",{children:[e.jsx("span",{style:{color:j.gold},children:h||"this account"}),b&&e.jsxs("span",{className:"font-mono",style:{userSelect:"none",fontSize:12,color:j.muted},children:[" ","· ",b]})]}),_t=e.jsxs("div",{className:"flex flex-col",style:{gap:4},children:[(h||b)&&e.jsxs("p",{className:"m-0","data-testid":"signing-as",style:{fontSize:12},children:["Signing in as ",Re]}),l.lines.length>0&&e.jsx("p",{className:"m-0",style:{fontSize:12,fontWeight:700,color:j.muted},children:"Allow this app"}),l.lines.map(m=>ye(m)),l.payment&&e.jsxs("p",{className:"m-0",style:{padding:"6px 0"},children:["Pay ",e.jsx("span",{style:{color:j.gold,fontWeight:600},children:ne})," now to ",s.originator,l.payment.description&&e.jsxs(e.Fragment,{children:[" “",l.payment.description,"”"]})]}),l.payment?.labels?.length?e.jsxs("p",{className:"m-0",style:{fontSize:13,color:j.muted},"data-testid":"payment-labels",children:["Labels: ",l.payment.labels.join(", ")]}):null,He,e.jsxs("label",{className:"flex items-center gap-3 cursor-pointer",style:{minHeight:44},children:[e.jsx("input",{type:"checkbox",checked:w,onChange:()=>P(!w),style:{width:18,height:18,accentColor:j.gold,flexShrink:0}}),e.jsx("span",{children:"Remember this site"})]}),!_&&D&&w&&e.jsxs("label",{className:"flex items-start gap-3 cursor-pointer",style:{padding:"6px 0"},children:[e.jsx("input",{type:"checkbox",checked:B,onChange:()=>de(!B),style:{width:18,height:18,accentColor:j.gold,flexShrink:0,marginTop:1}}),e.jsxs("span",{children:["Don't ask again on ",s.originator," for sign-in and signing."," ",R?.allowances?"Payments stay within the allowance;":"Payments still ask, or use its envelope;"," ","your personal details always ask."]})]}),e.jsxs("ul",{className:"m-0 mt-1 pl-4 break-all",style:{fontSize:11,color:j.muted},children:[l.payment&&e.jsxs("li",{children:["pay: ",l.payment.detail]}),l.lines.map(m=>e.jsx("li",{children:m.detail},m.requestID)),Lt>0]})]}),Qe={label:"Not now",onClick:()=>{ge("notNow")},disabled:ue},zt={label:"Block this site",onClick:()=>{ge("block")},disabled:ue},et={label:M?"I trust it, allow":Ot,onClick:()=>{ge("allow")},disabled:ue||Je,busy:We};let z,W,q=null,H;const V=m=>e.jsx("span",{style:{color:j.gold},children:m}),tt=m=>Ie(m,he);if(_&&O!=="careful")z=e.jsx(Oe,{amount:ee?.main??"",sub:ee?.sub}),H="One approval for all of it",W=e.jsx(e.Fragment,{children:V(_.title)}),q=e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"mint-sheet",children:[e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:15,fontWeight:600},"data-testid":"mint-cost",children:[e.jsx(T,{size:18}),"Costs ",tt(_.premiumSats)," + ",tt(_.feeSats)," network fee"]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs($,{children:[e.jsx(T,{}),"Locked with your keys"]}),e.jsxs($,{children:[e.jsx(T,{}),"Only on ",_.site]}),e.jsxs($,{children:[e.jsx(T,{}),"Next payment asks again"]})]})]});else if(O==="careful"){z=l.lines.length>0?null:e.jsx(cs,{}),H="Check this carefully";const m=s.items.some(I=>I.privileged),C=Ke.some(I=>s.items.find(G=>G.requestID===I.requestID)?.type==="certificate"),S=I=>e.jsx("span",{style:{color:"#FF6B6B"},children:I});W=m?e.jsxs(e.Fragment,{children:["Wants ",S("full control")," of your keys"]}):C?e.jsxs(e.Fragment,{children:["Wants your ",S("private details")]}):e.jsxs(e.Fragment,{children:["Wants ",S("more than usual")]}),q=e.jsxs("div",{ref:Ye,className:"flex flex-col",style:{gap:8},children:[m&&e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:j.redChip,fontSize:14},children:[e.jsx(ot,{}),"Could move your money"]}),Ke.map(I=>ye(I,!0)),Ze.length>0&&e.jsxs("div",{className:"flex flex-col","data-testid":"careful-ordinary-lines",style:{padding:"0 4px"},children:[e.jsx("p",{className:"m-0",style:{fontSize:12,fontWeight:700,color:j.muted},children:"Also asks to"}),Ze.map(I=>ye(I))]}),e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:j.redChip,fontSize:14},children:[e.jsx(ot,{}),"Only allow apps you trust"]})]})}else if(O==="pay")z=e.jsx(Oe,{amount:ee?.main??"",sub:ee?.sub}),H=l.payment?.description||"Asks you to pay",W=e.jsxs(e.Fragment,{children:["Pay ",V(ne)," now to ",V(te)]}),q=e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex items-center gap-3",style:{padding:14,borderRadius:16,background:j.chip},children:[e.jsx(ds,{site:s.originator,size:44}),e.jsxs("div",{className:"flex flex-col min-w-0",style:{gap:2,lineHeight:1.25},children:[e.jsxs("span",{className:"truncate",style:{fontSize:15,fontWeight:600},children:["To ",s.originator]}),e.jsx("span",{className:"truncate",style:{fontSize:13,color:j.muted},children:l.payment?.description?`“${l.payment.description}”`:"Straight from your wallet"}),l.payment?.labels?.length?e.jsxs("span",{className:"truncate",style:{fontSize:12,color:j.muted},"data-testid":"payment-labels",children:["Labels: ",l.payment.labels.join(", ")]}):null]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:j.soft},children:[e.jsx(T,{size:18}),Q>0?"Then small payments come out of the envelope":"Every payment asks you first"]}),Ve&&pe&&e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"envelope-offer",children:[e.jsx("span",{style:{fontSize:15,fontWeight:600},children:pe.balanceSats!==void 0?e.jsxs(e.Fragment,{children:["Top up the envelope",e.jsxs("span",{style:{fontSize:13,fontWeight:400,color:j.muted},children:[" ","· ",Ie(pe.balanceSats,he)," left, not enough for this"]})]}):e.jsxs(e.Fragment,{children:[Q>0?`Also put ${me(Q)}`:"Also put money"," in ",V(te),"'s envelope?"]})}),e.jsx(Rt,{presetsUsd:pe.presetsUsd,value:Q,onChange:Ee,allowNone:!0,disabled:ue}),e.jsxs("span",{style:{fontSize:12,color:j.muted},children:["Stays in your wallet. Small payments from ",te," come out of it without asking; Coin return any time."]})]})]});else if(O==="post")z=e.jsx(Ae,{site:s.originator}),H="Wants to post for you",W=e.jsxs(e.Fragment,{children:["Allow ",V(te)," to post for you"]}),q=e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs($,{children:[e.jsx(T,{}),"Post and like as you"]}),e.jsxs($,{children:[e.jsx(T,{}),"Nothing else moves"]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14},"data-testid":"post-cost",children:[e.jsx(T,{size:18}),ee?e.jsxs("span",{className:"flex flex-col",children:[e.jsxs("span",{children:["This post costs"," ",e.jsx("span",{style:{fontSize:20,fontWeight:800,color:j.gold},children:ee.main})]}),e.jsx("span",{style:{fontSize:12,color:j.muted},children:ee.sub})]}):"Each paid post asks you first"]})]});else if(O==="private")z=e.jsx(nt,{}),H="Your data",W=e.jsxs(e.Fragment,{children:["Use your wallet keys for your ",V(ys(l))]}),q=e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs($,{children:[e.jsx(T,{}),"Uses keys from your wallet"]}),e.jsxs($,{children:[e.jsx(T,{}),"No money moves"]})]});else if(Ge&&O==="signin")z=e.jsx(Ae,{site:s.originator}),H="You disconnected this site",W=e.jsxs(e.Fragment,{children:["Reconnect to ",V(te),"?"]}),q=e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs($,{children:[e.jsx(T,{}),"Shares your public key"]}),e.jsxs($,{children:[e.jsx(T,{}),"No money moves"]})]});else if(O==="signin")z=e.jsx(nt,{}),H="Sign-in request",W=e.jsxs(e.Fragment,{children:["Sign in to ",V(te)]}),q=e.jsxs(e.Fragment,{children:[Re&&e.jsxs("div",{className:"flex items-center gap-2.5",children:[e.jsx("div",{"aria-hidden":"true",style:{width:30,height:30,borderRadius:15,background:"conic-gradient(#F5C542, #B8860B, #FFE08A, #F5C542)",flexShrink:0}}),e.jsxs("span",{style:{fontSize:18,fontWeight:600},children:["as ",Re]})]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs($,{children:[e.jsx(T,{}),"No password"]}),e.jsxs($,{children:[e.jsx(T,{}),"No money moves"]})]})]});else{z=e.jsx(Ae,{site:s.originator}),H="Wants to connect",W=e.jsxs(e.Fragment,{children:["Use ",V("bWalletX")," on ",te]});const m=new Set(s.items.map(S=>S.type)),C=[{label:m.has("certificate")?"Your details":"Your name",icon:e.jsx(ho,{})}];m.has("protocol")&&C.push({label:"Sign posts",icon:e.jsx(go,{})}),m.has("basket")&&C.push({label:"Keep items",icon:e.jsx(yo,{})}),q=e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"grid",style:{gridTemplateColumns:`repeat(${C.length}, minmax(0, 1fr))`,gap:8},children:C.map(S=>e.jsxs("div",{className:"flex flex-col items-center",style:{gap:8,padding:"14px 6px",borderRadius:16,background:j.chip},children:[S.icon,e.jsx("span",{style:{fontSize:13,fontWeight:600,textAlign:"center"},children:S.label})]},S.label))}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:j.soft},children:[e.jsx(T,{size:18}),"Payments still ask you first"]})]})}return e.jsx(A.div,{className:"flex flex-col w-full h-full",style:{maxHeight:"100vh"},initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{type:"spring",damping:24,stiffness:260},"data-approval-kind":O,onPointerDownCapture:y,children:e.jsxs(xt,{tone:M?"red":"gold",site:s.originator,siteSub:H,onClose:()=>{ge("notNow")},closeLabel:"Deny and close",closeDisabled:ue,hero:z,title:W,primary:M?Qe:et,secondary:M?et:Qe,tertiary:M?zt:void 0,details:_t,detailsOpen:K,onToggleDetails:()=>{At(!0),It(!K)},error:Dt||(Je?"Scroll to read every line before allowing":""),children:[q,Xe.length>0&&e.jsx("div",{className:"flex flex-col","data-testid":"new-lines",style:{gap:4,marginTop:8},children:Xe.map(m=>ye(m,!0))})]})})},Ue={"aria-hidden":!0,width:28,height:28,viewBox:"0 0 24 24",fill:"none",stroke:j.gold,strokeWidth:1.8,strokeLinecap:"round",strokeLinejoin:"round"},ho=()=>e.jsxs("svg",{...Ue,children:[e.jsx("circle",{cx:"12",cy:"8",r:"4"}),e.jsx("path",{d:"M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"})]}),go=()=>e.jsxs("svg",{...Ue,children:[e.jsx("path",{d:"M12 20h9"}),e.jsx("path",{d:"M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"})]}),yo=()=>e.jsxs("svg",{...Ue,children:[e.jsx("rect",{x:"3",y:"7",width:"18",height:"13",rx:"2"}),e.jsx("path",{d:"M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"})]}),bo=t=>{const s=t.sequence,n=s?s.totalPosts:t.posts,o=s?s.totalSats:t.sats,i=s?s.totalTxs:t.txs;return{title:n!==void 0?`Lock ${n.toLocaleString("en")} posts to you`:"Lock your posts to you",site:`${t.originator} is asking`,privacy:"Private: only you can see them. They are encrypted with your wallet’s keys before they leave this device.",cost:`About ${o.toLocaleString("en")} sats in ${i.toLocaleString("en")} transaction${i===1?"":"s"}`,chunks:s?`Sent in ${s.chunks.toLocaleString("en")} parts. One Allow covers the whole run for 2 hours, up to 10% over this estimate. Anything more asks again.`:void 0}},vo=({request:t,onResponse:s})=>{const{theme:n}=Z(),[o,i]=d.useState(!1),r=bo(t),p=t.sequence?t.sequence.totalSats:t.sats,u=J(p,ve(t.usdPerBsv,!0)),a=n.color.global.gray,f=n.color.global.contrast,h=b=>{o||(i(!0),U({action:"MINT_PRIVATE_RESPONSE",requestID:t.requestID,allow:b}),s())};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(ps,{size:36,style:{color:f}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:f},children:r.title}),e.jsx("p",{className:"m-0 text-xs",style:{color:a},children:r.site}),e.jsxs("div",{className:"flex flex-col items-center","data-testid":"dollar-amount",children:[e.jsx("span",{style:{fontSize:32,fontWeight:800,lineHeight:1.1,color:f},children:u.main}),e.jsx("span",{className:"text-xs",style:{color:a},children:u.sub})]}),e.jsx("p",{className:"m-0 text-sm",style:{color:f},children:r.cost}),e.jsx("p",{className:"m-0 text-xs leading-relaxed",style:{color:a,maxWidth:"18rem"},children:r.privacy}),r.chunks&&e.jsx("p",{className:"m-0 text-xs leading-relaxed",style:{color:a,maxWidth:"18rem"},children:r.chunks}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(ae,{theme:n,type:"primary",label:"Allow",disabled:o,onClick:()=>h(!0)}),e.jsx(ae,{theme:n,type:"secondary-outline",label:"Decline",disabled:o,onClick:()=>h(!1)})]})]})},wo=({request:t,onResponse:s})=>{const{theme:n}=Z(),o=t.usdPerBsv,i=t.capSatsPerHour,r=o?i/1e8*o:void 0,[p,u]=d.useState(r!==void 0?r.toFixed(2):""),[a,f]=d.useState(String(i)),[h,b]=d.useState(!1),l=d.useMemo(()=>{const x=o?ut(Number(p),o):Math.floor(Number(a));return Number.isFinite(x)&&x>=1?Math.min(x,i):0},[p,a,o,i]),k=x=>{h||(b(!0),U({action:"STREAM_GRANT_RESPONSE",requestID:t.requestID,capSatsPerHour:x?l:null}),s())},g=n.color.global.gray,c=n.color.global.contrast,v=new Date(t.expiresAt).toLocaleString(),N=J(i,ve(o,!0));return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(us,{size:36,style:{color:c}}),e.jsxs("h2",{className:"m-0 text-lg font-semibold",style:{color:c},children:["Allow ",t.originator," to stream while you watch, up to"]}),e.jsxs("div",{className:"flex flex-col items-center","data-testid":"dollar-amount",children:[e.jsxs("span",{style:{fontSize:o?40:24,fontWeight:800,lineHeight:1.1,color:c},children:[N.main,e.jsx("span",{style:{fontSize:16,fontWeight:600},children:" an hour"})]}),e.jsx("span",{className:"text-xs",style:{color:g},children:N.sub})]}),t.description&&e.jsx("p",{className:"m-0 text-xs",style:{color:g,maxWidth:"18rem"},children:t.description}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:g,maxWidth:"18rem"},children:["Only “",t.protocolName,"” payments from ",t.originator," go through without asking, until ",v,". Anything else still asks you. Revoke any time in Settings › Streaming permissions."]}),e.jsxs("label",{className:"flex items-center gap-2 text-sm",style:{color:c},children:["Cap per hour ",o?"$":"",o?e.jsx("input",{"aria-label":"Cap in dollars per hour",inputMode:"decimal",value:p,onChange:x=>u(x.target.value),className:"w-24 px-2 py-1 rounded bg-transparent border",style:{color:c}}):e.jsx("input",{"aria-label":"Cap in sats per hour",inputMode:"numeric",value:a,onChange:x=>f(x.target.value),className:"w-28 px-2 py-1 rounded bg-transparent border",style:{color:c}}),!o&&"sats"]}),e.jsxs("p",{className:"m-0 text-xs",style:{color:g},children:[l?o?`${J(l,ve(o,!0)).main} an hour · ${l.toLocaleString()} sats`:`${l.toLocaleString()} sats an hour ${fs}`:"Enter a cap above zero",l===i?" (the most this site asked for)":""]}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(ae,{theme:n,type:"primary",label:"Allow",disabled:h||!l,onClick:()=>k(!0)}),e.jsx(ae,{theme:n,type:"secondary-outline",label:"Not now",disabled:h,onClick:()=>k(!1)})]})]})},jo=({request:t,onResponse:s})=>{const n=t.usdPerBsv,[o,i]=d.useState(fo),[r,p]=d.useState(!1),u=n?ut(o,n):0,a=t.envelope?.balanceSats??0,f=ve(n,!0),h=J(u,f),b=gt(t.originator),l=k=>{r||(p(!0),U({action:"STREAM_GRANT_RESPONSE",requestID:t.requestID,capSatsPerHour:k?u:null}),s())};return e.jsx(xt,{site:t.originator,siteSub:t.description||"Many small payments",onClose:()=>l(!1),closeLabel:"Not now",closeDisabled:r,hero:e.jsx(Oe,{amount:n?me(o):h.main,sub:h.sub,badge:"ENVELOPE"}),title:e.jsxs(e.Fragment,{children:["Put ",n?me(o):"money"," in ",e.jsx("span",{style:{color:j.gold},children:b}),"'s envelope"]}),primary:{label:n?`Put ${me(o)} in`:"Price unavailable",onClick:()=>l(!0),disabled:r||!u},secondary:{label:"Not now",onClick:()=>l(!1),disabled:r},testId:"envelope-sheet",children:e.jsxs("div",{className:"flex flex-col",style:{gap:10},children:[e.jsx(Rt,{presetsUsd:uo,value:o,onChange:i,disabled:r}),a>0&&e.jsxs("span",{style:{fontSize:13,color:j.muted},"data-testid":"envelope-balance",children:["Already in it: ",J(a,f).main]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs($,{children:[e.jsx(T,{}),"Stays in your wallet"]}),e.jsxs($,{children:[e.jsx(T,{}),"Only ",b," can spend it"]}),e.jsxs($,{children:[e.jsx(T,{}),"Coin return any time"]})]}),e.jsxs("span",{style:{fontSize:13,color:j.soft},children:["Small payments from ",t.originator," come out of the envelope without asking. When it is empty, it asks you again. Settings › Envelopes shows what is left."]})]})})},se={bg:"#0B0B0D",text:"#FFFFFF",muted:"#98A2B3",gold:"#F5C542",line:"#2B2F36"};function ko(t){const[s,n]=d.useState(null);return d.useEffect(()=>{if(!t)return;let o=!0;const i=()=>{if(!ms(t)){n(null);return}xs(t,{asking:!0,path:hs(t)}).then(r=>o&&n(r))};return i(),window.addEventListener(rt,i),window.addEventListener("storage",i),()=>{o=!1,window.removeEventListener(rt,i),window.removeEventListener("storage",i)}},[t]),s}const No=({originator:t,themed:s})=>e.jsxs("div",{"data-testid":"bwx-origin-strip",className:"flex items-center gap-2 px-3",style:{background:se.bg,color:se.text,borderBottom:`1px solid ${se.line}`,minHeight:32,fontFamily:"Inter, system-ui, sans-serif",fontSize:12,flexShrink:0},children:[e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24","aria-hidden":!0,fill:"none",stroke:se.gold,strokeWidth:"2.5",children:[e.jsx("rect",{x:"4",y:"11",width:"16",height:"10",rx:"2"}),e.jsx("path",{d:"M8 11V7a4 4 0 0 1 8 0v4"})]}),e.jsx("span",{style:{color:se.muted},children:"bWalletX · request from"}),e.jsx("span",{className:"font-bold truncate",style:{color:se.text},children:ht(t)}),s&&e.jsx("span",{className:"ml-auto whitespace-nowrap",style:{color:se.muted,fontSize:10},children:"site theme"})]}),So=({theme:t,originator:s})=>e.jsxs("div",{"data-testid":"bwx-site-banner",className:"flex items-center gap-3 px-4",style:{background:t.artData?`linear-gradient(90deg, ${t.bg} 35%, ${t.bg}99), url("${t.artData}") center / cover`:`linear-gradient(135deg, ${t.bg}, ${t.surface})`,color:t.text,borderBottom:`3px solid ${t.accent}`,minHeight:60,flexShrink:0},children:[t.logoData?e.jsx("img",{src:t.logoData,alt:"",width:36,height:36,style:{borderRadius:8,objectFit:"contain"}}):e.jsx("span",{"aria-hidden":!0,className:"flex items-center justify-center font-bold",style:{width:36,height:36,borderRadius:8,background:t.accent,color:t.onAccent},children:t.name.slice(0,1).toUpperCase()}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"font-bold truncate",style:{fontSize:15,color:t.text},children:t.name}),e.jsxs("div",{className:"truncate",style:{fontSize:11,color:t.accentHi},children:["Connected with bWalletX · ",ht(s)]})]})]}),Eo=({originator:t,children:s,theme:n})=>{const o=ko(n===void 0?t:void 0),i=n===void 0?o:n;return t?e.jsxs("div",{className:"flex flex-col w-full h-full",style:i?{boxShadow:`inset 3px 0 0 ${i.accent}, inset -3px 0 0 ${i.accent}`}:void 0,children:[e.jsx(No,{originator:t,themed:!!i}),i&&e.jsx(So,{theme:i,originator:t}),e.jsx("div",{className:"flex-1 min-h-0 flex items-center justify-center relative",children:s})]}):e.jsx(e.Fragment,{children:s})};pt.Buffer=dt;pt.process=Vt;window.Buffer=dt;const Co=t=>"payload"in t&&t.payload.originator||void 0,Po=1e4,Ro=2e3,X=new URLSearchParams(window.location.search).get("inpage"),ct=window.location.protocol==="chrome-extension:"&&window.top!==window&&!X&&!!window.location.ancestorOrigins?.length&&window.location.ancestorOrigins[0]!==window.location.origin,To=(t,s)=>{const[n,o]=d.useState(t?void 0:!0),[i,r]=d.useState(!t),[p,u]=d.useState(!1);return d.useEffect(()=>{t&&Y({action:"INPAGE_SHEET_CHECK",token:X}).then(a=>o(!!a?.success)).catch(()=>o(!1))},[t]),d.useEffect(()=>{if(!t||n!==!0||!s.current)return;let a;const f=new IntersectionObserver(h=>{const b=h[h.length-1];window.clearTimeout(a),b.isVisible&&b.intersectionRatio>=.99?a=window.setTimeout(()=>r(!0),500):r(!1)},{threshold:[0,.99,1],trackVisibility:!0,delay:100});return f.observe(s.current),()=>{window.clearTimeout(a),f.disconnect()}},[t,s,n]),d.useEffect(()=>{if(!t||i){u(!1);return}const a=window.setTimeout(()=>u(!0),1500);return()=>window.clearTimeout(a)},[t,i]),{tokenOk:n,armed:n===!0&&i,stuck:n===!0&&!i&&p}},Io=()=>{const{theme:t}=Z(),{isLocked:s,isReady:n}=oe(),o=d.useRef(null),i=d.useRef(null),r=To(!!X,i),p=!ct&&r.tokenOk===!0,u=d.useRef(p);u.current=p;const[a,f]=d.useState({kind:"loading"}),h=d.useRef(void 0),b=d.useRef(void 0),l=()=>{h.current!==void 0&&(window.clearTimeout(h.current),h.current=void 0)},k=d.useRef(a);k.current=a;const g=d.useCallback(async(x,y)=>{l();const E=k.current;if(x==="bundle"&&E.kind==="bundle"&&E.requestID===y){try{const F=await Y({action:"GET_PROMPT_PAYLOAD",kind:x,requestID:y});F?.success&&F.data&&f({kind:"bundle",requestID:y,payload:F.data})}catch{}return}f({kind:"loading"});let R;try{R=await Y({action:"GET_PROMPT_PAYLOAD",kind:x,requestID:y})}catch{R=void 0}R?.success&&R.data?f({kind:x,requestID:y,payload:R.data}):(f({kind:"expired"}),window.setTimeout(()=>{b.current?.()},Ro))},[]),c=d.useCallback(async()=>{l();let x;try{x=await Y({action:"CLOSE_PROMPT_WINDOW"})}catch{x=void 0}if(x===void 0){window.close();return}const y=x.data?.prompt;y&&(y.kind==="unlock"?f({kind:"unlock"}):y.requestID&&await g(y.kind,y.requestID))},[g]),v=d.useCallback(async()=>{l();let x;try{x=await Y({action:"GET_NEXT_PROMPT"})}catch{x=void 0}if(x?.data?.prompt){await g(x.data.prompt.kind,x.data.prompt.requestID);return}if(x?.data?.busy){f({kind:"waiting"}),h.current=window.setTimeout(()=>{c()},Po);return}await c()},[g,c]);b.current=v,d.useEffect(()=>{if(!n||!p)return;const x=new URLSearchParams(window.location.search),y=x.get("kind"),E=x.get("requestID");if(y==="unlock"){s?f({kind:"unlock"}):v();return}if(y&&E){g(y,E);return}v()},[n,p]),d.useEffect(()=>{const x=y=>{if(!(y?.action!=="SHOW_PROMPT"||!y.kind||!u.current)){if(y.kind==="unlock"){l(),f({kind:"unlock"});return}y.requestID&&g(y.kind,y.requestID)}};return chrome.runtime.onMessage.addListener(x),()=>chrome.runtime.onMessage.removeListener(x)},[g]);const N=t.color.global.walletBackground;return!ct&&X&&r.tokenOk===void 0?null:p?e.jsxs(Qt,{children:[X&&e.jsxs("div",{className:"flex items-center justify-between px-3 py-2",style:{background:N,borderBottom:"1px solid #ffffff14"},children:[e.jsx("span",{className:"text-sm font-bold",style:{color:t.color.global.contrast},children:"bWalletX"}),r.stuck&&e.jsx("button",{type:"button",className:"text-xs font-bold border-0 rounded-full px-3 py-1",style:{background:"#F5C542",color:"#0b0a08"},onClick:()=>chrome.runtime.sendMessage({action:"MOVE_PROMPT_TO_WINDOW"}).catch(()=>{}),children:"Open in bWalletX"}),e.jsx("button",{type:"button","aria-label":"Deny and close",className:"text-sm border-0 bg-transparent p-1",style:{color:t.color.global.gray},onClick:()=>chrome.runtime.sendMessage({action:"DISMISS_PROMPT_PANEL"}).catch(()=>{}),children:"✕"})]}),e.jsxs("div",{ref:o,className:"flex items-center justify-center relative p-0",style:{width:X?"100%":"var(--wallet-width)",height:X?"calc(100vh - 41px)":"var(--wallet-height)",backgroundColor:N,pointerEvents:r.armed?void 0:"none"},children:[X&&e.jsx("div",{ref:i,"aria-hidden":!0,style:{position:"absolute",top:0,left:0,width:24,height:24,pointerEvents:"none"}}),(!n||a.kind==="loading")&&e.jsx(st,{message:"Loading...",theme:t}),a.kind==="waiting"&&e.jsx(st,{message:"Waiting for request...",theme:t}),a.kind==="expired"&&e.jsx("p",{className:"text-xs",style:{color:t.color.global.gray},children:"This request expired or was already handled."}),a.kind==="unlock"&&e.jsx(es,{onUnlock:()=>{v()}}),e.jsxs(Eo,{originator:Co(a),children:[a.kind==="permission"&&e.jsx(Xs,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="bundle"&&e.jsx(xo,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="groupedPermission"&&e.jsx(Cs,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="counterpartyPermission"&&e.jsx(bs,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="oneSatPermission"&&e.jsx(Vs,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="streamGrant"&&(a.payload.envelope?e.jsx(jo,{request:a.payload,onResponse:()=>{v()}},a.requestID):e.jsx(wo,{request:a.payload,onResponse:()=>{v()}},a.requestID)),a.kind==="mintPrivate"&&e.jsx(vo,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="usbCheck"&&e.jsx(Ys,{request:a.payload,onResponse:()=>{v()}},a.requestID)]})]})]}):e.jsx("p",{className:"text-xs p-4",style:{color:"#98A2B3"},children:"Open bWalletX to answer this request."})},Tt=document.getElementById("root");if(!Tt)throw new Error("Root element");Ht.createRoot(Tt).render(e.jsx(Xt,{children:e.jsx(Yt,{children:e.jsx(Jt,{children:e.jsx(Zt,{children:e.jsx(Io,{})})})})}));
//# sourceMappingURL=prompt-tab-wk_1XKfU.js.map
