import{n as t}from"./crypto-BV2NSqmP.js";const e=[["rect",{width:"14",height:"20",x:"5",y:"2",rx:"2",ry:"2",key:"1yt0o3"}],["path",{d:"M12 18h.01",key:"mhygvu"}]],r=t("smartphone",e);export{r as S};
//# sourceMappingURL=smartphone-DBffR4vC.js.map
