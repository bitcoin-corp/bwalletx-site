import{i as e}from"./sessions-CU_IWapN.js";import{c6 as i,aM as n,cn as c}from"./index-CuAsuQNM.js";const l=["b0asex"],r=(a,s=l)=>{const[t,o]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!s.includes(t)?!1:!o||o===n.toLowerCase()||(c??[]).includes(o)},m=(a,s=!1)=>s||e(a)||r(i(a??void 0));export{m as c};
//# sourceMappingURL=bulkAccess-DDV6qvKy.js.map
