import{r as t}from"./index-BgdDy8zn.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-Dj2FUejS.js.map
