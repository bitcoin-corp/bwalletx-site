import{c as o}from"./index-CF7S9HFd.js";const r=[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]],c=o("arrow-up",r);export{c as A};
//# sourceMappingURL=arrow-up-C0v7W7Lw.js.map
