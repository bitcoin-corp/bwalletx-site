const e=""+new URL("bmoviesx-BHNuS4pv.png",import.meta.url).href;export{e as b};
//# sourceMappingURL=bmoviesx-BphOrHBQ.js.map
