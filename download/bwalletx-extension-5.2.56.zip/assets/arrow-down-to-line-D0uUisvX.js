import{t as o}from"./crypto-C1w-D8Dj.js";const e=[["path",{d:"M12 17V3",key:"1cwfxf"}],["path",{d:"m6 11 6 6 6-6",key:"12ii2o"}],["path",{d:"M19 21H5",key:"150jfl"}]],n=o("arrow-down-to-line",e);export{n as A};
//# sourceMappingURL=arrow-down-to-line-D0uUisvX.js.map
