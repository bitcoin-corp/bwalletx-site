import{r as t}from"./wocLimiter-CVYQRkJQ.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-mdrd644c.js.map
