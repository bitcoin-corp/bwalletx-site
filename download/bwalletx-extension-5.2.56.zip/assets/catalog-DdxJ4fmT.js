import{a3 as n,az as e,aA as c,aB as o,aC as i,aD as f}from"./index-BR8IFw7h.js";const r=n?`${n}/api/themes`:"";async function l(s=fetch){try{if(!r)return[...e];const a=await s(r);if(!a.ok)return[...e];const t=c(await a.json());return t.length?t:[...e]}catch{return[...e]}}function p(s,a){const t=o(a);t?i(s,t):f(s,a)}export{p as a,l as f};
//# sourceMappingURL=catalog-DdxJ4fmT.js.map
