import{t as e}from"./crypto-C1w-D8Dj.js";const y=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M8 14s1.5 2 4 2 4-2 4-2",key:"1y1vjs"}],["line",{x1:"9",x2:"9.01",y1:"9",y2:"9",key:"yxxnd0"}],["line",{x1:"15",x2:"15.01",y1:"9",y2:"9",key:"1p4y9e"}]],i=e("smile",y);export{i as S};
//# sourceMappingURL=smile-CbuBLine.js.map
