import{w as o}from"./crypto-C1w-D8Dj.js";const t=`${o()} (beta) by The Bitcoin Corporation Ltd. Based on the open-source Yours Wallet (MIT licence); not affiliated with or endorsed by its authors.`;export{t as U};
//# sourceMappingURL=brandText-bdRexsH3.js.map
