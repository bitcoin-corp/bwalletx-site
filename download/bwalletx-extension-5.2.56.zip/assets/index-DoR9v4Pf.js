const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DDTfJZzA.js","./index-BR8IFw7h.js","./crypto-C1w-D8Dj.js","./wocLimiter-CVYQRkJQ.js","./wocLimiter-Cw4eDz7L.css","./index-BbKU_OLL.css"])))=>i.map(i=>d[i]);
import{n as e,_ as t}from"./index-BR8IFw7h.js";import"./crypto-C1w-D8Dj.js";import"./wocLimiter-CVYQRkJQ.js";const a=e("Share",{web:()=>t(()=>import("./web-DDTfJZzA.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{a as Share};
//# sourceMappingURL=index-DoR9v4Pf.js.map
