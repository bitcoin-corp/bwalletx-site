import{r as s}from"./wocLimiter-CVYQRkJQ.js";import{U as r,V as o}from"./index-BR8IFw7h.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-BFokU5jJ.js.map
