import{r as u,j as e,i as is,R as ls}from"./wocLimiter-CVYQRkJQ.js";import{a4 as Qe,H as cs,bG as Nt,y as Et,z as ds}from"./crypto-C1w-D8Dj.js";import{aQ as W,b as Z,H as F,gv as K,iQ as ce,iR as O,iS as ps,b9 as us,hr as fs,gx as A,b0 as J,iE as hs,iT as Rt,hJ as ms,hK as xs,hL as gs,hM as ys,M as bs,gw as ht,hI as vs}from"./index-BR8IFw7h.js";import{u as ye,b as Ie,U as ws,y as Te,z as Ct,B as js,D as ks,q as $t,E as Ss,F as Ns,k as Q,G as Es,C as v,l as R,a as T,P as Re,H as Rs,I as Cs,J as qe,K as $s,N as ke,Q as Ps,R as Se,A as Pt,T as mt,x as Is,S as Ts,V as Ce,L as Ds,c as As,W as Os,X as xt,Y as Ls,Z as Fs,_ as Us,$ as _s}from"./reservedBaskets-oBBkSkZ8.js";import{a as Ms,u as Bs,s as zs}from"./twetchCalls-eK7Q_41k.js";import{a as gt,s as It,w as Ws,b as He}from"./approvalKind-C_G9UKut.js";import{A as qs}from"./arrow-left-right-TyyIcAqQ.js";import{L as Hs}from"./link-2-5y_q9iH4.js";const Vs=t=>{const{request:s,onResponse:n}=t,{theme:o}=W(),{handleSelect:i,hideMenu:r}=ye(),{addSnackbar:d}=Ie(),[c,a]=u.useState(!1),[f,m]=u.useState(""),{chromeStorageService:g}=Z(),{permissions:l}=s,[w,k]=u.useState(()=>l.protocols.map(()=>!0));u.useEffect(()=>{i("bsv"),r()},[i,r]);const p=()=>{const E=l.protocols.filter(($,U)=>w[U]);return E.length===0?{}:{protocols:E}},b=async()=>{a(!0),m("");try{const E=await ce(g);if(!E.ok){m(E.message),a(!1);return}Te(s.originator),O({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:p()}),n()}catch(E){d(E instanceof Error?E.message:String(E),"error"),a(!1)}},S=async()=>{a(!0),O({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),n()},x=E=>k($=>$.map((U,oe)=>oe===E?!U:U)),y=s.counterpartyLabel??`${s.counterparty.slice(0,8)}...${s.counterparty.slice(-8)}`;return e.jsxs(F.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ws,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Counterparty Permission"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","wants to interact with a counterparty"]})]})]}),e.jsxs(F.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all font-mono",style:{color:o.color.global.contrast},children:y})]}),e.jsx(K,{when:!!l.description,children:e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Purpose"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:l.description})]})}),e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),l.protocols.map((E,$)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:$<l.protocols.length-1?"1px solid rgba(255,255,255,0.04)":"none"},children:[e.jsx("input",{type:"checkbox",checked:w[$],onChange:()=>x($),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[E.protocolID?.[1]," (level ",E.protocolID?.[0],")"]}),E.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:E.description})]})]},`proto-${$}`))]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[f&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:f}),e.jsxs(F.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:c?.6:1},disabled:c,onClick:b,whileHover:{scale:c?1:1.02},whileTap:{scale:c?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[c&&e.jsx(Qe,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(F.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:c?.5:1},disabled:c,onClick:S,whileHover:{scale:c?1:1.02},whileTap:{scale:c?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},Tt=[{protocolID:[2,"bmintx archive"],origins:["bmintx.com","www.bmintx.com"],label:"Your private archive (bMintX)",description:"bMintX wants to lock your imported posts with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose."},{protocolID:[2,"bvideox records"],origins:["bvideox.com","www.bvideox.com"],label:"Your video records (bVideoX)",description:"bVideoX wants to lock your video records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"video",countFrom:/(\d+) private video records?/i}},{protocolID:[2,"bjobsx records"],origins:["bjobsx.com","www.bjobsx.com"],label:"Your work records (bJobsX)",description:"bJobsX wants to lock your profile records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"profile record",countFrom:/(\d+) private profile records?/i}},{protocolID:[2,"bdrivex records"],origins:["bdrivex.com","www.bdrivex.com"],label:"Your file records (bDriveX)",description:"bDriveX wants to lock your file records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"file record",countFrom:/(\d+) private file records?/i}},{protocolID:[2,"bcalx records"],origins:["bcalx.com","www.bcalx.com"],label:"Your calendar records (bCalX)",description:"bCalX wants to lock your calendar records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"calendar record",countFrom:/(\d+) private (?:calendar )?records?/i}}],Ks=t=>`${t[0]}:${t[1].trim().toLowerCase()}`;new Map(Tt.map(t=>[Ks(t.protocolID),t]));const Gs={"2:3241645161d8":{label:"BRC-29 payment",description:"An application is requesting permission to derive payment addresses for a specific recipient."},...Object.fromEntries(Tt.map(t=>[`${t.protocolID[0]}:${t.protocolID[1]}`,{label:t.label,description:t.description}]))},Dt=t=>t?Gs[`${t[0]}:${t[1]}`]:void 0,At=t=>Dt(t)?.label??t?.[1],Ys=t=>{switch(t){case 0:return"Level 0 · any app";case 1:return"Level 1 · same keys for any app using this protocol";case 2:return"Level 2 · same keys for any app using this protocol with this recipient";default:return`Level ${t??0}`}},Ot=t=>`${t[0]}:${t[1].trim().toLowerCase()}`,Xs=new Set([2532803679,1545534606,3968644154,2559579298,983045898,2744301556,111268922,3445661247,2334321181,4156441831,3583153857,2398265928,1065214202,2451633495,1587406450,3495424783,2196479044,3172368687,3977290595,2110695608,2486468533,3947228137,3114316294,3407865888,2095595255,927149303,1269930738,2919298931,2255687340,329407381,2945469548,2194069484,2746709595,2032425612,2219561992,2168751551,2928392842,3115196437,3200133649].map(t=>t>>>0)),Js=[[2,"3241645161d8"]],Qs=t=>{let s=2166136261;for(const n of new TextEncoder().encode(Ot(t)))s=Math.imul(s^n,16777619)>>>0;return s>>>0};new Set(Js.map(Ot));const Zs=t=>Array.isArray(t)&&t.length===2&&typeof t[0]=="number"&&typeof t[1]=="string"?[t[0],t[1]]:null,yt=t=>{const s=Zs(t);return!!s&&Xs.has(Qs(s))},eo=t=>{const{request:s,onResponse:n}=t,{theme:o}=W(),{handleSelect:i,hideMenu:r}=ye(),{addSnackbar:d}=Ie(),[c,a]=u.useState(!1),[f,m]=u.useState(""),{chromeStorageService:g}=Z(),l=g.getCurrentAccountObject().account?.pubKeys?.identityPubKey??"",{permissions:w}=s,k=g.getCurrentAccountObject().account,p=Ms(k?.addresses?.identityAddress,k?.name??"").payable?.trim()??"",b=p?p.startsWith("$")?p:`$${p}`:"",[S,x]=u.useState(!1);u.useEffect(()=>{i("bsv"),r()},[i,r]);const y=()=>{const C={},G=(w.protocolPermissions??[]).filter(Ae=>!yt(Ae.protocolID));return G.length>0&&(C.protocolPermissions=G),w.basketAccess?.length&&(C.basketAccess=w.basketAccess),C},E=async()=>{a(!0),m("");try{const C=await ce(g);if(!C.ok){m(C.message),a(!1);return}Te(s.originator),O({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:y()}),n()}catch(C){d(C instanceof Error?C.message:String(C),"error"),a(!1)}},$=async()=>{a(!0),O({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),n()},U=(w.protocolPermissions??[]).filter(C=>!yt(C.protocolID)),oe=s.originator.replace(/^[a-z]+:\/\//i,"").split(/[/?#]/)[0],De=`${oe} wants to sign you in${b?` as ${b}`:""}`,ve=[...U.map(C=>`Use your keys for “${At(C.protocolID)}”`),...(w.basketAccess??[]).map(C=>`See its own items in “${Ct(C.basket)}”`)];return e.jsxs(F.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsx("div",{className:"w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-4",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(js,{size:22,style:{color:"var(--bw-accent-hi)"}})}),e.jsx("h1",{className:"text-xl font-bold leading-snug text-center break-words",style:{color:o.color.global.contrast},"data-testid":"connect-title",children:De}),e.jsxs("p",{className:"text-xs mt-2 text-center break-all",style:{color:o.color.global.gray},children:["Request from"," ",e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})]}),e.jsxs("p",{className:"text-sm mt-4 text-center leading-relaxed",style:{color:o.color.global.gray},children:["Nothing is spent. If ",oe," later wants anything more, bWalletX will ask you then."]}),e.jsx(ks,{site:ps(s.originator),account:l,style:{marginTop:12}}),e.jsxs(K,{when:ve.length>0,children:[e.jsx("button",{type:"button",className:"text-xs mt-4 underline self-center",style:{color:o.color.global.gray,background:"transparent"},onClick:()=>x(C=>!C),children:S?"Hide details":"What does signing in allow?"}),e.jsx(K,{when:S,children:e.jsx("ul",{className:"text-xs mt-2 leading-relaxed list-disc pl-5",style:{color:o.color.global.gray},children:ve.map((C,G)=>e.jsx("li",{children:C},G))})})]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-6",children:[f&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:f}),e.jsxs(F.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:c?.6:1},disabled:c,onClick:E,whileTap:{scale:c?1:.97},"data-testid":"connect-sign-in",children:[c&&e.jsx(Qe,{size:14,className:"animate-spin"}),"Sign in"]}),e.jsx(F.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:c?.5:1},disabled:c,onClick:$,whileTap:{scale:c?1:.97},children:"Cancel"})]})]})},to=2e3;async function $e(t,s=to){let n;try{return await Promise.race([t.catch(()=>{}),new Promise(o=>{n=setTimeout(()=>o(void 0),s)})])}catch{return}finally{n&&clearTimeout(n)}}function so(t,s){return t?.find(n=>n.startsWith(`${s}:`))?.slice(s.length+1)}async function oo(t,s,n=[]){const o=t.ordfs;if(typeof o?.bulkMetadata!="function")return{state:"unverified"};const i=`${s}:-2`,r=await $e(o.bulkMetadata([i])),d=r?.[i]??r?.[s]??Object.values(r??{}).find(f=>!!f?.contentType);if(!d?.contentType)return{state:"unverified"};const c={contentType:d.contentType,origin:d.origin,name:typeof d.map?.name=="string"?d.map.name:void 0},a=n.find(f=>f.includes("/"));return a&&a!==d.contentType?{state:"mismatch",note:`Content type is ${d.contentType}, not ${a}`,...c}:{state:"verified",...c}}async function no(t,s,n){const o=t.opns;if(typeof o?.getOrigin!="function")return{state:"unverified"};const i=await $e(o.getOrigin(s));return i?.outpoint?i.outpoint!==n?{state:"mismatch",note:`“${s}” currently resolves to a different output`}:{state:"verified"}:{state:"unverified"}}async function ro(t,s,n,o=[]){const i=t.bsv21;if(typeof i?.getTokenDetails!="function")return{state:"unverified"};const r=await $e(i.getTokenDetails(s,{fresh:!0}));if(!r)return{state:"unverified"};if(r.status?.is_active===!1)return{state:"mismatch",note:"Token is not active on the overlay"};const d=r.token?.sym;if(n&&d&&n.toLowerCase()!==d.toLowerCase())return{state:"mismatch",note:`Token symbol is ${d}, not ${n}`};if(o.length>0&&typeof i.getOutputStatus=="function"){const c=await $e(i.getOutputStatus(s,o));if(!c)return{state:"unverified"};const a=c.filter(f=>f.state==="spent"||f.state==="unknown");if(a.length>0)return{state:"mismatch",note:a.length===1?"A spent token output is not valid on the overlay":`${a.length} spent token outputs are not valid on the overlay`};if(c.some(f=>f.state==="queued"))return{state:"unverified"}}return{state:"verified",...d?{name:d}:{}}}async function ao(t,s,n,o,i){if(!t||!s)return{state:"unverified"};const r=s==="purchase"||s.endsWith(".purchase"),d=s==="token-transfer"||s.startsWith("bsv21.");if(!r&&!d)return{state:"unverified"};const c={kindOrIntent:s,hasOrdfs:!!t.ordfs,hasBulk:typeof t.ordfs?.bulkMetadata=="function",inputTagSets:n.map(a=>a.tags),outputTagSets:o.map(a=>a.tags)};try{const a=[...n.map(p=>p.tags),...o.map(p=>p.tags)],f=p=>a.flatMap(b=>b.filter(S=>S.startsWith(`${p}:`)).map(S=>S.slice(p.length+1))),m=p=>{for(const b of a){const S=so(b,p);if(S)return S}},g=m("bsv21");if(g||s==="bsv21.purchase"||s==="token-transfer"||s.startsWith("bsv21.")){if(!g)return{state:"unverified"};const b=n.filter(x=>x.basket?.includes("bsv21")||x.tags.some(y=>y.startsWith("bsv21:"))).map(x=>x.outpoint).filter(Boolean);let S=m("sym");for(const x of n)if(x.customInstructions)try{const y=JSON.parse(x.customInstructions).sym;if(typeof y=="string"&&y.trim()){S=y.trim();break}}catch{}return await ro(t,g,S,b)}const l=m("name"),w=m("origin");if(c.name=l,c.origin=w,l&&w&&o.some(p=>p.basket?.includes("opns"))||s==="opns.purchase")return!l||!w?{state:"unverified"}:await no(t,l,w);if(!w)return c.reason="no-origin-tag",globalThis.__lastVerify=c,{state:"unverified"};const k=await oo(t,w,f("type"));if(c.verifyOrdinal=k,k.origin&&i)try{k.contentUrl=i(k.origin)}catch(p){c.contentUrlError=String(p)}return globalThis.__lastVerify=c,k}catch(a){return c.error=String(a),globalThis.__lastVerify=c,{state:"unverified"}}}function Lt(t){if(!t||typeof t!="object")return!1;const s=t;return Array.isArray(s.panels)&&typeof s.title=="string"}var io=`
.opp-root {
  --opp-bg: #ffffff;
  --opp-fg: #111827;
  --opp-muted: #6b7280;
  --opp-card-bg: #f7f8fa;
  --opp-card-border: #eceef2;
  --opp-accent: #E5A920;
  --opp-approve-bg: #E5A920;
  --opp-approve-fg: #ffffff;
  --opp-reject-bg: #ffffff;
  --opp-reject-fg: #111827;
  --opp-reject-border: #d1d5db;
  --opp-status-bg: #FFFBE6;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #ECFDF5;
  --opp-trust-ok-fg: #059669;
  --opp-trust-warn-bg: #FFFBEB;
  --opp-trust-warn-fg: #D97706;
  --opp-trust-bad-bg: #FEF2F2;
  --opp-trust-bad-fg: #DC2626;

  font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--opp-bg);
  color: var(--opp-fg);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 480px;
  min-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
}

.opp-bottom {
  margin-top: auto;
  display: flex;
  flex-direction: column;
}

.opp-root.opp-dark {
  --opp-bg: #0F1117;
  --opp-fg: #F9FAFB;
  --opp-muted: #9ca3af;
  --opp-card-bg: #1A1D27;
  --opp-card-border: #232636;
  --opp-reject-bg: #0F1117;
  --opp-reject-fg: #F9FAFB;
  --opp-reject-border: #2D3142;
  --opp-status-bg: #2A2408;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #0A2E1F;
  --opp-trust-ok-fg: #34D399;
  --opp-trust-warn-bg: #2A2008;
  --opp-trust-warn-fg: #FBBF24;
  --opp-trust-bad-bg: #2A1215;
  --opp-trust-bad-fg: #F87171;
}

.opp-body {
  padding: 24px 20px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
}

.opp-coin {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
}

.opp-title {
  font-size: 16px;
  font-weight: 700;
  margin: 0;
  text-align: center;
}

.opp-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  margin: 0;
  text-align: center;
  line-height: 1.4;
}

.opp-status {
  background: var(--opp-status-bg);
  color: var(--opp-status-fg);
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
  margin-top: 4px;
  border: 1px solid var(--opp-card-border);
}

.opp-card {
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px;
  padding: 16px;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.opp-featured {
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px 8px;
  padding: 16px;
}

/* Subtle danger chrome for burn / destructive token ops */
.opp-featured-danger {
  border-color: rgba(220, 38, 38, 0.45);
  background: color-mix(in srgb, var(--opp-card-bg) 88%, #7f1d1d 12%);
}

.opp-featured-danger .opp-featured-title {
  color: #f87171;
}

.opp-featured-danger .opp-featured-image,
.opp-featured-danger .opp-featured-placeholder {
  border: 1px solid rgba(220, 38, 38, 0.35);
  background: rgba(127, 29, 29, 0.25);
  color: #fca5a5;
}

.opp-dark .opp-featured-danger {
  border-color: rgba(248, 113, 113, 0.4);
  background: color-mix(in srgb, var(--opp-card-bg) 85%, #450a0a 15%);
}

.opp-preview-pair {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.opp-preview-arrow {
  color: var(--opp-muted);
  font-size: 14px;
  line-height: 1;
}

.opp-preview-pair .opp-featured-image {
  width: 64px;
  height: 64px;
}

.opp-featured-image {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-featured-image-token {
  width: 48px;
  height: 48px;
  border-radius: 999px;
}

.opp-featured-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--opp-muted);
  font-size: 18px;
}

.opp-preview-opns {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
}

.opp-preview-opns-avatar {
  width: 36px;
  height: 36px;
  border-radius: 999px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-preview-opns-name {
  font-size: 11px;
  font-weight: 600;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  color: var(--opp-fg, inherit);
}

.opp-preview-text {
  margin: 0;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
  font-size: 9px;
  line-height: 1.25;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  color: var(--opp-muted);
}

.opp-preview-json {
  white-space: pre;
  overflow: auto;
}

.opp-preview-frame {
  border: 0;
  padding: 0;
  overflow: hidden;
  background: #fff;
  pointer-events: none;
}

.opp-preview-value {
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  background: rgba(229, 169, 32, 0.12);
  border: 1px solid rgba(229, 169, 32, 0.35);
  color: var(--opp-fg, inherit);
}

.opp-preview-value-icon {
  width: 32px;
  height: 32px;
  color: #E5A920;
}

/* Amount subtitles must never ellipsis — full sat counts are the point. */
.opp-featured-subtitle-text.opp-amount {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-variant-numeric: tabular-nums;
  white-space: normal;
  overflow: visible;
  text-overflow: unset;
  word-break: keep-all;
}

.opp-featured-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  flex: 1;
}

.opp-featured-title {
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.opp-featured-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.opp-featured-subtitle-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
}

.opp-featured-meta-line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  color: var(--opp-muted);
}

.opp-featured-meta-line-bare {
  align-items: center;
}

.opp-featured-meta-key {
  flex-shrink: 0;
  opacity: 0.75;
  min-width: 2.5em;
}

.opp-featured-meta-value {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  flex: 1;
}

.opp-featured-meta-value-mono {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 11px;
}

.opp-trust-wrap {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0 20px 8px;
}

.opp-trust {
  display: inline-flex;
  align-self: flex-start;
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 600;
}

.opp-trust-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-trust-note {
  padding: 10px;
  border-radius: 8px;
  font-size: 11px;
  line-height: 1.35;
}

.opp-trust-note-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-note-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-note-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.opp-row-key {
  color: var(--opp-muted);
  flex-shrink: 0;
}

.opp-row-value-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 70%;
  justify-content: flex-end;
}

.opp-row-value {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 12px;
  font-weight: 500;
  text-align: right;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.opp-copy {
  flex-shrink: 0;
  width: 22px;
  height: 22px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  border: 1px solid var(--opp-reject-border);
  background: var(--opp-bg);
  color: var(--opp-fg);
  cursor: pointer;
}

.opp-copy:hover {
  border-color: var(--opp-accent);
  color: var(--opp-accent);
}

.opp-fee-note {
  font-size: 11px;
  color: var(--opp-muted);
  line-height: 1.3;
  margin-top: -4px;
}

.opp-actions {
  display: flex;
  gap: 12px;
  padding: 20px 20px 12px;
}

.opp-button {
  flex: 1;
  padding: 0 16px;
  height: 48px;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid transparent;
  transition: opacity 120ms ease;
}

.opp-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.opp-button-reject {
  background: var(--opp-reject-bg);
  color: var(--opp-reject-fg);
  border-color: var(--opp-reject-border);
}

.opp-button-approve {
  background: var(--opp-approve-bg);
  color: var(--opp-approve-fg);
}

.opp-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 20px 16px;
  font-size: 11px;
  font-weight: 500;
  color: var(--opp-muted);
}
`;function lo({request:t,onApprove:s,onReject:n,theme:o="auto",services:i}){const r=yo(o),d=co(t),[c,a]=u.useState(!1),[f,m]=u.useState(),g=t.kind==="transaction"&&Lt(t.payload)?t.payload:void 0;u.useEffect(()=>{if(!i||!g?.trust||!g.verify)return;let p=!0;const b=i.ordfs?.getContentUrl?.bind(i.ordfs);return ao(i,g.verify.kind,g.verify.inputs,g.verify.outputs,b).then(S=>{p&&S&&m(S)}).catch(()=>{}),()=>{p=!1}},[i,g]);const l=f?po(d,f):d,w=p=>()=>{if(!c){a(!0);try{p==="approve"?s():n()}finally{a(!1)}}};u.useEffect(()=>{const p=b=>{c||(b.key==="Escape"?n():b.key==="Enter"&&s())};return window.addEventListener("keydown",p),()=>window.removeEventListener("keydown",p)},[s,n,c]);const k=`opp-root${r==="dark"?" opp-dark":""}`;return e.jsxs("div",{className:k,children:[e.jsx("style",{children:io}),e.jsxs("div",{className:"opp-body",children:[e.jsxs("svg",{className:"opp-coin",viewBox:"0 0 100 100","aria-label":"1Sat Ordinals",children:[e.jsx("circle",{cx:"50",cy:"50",r:"50",fill:"#222"}),e.jsx("circle",{cx:"50",cy:"50",r:"40",fill:"#fff"}),e.jsx("circle",{cx:"50",cy:"50",r:"32",fill:"#E5A920"}),e.jsx("rect",{x:"47",y:"28",width:"6",height:"28",rx:"3",fill:"#fff"})]}),e.jsx("h2",{className:"opp-title",children:l.title}),e.jsx("p",{className:"opp-subtitle",children:l.subtitle}),e.jsx("div",{className:"opp-status",children:"Awaiting Approval"})]}),l.panels.map((p,b)=>{const S=p.variant??"ordinal",x=["opp-featured"];return S==="token"&&x.push("opp-featured-token"),S==="value"&&x.push("opp-featured-value"),p.tone==="danger"&&x.push("opp-featured-danger"),e.jsxs("div",{className:x.join(" "),children:[p.prior?e.jsxs("div",{className:"opp-preview-pair","aria-label":"Previous and new inscription",children:[e.jsx(Ve,{panel:{...p,previewKind:p.prior.previewKind,imageUrl:p.prior.imageUrl,contentUrl:p.prior.contentUrl,previewText:p.prior.previewText,prior:void 0}}),e.jsx("span",{className:"opp-preview-arrow","aria-hidden":!0,children:"→"}),e.jsx(Ve,{panel:p})]}):e.jsx(Ve,{panel:p}),e.jsxs("div",{className:"opp-featured-meta",children:[e.jsx("div",{className:"opp-featured-title",children:p.title}),p.subtitle&&e.jsxs("div",{className:"opp-featured-subtitle",children:[e.jsx("span",{className:p.amountSats!=null?"opp-featured-subtitle-text opp-amount":"opp-featured-subtitle-text",children:p.subtitle}),p.subtitleCopy&&e.jsx(Ke,{text:p.subtitleCopy})]}),(p.meta??[]).map(y=>e.jsxs("div",{className:`opp-featured-meta-line${y.key?"":" opp-featured-meta-line-bare"}`,children:[y.key?e.jsx("span",{className:"opp-featured-meta-key",children:y.key}):null,e.jsx("span",{className:`opp-featured-meta-value${y.key?"":" opp-featured-meta-value-mono"}`,title:y.copyValue??y.value,children:y.value}),y.copyValue&&e.jsx(Ke,{text:y.copyValue})]},`${y.key}:${y.value}`))]})]},`panel-${b}-${p.title}`)}),l.trust&&e.jsxs("div",{className:"opp-trust-wrap",children:[e.jsx("span",{className:`opp-trust opp-trust-${l.trust.state}`,children:ho(l.trust.state)}),l.trust.note&&e.jsx("div",{className:`opp-trust-note opp-trust-note-${l.trust.state}`,children:l.trust.note})]}),(l.rows.length>0||l.indexerFee||l.funding)&&e.jsxs("div",{className:"opp-card",children:[l.rows.map(p=>e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:p.key}),e.jsxs("span",{className:"opp-row-value-wrap",children:[e.jsx("span",{className:"opp-row-value",title:p.copyValue??p.value,children:p.value}),p.copyValue&&e.jsx(Ke,{text:p.copyValue})]})]},`${p.key}:${p.value}`)),l.indexerFee&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"1Sat Overlay Fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[bt(l.indexerFee.sats)," sats"]})]}),l.funding?.networkFeeSats!=null&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"Network fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[bt(l.funding.networkFeeSats)," sats"]})]}),l.funding?.note&&e.jsx("div",{className:"opp-fee-note",children:l.funding.note})]}),e.jsxs("div",{className:"opp-bottom",children:[e.jsxs("div",{className:"opp-actions",children:[e.jsx("button",{type:"button",className:"opp-button opp-button-reject",onClick:w("reject"),disabled:c,children:"Reject"}),e.jsx("button",{type:"button",className:"opp-button opp-button-approve",onClick:w("approve"),disabled:c,children:"Approve"})]}),e.jsx("div",{className:"opp-footer",children:e.jsx("span",{children:"Secured by 1Sat Ordinals"})})]})]})}function co(t){if(t.kind==="transaction"&&Lt(t.payload))return{title:t.payload.title,subtitle:t.payload.subtitle,panels:t.payload.panels,rows:t.payload.rows,trust:t.payload.trust,indexerFee:t.payload.indexerFee,funding:t.payload.funding};if(t.kind==="basketAccess"){const s=t.payload.baskets??[],n=s.length>0&&s.every(r=>r.scope||r.basket.startsWith("p ")),o=s.filter(r=>r.imageUrl||r.name||r.value).map(r=>({title:r.scope==="collection"?r.name?`Collection · ${r.name}`:"Collection":r.scope?r.scope:"Basket",subtitle:r.value?r.value.length>24?`${r.value.slice(0,10)}…${r.value.slice(-10)}`:r.value:r.basket,subtitleCopy:r.value,...r.imageUrl&&{previewKind:"image",contentUrl:r.imageUrl,imageUrl:r.imageUrl},tone:"default"})),i=s.flatMap(r=>r.scope==="collection"?r.description?[{key:"Access",value:r.description}]:[]:[{key:r.basket,value:r.description??"List, insert, and remove outputs"}]);return{title:n?s.length===1?s[0].scope==="collection"?"Grant Collection View":"Grant Item View":`Grant View (${s.length})`:s.length===1?"Grant Basket Access":`Grant Access to ${s.length} Baskets`,subtitle:n?`${Ne(t.originator)} wants to view items in your wallet`:`${Ne(t.originator)} wants to read and write 1Sat baskets`,panels:o,rows:i}}return t.kind==="protocol"?{title:"Protocol Access",subtitle:`${Ne(t.originator)} wants protocol access`,panels:[],rows:[{key:"Detail",value:t.summary||"Protocol request"}]}:{title:"Signature Request",subtitle:`${Ne(t.originator)} wants a signature`,panels:[],rows:[{key:"Detail",value:t.summary||"Signature request"}]}}function po(t,s){const n=t.panels.map((o,i)=>{if(i!==0)return o;const r=o.previewKind==="opns",d=s.contentType?uo(s.contentType):void 0,c=r?"opns":d&&d!=="none"?d:o.previewKind,a=s.contentUrl??o.contentUrl??o.imageUrl;let f=o.subtitle;if(s.name&&!r)if(!f)f=s.name;else{const m=f.trim().split(/\s+/);m.length>=2&&(m[m.length-1]=s.name,f=m.join(" "))}return{...o,previewKind:c,...f?{subtitle:f}:{},...r?{...s.contentUrl&&!o.imageUrl?{imageUrl:s.contentUrl}:o.imageUrl?{imageUrl:o.imageUrl}:{}}:c==="image"?{imageUrl:a,contentUrl:a}:a?{contentUrl:a,imageUrl:void 0}:{}}});return{...t,panels:n,trust:{state:s.state,note:s.note}}}function uo(t){const s=t.toLowerCase();return s==="image/svg+xml"||s==="svg"||s.endsWith("+svg")?"svg":s.startsWith("image/")?"image":s.includes("json")?"json":s.includes("html")||s==="application/xhtml+xml"?"html":s.startsWith("text/")?"text":"none"}function fo(t){return`${t.toLocaleString("en-US")} sats`}function bt(t){return t.toLocaleString("en-US")}function ho(t){return t==="verified"?"Verified":t==="mismatch"?"Mismatch":"Unverified"}function Ve({panel:t}){const s=t.variant??"ordinal",n=s==="token"?"opp-featured-image opp-featured-image-token":s==="value"?"opp-featured-image opp-preview-value":"opp-featured-image",o=t.previewKind??(t.imageUrl?"image":"none"),i=t.contentUrl??t.imageUrl,[r,d]=u.useState(!1);if(s==="value"){const c=t.valueIcon??"pay";return e.jsx("div",{className:n,title:t.amountSats!=null?fo(t.amountSats):void 0,"aria-hidden":!0,children:e.jsx(xo,{kind:c})})}if(o==="opns"){const c=!!t.imageUrl&&!r;return e.jsxs("div",{className:`${n} opp-preview-opns`,"aria-hidden":!t.opnsHero,children:[c?e.jsx("img",{className:"opp-preview-opns-avatar",src:t.imageUrl,alt:"",onError:()=>d(!0)}):e.jsx("div",{className:"opp-preview-opns-avatar opp-featured-placeholder",children:"◈"}),e.jsx("span",{className:"opp-preview-opns-name",title:t.opnsHero,children:t.opnsHero??"OpNS"})]})}return o==="image"&&t.imageUrl&&!r?e.jsx("img",{className:n,src:t.imageUrl,alt:t.title,onError:()=>d(!0)}):o==="image"&&r?e.jsx("div",{className:`${n} opp-featured-placeholder`,"aria-hidden":!0,children:"▭"}):(o==="text"||o==="json"||o==="html")&&t.previewText?e.jsx("pre",{className:`${n} opp-preview-text${o==="json"?" opp-preview-json":""}`,children:t.previewText}):(o==="text"||o==="json")&&i?e.jsx(go,{url:i,kind:o,className:n}):(o==="html"||o==="svg")&&i?e.jsx("iframe",{className:`${n} opp-preview-frame`,src:i,title:`${t.title} preview`,sandbox:"",referrerPolicy:"no-referrer"}):e.jsx("div",{className:`${n} opp-featured-placeholder`,"aria-hidden":!0,children:s==="token"?"◎":mo(o)})}function mo(t){return t==="text"||t==="json"?"¶":t==="html"||t==="svg"?"⌂":"▭"}function xo({kind:t}){return t==="lock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V8a4 4 0 018 0v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):t==="unlock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V7.5A4 4 0 0116 7",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("path",{d:"M16 4.5v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"9",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M12 7v10M9 10.5c0-1.4 1.3-2.5 3-2.5s3 1.1 3 2.5-1.3 2.5-3 2.5-3 1.1-3 2.5 1.3 2.5 3 2.5 3-1.1 3-2.5",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})}function go({url:t,kind:s,className:n}){const[o,i]=u.useState(null),[r,d]=u.useState(!1);return u.useEffect(()=>{let c=!1;return i(null),d(!1),fetch(t).then(async a=>{if(!a.ok)throw new Error(String(a.status));const f=await a.text();if(!c){if(s==="json")try{i(JSON.stringify(JSON.parse(f),null,2));return}catch{}i(f.slice(0,800))}}).catch(()=>{c||d(!0)}),()=>{c=!0}},[t,s]),r?e.jsx("div",{className:`${n} opp-featured-placeholder`,"aria-hidden":!0,children:"¶"}):e.jsx("pre",{className:`${n} opp-preview-text${s==="json"?" opp-preview-json":""}`,children:o??"…"})}function Ke({text:t}){const[s,n]=u.useState(!1),o=()=>{navigator.clipboard?.writeText(t).then(()=>{n(!0),window.setTimeout(()=>n(!1),1200)})};return e.jsx("button",{type:"button",className:"opp-copy",onClick:o,"aria-label":s?"Copied":"Copy full value",title:s?"Copied":"Copy",children:s?e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:e.jsx("path",{d:"M5 13l4 4L19 7",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round"})}):e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"9",y:"9",width:"11",height:"11",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M5 15V5a2 2 0 012-2h10",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})})}function yo(t){const[s,n]=u.useState(()=>t==="auto"?bo():t);return u.useEffect(()=>{if(t!=="auto"){n(t);return}const o=window.matchMedia("(prefers-color-scheme: dark)"),i=()=>n(o.matches?"dark":"light");return i(),o.addEventListener("change",i),()=>o.removeEventListener("change",i)},[t]),s}function bo(){return typeof window>"u"||!window.matchMedia?"light":window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function Ne(t){try{return new URL(t.includes("://")?t:`https://${t}`).host||t}catch{return t.length<=32?t:`${t.slice(0,14)}…${t.slice(-12)}`}}const vo=({request:t,onResponse:s})=>{const{theme:n}=W(),{handleSelect:o,hideMenu:i}=ye(),{apiContext:r,chromeStorageService:d}=Z(),c=r?.services;u.useEffect(()=>{o("bsv"),i()},[o,i]);const[a,f]=u.useState(""),m=u.useRef(!1),g=async k=>{if(!m.current){if(m.current=!0,k){f("");const p=await ce(d);if(!p.ok){f(p.message),m.current=!1;return}}O({action:"ONE_SAT_PERMISSION_RESPONSE",requestID:t.requestID,approved:k}),s()}},w=n.color.global.walletBackground.toLowerCase()==="#000000"||/^#[01]/.test(n.color.global.walletBackground)?"dark":"light";return e.jsxs("div",{style:{width:"100%",height:"100%",overflowY:"auto",display:"flex",flexDirection:"column",alignItems:"stretch",justifyContent:"center"},children:[a&&e.jsx("p",{className:"text-xs text-center m-0 pt-2",style:{color:"#ef4444"},children:a}),e.jsx(lo,{request:t.request,onApprove:()=>{g(!0)},onReject:()=>{g(!1)},theme:w,services:c})]})},wo=t=>{switch(t){case"protocol":return"Protocol Permission";case"basket":return"Basket Access";case"certificate":return"Certificate Access";case"spending":return"Spending Authorization";default:return"Permission Request"}},jo=t=>{switch(t.type){case"protocol":{const s=Dt(t.protocolID);return s?s.description:`An application is requesting permission to use protocol "${t.protocolID?.[1]||"unknown"}" with security level ${t.protocolID?.[0]||0}.`}case"basket":return`An application is requesting access to basket "${t.basket||"unknown"}".`;case"certificate":return"An application is requesting access to certificate data.";case"spending":return`An application is requesting authorization to spend ${t.spending?.satoshis||0} satoshis.`;default:return"An application is requesting a permission."}},ko=t=>{const{request:s,onResponse:n}=t,{theme:o}=W(),i=$t(),{handleSelect:r,hideMenu:d}=ye(),{addSnackbar:c}=Ie(),[a,f]=u.useState(!1),[m,g]=u.useState(""),{chromeStorageService:l}=Z();u.useEffect(()=>{r("bsv"),d()},[r,d]);const w=async()=>{f(!0),g("");try{const p=await ce(l);if(!p.ok){g(p.message),f(!1);return}Te(s.originator),O({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!0}),n()}catch(p){const b=p instanceof Error?p.message:String(p);c(b,"error"),f(!1)}},k=async()=>{f(!0),O({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!1}),n()};return e.jsxs(F.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(Ss,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:wo(s.type)}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:jo(s)})]})]}),e.jsxs(F.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"12rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Origin"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.displayOriginator||s.originator})]}),e.jsxs(K,{when:s.type==="protocol"&&!!s.protocolID,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Protocol"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:At(s.protocolID)})]}),e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.counterparty?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Security"}),e.jsx("span",{className:"text-xs",style:{color:o.color.global.contrast},children:Ys(s.protocolID?.[0])})]}),e.jsx(K,{when:!!s.counterparty,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.counterparty})]})})]}),e.jsx(K,{when:s.type==="basket"&&!!s.basket,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Basket"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.basket})]})}),e.jsxs(K,{when:s.type==="certificate"&&!!s.certificate,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Cert Type"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.certType})]}),e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Fields"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.fields.join(", ")})]})]}),e.jsxs(K,{when:s.type==="spending"&&!!s.spending,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.spending?.lineItems?.length?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Amount"}),e.jsx(Ns,{sats:s.spending?.satoshis||0,price:i,size:24,align:"left",color:"var(--bw-accent-hi)",mutedColor:o.color.global.gray})]}),e.jsx(K,{when:!!s.spending?.lineItems?.length,children:s.spending?.lineItems?.map((p,b)=>e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:b<(s.spending?.lineItems?.length??0)-1?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:p.type}),e.jsxs("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:[p.description," (",Q(p.satoshis,i).main," ·"," ",Q(p.satoshis,i).sub,")"]})]},b))})]}),e.jsx(K,{when:!!s.reason,children:e.jsxs("div",{className:"flex flex-row py-2",style:{borderTop:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Reason"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.reason})]})})]}),e.jsx(K,{when:!!s.privileged,children:e.jsxs(F.div,{className:"flex items-start gap-2 rounded-xl px-3 py-2.5 mb-4",style:{background:"rgba(245,166,35,0.08)",border:"1px solid rgba(245,166,35,0.15)"},initial:{opacity:0},animate:{opacity:1},transition:{delay:.12},children:[e.jsx(us,{size:14,className:"mt-0.5 flex-shrink-0",style:{color:"#f5a623"}}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:"#f5a623"},children:"This is a privileged operation"})]})}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[m&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:m}),e.jsxs(F.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:a?.6:1},disabled:a,onClick:w,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[a&&e.jsx(Qe,{size:14,className:"animate-spin"}),"Allow"]}),e.jsx(F.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:a?.5:1},disabled:a,onClick:k,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny"})]})]})},So=({request:t,onResponse:s})=>{const{theme:n}=W(),{chromeStorageService:o}=Z(),[i,r]=u.useState(""),[d,c]=u.useState(!1),a=async g=>{if(!d){if(c(!0),r(""),g){const l=await ce(o);if(!l.ok){r(l.message),c(!1);return}}O({action:"USB_CHECK_RESPONSE",requestID:t.requestID,ok:g}),s()}},f=n.color.global.gray,m=n.color.global.contrast;return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(fs,{size:40,style:{color:m}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:m},children:"Confirm your USB key"}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:f,maxWidth:"18rem"},children:[t.originator?`${t.originator} is asking bWallet to ${t.reason}.`:`A site is asking bWallet to ${t.reason}.`," ","Insert your USB key, then confirm."]}),i&&e.jsx("p",{className:"m-0 text-xs",style:{color:"#ef4444"},children:i}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(A,{theme:n,type:"primary",label:"Confirm USB key",disabled:d,onClick:()=>{a(!0)}}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Cancel",disabled:d,onClick:()=>{a(!1)}})]})]})},No="once:",Eo=t=>typeof t=="string"&&t.startsWith(No),Ft=/\b(auth|authentication|sign[- ]?in|login|log[- ]?in)\b/i,vt="0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798",Ro=t=>{if(t==="anyone")return!0;if(typeof t!="string"||!/^[0-9a-fA-F]{66}$|^[0-9a-fA-F]{130}$/.test(t.trim()))return!1;const s=t.trim().toLowerCase();if(s===vt)return!0;try{return cs.fromString(s).toString()===vt}catch{return!1}},Co=new Set(["2:bwallet sign in","2:bads session","2:auth message signature"]),$o=t=>`${t[0]}:${t[1].trim().toLowerCase()}`,Po=t=>{if(typeof t!="string")return!1;const s=t.trim().toLowerCase();return Ft.test(s)||s==="message signing"},Io=t=>{const s=To(t);return!!s&&Co.has($o(s))};function To(t){return Array.isArray(t)&&t.length===2&&typeof t[0]=="number"&&typeof t[1]=="string"?[t[0],t[1]]:null}const Do=t=>{const s=t.map(o=>o.recipientsHash?`${o.requestID}#${o.recipientsHash}`:o.requestID).sort().join(`
`);let n=2166136261;for(let o=0;o<s.length;o++)n^=s.charCodeAt(o),n=Math.imul(n,16777619)>>>0;return`${t.length}:${n.toString(16)}`},Ao=5,Oo=/e-?mail|phone|mobile|kyc|passport|licen[cs]e|birth|dob|address|ssn|national|tax|id_?number/i,se=t=>String(t.protocolID?.[1]??"unknown"),le=t=>Number(t.protocolID?.[0]??0),Ut=t=>!!(t.privileged||t.type==="certificate"&&(t.certificate?.fields??[]).some(s=>Oo.test(s))||be(t)),Ze=t=>t.type==="protocol"&&!t.privileged&&t.protocolID?.[1]==="identity key retrieval"&&(t.counterparty===void 0||t.counterparty==="self"),Lo=Ft,Pe=t=>{const s=t.calls??[],n=(...o)=>s.length>0&&s.every(i=>o.includes(i));switch(t.usageType){case"signing":return n("verifySignature")?"verify":"sign";case"encrypting":return n("encrypt")?"encrypt":n("decrypt")?"decrypt":"encryptDecrypt";case"hmac":return"hmac";case"linkageRevelation":return"linkage";case"publicKey":return"publicKey";case"generic":return"generic";default:return"other"}},xe=t=>Ro(t.counterparty),et=t=>t.type!=="protocol"?!1:be(t)?!0:Ze(t)||ge(t)||t.usageType==="generic"||t.usageType==="identityKey"?!1:le(t)===1?Po(se(t)):le(t)===2&&xe(t)&&!Io(t.protocolID),be=t=>Eo(t.requestID),Fo=t=>{const s=Pe(t);return s==="sign"||s==="other"},_t=t=>t.type==="protocol"&&!t.privileged&&!et(t)&&(Ze(t)||le(t)!==1&&Fo(t)&&(xe(t)||Lo.test(se(t))&&(t.counterparty===void 0||t.counterparty==="self"))),Uo=[[/agent history/i,"Ask b chats"],[/\b(chat|message)s?\b/i,"chats"],[/\bnotes?\b/i,"notes"],[/\b(history|private|backup|vault|encrypt)/i,"data"]],Mt=t=>{if(t.type!=="protocol"||t.privileged||t.counterparty!=="self"||_t(t))return;const s=se(t);return Uo.find(([n])=>n.test(s))?.[1]},_o="bap",Mo=[1,"sigma"],ge=t=>t.type==="protocol"&&!t.privileged&&se(t).toLowerCase()===Mo[1],Xe=t=>t.type==="basket"&&t.basket===_o,Bt={verify:"Check signatures with",encrypt:"Encrypt with",decrypt:"Decrypt with",encryptDecrypt:"Encrypt and decrypt with",hmac:"Make and check HMAC codes with",linkage:"Reveal how others can link",publicKey:"See a public key from"},Je=t=>t.originator,Bo=t=>{const s=se(t),n=Je(t);if(be(t))return Pe(t)==="hmac"?`Make one code as you for ${n} ("${s}"). The service it is for could accept it as you`:`Sign once as you for ${n} ("${s}"). Other sites could accept this too`;const o=Pe(t);return o==="sign"||o==="other"?xe(t)?`Sign as you for ${n} ("${s}"), a signature anyone can check`:`Sign with your "${s}" keys for ${n}`:`${o==="generic"?"Use":Bt[o]} your "${s}" keys for ${n}`},wt=t=>{switch(t.type){case"protocol":{if(Ze(t))return"See your public identity (the key that names you)";if(et(t))return Bo(t);const s=Pe(t),n=se(t),o=s!=="sign"&&s!=="generic"&&s!=="other"?Bt[s]:"";if(le(t)===1&&!ge(t)&&s!=="generic")return o?`${o} your "${n}" keys for ${Je(t)}`:`Sign with your "${n}" keys for ${Je(t)}`;if(xe(t)){if(s==="sign"||s==="other")return"Prove it's you (a signature anyone can check)";if(s==="encrypt")return`Encrypt with your "${n}" keys, readable by anyone`;if(o)return`${o} your "${n}" keys`}if(ge(t))return"Sign your posts and likes as you";const i=Mt(t);return i?`Use keys from your wallet for your ${i}`:le(t)===2&&t.counterparty&&t.counterparty!=="self"&&!xe(t)?o?`${o} your "${n}" keys, shared with one named person or service`:`Sign and encrypt with your "${n}" keys, shared with one named person or service`:o?`${o} your "${n}" keys`:`Sign and encrypt anything with your "${n}" keys`}case"basket":return Xe(t)?"Use your public profile (name and picture) on its posts":"Keep its tickets and tokens in your wallet";case"certificate":{const s=t.certificate?.fields??[];return s.length?`See your certificate details (${s.join(", ")})`:"See your certificates"}default:return"Spend from your wallet"}},zt=t=>(t??[]).map((s,n)=>({x:s,i:n})).sort((s,n)=>n.x.satoshis-s.x.satoshis||s.i-n.i).map(({x:s})=>s),Ge=t=>{const s=[];switch(t.type){case"protocol":s.push(`protocol "${se(t)}" level ${le(t)}`),t.counterparty&&s.push(`counterparty ${t.counterparty}`);break;case"basket":s.push(Ct(t.basket)==="Unknown basket"?"Unknown basket":`basket "${t.basket}"`);break;case"certificate":s.push(`certificate ${t.certificate?.certType??""}`,`verifier ${t.certificate?.verifier??""}`);break;case"spending":s.push(`${t.spending?.satoshis??0} sats`),t.labels?.length&&s.push(`labels: ${t.labels.join(", ")}`);break}return t.privileged&&s.push("privileged"),t.reason&&s.push(`reason: ${t.reason}`),s.join(" · ")},zo=t=>{const s=[];let n;for(const r of t.items){if(r.type==="spending"){const f=r.spending?.satoshis??0;!n&&!r.addedLive?n={requestID:r.requestID,satoshis:f,description:r.spending?.lineItems?.find(m=>m.description)?.description??r.reason,detail:Ge(r),...r.labels?.length?{labels:[...r.labels]}:{},...r.recipients?.length||r.recipientsHash!==void 0?{recipients:(r.recipients??[]).map(m=>({...m}))}:{}}:s.push({requestID:r.requestID,text:`${r.addedLive?"New: pay":"Also pay"} ${f.toLocaleString()} sats`,detail:[Ge(r),...zt(r.recipients).map(m=>`to ${m.to}: ${m.satoshis} sats`)].join(" · "),risky:!0,checked:!1,...r.addedLive?{isNew:!0}:{}});continue}const d=be(r)&&!r.addedLive&&t.items.length===1,c=d?!1:Ut(r),a=d||!c&&!r.addedLive&&!et(r);s.push({requestID:r.requestID,...d?{once:!0}:{},text:r.addedLive?`New: ${wt(r)}`:wt(r),...r.addedLive?{isNew:!0}:{},detail:Ge(r),risky:c,checked:a,signIn:_t(r),privateLabel:Mt(r),...ge(r)||Xe(r)?{post:!0}:{}})}const o=n?s.length?"connectAndPay":"pay":"connect",i=t.items.some(ge)||t.items.some(Xe);return{originator:t.originator,lines:s,payment:n,mode:o,...i?{purpose:"post"}:{}}},Wo=(t,s)=>{const n=t.lines.filter(r=>!r.risky&&!r.isNew),o=n.find(r=>r.privateLabel)?.privateLabel,i=r=>{switch(s){case"signin":return r.signIn===!0;case"private":return r.signIn===!0&&r.checked||!!o&&r.privateLabel===o;case"post":return r.post===!0;case"connect":return r.checked;case"pay":case"mint":return r.signIn===!0&&r.checked;default:return!1}};return new Set(n.filter(i).map(r=>r.requestID))},qo=(t,s,n,o)=>({summarised:s?new Set:Wo(t,o),faceTicks:new Set(t.lines.filter(i=>s||i.isNew).map(i=>i.requestID)),hidden:new Set(n?t.lines.filter(i=>!n.has(i.requestID)).map(i=>i.requestID):[])}),Ho=(t,s)=>s?.hidden?.size?t.filter(n=>!s.hidden.has(n.requestID)):t,Vo=(t,s,n,o,i={})=>{const r={};for(const d of t.lines){if(!o&&i.hidden?.has(d.requestID))continue;const c=o||!!i.faceTicks?.has(d.requestID);if(s&&d.isNew&&n[d.requestID]===void 0)continue;if(!c&&!d.isNew&&!i.summarised?.has(d.requestID)){r[d.requestID]=!1;continue}const a=n[d.requestID]??(d.isNew?!1:d.checked||!d.risky&&!c);r[d.requestID]=s&&a}return t.payment&&(r[t.payment.requestID]=s),r},Ko=(t,s,n,o,i={})=>({decisions:Vo(t,s==="allow",n,o,i),block:s==="block",mayStore:s==="allow"}),Go=t=>Ut(t)||t.type==="protocol"&&t.counterparty==="anyone"?!1:t.type==="basket"?!!t.basket&&!Es(t.basket):!1,Yo=t=>!t.items.some(s=>s.framePair)&&t.items.some(s=>Go(s)),Xo=[.25,1,5],Jo=1,me=t=>t<1?`$${t.toFixed(2)}`:Number.isInteger(t)?`$${t}`:`$${t.toFixed(2)}`,Wt=t=>{const s=t.allowNone?[0,...t.presetsUsd]:[...t.presetsUsd];return e.jsx("div",{className:"flex flex-wrap",style:{gap:8},role:"radiogroup","aria-label":"Envelope amount",children:s.map(n=>{const o=t.value===n;return e.jsx("button",{type:"button",role:"radio","aria-checked":o,disabled:t.disabled,onClick:()=>t.onChange(n),style:{minHeight:44,padding:"0 16px",borderRadius:22,border:`1.5px solid ${o?v.gold:v.chip}`,background:o?v.gold:v.chip,color:o?v.bg:v.ink,fontSize:n?16:14,fontWeight:700,cursor:"pointer"},children:n?me(n):"No envelope"},n)})})};function Qo(t){return{allowDisabled:t.busy||!t.armed||t.hold||t.mustRead,denyDisabled:t.busy}}const Zo=(t,s)=>t.key==="Escape"&&!t.defaultPrevented&&!s,en="One approval: signs and seals",tn="Seal",sn=({seal:t})=>e.jsx(Re,{amount:`#${t.docHash.slice(0,8)}`,sub:"Document fingerprint, as under the document",badge:"SEAL",fontSize:"min(60px, 8vh)"}),on=({seal:t})=>e.jsx("span",{style:{color:v.gold},children:t.title}),nn=t=>{const{seal:s,feeText:n,signingAs:o}=t;return e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"seal-sheet",children:[e.jsxs("div",{className:"flex items-center gap-2 flex-wrap",style:{fontSize:15,fontWeight:600},"data-testid":"seal-signer",children:[e.jsx(R,{size:18}),"Signed as ",e.jsxs("span",{style:{color:v.gold},children:["$",s.handle.replace(/^\$/,"")]}),s.roles.length>0&&e.jsxs("span",{style:{color:v.muted,fontWeight:400},children:["· ",s.roles.join(", ")]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:15,fontWeight:600},"data-testid":"seal-cost",children:[e.jsx(R,{size:18}),"Network fee only, at most ",n]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs(T,{children:[e.jsx(R,{}),"Only on ",s.site]}),e.jsxs(T,{children:[e.jsx(R,{}),"Hashes on chain, not the document"]}),e.jsxs(T,{children:[e.jsx(R,{}),"Next payment asks again"]})]}),o&&e.jsxs("p",{className:"m-0","data-testid":"signing-as",style:{fontSize:12,color:v.muted},children:["Signing with ",o]})]})},jt=12,rn=17,an=({recipients:t})=>{if(!t)return null;const s=zt(t);if(s.length===0)return e.jsx("li",{"data-testid":"pay-recipient",children:"no outputs: only the network fee"});const n=s.map((i,r)=>e.jsxs("li",{"data-testid":"pay-recipient",children:["to ",i.to,": ",i.satoshis.toLocaleString()," sats"]},`to-${r}`));if(s.length<=jt)return e.jsx(e.Fragment,{children:n});const o=s.reduce((i,r)=>i+r.satoshis,0);return e.jsxs("li",{"data-testid":"pay-recipients-all",children:[s.length.toLocaleString()," outputs, ",o.toLocaleString()," sats in all, largest first:",e.jsx("ul",{className:"m-0 pl-4",style:{maxHeight:jt*rn,overflowY:"auto",overscrollBehavior:"contain"},children:n})]})},ln=3e3,cn=t=>{const{request:s,onResponse:n,armed:o=!0}=t,{handleSelect:i,hideMenu:r}=ye(),{addSnackbar:d}=Ie(),{chromeStorageService:c}=Z(),a=c.getCurrentAccountObject().account,f=Bs(a?.addresses?.identityAddress,a?.name??"",a?.settings?.socialProfile?.displayName??"",!1),m=Rs(f.displayName,f.paymail,f.handle).tag,g=Cs(a?.pubKeys?.identityPubKey),l=u.useMemo(()=>zo(s),[s]),[w,k]=u.useState({}),[p,b]=u.useState(!1),S=u.useRef(s.items.length);u.useEffect(()=>{if(s.items.length===S.current)return;S.current=s.items.length,b(!0);const h=setTimeout(()=>b(!1),1e3);return()=>clearTimeout(h)},[s.items.length]);const x=u.useRef(!1),y=()=>{x.current||(x.current=!0,J({action:"BUNDLE_SHEET_FREEZE",bundleID:s.bundleID}).catch(()=>{}))},E=(h,N)=>w[h]??N,[$,U]=u.useState(),[oe,De]=u.useState(Ao),[ve,C]=u.useState(!0),[G,Ae]=u.useState(0),[de,Ht]=u.useState(!0),st=u.useMemo(()=>Yo(s),[s]),[Oe,Vt]=u.useState(!0),[ot]=u.useState(()=>gt(l)!=="careful"),[pe,Le]=u.useState(!1),[Kt,nt]=u.useState("");u.useEffect(()=>{i("bsv"),r()},[i,r]),u.useEffect(()=>{J({action:"GET_BUNDLE_ALLOWANCE",originator:s.originator}).then(h=>{!h?.success||!h.data||(U(h.data),De(h.data.defaultUsd))}).catch(()=>{})},[s.originator]);const q=s.mint&&l.payment&&l.lines.every(h=>!h.risky)?s.mint:void 0,Y=s.items.length===1?s.items[0].seal:void 0,rt=!1,ue=!q&&l.payment&&$?.usdPerBsv?$.envelope:void 0,at=!!ue?.offer,we=$t($?.usdPerBsv),ee=l.payment?Q(l.payment.satoshis,we):void 0,ne=async h=>{const N=h==="allow";Le(!0),nt("");try{if(N){const I=await ce(c);if(!I.ok){nt(I.message),Le(!1);return}}N&&Te(s.originator);const j=Ko(l,h,w,ot,Ue),V=await J({action:"BUNDLE_PERMISSION_RESPONSE",seenHash:ts(h),bundleID:s.bundleID,decisions:j.decisions,allowanceUsd:j.mayStore&&rt&&ve?oe:0,envelopeUsd:j.mayStore&&at?G:0,remember:j.mayStore&&de,trustSite:!q&&!Y&&j.mayStore&&de&&st&&Oe,block:j.block});V&&V.success===!1&&V.error&&(d(V.error,"error"),await new Promise(I=>setTimeout(I,ln))),n()}catch(j){d(j instanceof Error?j.message:String(j),"error"),Le(!1)}},P=gt(l),L=It(s.originator),Gt=l.lines.length+(l.payment?1:0)>1,re=l.payment?qe(l.payment.satoshis,we):"",Yt=0,Fe=s.items.some(h=>h.reconnect),fe=s.items.find(h=>h.framePair)?.framePair,Xt=fe?"Allow inside this site":Fe?"Reconnect":q?`${q.title.split(" ")[0]} · ${re}`:Y?tn:P==="post"?l.payment?`Allow & pay ${re}`:"Allow posting":P==="signonce"?s.items[0]?.usageType==="hmac"?"Allow once":"Sign once":P==="private"?"Allow":P==="signin"?"Connect and sign in":P==="pay"?l.mode==="connectAndPay"?`Connect & pay ${re}`:`Pay ${re}`:Gt?"Allow all":"Connect",Jt=Ws(l.lines,h=>E(l.lines[h].requestID,l.lines[h].checked)),Qt=pe||!o||p,D=P==="careful",it=l.lines.filter(h=>h.risky),lt=l.lines.filter(h=>h.isNew&&!(D&&h.risky)),[Zt,es]=u.useState(()=>new Set),ct=u.useRef(null);u.useEffect(()=>{const h=ct.current,N=h?.closest("[data-approval-scroll]");if(!D||!h||!N)return;const j=()=>{const I=N.querySelector('[data-testid="approval-choices"]'),ze=Math.max(N.getBoundingClientRect().top,0),as=Math.min(I?I.getBoundingClientRect().top:window.innerHeight,window.innerHeight),We=[];N.querySelectorAll("[data-line-id]").forEach(ie=>{const he=ie.getBoundingClientRect();he.height>0&&he.top>=ze-1&&he.bottom<=as+1&&We.push(ie.dataset.lineId??"")}),es(ie=>We.every(he=>ie.has(he))?ie:new Set([...ie,...We]))};j();const V=setTimeout(j,700);return N.addEventListener("scroll",j,{passive:!0}),window.addEventListener("resize",j),()=>{clearTimeout(V),N.removeEventListener("scroll",j),window.removeEventListener("resize",j)}},[D,l]);const Ue=qo(l,D,D&&!ot?Zt:void 0,P),dt=D&&Ue.hidden.size>0,_e=u.useRef({busy:pe,send:ne});_e.current={busy:pe,send:ne},u.useEffect(()=>{const h=N=>{Zo(N,_e.current.busy)&&(N.preventDefault(),_e.current.send("notNow"))};return window.addEventListener("keydown",h),()=>window.removeEventListener("keydown",h)},[]);const pt=D?l.lines.filter(h=>!h.risky&&!h.isNew):[],ts=h=>Do(h==="allow"?Ho(s.items,Ue):s.items),ss=(h,N)=>k(j=>({...j,[h]:!E(h,N)})),je=(h,N=!1)=>e.jsxs("label",{"data-line-id":h.requestID,className:"flex items-start gap-3 cursor-pointer",style:{minHeight:44,padding:N?"10px 14px":"8px 0",borderRadius:N?14:0,background:N?v.redChip:void 0,fontSize:15},children:[e.jsx("input",{type:"checkbox",checked:E(h.requestID,h.checked),onChange:()=>ss(h.requestID,h.checked),style:{width:22,height:22,accentColor:h.risky?v.red:v.gold,flexShrink:0,marginTop:1}}),e.jsxs("span",{className:"flex flex-col min-w-0",style:{gap:2},children:[e.jsx("span",{style:{color:h.risky?"#FF6B6B":void 0,fontWeight:600,lineHeight:1.3},children:h.text}),h.detail&&e.jsx("span",{className:"break-all",style:{fontSize:12,color:v.muted},children:h.detail})]})]},h.requestID),ae=(m||g)&&e.jsxs("span",{children:[e.jsx("span",{style:{color:v.gold},children:m||"this account"}),g&&e.jsxs("span",{className:"font-mono",style:{userSelect:"none",fontSize:12,color:v.muted},children:[" ","· ",g]})]}),os=e.jsxs("div",{className:"flex flex-col",style:{gap:4},children:[(m||g)&&e.jsxs("p",{className:"m-0","data-testid":"signing-as",style:{fontSize:12},children:["Signing in as ",ae]}),!D&&l.lines.some(h=>!h.isNew)&&e.jsxs("p",{className:"m-0",style:{fontSize:13,fontWeight:700,color:v.muted},children:["This lets ",L,":"]}),!D&&l.lines.filter(h=>!h.isNew).map(h=>je(h)),l.payment&&e.jsxs("p",{className:"m-0",style:{padding:"6px 0"},children:["Pay ",e.jsx("span",{style:{color:v.gold,fontWeight:600},children:re})," now to ",s.originator,l.payment.description&&e.jsxs(e.Fragment,{children:[" “",l.payment.description,"”"]})]}),l.payment?.labels?.length?e.jsxs("p",{className:"m-0",style:{fontSize:13,color:v.muted},"data-testid":"payment-labels",children:["Labels: ",l.payment.labels.join(", ")]}):null,rt,e.jsxs("label",{className:"flex items-center gap-3 cursor-pointer",style:{minHeight:44},children:[e.jsx("input",{type:"checkbox",checked:de,onChange:()=>Ht(!de),style:{width:18,height:18,accentColor:v.gold,flexShrink:0}}),e.jsx("span",{children:"Remember this site"})]}),!q&&st&&de&&e.jsxs("label",{className:"flex items-start gap-3 cursor-pointer",style:{padding:"6px 0"},children:[e.jsx("input",{type:"checkbox",checked:Oe,onChange:()=>Vt(!Oe),style:{width:18,height:18,accentColor:v.gold,flexShrink:0,marginTop:1}}),e.jsxs("span",{children:["Don't ask again on ",s.originator," for sign-in and signing."," ",$?.allowances?"Payments stay within the allowance;":"Payments still ask, or use its envelope;"," ","your personal details always ask."]})]}),e.jsxs("ul",{className:"m-0 mt-1 pl-4 break-all",style:{fontSize:11,color:v.muted},children:[l.payment&&e.jsxs("li",{children:["pay: ",l.payment.detail]}),e.jsx(an,{recipients:l.payment?.recipients}),Yt>0]})]}),{allowDisabled:ns,denyDisabled:Me}=Qo({busy:pe,armed:o,hold:p,mustRead:dt}),ut={label:"Not now",onClick:()=>{ne("notNow")},disabled:Me},rs={label:"Block this site",onClick:()=>{ne("block")},disabled:Me},ft={label:(D?"I trust it, allow":Xt)+(Fe||q||Y?"":Jt),onClick:()=>{ne("allow")},disabled:ns,busy:pe};let _,M,B=null,z;const H=h=>e.jsx("span",{style:{color:v.gold},children:h}),Be=h=>qe(h,we);if(Y&&P!=="careful")_=e.jsx(sn,{seal:Y}),z=en,M=e.jsx(on,{seal:Y}),B=e.jsx(nn,{seal:Y,feeText:Be(Y.maxSats),signingAs:ae||void 0});else if(q&&P!=="careful")_=e.jsx(Re,{amount:ee?.main??"",sub:ee?.sub}),z="One approval for all of it",M=e.jsx(e.Fragment,{children:H(q.title)}),B=e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"mint-sheet",children:[e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:15,fontWeight:600},"data-testid":"mint-cost",children:[e.jsx(R,{size:18}),"Costs ",Be(q.premiumSats)," + ",Be(q.feeSats)," network fee"]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs(T,{children:[e.jsx(R,{}),"Locked with your keys"]}),e.jsxs(T,{children:[e.jsx(R,{}),"Only on ",q.site]}),e.jsxs(T,{children:[e.jsx(R,{}),"Next payment asks again"]})]})]});else if(P==="careful"){_=l.lines.length>0?null:e.jsx($s,{}),z="Check this carefully";const h=s.items.some(I=>I.privileged),N=it.some(I=>s.items.find(ze=>ze.requestID===I.requestID)?.type==="certificate"),j=I=>e.jsx("span",{style:{color:"#FF6B6B"},children:I}),V=s.items.some(I=>be(I));M=h?e.jsxs(e.Fragment,{children:["Wants ",j("full control")," of your keys"]}):N?e.jsxs(e.Fragment,{children:["Wants your ",j("private details")]}):V?e.jsxs(e.Fragment,{children:["Wants a signature ",j("other sites accept")]}):e.jsxs(e.Fragment,{children:["Wants ",j("more than usual")]}),B=e.jsxs("div",{ref:ct,className:"flex flex-col",style:{gap:8},children:[h&&e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:v.redChip,fontSize:14},children:[e.jsx(ke,{}),"Could move your money"]}),V&&e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"shared-key-warning",children:[e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:v.redChip,fontSize:14},children:[e.jsx(ke,{}),"Other sites could accept these as you"]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:v.soft},children:[e.jsx(R,{size:18}),"Each one is just this once"]})]}),it.map(I=>je(I,!0)),pt.length>0&&e.jsxs("div",{className:"flex flex-col","data-testid":"careful-ordinary-lines",style:{padding:"0 4px"},children:[e.jsx("p",{className:"m-0",style:{fontSize:12,fontWeight:700,color:v.muted},children:"Also asks to"}),pt.map(I=>je(I))]}),e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:v.redChip,fontSize:14},children:[e.jsx(ke,{}),"Only allow apps you trust"]})]})}else if(P==="pay")_=e.jsx(Re,{amount:ee?.main??"",sub:ee?.sub}),z=l.payment?.description||"Asks you to pay",M=e.jsxs(e.Fragment,{children:["Pay ",H(re)," now to ",H(L)]}),B=e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex items-center gap-3",style:{padding:14,borderRadius:16,background:v.chip},children:[e.jsx(Ps,{site:s.originator,size:44}),e.jsxs("div",{className:"flex flex-col min-w-0",style:{gap:2,lineHeight:1.25},children:[e.jsxs("span",{className:"truncate",style:{fontSize:15,fontWeight:600},children:["To ",s.originator]}),e.jsx("span",{className:"truncate",style:{fontSize:13,color:v.muted},children:l.payment?.description?`“${l.payment.description}”`:"Straight from your wallet"}),l.payment?.labels?.length?e.jsxs("span",{className:"truncate",style:{fontSize:12,color:v.muted},"data-testid":"payment-labels",children:["Labels: ",l.payment.labels.join(", ")]}):null]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:v.soft},children:[e.jsx(R,{size:18}),G>0?"Then small payments come out of the envelope":"Every payment asks you first"]}),at&&ue&&e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"envelope-offer",children:[e.jsx("span",{style:{fontSize:15,fontWeight:600},children:ue.balanceSats!==void 0?e.jsxs(e.Fragment,{children:["Top up the envelope",e.jsxs("span",{style:{fontSize:13,fontWeight:400,color:v.muted},children:[" ","· ",qe(ue.balanceSats,we)," left, not enough for this"]})]}):e.jsxs(e.Fragment,{children:[G>0?`Also put ${me(G)}`:"Also put money"," in ",H(L),"'s envelope?"]})}),e.jsx(Wt,{presetsUsd:ue.presetsUsd,value:G,onChange:Ae,allowNone:!0,disabled:Qt}),e.jsxs("span",{style:{fontSize:12,color:v.muted},children:["Stays in your wallet. Small payments from ",L," come out of it without asking; Coin return any time."]})]})]});else if(P==="post")_=e.jsx(Se,{site:s.originator}),z="Wants to post for you",M=e.jsxs(e.Fragment,{children:["Allow ",H(L)," to post for you"]}),B=e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs(T,{children:[e.jsx(R,{}),"Post and like as you"]}),e.jsxs(T,{children:[e.jsx(R,{}),"Nothing else moves"]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14},"data-testid":"post-cost",children:[e.jsx(R,{size:18}),ee?e.jsxs("span",{className:"flex flex-col",children:[e.jsxs("span",{children:["This post costs"," ",e.jsx("span",{style:{fontSize:20,fontWeight:800,color:v.gold},children:ee.main})]}),e.jsx("span",{style:{fontSize:12,color:v.muted},children:ee.sub})]}):"Each paid post asks you first"]})]});else if(P==="signonce"){const h=String(s.items[0]?.protocolID?.[1]??""),N=s.items[0]?.usageType==="hmac",j=V=>e.jsx("span",{style:{color:v.redSoft},children:V});_=null,z="One signature, check it",M=N?e.jsxs(e.Fragment,{children:["One code as you for ",j(L)]}):e.jsxs(e.Fragment,{children:["Sign once as you for ",j(L)]}),B=e.jsxs("div",{className:"flex flex-col",style:{gap:8,marginTop:4},"data-testid":"sign-once",children:[ae&&e.jsxs("span",{style:{fontSize:15},children:["as ",ae]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[h&&e.jsx(T,{tone:"red",children:e.jsxs("span",{"data-testid":"sign-once-protocol",children:["“",h,"”"]})}),e.jsxs(T,{tone:"red",children:[e.jsx(R,{}),"Just this once"]})]}),e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:v.redChip,fontSize:14},children:[e.jsx(ke,{}),"Other sites could accept it as you. Only sign if you trust ",L,"."]})]})}else if(P==="private")_=e.jsx(mt,{}),z="Your data",M=e.jsx(e.Fragment,{children:H(He("private",L,l))}),B=e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs(T,{children:[e.jsx(R,{}),"Uses keys from your wallet"]}),e.jsxs(T,{children:[e.jsx(R,{}),"No money moves"]})]});else if(fe)_=e.jsx(Se,{site:s.originator}),z=`Inside ${fe}`,M=e.jsxs(e.Fragment,{children:["Let ",H(L)," use your wallet inside ",H(fe),"?"]}),B=e.jsxs("div",{className:"flex flex-col",style:{gap:8,marginTop:4,fontSize:13},children:[e.jsxs("span",{children:[s.originator," is shown inside ",fe,". Only allow it if you opened it there yourself."]}),e.jsxs("span",{style:{color:v.muted,fontSize:12},children:["After this, what you already allowed ",s.originator," applies here too."]})]});else if(Fe&&P==="signin")_=e.jsx(Se,{site:s.originator}),z="You disconnected this site",M=e.jsxs(e.Fragment,{children:["Reconnect to ",H(L),"?"]}),B=e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs(T,{children:[e.jsx(R,{}),"Shares your public key"]}),e.jsxs(T,{children:[e.jsx(R,{}),"No money moves"]})]});else if(P==="signin")_=e.jsx(mt,{}),z="Connect and sign in",M=e.jsx(e.Fragment,{children:H(He("signin",L,l))}),B=e.jsxs(e.Fragment,{children:[ae&&e.jsxs("div",{className:"flex items-center gap-2.5",children:[e.jsx("div",{"aria-hidden":"true",style:{width:30,height:30,borderRadius:15,background:"conic-gradient(#F5C542, #B8860B, #FFE08A, #F5C542)",flexShrink:0}}),e.jsxs("span",{style:{fontSize:18,fontWeight:600},children:["as ",ae]})]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs(T,{children:[e.jsx(R,{}),"No password"]}),e.jsxs(T,{children:[e.jsx(R,{}),"No money moves"]})]})]});else{_=e.jsx(Se,{site:s.originator}),z="Wants to connect",M=e.jsx(e.Fragment,{children:H(He("connect",L,l))});const h=new Set(s.items.map(j=>j.type)),N=[{label:h.has("certificate")?"Your details":"Your name",icon:e.jsx(dn,{})}];h.has("protocol")&&N.push({label:"Sign posts",icon:e.jsx(pn,{})}),h.has("basket")&&N.push({label:"Keep items",icon:e.jsx(un,{})}),B=e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"grid",style:{gridTemplateColumns:`repeat(${N.length}, minmax(0, 1fr))`,gap:8},children:N.map(j=>e.jsxs("div",{className:"flex flex-col items-center",style:{gap:8,padding:"14px 6px",borderRadius:16,background:v.chip},children:[j.icon,e.jsx("span",{style:{fontSize:13,fontWeight:600,textAlign:"center"},children:j.label})]},j.label))}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:v.soft},children:[e.jsx(R,{size:18}),"Payments still ask you first"]})]})}return e.jsx(F.div,{className:"flex flex-col w-full h-full",style:{maxHeight:"100vh"},initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{type:"spring",damping:24,stiffness:260},"data-approval-kind":P,onPointerDownCapture:y,children:e.jsxs(Pt,{tone:D||P==="signonce"?"red":"gold",site:s.originator,siteSub:z,onClose:()=>{ne("notNow")},closeLabel:"Deny and close",closeDisabled:Me,hero:_,title:M,primary:D?ut:ft,secondary:D?ft:ut,tertiary:D||P==="signonce"?rs:void 0,error:Kt||(dt?"Scroll to read every line before allowing":""),children:[B,!(Y&&!D)&&e.jsx("div",{"data-testid":"approval-lines",style:{marginTop:8},children:os}),lt.length>0&&e.jsx("div",{className:"flex flex-col","data-testid":"new-lines",style:{gap:4,marginTop:8},children:lt.map(h=>je(h,!0))})]})})},tt={"aria-hidden":!0,width:28,height:28,viewBox:"0 0 24 24",fill:"none",stroke:v.gold,strokeWidth:1.8,strokeLinecap:"round",strokeLinejoin:"round"},dn=()=>e.jsxs("svg",{...tt,children:[e.jsx("circle",{cx:"12",cy:"8",r:"4"}),e.jsx("path",{d:"M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"})]}),pn=()=>e.jsxs("svg",{...tt,children:[e.jsx("path",{d:"M12 20h9"}),e.jsx("path",{d:"M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"})]}),un=()=>e.jsxs("svg",{...tt,children:[e.jsx("rect",{x:"3",y:"7",width:"18",height:"13",rx:"2"}),e.jsx("path",{d:"M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"})]}),kt=t=>`${(t/1e8).toFixed(8)} BSV`,Ee=t=>`$${t.toFixed(2)}`;function fn(t){const s=t.symbol?`$${t.symbol}`:"tokens",n=`${kt(t.priceSats)} (${Ee(t.usdAtRate)})`,o=[[t.side==="offer"?"You give":"You get",`${t.tokens} ${s}`],[t.side==="offer"?"You get":"You pay",n],["Contract price",t.terms.priceSats!==void 0?`${t.terms.priceSats.toLocaleString("en-US")} sats`:Ee(t.terms.priceUsd??0)],["Rate",`$${t.rate.toFixed(2)} per BSV (${t.rateSource})`]];t.overlayFeeSats>0&&o.push(["Indexing fee",kt(t.overlayFeeSats)]),o.push(["Contract",t.terms.ref],["Document hash",`${t.terms.docHash.slice(0,16)}…`]),t.terms.sellerKey&&o.push(["Seller wallet",`${t.terms.sellerKey.slice(0,16)}…`]),t.terms.expiresAt&&o.push(["Offer expires",new Date(t.terms.expiresAt).toISOString().replace("T"," ").slice(0,16)+" UTC"]);const i=t.side==="offer"?`Offer ${t.tokens} ${s} for ${Ee(t.usdAtRate)}`:`Swap ${Ee(t.usdAtRate)} for ${t.tokens} ${s}`,r=t.side==="offer"?`${t.split?`First the wallet sets aside exactly ${t.tokens} ${s} (a small token send to yourself). `:""}Then it signs your half only: your tokens move only in the buyer's transaction, which must pay you ${n}. Nothing is broadcast now.`:"One transaction: the tokens come to you and the price goes to the seller, with the contract hash on chain. If it does not broadcast, nothing moves.";return{title:i,rows:o,note:r,action:t.side==="offer"?"Sign offer":"Pay and swap"}}const hn=({request:t,onResponse:s})=>{const{theme:n}=W(),[o,i]=u.useState(!1),r=fn(t),d=n.color.global.gray,c=n.color.global.contrast,a=f=>{o||(i(!0),O({action:"SWAP_RESPONSE",requestID:t.requestID,allow:f}),s())};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 gap-3",children:[e.jsx(qs,{size:32,style:{color:c}}),e.jsx("h2",{className:"m-0 text-lg font-semibold text-center",style:{color:c},children:r.title}),e.jsx("div",{className:"flex flex-col gap-1.5 w-full",style:{maxWidth:"20rem"},"data-testid":"swap-rows",children:r.rows.map(([f,m])=>e.jsxs("div",{className:"flex justify-between gap-3 text-sm",children:[e.jsx("span",{style:{color:d},children:f}),e.jsx("span",{className:"text-right break-all",style:{color:c},children:m})]},f))}),e.jsx("p",{className:"m-0 text-xs leading-relaxed text-center",style:{color:d,maxWidth:"20rem"},children:r.note}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"20rem"},children:[e.jsx(A,{theme:n,type:"primary",label:r.action,disabled:o,onClick:()=>a(!0)}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Decline",disabled:o,onClick:()=>a(!1)})]})]})},mn=({request:t,onResponse:s})=>{const{theme:n}=W(),{chromeStorageService:o}=Z(),[i,r]=u.useState(!1),{pack:d,originator:c}=t,a=d.look,f=n.color.global.gray,m=n.color.global.contrast,g=l=>{if(!i){if(r(!0),l==="used"){const w=o.getCurrentAccountObject().account?.pubKeys?.identityPubKey??"";hs(w,d)}O({action:"THEME_OFFER_RESPONSE",requestID:t.requestID,answer:l}),s()}};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 gap-3",children:[e.jsx(Is,{size:32,style:{color:m}}),e.jsxs("h2",{className:"m-0 text-lg font-semibold text-center",style:{color:m},children:["Use the ",d.label," look?"]}),e.jsxs("p",{className:"m-0 text-xs text-center",style:{color:f},children:["Offered by ",e.jsx("strong",{style:{color:m},children:c})]}),e.jsxs("div",{"data-testid":"theme-offer-card","aria-hidden":"true",style:{width:"100%",maxWidth:"20rem",aspectRatio:"1.586",borderRadius:16,background:`linear-gradient(135deg, ${a.surface}, ${a.bg})`,border:`2px solid ${a.accent}`,padding:14,display:"flex",flexDirection:"column",justifyContent:"space-between",boxSizing:"border-box"},children:[e.jsx("span",{style:{display:"flex",gap:4},children:[a.accent,a.hi,a.lo,a.success,a.danger].map((l,w)=>e.jsx("i",{style:{width:18,height:18,borderRadius:999,background:l,display:"block"}},w))}),e.jsx("span",{style:{color:a.text,fontWeight:800,fontSize:18},children:d.label}),e.jsx("span",{style:{alignSelf:"flex-start",background:a.accent,color:a.on,borderRadius:999,padding:"4px 12px",fontSize:12,fontWeight:700},children:"$0.00"})]}),e.jsx("p",{className:"m-0 text-xs leading-relaxed text-center",style:{color:f,maxWidth:"20rem"},children:"Colours only. Switch back any time in Settings › Theme."}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"20rem"},children:[e.jsx(A,{theme:n,type:"primary",label:"Use it",disabled:i,onClick:()=>g("used")}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Not now",disabled:i,onClick:()=>g("declined")}),e.jsx(A,{theme:n,type:"secondary",label:"Never for this site",disabled:i,onClick:()=>g("never")})]})]})},xn=({request:t,onResponse:s})=>{const{theme:n}=W(),[o,i]=u.useState(!1),r=zs(t),d=n.color.global.gray,c=n.color.global.contrast,a=f=>{o||(i(!0),O({action:"TWETCH_RESPONSE",requestID:t.requestID,allow:f}),s())};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(Ts,{size:36,style:{color:c}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:c},children:r.title}),t.kind==="post"&&e.jsx("p",{className:"m-0 text-sm leading-relaxed whitespace-pre-wrap break-words",style:{color:c,maxWidth:"18rem"},"data-testid":"twetch-preview",children:t.preview}),e.jsx("p",{className:"m-0 text-xs leading-relaxed",style:{color:d,maxWidth:"18rem"},children:r.body}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(A,{theme:n,type:"primary",label:r.approve,disabled:o,onClick:()=>a(!0)}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Decline",disabled:o,onClick:()=>a(!1)})]})]})},gn=({request:t,onResponse:s})=>{const{theme:n}=W(),[o,i]=u.useState(!1),r=n.color.global.gray,d=n.color.global.contrast,c=a=>{o||(i(!0),O({action:"PROVE_HOLDINGS_RESPONSE",requestID:t.requestID,allow:a}),s())};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(Hs,{size:36,style:{color:d}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:d},children:"Show your tokens in bChatX?"}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:r,maxWidth:"18rem"},children:[t.originator," can then see which wallet addresses hold your tokens, so your rooms and swaps work. Your wallet signs a message for each one. Nothing is spent."]}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(A,{theme:n,type:"primary",label:"Allow",disabled:o,onClick:()=>c(!0)}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Not now",disabled:o,onClick:()=>c(!1)})]})]})},yn=t=>{const s=t.sequence,n=s?s.totalPosts:t.posts,o=s?s.totalSats:t.sats,i=s?s.totalTxs:t.txs;return{title:n!==void 0?`Lock ${n.toLocaleString("en")} posts to you`:"Lock your posts to you",site:`${t.originator} is asking`,privacy:"Private: only you can see them. They are encrypted with your wallet’s keys before they leave this device.",cost:`About ${o.toLocaleString("en")} sats in ${i.toLocaleString("en")} transaction${i===1?"":"s"}`,chunks:s?`Sent in ${s.chunks.toLocaleString("en")} parts. One Allow covers the whole run for 2 hours, up to 10% over this estimate. Anything more asks again.`:void 0}},bn=({request:t,onResponse:s})=>{const{theme:n}=W(),[o,i]=u.useState(!1),r=yn(t),d=t.sequence?t.sequence.totalSats:t.sats,c=Q(d,Ce(t.usdPerBsv,!0)),a=n.color.global.gray,f=n.color.global.contrast,m=g=>{o||(i(!0),O({action:"MINT_PRIVATE_RESPONSE",requestID:t.requestID,allow:g}),s())};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(Ds,{size:36,style:{color:f}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:f},children:r.title}),e.jsx("p",{className:"m-0 text-xs",style:{color:a},children:r.site}),e.jsxs("div",{className:"flex flex-col items-center","data-testid":"dollar-amount",children:[e.jsx("span",{style:{fontSize:32,fontWeight:800,lineHeight:1.1,color:f},children:c.main}),e.jsx("span",{className:"text-xs",style:{color:a},children:c.sub})]}),e.jsx("p",{className:"m-0 text-sm",style:{color:f},children:r.cost}),e.jsx("p",{className:"m-0 text-xs leading-relaxed",style:{color:a,maxWidth:"18rem"},children:r.privacy}),r.chunks&&e.jsx("p",{className:"m-0 text-xs leading-relaxed",style:{color:a,maxWidth:"18rem"},children:r.chunks}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(A,{theme:n,type:"primary",label:"Allow",disabled:o,onClick:()=>m(!0)}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Decline",disabled:o,onClick:()=>m(!1)})]})]})},vn=({request:t,onResponse:s})=>{const{theme:n}=W(),o=t.usdPerBsv,i=t.capSatsPerHour,r=o?i/1e8*o:void 0,[d,c]=u.useState(r!==void 0?r.toFixed(2):""),[a,f]=u.useState(String(i)),[m,g]=u.useState(!1),l=u.useMemo(()=>{const x=o?Rt(Number(d),o):Math.floor(Number(a));return Number.isFinite(x)&&x>=1?Math.min(x,i):0},[d,a,o,i]),w=x=>{m||(g(!0),O({action:"STREAM_GRANT_RESPONSE",requestID:t.requestID,capSatsPerHour:x?l:null}),s())},k=n.color.global.gray,p=n.color.global.contrast,b=new Date(t.expiresAt).toLocaleString(),S=Q(i,Ce(o,!0));return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(As,{size:36,style:{color:p}}),e.jsxs("h2",{className:"m-0 text-lg font-semibold",style:{color:p},children:["Allow ",t.originator," to stream while you watch, up to"]}),e.jsxs("div",{className:"flex flex-col items-center","data-testid":"dollar-amount",children:[e.jsxs("span",{style:{fontSize:o?40:24,fontWeight:800,lineHeight:1.1,color:p},children:[S.main,e.jsx("span",{style:{fontSize:16,fontWeight:600},children:" an hour"})]}),e.jsx("span",{className:"text-xs",style:{color:k},children:S.sub})]}),t.description&&e.jsx("p",{className:"m-0 text-xs",style:{color:k,maxWidth:"18rem"},children:t.description}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:k,maxWidth:"18rem"},children:["Only “",t.protocolName,"” payments from ",t.originator," go through without asking, until ",b,". Anything else still asks you. Revoke any time in Settings › Streaming permissions."]}),e.jsxs("label",{className:"flex items-center gap-2 text-sm",style:{color:p},children:["Cap per hour ",o?"$":"",o?e.jsx("input",{"aria-label":"Cap in dollars per hour",inputMode:"decimal",value:d,onChange:x=>c(x.target.value),className:"w-24 px-2 py-1 rounded bg-transparent border",style:{color:p}}):e.jsx("input",{"aria-label":"Cap in sats per hour",inputMode:"numeric",value:a,onChange:x=>f(x.target.value),className:"w-28 px-2 py-1 rounded bg-transparent border",style:{color:p}}),!o&&"sats"]}),e.jsxs("p",{className:"m-0 text-xs",style:{color:k},children:[l?o?`${Q(l,Ce(o,!0)).main} an hour · ${l.toLocaleString()} sats`:`${l.toLocaleString()} sats an hour ${Os}`:"Enter a cap above zero",l===i?" (the most this site asked for)":""]}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(A,{theme:n,type:"primary",label:"Allow",disabled:m||!l,onClick:()=>w(!0)}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Not now",disabled:m,onClick:()=>w(!1)})]})]})},wn=({request:t,onResponse:s})=>{const n=t.usdPerBsv,[o,i]=u.useState(Jo),[r,d]=u.useState(!1),c=n?Rt(o,n):0,a=t.envelope?.balanceSats??0,f=Ce(n,!0),m=Q(c,f),g=It(t.originator),l=w=>{r||(d(!0),O({action:"STREAM_GRANT_RESPONSE",requestID:t.requestID,capSatsPerHour:w?c:null}),s())};return e.jsx(Pt,{site:t.originator,siteSub:t.description||"Many small payments",onClose:()=>l(!1),closeLabel:"Not now",closeDisabled:r,hero:e.jsx(Re,{amount:n?me(o):m.main,sub:m.sub,badge:"ENVELOPE"}),title:e.jsxs(e.Fragment,{children:["Put ",n?me(o):"money"," in ",e.jsx("span",{style:{color:v.gold},children:g}),"'s envelope"]}),primary:{label:n?`Put ${me(o)} in`:"Price unavailable",onClick:()=>l(!0),disabled:r||!c},secondary:{label:"Not now",onClick:()=>l(!1),disabled:r},testId:"envelope-sheet",children:e.jsxs("div",{className:"flex flex-col",style:{gap:10},children:[e.jsx(Wt,{presetsUsd:Xo,value:o,onChange:i,disabled:r}),a>0&&e.jsxs("span",{style:{fontSize:13,color:v.muted},"data-testid":"envelope-balance",children:["Already in it: ",Q(a,f).main]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs(T,{children:[e.jsx(R,{}),"Stays in your wallet"]}),e.jsxs(T,{children:[e.jsx(R,{}),"Only ",g," can spend it"]}),e.jsxs(T,{children:[e.jsx(R,{}),"Coin return any time"]})]}),e.jsxs("span",{style:{fontSize:13,color:v.soft},children:["Small payments from ",t.originator," come out of the envelope without asking. When it is empty, it asks you again. Settings › Envelopes shows what is left."]})]})})},te={bg:"#0B0B0D",text:"#FFFFFF",muted:"#98A2B3",gold:"#F5C542",line:"#2B2F36"};function jn(t){const[s,n]=u.useState(null);return u.useEffect(()=>{if(!t)return;let o=!0;const i=()=>{if(!Ls(t)){n(null);return}Fs(t,{asking:!0,path:Us(t)}).then(r=>o&&n(r))};return i(),window.addEventListener(xt,i),window.addEventListener("storage",i),()=>{o=!1,window.removeEventListener(xt,i),window.removeEventListener("storage",i)}},[t]),s}const Ye=t=>t.replace(/^https?:\/\//,"").replace(/\/.*$/,"").toLowerCase(),kn=(t,s)=>s?.length?`${Ye(t)} (inside ${s.map(n=>Ye(n)).join(", ")})`:Ye(t),Sn=1500,Nn=({originator:t,themed:s,embeddedIn:n})=>e.jsxs("div",{"data-testid":"bwx-origin-strip",className:"flex items-center gap-2 px-3",style:{background:te.bg,color:te.text,borderBottom:`1px solid ${te.line}`,minHeight:32,fontFamily:"Inter, system-ui, sans-serif",fontSize:12,flexShrink:0},children:[e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24","aria-hidden":!0,fill:"none",stroke:te.gold,strokeWidth:"2.5",children:[e.jsx("rect",{x:"4",y:"11",width:"16",height:"10",rx:"2"}),e.jsx("path",{d:"M8 11V7a4 4 0 0 1 8 0v4"})]}),e.jsx("span",{style:{color:te.muted},children:"bWalletX · request from"}),e.jsx("span",{className:"font-bold truncate",style:{color:te.text},children:kn(t,n)}),s&&e.jsx("span",{className:"ml-auto whitespace-nowrap",style:{color:te.muted,fontSize:10},children:"site theme"})]}),En=({theme:t,originator:s})=>e.jsxs("div",{"data-testid":"bwx-site-banner",className:"flex items-center gap-3 px-4",style:{background:t.artData?`linear-gradient(90deg, ${t.bg} 35%, ${t.bg}99), url("${t.artData}") center / cover`:`linear-gradient(135deg, ${t.bg}, ${t.surface})`,color:t.text,borderBottom:`3px solid ${t.accent}`,minHeight:60,flexShrink:0},children:[t.logoData?e.jsx("img",{src:t.logoData,alt:"",width:36,height:36,style:{borderRadius:8,objectFit:"contain"}}):e.jsx("span",{"aria-hidden":!0,className:"flex items-center justify-center font-bold",style:{width:36,height:36,borderRadius:8,background:t.accent,color:t.onAccent},children:t.name.slice(0,1).toUpperCase()}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"font-bold truncate",style:{fontSize:15,color:t.text},children:t.name}),e.jsxs("div",{className:"truncate",style:{fontSize:11,color:t.accentHi},children:["Connected with bWalletX · ",_s(s)]})]})]}),Rn=({originator:t,children:s,theme:n,embeddedIn:o})=>{const i=jn(n===void 0?t:void 0),r=n===void 0?i:n,d=!!o?.length,[c,a]=u.useState(!d);return u.useEffect(()=>{if(!d)return a(!0);a(!1);const f=setTimeout(()=>a(!0),Sn);return()=>clearTimeout(f)},[d,t]),t?e.jsxs("div",{className:"flex flex-col w-full h-full",style:r?{boxShadow:`inset 3px 0 0 ${r.accent}, inset -3px 0 0 ${r.accent}`}:void 0,children:[e.jsx(Nn,{originator:t,themed:!!r,embeddedIn:o}),r&&e.jsx(En,{theme:r,originator:t}),e.jsx("div",{className:"flex-1 min-h-0 flex items-center justify-center relative","data-testid":"bwx-sheet-body","data-armed":c?"true":"false",style:c?void 0:{pointerEvents:"none"},children:s})]}):e.jsx(e.Fragment,{children:s})};is();Et.Buffer=Nt;Et.process=ds;window.Buffer=Nt;const Cn=t=>"payload"in t&&t.payload.originator||void 0,$n=t=>{const s="payload"in t?t.payload.embeddedIn:void 0;return Array.isArray(s)?s.filter(n=>typeof n=="string"):void 0},Pn=1e4,In=2e3,X=new URLSearchParams(window.location.search).get("inpage"),St=window.location.protocol==="chrome-extension:"&&window.top!==window&&!X&&!!window.location.ancestorOrigins?.length&&window.location.ancestorOrigins[0]!==window.location.origin,Tn=(t,s)=>{const[n,o]=u.useState(t?void 0:!0),[i,r]=u.useState(!t),[d,c]=u.useState(!1);return u.useEffect(()=>{t&&J({action:"INPAGE_SHEET_CHECK",token:X}).then(a=>o(!!a?.success)).catch(()=>o(!1))},[t]),u.useEffect(()=>{if(!t||n!==!0||!s.current)return;let a;const f=new IntersectionObserver(m=>{const g=m[m.length-1];window.clearTimeout(a),g.isVisible&&g.intersectionRatio>=.99?a=window.setTimeout(()=>r(!0),500):r(!1)},{threshold:[0,.99,1],trackVisibility:!0,delay:100});return f.observe(s.current),()=>{window.clearTimeout(a),f.disconnect()}},[t,s,n]),u.useEffect(()=>{if(!t||i){c(!1);return}const a=window.setTimeout(()=>c(!0),1500);return()=>window.clearTimeout(a)},[t,i]),{tokenOk:n,armed:n===!0&&i,stuck:n===!0&&!i&&d}},Dn=()=>{const{theme:t}=W(),{isLocked:s,isReady:n}=Z(),o=u.useRef(null),i=u.useRef(null),r=Tn(!!X,i),d=!St&&r.tokenOk===!0,c=u.useRef(d);c.current=d;const[a,f]=u.useState({kind:"loading"}),m=u.useRef(void 0),g=u.useRef(void 0),l=()=>{m.current!==void 0&&(window.clearTimeout(m.current),m.current=void 0)},w=u.useRef(a);w.current=a;const k=u.useCallback(async(x,y)=>{l();const E=w.current;if(x==="bundle"&&E.kind==="bundle"&&E.requestID===y){try{const U=await J({action:"GET_PROMPT_PAYLOAD",kind:x,requestID:y});U?.success&&U.data&&f({kind:"bundle",requestID:y,payload:U.data})}catch{}return}f({kind:"loading"});let $;try{$=await J({action:"GET_PROMPT_PAYLOAD",kind:x,requestID:y})}catch{$=void 0}$?.success&&$.data?f({kind:x,requestID:y,payload:$.data}):(f({kind:"expired"}),window.setTimeout(()=>{g.current?.()},In))},[]),p=u.useCallback(async()=>{l();let x;try{x=await J({action:"CLOSE_PROMPT_WINDOW"})}catch{x=void 0}if(x===void 0){window.close();return}const y=x.data?.prompt;y&&(y.kind==="unlock"?f({kind:"unlock"}):y.requestID&&await k(y.kind,y.requestID))},[k]),b=u.useCallback(async()=>{l();let x;try{x=await J({action:"GET_NEXT_PROMPT"})}catch{x=void 0}if(x?.data?.prompt){await k(x.data.prompt.kind,x.data.prompt.requestID);return}if(x?.data?.busy){f({kind:"waiting"}),m.current=window.setTimeout(()=>{p()},Pn);return}await p()},[k,p]);g.current=b,u.useEffect(()=>{if(!n||!d)return;const x=new URLSearchParams(window.location.search),y=x.get("kind"),E=x.get("requestID");if(y==="unlock"){s?f({kind:"unlock"}):b();return}if(y&&E){k(y,E);return}b()},[n,d]),u.useEffect(()=>{const x=y=>{if(!(y?.action!=="SHOW_PROMPT"||!y.kind||!c.current)){if(y.kind==="unlock"){l(),f({kind:"unlock"});return}y.requestID&&k(y.kind,y.requestID)}};return chrome.runtime.onMessage.addListener(x),()=>chrome.runtime.onMessage.removeListener(x)},[k]);const S=t.color.global.walletBackground;return!St&&X&&r.tokenOk===void 0?null:d?e.jsxs(bs,{children:[X&&e.jsxs("div",{className:"flex items-center justify-between px-3 py-2",style:{background:S,borderBottom:"1px solid #ffffff14"},children:[e.jsx("span",{className:"text-sm font-bold",style:{color:t.color.global.contrast},children:"bWalletX"}),r.stuck&&e.jsx("button",{type:"button",className:"text-xs font-bold border-0 rounded-full px-3 py-1",style:{background:"#F5C542",color:"#0b0a08"},onClick:()=>chrome.runtime.sendMessage({action:"MOVE_PROMPT_TO_WINDOW"}).catch(()=>{}),children:"Open in bWalletX"}),e.jsx("button",{type:"button","aria-label":"Deny and close",className:"text-sm border-0 bg-transparent p-1",style:{color:t.color.global.gray},onClick:()=>chrome.runtime.sendMessage({action:"DISMISS_PROMPT_PANEL"}).catch(()=>{}),children:"✕"})]}),e.jsxs("div",{ref:o,className:"flex items-center justify-center relative p-0",style:{width:X?"100%":"var(--wallet-width)",height:X?"calc(100vh - 41px)":"var(--wallet-height)",backgroundColor:S,pointerEvents:r.armed?void 0:"none"},children:[X&&e.jsx("div",{ref:i,"aria-hidden":!0,style:{position:"absolute",top:0,left:0,width:24,height:24,pointerEvents:"none"}}),(!n||a.kind==="loading")&&e.jsx(ht,{message:"Loading...",theme:t}),a.kind==="waiting"&&e.jsx(ht,{message:"Waiting for request...",theme:t}),a.kind==="expired"&&e.jsx("p",{className:"text-xs",style:{color:t.color.global.gray},children:"This request expired or was already handled."}),a.kind==="unlock"&&e.jsx(vs,{onUnlock:()=>{b()}}),e.jsxs(Rn,{originator:Cn(a),embeddedIn:$n(a),children:[a.kind==="permission"&&e.jsx(ko,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="bundle"&&e.jsx(cn,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="groupedPermission"&&e.jsx(eo,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="counterpartyPermission"&&e.jsx(Vs,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="oneSatPermission"&&e.jsx(vo,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="streamGrant"&&(a.payload.envelope?e.jsx(wn,{request:a.payload,onResponse:()=>{b()}},a.requestID):e.jsx(vn,{request:a.payload,onResponse:()=>{b()}},a.requestID)),a.kind==="mintPrivate"&&e.jsx(bn,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="swap"&&e.jsx(hn,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="themeOffer"&&e.jsx(mn,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="proveHoldings"&&e.jsx(gn,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="twetch"&&e.jsx(xn,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="usbCheck"&&e.jsx(So,{request:a.payload,onResponse:()=>{b()}},a.requestID)]})]})]}):e.jsx("p",{className:"text-xs p-4",style:{color:"#98A2B3"},children:"Open bWalletX to answer this request."})},qt=document.getElementById("root");if(!qt)throw new Error("Root element");ls.createRoot(qt).render(e.jsx(ms,{children:e.jsx(xs,{children:e.jsx(gs,{children:e.jsx(ys,{children:e.jsx(Dn,{})})})})}));
//# sourceMappingURL=prompt-tab-DV-zC4BK.js.map
