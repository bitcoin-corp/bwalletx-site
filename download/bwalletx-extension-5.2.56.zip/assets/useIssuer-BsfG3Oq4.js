import{r as u}from"./wocLimiter-CVYQRkJQ.js";import{c as t,v as c}from"./sessions-CQ7giapu.js";function n(r){const[f,s]=u.useState(()=>r?t(r):null);return u.useEffect(()=>{if(!r)return s(null);let e=!0;return s(t(r)),c(r).then(a=>e&&s(a)).catch(()=>{}),()=>{e=!1}},[r]),f}export{n as u};
//# sourceMappingURL=useIssuer-BsfG3Oq4.js.map
