import{r as n}from"./wocLimiter-CVYQRkJQ.js";import{X as s}from"./index-BR8IFw7h.js";const u=(e,r)=>{const t=n.useRef(r);t.current=r,n.useEffect(()=>{const o=c=>c.detail===e&&t.current();return window.addEventListener(s,o),()=>window.removeEventListener(s,o)},[e])};export{u};
//# sourceMappingURL=useTabHome-C6-23HPY.js.map
