import{e}from"./index-BR8IFw7h.js";import{j as a}from"./main-CEeGam2q.js";const r=(o,t)=>{a(`bsv21:${o}`),t(e("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-D44YguDA.js.map
