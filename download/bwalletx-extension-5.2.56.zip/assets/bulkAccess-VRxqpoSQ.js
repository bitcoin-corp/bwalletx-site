import{i as e}from"./sessions-CQ7giapu.js";import{aS as i,aT as l,aU as n}from"./index-BR8IFw7h.js";const r=["b0asex"],c=(a,s=r)=>{const[t,o]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!s.includes(t)?!1:!o||o===l.toLowerCase()||(n??[]).includes(o)},m=(a,s=!1)=>s||e(a)||c(i(a??void 0));export{m as c};
//# sourceMappingURL=bulkAccess-VRxqpoSQ.js.map
