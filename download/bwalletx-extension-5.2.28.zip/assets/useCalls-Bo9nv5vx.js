import{r as s}from"./index-UUJpKimX.js";import{hN as r,aK as a}from"./index-9N9rsFLG.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-Bo9nv5vx.js.map
