import{gs as r}from"./main-B6H2S89w.js";import{g as e}from"./ApprovalHeroes-Dj9WYLze.js";import{b0 as i}from"./index-9N9rsFLG.js";const l=["b0asex"],n=(o,a=l)=>{const[s,t]=o.trim().toLowerCase().replace(/^\$/,"").split("@");return!s||!a.includes(s)?!1:!t||t===i.toLowerCase()},A=(o,a=!1)=>a||r(o)||n(e(o??void 0));export{A as c};
//# sourceMappingURL=bulkAccess-D_JYkiWo.js.map
