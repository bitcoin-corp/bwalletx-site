const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-iXTfl4PV.js","./index-9N9rsFLG.js","./crypto-BtJNqGP6.js","./index-UUJpKimX.js","./index-BDtJ2amF.css","./extensionMedia-Rm_l9uoo.js","./index-5OHi5hZI.css"])))=>i.map(i=>d[i]);
import{ab as e,_ as t}from"./index-9N9rsFLG.js";import"./crypto-BtJNqGP6.js";import"./index-UUJpKimX.js";import"./extensionMedia-Rm_l9uoo.js";const _=e("Share",{web:()=>t(()=>import("./web-iXTfl4PV.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-CP5hI17-.js.map
