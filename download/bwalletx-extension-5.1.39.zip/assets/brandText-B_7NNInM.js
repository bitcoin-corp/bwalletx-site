import{t as o}from"./index-BSsOc9DP.js";const e=`${o()} (beta) by The Bitcoin Corporation Ltd. Based on the open-source Yours Wallet (MIT licence); not affiliated with or endorsed by its authors.`;export{e as U};
//# sourceMappingURL=brandText-B_7NNInM.js.map
