import{r as s}from"./index-CTLfQ20f.js";import{hG as r,hH as o}from"./main-LLsP3BqD.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-BGunP-l3.js.map
