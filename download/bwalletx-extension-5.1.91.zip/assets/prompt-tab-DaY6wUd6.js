import{r as u,j as e,b as ke}from"./index-CTLfQ20f.js";import{b as X,aW as fe,U as xe,T as je}from"./index-ZUCtc5uM.js";import{a as O,b as M,e as C,ai as D,cb as q,cc as $,aO as Ne,U as Se,aj as ae,bv as F,c9 as Ee,ca as Ce,c2 as Pe,c3 as De,c4 as Ae,P as ie,c8 as Ie}from"./index-D44PAIa1.js";import{a as V,u as J,U as Re,S as ne,b as Te,C as $e}from"./useSnackbar-DKalhjfA.js";const Be=t=>{const{request:s,onResponse:l}=t,{theme:o}=O(),{handleSelect:a,hideMenu:i}=V(),{addSnackbar:f}=J(),[n,d]=u.useState(!1),[c,y]=u.useState(""),{chromeStorageService:g}=M(),{permissions:p}=s,[k,b]=u.useState(()=>p.protocols.map(()=>!0));u.useEffect(()=>{a("bsv"),i()},[a,i]);const r=()=>{const S=p.protocols.filter((A,R)=>k[R]);return S.length===0?{}:{protocols:S}},x=async()=>{d(!0),y("");try{const S=await q(g);if(!S.ok){y(S.message),d(!1);return}$({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:r()}),l()}catch(S){f(S instanceof Error?S.message:String(S),"error"),d(!1)}},h=async()=>{d(!0),$({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),l()},w=S=>b(A=>A.map((R,B)=>B===S?!R:R)),v=s.counterpartyLabel??`${s.counterparty.slice(0,8)}...${s.counterparty.slice(-8)}`;return e.jsxs(C.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(Re,{size:18,style:{color:"#FFD24D"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Counterparty Permission"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","wants to interact with a counterparty"]})]})]}),e.jsxs(C.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all font-mono",style:{color:o.color.global.contrast},children:v})]}),e.jsx(D,{when:!!p.description,children:e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Purpose"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:p.description})]})}),e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),p.protocols.map((S,A)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:A<p.protocols.length-1?"1px solid rgba(255,255,255,0.04)":"none"},children:[e.jsx("input",{type:"checkbox",checked:k[A],onChange:()=>w(A),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[S.protocolID?.[1]," (level ",S.protocolID?.[0],")"]}),S.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:S.description})]})]},`proto-${A}`))]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[c&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:c}),e.jsxs(C.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, #FFD24D 0%, #EAB300 100%)",color:"#010101",opacity:n?.6:1},disabled:n,onClick:x,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[n&&e.jsx(X,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(C.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:n?.5:1},disabled:n,onClick:h,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},Ue={"2:3241645161d8":{label:"BRC-29 payment",description:"An application is requesting permission to derive payment addresses for a specific recipient."}},me=t=>t?Ue[`${t[0]}:${t[1]}`]:void 0,ge=t=>me(t)?.label??t?.[1],Fe=t=>{switch(t){case 0:return"Level 0 · any app";case 1:return"Level 1 · this app only";case 2:return"Level 2 · this app and this recipient only";default:return`Level ${t??0}`}},Oe=t=>{const{request:s,onResponse:l}=t,{theme:o}=O(),{handleSelect:a,hideMenu:i}=V(),{addSnackbar:f}=J(),[n,d]=u.useState(!1),[c,y]=u.useState(""),{chromeStorageService:g}=M(),{permissions:p}=s,[k,b]=u.useState(()=>(p.protocolPermissions??[]).map(()=>!0)),[r,x]=u.useState(()=>(p.basketAccess??[]).map(()=>!0)),[h,w]=u.useState(()=>(p.certificateAccess??[]).map(()=>!0)),[v,S]=u.useState(!0);u.useEffect(()=>{a("bsv"),i()},[a,i]);const A=()=>{const m={},N=(p.protocolPermissions??[]).filter((W,U)=>k[U]);N.length>0&&(m.protocolPermissions=N);const E=(p.basketAccess??[]).filter((W,U)=>r[U]);E.length>0&&(m.basketAccess=E);const I=(p.certificateAccess??[]).filter((W,U)=>h[U]);return I.length>0&&(m.certificateAccess=I),v&&p.spendingAuthorization&&(m.spendingAuthorization=p.spendingAuthorization),m},R=async()=>{d(!0),y("");try{const m=await q(g);if(!m.ok){y(m.message),d(!1);return}$({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:A()}),l()}catch(m){f(m instanceof Error?m.message:String(m),"error"),d(!1)}},B=async()=>{d(!0),$({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),l()},Q=m=>b(N=>N.map((E,I)=>I===m?!E:E)),G=m=>x(N=>N.map((E,I)=>I===m?!E:E)),z=m=>w(N=>N.map((E,I)=>I===m?!E:E));return e.jsxs(C.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ne,{size:18,style:{color:"#FFD24D"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Permission Request"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","is requesting the following permissions"]})]})]}),e.jsx(D,{when:!!p.description,children:e.jsx("p",{className:"text-xs mb-3 leading-relaxed",style:{color:o.color.global.gray},children:p.description})}),e.jsx(D,{when:!!p.spendingAuthorization,children:e.jsxs(C.div,{className:"w-full rounded-2xl px-4 py-3 mb-3",style:{background:"rgba(247,144,9,0.08)",border:"1px solid rgba(247,144,9,0.2)"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.06},children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pb-1",style:{color:"#F79009"},children:"Spending Authorization"}),e.jsxs("label",{className:"flex items-start gap-3 py-1 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:v,onChange:()=>S(!v),className:"mt-0.5 accent-orange-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-semibold",style:{color:"#F79009"},children:["This app wants to spend up to ",((p.spendingAuthorization?.amount??0)/1e8).toFixed(8)," BSV"," ","(",(p.spendingAuthorization?.amount??0).toLocaleString()," satoshis)"]}),p.spendingAuthorization?.description&&e.jsxs("span",{className:"text-xs mt-1 opacity-70",style:{color:o.color.global.contrast},children:["App says: “",p.spendingAuthorization.description,"”"]})]})]})]})}),e.jsxs(C.div,{className:"w-full rounded-2xl px-4 py-2 mb-5",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs(D,{when:!!p.protocolPermissions?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),p.protocolPermissions?.map((m,N)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:k[N],onChange:()=>Q(N),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[ge(m.protocolID)," (level ",m.protocolID[0],")",m.counterparty?` — ${m.counterparty.slice(0,10)}...`:""]}),m.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:m.description})]})]},`proto-${N}`))]}),e.jsxs(D,{when:!!p.basketAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Baskets"}),p.basketAccess?.map((m,N)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:r[N],onChange:()=>G(N),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:m.basket}),m.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:m.description})]})]},`basket-${N}`))]}),e.jsxs(D,{when:!!p.certificateAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Certificates"}),p.certificateAccess?.map((m,N)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:h[N],onChange:()=>z(N),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:m.type}),e.jsxs("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:[m.description," — fields: ",m.fields.join(", ")]})]})]},`cert-${N}`))]})]}),e.jsxs("div",{className:"flex flex-col gap-3",children:[c&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:c}),e.jsxs(C.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, #FFD24D 0%, #EAB300 100%)",color:"#010101",opacity:n?.6:1},disabled:n,onClick:R,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[n&&e.jsx(X,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(C.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:n?.5:1},disabled:n,onClick:B,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},Me=2e3;async function Y(t,s=Me){let l;try{return await Promise.race([t.catch(()=>{}),new Promise(o=>{l=setTimeout(()=>o(void 0),s)})])}catch{return}finally{l&&clearTimeout(l)}}function Le(t,s){return t?.find(l=>l.startsWith(`${s}:`))?.slice(s.length+1)}async function _e(t,s,l=[]){const o=t.ordfs;if(typeof o?.bulkMetadata!="function")return{state:"unverified"};const a=`${s}:-2`,i=await Y(o.bulkMetadata([a])),f=i?.[a]??i?.[s]??Object.values(i??{}).find(c=>!!c?.contentType);if(!f?.contentType)return{state:"unverified"};const n={contentType:f.contentType,origin:f.origin,name:typeof f.map?.name=="string"?f.map.name:void 0},d=l.find(c=>c.includes("/"));return d&&d!==f.contentType?{state:"mismatch",note:`Content type is ${f.contentType}, not ${d}`,...n}:{state:"verified",...n}}async function qe(t,s,l){const o=t.opns;if(typeof o?.getOrigin!="function")return{state:"unverified"};const a=await Y(o.getOrigin(s));return a?.outpoint?a.outpoint!==l?{state:"mismatch",note:`“${s}” currently resolves to a different output`}:{state:"verified"}:{state:"unverified"}}async function ze(t,s,l,o=[]){const a=t.bsv21;if(typeof a?.getTokenDetails!="function")return{state:"unverified"};const i=await Y(a.getTokenDetails(s,{fresh:!0}));if(!i)return{state:"unverified"};if(i.status?.is_active===!1)return{state:"mismatch",note:"Token is not active on the overlay"};const f=i.token?.sym;if(l&&f&&l.toLowerCase()!==f.toLowerCase())return{state:"mismatch",note:`Token symbol is ${f}, not ${l}`};if(o.length>0&&typeof a.getOutputStatus=="function"){const n=await Y(a.getOutputStatus(s,o));if(!n)return{state:"unverified"};const d=n.filter(c=>c.state==="spent"||c.state==="unknown");if(d.length>0)return{state:"mismatch",note:d.length===1?"A spent token output is not valid on the overlay":`${d.length} spent token outputs are not valid on the overlay`};if(n.some(c=>c.state==="queued"))return{state:"unverified"}}return{state:"verified",...f?{name:f}:{}}}async function We(t,s,l,o,a){if(!t||!s)return{state:"unverified"};const i=s==="purchase"||s.endsWith(".purchase"),f=s==="token-transfer"||s.startsWith("bsv21.");if(!i&&!f)return{state:"unverified"};const n={kindOrIntent:s,hasOrdfs:!!t.ordfs,hasBulk:typeof t.ordfs?.bulkMetadata=="function",inputTagSets:l.map(d=>d.tags),outputTagSets:o.map(d=>d.tags)};try{const d=[...l.map(r=>r.tags),...o.map(r=>r.tags)],c=r=>d.flatMap(x=>x.filter(h=>h.startsWith(`${r}:`)).map(h=>h.slice(r.length+1))),y=r=>{for(const x of d){const h=Le(x,r);if(h)return h}},g=y("bsv21");if(g||s==="bsv21.purchase"||s==="token-transfer"||s.startsWith("bsv21.")){if(!g)return{state:"unverified"};const x=l.filter(w=>w.basket?.includes("bsv21")||w.tags.some(v=>v.startsWith("bsv21:"))).map(w=>w.outpoint).filter(Boolean);let h=y("sym");for(const w of l)if(w.customInstructions)try{const v=JSON.parse(w.customInstructions).sym;if(typeof v=="string"&&v.trim()){h=v.trim();break}}catch{}return await ze(t,g,h,x)}const p=y("name"),k=y("origin");if(n.name=p,n.origin=k,p&&k&&o.some(r=>r.basket?.includes("opns"))||s==="opns.purchase")return!p||!k?{state:"unverified"}:await qe(t,p,k);if(!k)return n.reason="no-origin-tag",globalThis.__lastVerify=n,{state:"unverified"};const b=await _e(t,k,c("type"));if(n.verifyOrdinal=b,b.origin&&a)try{b.contentUrl=a(b.origin)}catch(r){n.contentUrlError=String(r)}return globalThis.__lastVerify=n,b}catch(d){return n.error=String(d),globalThis.__lastVerify=n,{state:"unverified"}}}function he(t){if(!t||typeof t!="object")return!1;const s=t;return Array.isArray(s.panels)&&typeof s.title=="string"}var Ve=`
.opp-root {
  --opp-bg: #ffffff;
  --opp-fg: #111827;
  --opp-muted: #6b7280;
  --opp-card-bg: #f7f8fa;
  --opp-card-border: #eceef2;
  --opp-accent: #E5A920;
  --opp-approve-bg: #E5A920;
  --opp-approve-fg: #ffffff;
  --opp-reject-bg: #ffffff;
  --opp-reject-fg: #111827;
  --opp-reject-border: #d1d5db;
  --opp-status-bg: #FFFBE6;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #ECFDF5;
  --opp-trust-ok-fg: #059669;
  --opp-trust-warn-bg: #FFFBEB;
  --opp-trust-warn-fg: #D97706;
  --opp-trust-bad-bg: #FEF2F2;
  --opp-trust-bad-fg: #DC2626;

  font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--opp-bg);
  color: var(--opp-fg);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 480px;
  min-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
}

.opp-bottom {
  margin-top: auto;
  display: flex;
  flex-direction: column;
}

.opp-root.opp-dark {
  --opp-bg: #0F1117;
  --opp-fg: #F9FAFB;
  --opp-muted: #9ca3af;
  --opp-card-bg: #1A1D27;
  --opp-card-border: #232636;
  --opp-reject-bg: #0F1117;
  --opp-reject-fg: #F9FAFB;
  --opp-reject-border: #2D3142;
  --opp-status-bg: #2A2408;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #0A2E1F;
  --opp-trust-ok-fg: #34D399;
  --opp-trust-warn-bg: #2A2008;
  --opp-trust-warn-fg: #FBBF24;
  --opp-trust-bad-bg: #2A1215;
  --opp-trust-bad-fg: #F87171;
}

.opp-body {
  padding: 24px 20px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
}

.opp-coin {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
}

.opp-title {
  font-size: 16px;
  font-weight: 700;
  margin: 0;
  text-align: center;
}

.opp-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  margin: 0;
  text-align: center;
  line-height: 1.4;
}

.opp-status {
  background: var(--opp-status-bg);
  color: var(--opp-status-fg);
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
  margin-top: 4px;
  border: 1px solid var(--opp-card-border);
}

.opp-card {
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px;
  padding: 16px;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.opp-featured {
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px 8px;
  padding: 16px;
}

/* Subtle danger chrome for burn / destructive token ops */
.opp-featured-danger {
  border-color: rgba(220, 38, 38, 0.45);
  background: color-mix(in srgb, var(--opp-card-bg) 88%, #7f1d1d 12%);
}

.opp-featured-danger .opp-featured-title {
  color: #f87171;
}

.opp-featured-danger .opp-featured-image,
.opp-featured-danger .opp-featured-placeholder {
  border: 1px solid rgba(220, 38, 38, 0.35);
  background: rgba(127, 29, 29, 0.25);
  color: #fca5a5;
}

.opp-dark .opp-featured-danger {
  border-color: rgba(248, 113, 113, 0.4);
  background: color-mix(in srgb, var(--opp-card-bg) 85%, #450a0a 15%);
}

.opp-preview-pair {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.opp-preview-arrow {
  color: var(--opp-muted);
  font-size: 14px;
  line-height: 1;
}

.opp-preview-pair .opp-featured-image {
  width: 64px;
  height: 64px;
}

.opp-featured-image {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-featured-image-token {
  width: 48px;
  height: 48px;
  border-radius: 999px;
}

.opp-featured-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--opp-muted);
  font-size: 18px;
}

.opp-preview-opns {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
}

.opp-preview-opns-avatar {
  width: 36px;
  height: 36px;
  border-radius: 999px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-preview-opns-name {
  font-size: 11px;
  font-weight: 600;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  color: var(--opp-fg, inherit);
}

.opp-preview-text {
  margin: 0;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
  font-size: 9px;
  line-height: 1.25;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  color: var(--opp-muted);
}

.opp-preview-json {
  white-space: pre;
  overflow: auto;
}

.opp-preview-frame {
  border: 0;
  padding: 0;
  overflow: hidden;
  background: #fff;
  pointer-events: none;
}

.opp-preview-value {
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  background: rgba(229, 169, 32, 0.12);
  border: 1px solid rgba(229, 169, 32, 0.35);
  color: var(--opp-fg, inherit);
}

.opp-preview-value-icon {
  width: 32px;
  height: 32px;
  color: #E5A920;
}

/* Amount subtitles must never ellipsis — full sat counts are the point. */
.opp-featured-subtitle-text.opp-amount {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-variant-numeric: tabular-nums;
  white-space: normal;
  overflow: visible;
  text-overflow: unset;
  word-break: keep-all;
}

.opp-featured-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  flex: 1;
}

.opp-featured-title {
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.opp-featured-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.opp-featured-subtitle-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
}

.opp-featured-meta-line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  color: var(--opp-muted);
}

.opp-featured-meta-line-bare {
  align-items: center;
}

.opp-featured-meta-key {
  flex-shrink: 0;
  opacity: 0.75;
  min-width: 2.5em;
}

.opp-featured-meta-value {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  flex: 1;
}

.opp-featured-meta-value-mono {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 11px;
}

.opp-trust-wrap {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0 20px 8px;
}

.opp-trust {
  display: inline-flex;
  align-self: flex-start;
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 600;
}

.opp-trust-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-trust-note {
  padding: 10px;
  border-radius: 8px;
  font-size: 11px;
  line-height: 1.35;
}

.opp-trust-note-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-note-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-note-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.opp-row-key {
  color: var(--opp-muted);
  flex-shrink: 0;
}

.opp-row-value-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 70%;
  justify-content: flex-end;
}

.opp-row-value {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 12px;
  font-weight: 500;
  text-align: right;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.opp-copy {
  flex-shrink: 0;
  width: 22px;
  height: 22px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  border: 1px solid var(--opp-reject-border);
  background: var(--opp-bg);
  color: var(--opp-fg);
  cursor: pointer;
}

.opp-copy:hover {
  border-color: var(--opp-accent);
  color: var(--opp-accent);
}

.opp-fee-note {
  font-size: 11px;
  color: var(--opp-muted);
  line-height: 1.3;
  margin-top: -4px;
}

.opp-actions {
  display: flex;
  gap: 12px;
  padding: 20px 20px 12px;
}

.opp-button {
  flex: 1;
  padding: 0 16px;
  height: 48px;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid transparent;
  transition: opacity 120ms ease;
}

.opp-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.opp-button-reject {
  background: var(--opp-reject-bg);
  color: var(--opp-reject-fg);
  border-color: var(--opp-reject-border);
}

.opp-button-approve {
  background: var(--opp-approve-bg);
  color: var(--opp-approve-fg);
}

.opp-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 20px 16px;
  font-size: 11px;
  font-weight: 500;
  color: var(--opp-muted);
}
`;function Ge({request:t,onApprove:s,onReject:l,theme:o="auto",services:a}){const i=tt(o),f=He(t),[n,d]=u.useState(!1),[c,y]=u.useState(),g=t.kind==="transaction"&&he(t.payload)?t.payload:void 0;u.useEffect(()=>{if(!a||!g?.trust||!g.verify)return;let r=!0;const x=a.ordfs?.getContentUrl?.bind(a.ordfs);return We(a,g.verify.kind,g.verify.inputs,g.verify.outputs,x).then(h=>{r&&h&&y(h)}).catch(()=>{}),()=>{r=!1}},[a,g]);const p=c?Ke(f,c):f,k=r=>()=>{if(!n){d(!0);try{r==="approve"?s():l()}finally{d(!1)}}};u.useEffect(()=>{const r=x=>{n||(x.key==="Escape"?l():x.key==="Enter"&&s())};return window.addEventListener("keydown",r),()=>window.removeEventListener("keydown",r)},[s,l,n]);const b=`opp-root${i==="dark"?" opp-dark":""}`;return e.jsxs("div",{className:b,children:[e.jsx("style",{children:Ve}),e.jsxs("div",{className:"opp-body",children:[e.jsxs("svg",{className:"opp-coin",viewBox:"0 0 100 100","aria-label":"1Sat Ordinals",children:[e.jsx("circle",{cx:"50",cy:"50",r:"50",fill:"#222"}),e.jsx("circle",{cx:"50",cy:"50",r:"40",fill:"#fff"}),e.jsx("circle",{cx:"50",cy:"50",r:"32",fill:"#E5A920"}),e.jsx("rect",{x:"47",y:"28",width:"6",height:"28",rx:"3",fill:"#fff"})]}),e.jsx("h2",{className:"opp-title",children:p.title}),e.jsx("p",{className:"opp-subtitle",children:p.subtitle}),e.jsx("div",{className:"opp-status",children:"Awaiting Approval"})]}),p.panels.map((r,x)=>{const h=r.variant??"ordinal",w=["opp-featured"];return h==="token"&&w.push("opp-featured-token"),h==="value"&&w.push("opp-featured-value"),r.tone==="danger"&&w.push("opp-featured-danger"),e.jsxs("div",{className:w.join(" "),children:[r.prior?e.jsxs("div",{className:"opp-preview-pair","aria-label":"Previous and new inscription",children:[e.jsx(ee,{panel:{...r,previewKind:r.prior.previewKind,imageUrl:r.prior.imageUrl,contentUrl:r.prior.contentUrl,previewText:r.prior.previewText,prior:void 0}}),e.jsx("span",{className:"opp-preview-arrow","aria-hidden":!0,children:"→"}),e.jsx(ee,{panel:r})]}):e.jsx(ee,{panel:r}),e.jsxs("div",{className:"opp-featured-meta",children:[e.jsx("div",{className:"opp-featured-title",children:r.title}),r.subtitle&&e.jsxs("div",{className:"opp-featured-subtitle",children:[e.jsx("span",{className:r.amountSats!=null?"opp-featured-subtitle-text opp-amount":"opp-featured-subtitle-text",children:r.subtitle}),r.subtitleCopy&&e.jsx(te,{text:r.subtitleCopy})]}),(r.meta??[]).map(v=>e.jsxs("div",{className:`opp-featured-meta-line${v.key?"":" opp-featured-meta-line-bare"}`,children:[v.key?e.jsx("span",{className:"opp-featured-meta-key",children:v.key}):null,e.jsx("span",{className:`opp-featured-meta-value${v.key?"":" opp-featured-meta-value-mono"}`,title:v.copyValue??v.value,children:v.value}),v.copyValue&&e.jsx(te,{text:v.copyValue})]},`${v.key}:${v.value}`))]})]},`panel-${x}-${r.title}`)}),p.trust&&e.jsxs("div",{className:"opp-trust-wrap",children:[e.jsx("span",{className:`opp-trust opp-trust-${p.trust.state}`,children:Je(p.trust.state)}),p.trust.note&&e.jsx("div",{className:`opp-trust-note opp-trust-note-${p.trust.state}`,children:p.trust.note})]}),(p.rows.length>0||p.indexerFee||p.funding)&&e.jsxs("div",{className:"opp-card",children:[p.rows.map(r=>e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:r.key}),e.jsxs("span",{className:"opp-row-value-wrap",children:[e.jsx("span",{className:"opp-row-value",title:r.copyValue??r.value,children:r.value}),r.copyValue&&e.jsx(te,{text:r.copyValue})]})]},`${r.key}:${r.value}`)),p.indexerFee&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"1Sat Overlay Fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[le(p.indexerFee.sats)," sats"]})]}),p.funding?.networkFeeSats!=null&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"Network fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[le(p.funding.networkFeeSats)," sats"]})]}),p.funding?.note&&e.jsx("div",{className:"opp-fee-note",children:p.funding.note})]}),e.jsxs("div",{className:"opp-bottom",children:[e.jsxs("div",{className:"opp-actions",children:[e.jsx("button",{type:"button",className:"opp-button opp-button-reject",onClick:k("reject"),disabled:n,children:"Reject"}),e.jsx("button",{type:"button",className:"opp-button opp-button-approve",onClick:k("approve"),disabled:n,children:"Approve"})]}),e.jsx("div",{className:"opp-footer",children:e.jsx("span",{children:"Secured by 1Sat Ordinals"})})]})]})}function He(t){if(t.kind==="transaction"&&he(t.payload))return{title:t.payload.title,subtitle:t.payload.subtitle,panels:t.payload.panels,rows:t.payload.rows,trust:t.payload.trust,indexerFee:t.payload.indexerFee,funding:t.payload.funding};if(t.kind==="basketAccess"){const s=t.payload.baskets??[],l=s.length>0&&s.every(i=>i.scope||i.basket.startsWith("p ")),o=s.filter(i=>i.imageUrl||i.name||i.value).map(i=>({title:i.scope==="collection"?i.name?`Collection · ${i.name}`:"Collection":i.scope?i.scope:"Basket",subtitle:i.value?i.value.length>24?`${i.value.slice(0,10)}…${i.value.slice(-10)}`:i.value:i.basket,subtitleCopy:i.value,...i.imageUrl&&{previewKind:"image",contentUrl:i.imageUrl,imageUrl:i.imageUrl},tone:"default"})),a=s.flatMap(i=>i.scope==="collection"?i.description?[{key:"Access",value:i.description}]:[]:[{key:i.basket,value:i.description??"List, insert, and remove outputs"}]);return{title:l?s.length===1?s[0].scope==="collection"?"Grant Collection View":"Grant Item View":`Grant View (${s.length})`:s.length===1?"Grant Basket Access":`Grant Access to ${s.length} Baskets`,subtitle:l?`${K(t.originator)} wants to view items in your wallet`:`${K(t.originator)} wants to read and write 1Sat baskets`,panels:o,rows:a}}return t.kind==="protocol"?{title:"Protocol Access",subtitle:`${K(t.originator)} wants protocol access`,panels:[],rows:[{key:"Detail",value:t.summary||"Protocol request"}]}:{title:"Signature Request",subtitle:`${K(t.originator)} wants a signature`,panels:[],rows:[{key:"Detail",value:t.summary||"Signature request"}]}}function Ke(t,s){const l=t.panels.map((o,a)=>{if(a!==0)return o;const i=o.previewKind==="opns",f=s.contentType?Ye(s.contentType):void 0,n=i?"opns":f&&f!=="none"?f:o.previewKind,d=s.contentUrl??o.contentUrl??o.imageUrl;let c=o.subtitle;if(s.name&&!i)if(!c)c=s.name;else{const y=c.trim().split(/\s+/);y.length>=2&&(y[y.length-1]=s.name,c=y.join(" "))}return{...o,previewKind:n,...c?{subtitle:c}:{},...i?{...s.contentUrl&&!o.imageUrl?{imageUrl:s.contentUrl}:o.imageUrl?{imageUrl:o.imageUrl}:{}}:n==="image"?{imageUrl:d,contentUrl:d}:d?{contentUrl:d,imageUrl:void 0}:{}}});return{...t,panels:l,trust:{state:s.state,note:s.note}}}function Ye(t){const s=t.toLowerCase();return s==="image/svg+xml"||s==="svg"||s.endsWith("+svg")?"svg":s.startsWith("image/")?"image":s.includes("json")?"json":s.includes("html")||s==="application/xhtml+xml"?"html":s.startsWith("text/")?"text":"none"}function Xe(t){return`${t.toLocaleString("en-US")} sats`}function le(t){return t.toLocaleString("en-US")}function Je(t){return t==="verified"?"Verified":t==="mismatch"?"Mismatch":"Unverified"}function ee({panel:t}){const s=t.variant??"ordinal",l=s==="token"?"opp-featured-image opp-featured-image-token":s==="value"?"opp-featured-image opp-preview-value":"opp-featured-image",o=t.previewKind??(t.imageUrl?"image":"none"),a=t.contentUrl??t.imageUrl,[i,f]=u.useState(!1);if(s==="value"){const n=t.valueIcon??"pay";return e.jsx("div",{className:l,title:t.amountSats!=null?Xe(t.amountSats):void 0,"aria-hidden":!0,children:e.jsx(Ze,{kind:n})})}if(o==="opns"){const n=!!t.imageUrl&&!i;return e.jsxs("div",{className:`${l} opp-preview-opns`,"aria-hidden":!t.opnsHero,children:[n?e.jsx("img",{className:"opp-preview-opns-avatar",src:t.imageUrl,alt:"",onError:()=>f(!0)}):e.jsx("div",{className:"opp-preview-opns-avatar opp-featured-placeholder",children:"◈"}),e.jsx("span",{className:"opp-preview-opns-name",title:t.opnsHero,children:t.opnsHero??"OpNS"})]})}return o==="image"&&t.imageUrl&&!i?e.jsx("img",{className:l,src:t.imageUrl,alt:t.title,onError:()=>f(!0)}):o==="image"&&i?e.jsx("div",{className:`${l} opp-featured-placeholder`,"aria-hidden":!0,children:"▭"}):(o==="text"||o==="json"||o==="html")&&t.previewText?e.jsx("pre",{className:`${l} opp-preview-text${o==="json"?" opp-preview-json":""}`,children:t.previewText}):(o==="text"||o==="json")&&a?e.jsx(et,{url:a,kind:o,className:l}):(o==="html"||o==="svg")&&a?e.jsx("iframe",{className:`${l} opp-preview-frame`,src:a,title:`${t.title} preview`,sandbox:"",referrerPolicy:"no-referrer"}):e.jsx("div",{className:`${l} opp-featured-placeholder`,"aria-hidden":!0,children:s==="token"?"◎":Qe(o)})}function Qe(t){return t==="text"||t==="json"?"¶":t==="html"||t==="svg"?"⌂":"▭"}function Ze({kind:t}){return t==="lock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V8a4 4 0 018 0v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):t==="unlock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V7.5A4 4 0 0116 7",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("path",{d:"M16 4.5v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"9",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M12 7v10M9 10.5c0-1.4 1.3-2.5 3-2.5s3 1.1 3 2.5-1.3 2.5-3 2.5-3 1.1-3 2.5 1.3 2.5 3 2.5 3-1.1 3-2.5",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})}function et({url:t,kind:s,className:l}){const[o,a]=u.useState(null),[i,f]=u.useState(!1);return u.useEffect(()=>{let n=!1;return a(null),f(!1),fetch(t).then(async d=>{if(!d.ok)throw new Error(String(d.status));const c=await d.text();if(!n){if(s==="json")try{a(JSON.stringify(JSON.parse(c),null,2));return}catch{}a(c.slice(0,800))}}).catch(()=>{n||f(!0)}),()=>{n=!0}},[t,s]),i?e.jsx("div",{className:`${l} opp-featured-placeholder`,"aria-hidden":!0,children:"¶"}):e.jsx("pre",{className:`${l} opp-preview-text${s==="json"?" opp-preview-json":""}`,children:o??"…"})}function te({text:t}){const[s,l]=u.useState(!1),o=()=>{navigator.clipboard?.writeText(t).then(()=>{l(!0),window.setTimeout(()=>l(!1),1200)})};return e.jsx("button",{type:"button",className:"opp-copy",onClick:o,"aria-label":s?"Copied":"Copy full value",title:s?"Copied":"Copy",children:s?e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:e.jsx("path",{d:"M5 13l4 4L19 7",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round"})}):e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"9",y:"9",width:"11",height:"11",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M5 15V5a2 2 0 012-2h10",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})})}function tt(t){const[s,l]=u.useState(()=>t==="auto"?st():t);return u.useEffect(()=>{if(t!=="auto"){l(t);return}const o=window.matchMedia("(prefers-color-scheme: dark)"),a=()=>l(o.matches?"dark":"light");return a(),o.addEventListener("change",a),()=>o.removeEventListener("change",a)},[t]),s}function st(){return typeof window>"u"||!window.matchMedia?"light":window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function K(t){try{return new URL(t.includes("://")?t:`https://${t}`).host||t}catch{return t.length<=32?t:`${t.slice(0,14)}…${t.slice(-12)}`}}const ot=({request:t,onResponse:s})=>{const{theme:l}=O(),{handleSelect:o,hideMenu:a}=V(),{apiContext:i,chromeStorageService:f}=M(),n=i?.services;u.useEffect(()=>{o("bsv"),a()},[o,a]);const[d,c]=u.useState(""),y=u.useRef(!1),g=async b=>{if(!y.current){if(y.current=!0,b){c("");const r=await q(f);if(!r.ok){c(r.message),y.current=!1;return}}$({action:"ONE_SAT_PERMISSION_RESPONSE",requestID:t.requestID,approved:b}),s()}},k=l.color.global.walletBackground.toLowerCase()==="#000000"||/^#[01]/.test(l.color.global.walletBackground)?"dark":"light";return e.jsxs("div",{style:{width:"100%",height:"100%",overflowY:"auto",display:"flex",flexDirection:"column",alignItems:"stretch",justifyContent:"center"},children:[d&&e.jsx("p",{className:"text-xs text-center m-0 pt-2",style:{color:"#ef4444"},children:d}),e.jsx(Ge,{request:t.request,onApprove:()=>{g(!0)},onReject:()=>{g(!1)},theme:k,services:n})]})},rt=t=>{switch(t){case"protocol":return"Protocol Permission";case"basket":return"Basket Access";case"certificate":return"Certificate Access";case"spending":return"Spending Authorization";default:return"Permission Request"}},nt=t=>{switch(t.type){case"protocol":{const s=me(t.protocolID);return s?s.description:`An application is requesting permission to use protocol "${t.protocolID?.[1]||"unknown"}" with security level ${t.protocolID?.[0]||0}.`}case"basket":return`An application is requesting access to basket "${t.basket||"unknown"}".`;case"certificate":return"An application is requesting access to certificate data.";case"spending":return`An application is requesting authorization to spend ${t.spending?.satoshis||0} satoshis.`;default:return"An application is requesting a permission."}},ce=t=>t>=1e8?`${(t/1e8).toFixed(8)} BSV`:`${t.toLocaleString()} satoshis`,at=t=>{const{request:s,onResponse:l}=t,{theme:o}=O(),{handleSelect:a,hideMenu:i}=V(),{addSnackbar:f}=J(),[n,d]=u.useState(!1),[c,y]=u.useState(""),{chromeStorageService:g}=M();u.useEffect(()=>{a("bsv"),i()},[a,i]);const p=async()=>{d(!0),y("");try{const b=await q(g);if(!b.ok){y(b.message),d(!1);return}$({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!0}),l()}catch(b){const r=b instanceof Error?b.message:String(b);f(r,"error"),d(!1)}},k=async()=>{d(!0),$({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!1}),l()};return e.jsxs(C.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ne,{size:18,style:{color:"#FFD24D"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:rt(s.type)}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:nt(s)})]})]}),e.jsxs(C.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"12rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Origin"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.displayOriginator||s.originator})]}),e.jsxs(D,{when:s.type==="protocol"&&!!s.protocolID,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Protocol"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:ge(s.protocolID)})]}),e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.counterparty?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Security"}),e.jsx("span",{className:"text-xs",style:{color:o.color.global.contrast},children:Fe(s.protocolID?.[0])})]}),e.jsx(D,{when:!!s.counterparty,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.counterparty})]})})]}),e.jsx(D,{when:s.type==="basket"&&!!s.basket,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Basket"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.basket})]})}),e.jsxs(D,{when:s.type==="certificate"&&!!s.certificate,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Cert Type"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.certType})]}),e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Fields"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.fields.join(", ")})]})]}),e.jsxs(D,{when:s.type==="spending"&&!!s.spending,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.spending?.lineItems?.length?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Amount"}),e.jsx("span",{className:"text-xs font-semibold",style:{color:"#FFD24D"},children:ce(s.spending?.satoshis||0)})]}),e.jsx(D,{when:!!s.spending?.lineItems?.length,children:s.spending?.lineItems?.map((b,r)=>e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:r<(s.spending?.lineItems?.length??0)-1?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:b.type}),e.jsxs("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:[b.description," (",ce(b.satoshis),")"]})]},r))})]}),e.jsx(D,{when:!!s.reason,children:e.jsxs("div",{className:"flex flex-row py-2",style:{borderTop:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Reason"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.reason})]})})]}),e.jsx(D,{when:!!s.privileged,children:e.jsxs(C.div,{className:"flex items-start gap-2 rounded-xl px-3 py-2.5 mb-4",style:{background:"rgba(245,166,35,0.08)",border:"1px solid rgba(245,166,35,0.15)"},initial:{opacity:0},animate:{opacity:1},transition:{delay:.12},children:[e.jsx(Ne,{size:14,className:"mt-0.5 flex-shrink-0",style:{color:"#f5a623"}}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:"#f5a623"},children:"This is a privileged operation"})]})}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[c&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:c}),e.jsxs(C.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, #FFD24D 0%, #EAB300 100%)",color:"#010101",opacity:n?.6:1},disabled:n,onClick:p,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[n&&e.jsx(X,{size:14,className:"animate-spin"}),"Allow"]}),e.jsx(C.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:n?.5:1},disabled:n,onClick:k,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny"})]})]})},it=({request:t,onResponse:s})=>{const{theme:l}=O(),{chromeStorageService:o}=M(),[a,i]=u.useState(""),[f,n]=u.useState(!1),d=async g=>{if(!f){if(n(!0),i(""),g){const p=await q(o);if(!p.ok){i(p.message),n(!1);return}}$({action:"USB_CHECK_RESPONSE",requestID:t.requestID,ok:g}),s()}},c=l.color.global.gray,y=l.color.global.contrast;return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(Se,{size:40,style:{color:y}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:y},children:"Confirm your USB key"}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:c,maxWidth:"18rem"},children:[t.originator?`${t.originator} is asking bWallet to ${t.reason}.`:`A site is asking bWallet to ${t.reason}.`," ","Insert your USB key, then confirm."]}),a&&e.jsx("p",{className:"m-0 text-xs",style:{color:"#ef4444"},children:a}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(ae,{theme:l,type:"primary",label:"Confirm USB key",disabled:f,onClick:()=>{d(!0)}}),e.jsx(ae,{theme:l,type:"secondary-outline",label:"Cancel",disabled:f,onClick:()=>{d(!1)}})]})]})},pe=5,se=[0,1,5,20],lt=/e-?mail|phone|mobile|kyc|passport|licen[cs]e|birth|dob|address|ssn|national|tax|id_?number/i,ct=t=>String(t.protocolID?.[1]??"unknown"),ye=t=>Number(t.protocolID?.[0]??0),pt=t=>!!(t.privileged||t.type==="protocol"&&t.counterparty==="anyone"||t.type==="certificate"&&(t.certificate?.fields??[]).some(s=>lt.test(s))),dt=t=>{switch(t.type){case"protocol":return t.counterparty==="anyone"?"Sign and decrypt for anyone, not just this app":ye(t)===2&&t.counterparty&&t.counterparty!=="self"?"Sign and share keys with one named person or service":"Sign in and sign its messages";case"basket":return"Keep its tickets and tokens in your wallet";case"certificate":{const s=t.certificate?.fields??[];return s.length?`See your certificate details (${s.join(", ")})`:"See your certificates"}default:return"Spend from your wallet"}},oe=t=>{const s=[];switch(t.type){case"protocol":s.push(`protocol "${ct(t)}" level ${ye(t)}`),t.counterparty&&s.push(`counterparty ${t.counterparty}`);break;case"basket":s.push(`basket "${t.basket??""}"`);break;case"certificate":s.push(`certificate ${t.certificate?.certType??""}`,`verifier ${t.certificate?.verifier??""}`);break;case"spending":s.push(`${t.spending?.satoshis??0} sats`);break}return t.privileged&&s.push("privileged"),t.reason&&s.push(`reason: ${t.reason}`),s.join(" · ")},ut=t=>{const s=[];let l;for(const a of t.items){if(a.type==="spending"){const f=a.spending?.satoshis??0;l?s.push({requestID:a.requestID,text:`Also pay ${f.toLocaleString()} sats`,detail:oe(a),risky:!0,checked:!1}):l={requestID:a.requestID,satoshis:f,description:a.spending?.lineItems?.find(n=>n.description)?.description??a.reason,detail:oe(a)};continue}const i=pt(a);s.push({requestID:a.requestID,text:dt(a),detail:oe(a),risky:i,checked:!i})}const o=l?s.length?"connectAndPay":"pay":"connect";return{originator:t.originator,lines:s,payment:l,mode:o}},de="#F04438",re="#FFD24D",ue=t=>t<1?`${Math.round(t*100)}¢`:`$${t.toFixed(2)}`,ft=t=>t>=1e8?`${(t/1e8).toFixed(8)} BSV`:`${t.toLocaleString()} sats`,xt=t=>{const{request:s,onResponse:l,armed:o=!0}=t,{theme:a}=O(),{handleSelect:i,hideMenu:f}=V(),{addSnackbar:n}=J(),{chromeStorageService:d}=M(),c=u.useMemo(()=>ut(s),[s]),[y,g]=u.useState({}),p=u.useRef(s.items.length),k=Math.max(0,s.items.length-p.current),b=(j,P)=>y[j]??P,[r,x]=u.useState(),[h,w]=u.useState(pe),[v,S]=u.useState(!0),[A,R]=u.useState(!0),[B,Q]=u.useState(!1),[G,z]=u.useState(!1),[m,N]=u.useState("");u.useEffect(()=>{i("bsv"),f()},[i,f]),u.useEffect(()=>{F({action:"GET_BUNDLE_ALLOWANCE",originator:s.originator}).then(j=>{!j?.success||!j.data||(x(j.data),w(j.data.defaultUsd))}).catch(()=>{})},[s.originator]);const E=!!r?.usdPerBsv&&r.existingSats===void 0,I=c.payment&&r?.usdPerBsv?c.payment.satoshis/1e8*r.usdPerBsv:void 0,W=async j=>{z(!0),N("");try{if(j){const L=await q(d);if(!L.ok){N(L.message),z(!1);return}}const P={};for(const L of c.lines)P[L.requestID]=j&&b(L.requestID,L.checked);c.payment&&(P[c.payment.requestID]=j),await F({action:"BUNDLE_PERMISSION_RESPONSE",bundleID:s.bundleID,decisions:P,allowanceUsd:j&&E&&v?h:0,remember:A}),l()}catch(P){n(P instanceof Error?P.message:String(P),"error"),z(!1)}},U=c.mode==="pay"?"asks you to pay":"wants to connect",ve=c.mode==="pay"?"Pay":c.mode==="connectAndPay"?"Connect & pay":"Connect",we=()=>{const j=se.indexOf(h),P=se[(j+1)%se.length];w(P),S(P>0)},Z=G||!o,H=a.color.global.contrast,T=a.color.global.gray;return e.jsxs(C.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ne,{size:18,style:{color:re}})}),e.jsxs("p",{className:"text-sm leading-snug m-0",style:{color:T},children:[e.jsx("span",{className:"font-bold",style:{color:H},children:s.originator})," ",U]})]}),k>0&&e.jsxs("p",{className:"text-xs mb-2 m-0",style:{color:re},children:["+",k," more added while this was open"]}),e.jsxs("div",{className:"w-full rounded-2xl px-3 py-1 mb-3",style:{background:a.color.global.row,border:"1px solid rgba(255,255,255,0.06)"},children:[c.lines.map(j=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:b(j.requestID,j.checked),onChange:()=>g(P=>({...P,[j.requestID]:!b(j.requestID,j.checked)})),className:"mt-0.5 accent-green-400"}),e.jsx("span",{className:"text-xs",style:{color:j.risky?de:H},children:j.text})]},j.requestID)),E&&e.jsxs("div",{className:"flex items-start gap-3 py-2",children:[e.jsx("input",{type:"checkbox",checked:v&&h>0,onChange:()=>{h===0&&w(pe),S(!(v&&h>0))},className:"mt-0.5 accent-green-400","aria-label":"Monthly allowance"}),e.jsx("span",{className:"text-xs flex-1",style:{color:H},children:h>0?`Spend up to ${ue(h)} a month without asking`:"Ask me before every payment"}),e.jsx("button",{type:"button",className:"text-xs border-0 bg-transparent p-0 underline",style:{color:T},onClick:we,children:"change"})]})]}),c.payment&&e.jsxs("div",{className:"w-full rounded-2xl px-3 py-2 mb-3",style:{background:"rgba(161,255,139,0.06)",border:"1px solid rgba(161,255,139,0.2)"},children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider m-0 pb-1",style:{color:T},children:"Pay now"}),e.jsxs("p",{className:"text-sm font-semibold m-0",style:{color:re},children:[I!==void 0?ue(I):ft(c.payment.satoshis)," ",e.jsxs("span",{className:"font-normal",style:{color:H},children:["to ",s.originator]})]}),c.payment.description&&e.jsxs("p",{className:"text-xs m-0 mt-0.5",style:{color:T},children:["“",c.payment.description,"”"]})]}),e.jsxs("label",{className:"flex items-center gap-2 mb-3 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:A,onChange:()=>R(!A),className:"accent-green-400"}),e.jsx("span",{className:"text-xs",style:{color:T},children:"Remember this site"})]}),m&&e.jsx("p",{className:"text-xs text-center m-0 mb-2",style:{color:de},children:m}),e.jsxs("div",{className:"flex gap-3",children:[e.jsx("button",{type:"button",className:"flex-1 py-3 rounded-xl font-semibold text-sm",style:{background:"transparent",color:T,border:"1px solid rgba(255,255,255,0.1)"},disabled:Z,onClick:()=>{W(!1)},children:"Deny"}),e.jsxs("button",{type:"button",className:"flex-[2] py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, #FFD24D 0%, #EAB300 100%)",color:"#010101",opacity:Z?.6:1},disabled:Z,onClick:()=>{W(!0)},children:[G&&e.jsx(X,{size:14,className:"animate-spin"}),ve]})]}),e.jsxs("button",{type:"button",className:"flex items-center gap-1 mt-3 text-xs border-0 bg-transparent p-0",style:{color:T},onClick:()=>Q(!B),children:[B?e.jsx(Te,{size:12}):e.jsx($e,{size:12}),"Details"]}),B&&e.jsxs("ul",{className:"text-[11px] mt-1 pl-4 break-all",style:{color:T},children:[c.payment&&e.jsxs("li",{children:["pay: ",c.payment.detail]}),c.lines.map(j=>e.jsx("li",{children:j.detail},j.requestID)),E&&v&&h>0&&e.jsxs("li",{children:["allowance: monthly spending cap for ",s.originator]})]})]})};xe.Buffer=fe;xe.process=je;window.Buffer=fe;const mt=1e4,gt=2e3,_=new URLSearchParams(window.location.search).get("inpage"),ht=window.location.protocol==="chrome-extension:"&&window.top!==window&&!_&&!!window.location.ancestorOrigins?.length&&window.location.ancestorOrigins[0]!==window.location.origin,yt=(t,s)=>{const[l,o]=u.useState(t?void 0:!0),[a,i]=u.useState(!t);return u.useEffect(()=>{t&&F({action:"INPAGE_SHEET_CHECK",token:_}).then(f=>o(!!f?.success)).catch(()=>o(!1))},[t]),u.useEffect(()=>{if(!t||!s.current)return;let f;const n=new IntersectionObserver(d=>{const c=d[d.length-1];window.clearTimeout(f),c.isVisible?f=window.setTimeout(()=>i(!0),500):i(!1)},{threshold:[1],trackVisibility:!0,delay:100});return n.observe(s.current),()=>{window.clearTimeout(f),n.disconnect()}},[t,s]),{tokenOk:l,armed:l===!0&&a}},bt=()=>{const{theme:t}=O(),{isLocked:s,isReady:l}=M(),[o,a]=u.useState({kind:"loading"}),i=u.useRef(void 0),f=u.useRef(void 0),n=()=>{i.current!==void 0&&(window.clearTimeout(i.current),i.current=void 0)},d=u.useRef(o);d.current=o;const c=u.useCallback(async(r,x)=>{n();const h=d.current;if(r==="bundle"&&h.kind==="bundle"&&h.requestID===x){try{const v=await F({action:"GET_PROMPT_PAYLOAD",kind:r,requestID:x});v?.success&&v.data&&a({kind:"bundle",requestID:x,payload:v.data})}catch{}return}a({kind:"loading"});let w;try{w=await F({action:"GET_PROMPT_PAYLOAD",kind:r,requestID:x})}catch{w=void 0}w?.success&&w.data?a({kind:r,requestID:x,payload:w.data}):(a({kind:"expired"}),window.setTimeout(()=>{f.current?.()},gt))},[]),y=u.useCallback(async()=>{n();let r;try{r=await F({action:"CLOSE_PROMPT_WINDOW"})}catch{r=void 0}if(r===void 0){window.close();return}const x=r.data?.prompt;x&&(x.kind==="unlock"?a({kind:"unlock"}):x.requestID&&await c(x.kind,x.requestID))},[c]),g=u.useCallback(async()=>{n();let r;try{r=await F({action:"GET_NEXT_PROMPT"})}catch{r=void 0}if(r?.data?.prompt){await c(r.data.prompt.kind,r.data.prompt.requestID);return}if(r?.data?.busy){a({kind:"waiting"}),i.current=window.setTimeout(()=>{y()},mt);return}await y()},[c,y]);f.current=g,u.useEffect(()=>{if(!l)return;const r=new URLSearchParams(window.location.search),x=r.get("kind"),h=r.get("requestID");if(x==="unlock"){s?a({kind:"unlock"}):g();return}if(x&&h){c(x,h);return}g()},[l]),u.useEffect(()=>{const r=x=>{if(!(x?.action!=="SHOW_PROMPT"||!x.kind)){if(x.kind==="unlock"){n(),a({kind:"unlock"});return}x.requestID&&c(x.kind,x.requestID)}};return chrome.runtime.onMessage.addListener(r),()=>chrome.runtime.onMessage.removeListener(r)},[c]);const p=t.color.global.walletBackground,k=u.useRef(null),b=yt(!!_,k);return ht||b.tokenOk===!1?e.jsx("p",{className:"text-xs p-4",style:{color:"#98A2B3"},children:"Open bWalletX to answer this request."}):e.jsxs(Ae,{children:[_&&e.jsxs("div",{className:"flex items-center justify-between px-3 py-2",style:{background:p,borderBottom:"1px solid #ffffff14"},children:[e.jsx("span",{className:"text-sm font-bold",style:{color:t.color.global.contrast},children:"bWalletX"}),e.jsx("button",{type:"button","aria-label":"Deny and close",className:"text-sm border-0 bg-transparent p-1",style:{color:t.color.global.gray},onClick:()=>chrome.runtime.sendMessage({action:"DISMISS_PROMPT_PANEL"}).catch(()=>{}),children:"✕"})]}),e.jsxs("div",{ref:k,className:"flex items-center justify-center relative p-0",style:{width:_?"100%":"var(--wallet-width)",height:_?"calc(100vh - 41px)":"var(--wallet-height)",backgroundColor:p,pointerEvents:b.armed?void 0:"none"},children:[(!l||o.kind==="loading")&&e.jsx(ie,{message:"Loading...",theme:t}),o.kind==="waiting"&&e.jsx(ie,{message:"Waiting for request...",theme:t}),o.kind==="expired"&&e.jsx("p",{className:"text-xs",style:{color:t.color.global.gray},children:"This request expired or was already handled."}),o.kind==="unlock"&&e.jsx(Ie,{onUnlock:()=>{g()}}),o.kind==="permission"&&e.jsx(at,{request:o.payload,onResponse:()=>{g()}},o.requestID),o.kind==="bundle"&&e.jsx(xt,{request:o.payload,onResponse:()=>{g()}},o.requestID),o.kind==="groupedPermission"&&e.jsx(Oe,{request:o.payload,onResponse:()=>{g()}},o.requestID),o.kind==="counterpartyPermission"&&e.jsx(Be,{request:o.payload,onResponse:()=>{g()}},o.requestID),o.kind==="oneSatPermission"&&e.jsx(ot,{request:o.payload,onResponse:()=>{g()}},o.requestID),o.kind==="usbCheck"&&e.jsx(it,{request:o.payload,onResponse:()=>{g()}},o.requestID)]})]})},be=document.getElementById("root");if(!be)throw new Error("Root element");ke.createRoot(be).render(e.jsx(Ee,{children:e.jsx(Ce,{children:e.jsx(Pe,{children:e.jsx(De,{children:e.jsx(bt,{})})})})}));
//# sourceMappingURL=prompt-tab-DaY6wUd6.js.map
