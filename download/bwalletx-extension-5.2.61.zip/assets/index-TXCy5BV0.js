const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DH61V5i0.js","./index-CmoPvk1o.js","./crypto-CpMMdW64.js","./wocLimiter-uHHeeIuD.js","./wocLimiter-Cw4eDz7L.css","./index-D7NokxBA.css"])))=>i.map(i=>d[i]);
import{n as e,_ as t}from"./index-CmoPvk1o.js";import"./crypto-CpMMdW64.js";import"./wocLimiter-uHHeeIuD.js";const a=e("Share",{web:()=>t(()=>import("./web-DH61V5i0.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{a as Share};
//# sourceMappingURL=index-TXCy5BV0.js.map
