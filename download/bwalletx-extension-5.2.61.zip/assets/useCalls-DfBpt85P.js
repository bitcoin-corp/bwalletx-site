import{r as s}from"./wocLimiter-uHHeeIuD.js";import{U as r,V as o}from"./index-CmoPvk1o.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-DfBpt85P.js.map
