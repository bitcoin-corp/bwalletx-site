import{e}from"./index-CmoPvk1o.js";import{j as a}from"./main-CyndPhaY.js";const r=(o,t)=>{a(`bsv21:${o}`),t(e("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-B_tsbrpu.js.map
