import{r as u,j as e,A as ce,i as is,R as ls}from"./wocLimiter-uHHeeIuD.js";import{y as cs,_ as Ze,bg as Pt,v as Rt,w as ds}from"./crypto-CpMMdW64.js";import{aR as W,b as Z,H as F,gR as G,jc as pe,jd as O,je as ps,be as us,hP as fs,gT as A,b1 as Q,jf as et,iO as hs,i5 as ms,i6 as xs,i7 as gs,i8 as ys,M as bs,gS as xt,i4 as vs}from"./index-CmoPvk1o.js";import{r as Ct,t as ws,u as ve,b as De,U as js,v as Ae,w as ks,x as Ss,l as It,y as Ns,D as Es,h as J,C as b,i as P,a as T,P as Ce,z as Ps,B as Rs,E as Se,F as Cs,G as Ne,H as Is,I as Ee,A as $t,J as gt,q as $s,S as Ts,K as Ie,L as Ds,c as As,N as Os,O as yt,Q as Ls,R as Fs,T as Us,V as _s}from"./DollarAmount-CcdHBgp7.js";import{g as Bs,P as zs,a as Ms,h as bt,u as Ws,s as qs}from"./twetchCalls-6PyjwT_Q.js";import{a as vt,s as Tt,w as Hs,b as Ve}from"./approvalKind-C_G9UKut.js";import{A as Vs}from"./arrow-left-right-vuBqVcY6.js";import{L as Ks}from"./link-2-29gRX_tT.js";const Gs="once:",Ys=t=>typeof t=="string"&&t.startsWith(Gs),Dt=/\b(auth|authentication|sign[- ]?in|login|log[- ]?in)\b/i,wt="0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798",Js=t=>{if(t==="anyone")return!0;if(typeof t!="string"||!/^[0-9a-fA-F]{66}$|^[0-9a-fA-F]{130}$/.test(t.trim()))return!1;const s=t.trim().toLowerCase();if(s===wt)return!0;try{return cs.fromString(s).toString()===wt}catch{return!1}},Xs=new Set(["2:bwallet sign in","2:bads session","2:auth message signature"]),Qs=t=>`${t[0]}:${t[1].trim().toLowerCase()}`,Zs=t=>{if(typeof t!="string")return!1;const s=t.trim().toLowerCase();return Dt.test(s)||s==="message signing"},eo=t=>{const s=to(t);return!!s&&Xs.has(Qs(s))};function to(t){return Array.isArray(t)&&t.length===2&&typeof t[0]=="number"&&typeof t[1]=="string"?[t[0],t[1]]:null}const so=t=>{const s=t.map(o=>o.recipientsHash?`${o.requestID}#${o.recipientsHash}`:o.requestID).sort().join(`
`);let n=2166136261;for(let o=0;o<s.length;o++)n^=s.charCodeAt(o),n=Math.imul(n,16777619)>>>0;return`${t.length}:${n.toString(16)}`},oo=5,no=/e-?mail|phone|mobile|kyc|passport|licen[cs]e|birth|dob|address|ssn|national|tax|id_?number/i,se=t=>String(t.protocolID?.[1]??"unknown"),de=t=>Number(t.protocolID?.[0]??0),At=t=>!!(t.privileged||t.type==="certificate"&&(t.certificate?.fields??[]).some(s=>no.test(s))||we(t)),tt=t=>t.type==="protocol"&&!t.privileged&&t.protocolID?.[1]==="identity key retrieval"&&(t.counterparty===void 0||t.counterparty==="self"),ro=Dt,$e=t=>{const s=t.calls??[],n=(...o)=>s.length>0&&s.every(i=>o.includes(i));switch(t.usageType){case"signing":return n("verifySignature")?"verify":"sign";case"encrypting":return n("encrypt")?"encrypt":n("decrypt")?"decrypt":"encryptDecrypt";case"hmac":return"hmac";case"linkageRevelation":return"linkage";case"publicKey":return"publicKey";case"generic":return"generic";default:return"other"}},ye=t=>Js(t.counterparty),st=t=>t.type!=="protocol"?!1:we(t)?!0:tt(t)||be(t)||t.usageType==="generic"||t.usageType==="identityKey"?!1:de(t)===1?Zs(se(t)):de(t)===2&&ye(t)&&!eo(t.protocolID),we=t=>Ys(t.requestID),ao=t=>{const s=$e(t);return s==="sign"||s==="other"},Ot=t=>t.type==="protocol"&&!t.privileged&&!st(t)&&(tt(t)||de(t)!==1&&ao(t)&&(ye(t)||ro.test(se(t))&&(t.counterparty===void 0||t.counterparty==="self"))),io=[[/agent history/i,"Ask b chats"],[/\b(chat|message)s?\b/i,"chats"],[/\bnotes?\b/i,"notes"],[/\b(history|private|backup|vault|encrypt)/i,"data"]],Lt=t=>{if(t.type!=="protocol"||t.privileged||t.counterparty!=="self"||Ot(t))return;const s=se(t);return io.find(([n])=>n.test(s))?.[1]},lo="bap",co=[1,"sigma"],be=t=>t.type==="protocol"&&!t.privileged&&se(t).toLowerCase()===co[1],Xe=t=>t.type==="basket"&&t.basket===lo,Ft={verify:"Check signatures with",encrypt:"Encrypt with",decrypt:"Decrypt with",encryptDecrypt:"Encrypt and decrypt with",hmac:"Make and check HMAC codes with",linkage:"Reveal how others can link",publicKey:"See a public key from"},Qe=t=>t.originator,po=t=>{const s=se(t),n=Qe(t);if(we(t))return $e(t)==="hmac"?`Make one code as you for ${n} ("${s}"). The service it is for could accept it as you`:`Sign once as you for ${n} ("${s}"). Other sites could accept this too`;const o=$e(t);return o==="sign"||o==="other"?ye(t)?`Sign as you for ${n} ("${s}"), a signature anyone can check`:`Sign with your "${s}" keys for ${n}`:`${o==="generic"?"Use":Ft[o]} your "${s}" keys for ${n}`},jt=t=>{switch(t.type){case"protocol":{if(tt(t))return"See your public identity (the key that names you)";if(st(t))return po(t);const s=$e(t),n=se(t),o=s!=="sign"&&s!=="generic"&&s!=="other"?Ft[s]:"";if(de(t)===1&&!be(t)&&s!=="generic")return o?`${o} your "${n}" keys for ${Qe(t)}`:`Sign with your "${n}" keys for ${Qe(t)}`;if(ye(t)){if(s==="sign"||s==="other")return"Prove it's you (a signature anyone can check)";if(s==="encrypt")return`Encrypt with your "${n}" keys, readable by anyone`;if(o)return`${o} your "${n}" keys`}if(be(t))return"Sign your posts and likes as you";const i=Lt(t);return i?`Use keys from your wallet for your ${i}`:de(t)===2&&t.counterparty&&t.counterparty!=="self"&&!ye(t)?o?`${o} your "${n}" keys, shared with one named person or service`:`Sign and encrypt with your "${n}" keys, shared with one named person or service`:o?`${o} your "${n}" keys`:`Sign and encrypt anything with your "${n}" keys`}case"basket":return Xe(t)?"Use your public profile (name and picture) on its posts":"Keep its tickets and tokens in your wallet";case"certificate":{const s=t.certificate?.fields??[];return s.length?`See your certificate details (${s.join(", ")})`:"See your certificates"}default:return"Spend from your wallet"}},Ut=t=>(t??[]).map((s,n)=>({x:s,i:n})).sort((s,n)=>n.x.satoshis-s.x.satoshis||s.i-n.i).map(({x:s})=>s),Ke=t=>{const s=[];switch(t.type){case"protocol":s.push(`protocol "${se(t)}" level ${de(t)}`),t.counterparty&&s.push(`counterparty ${t.counterparty}`);break;case"basket":s.push(Ct(t.basket)==="Unknown basket"?"Unknown basket":`basket "${t.basket}"`);break;case"certificate":s.push(`certificate ${t.certificate?.certType??""}`,`verifier ${t.certificate?.verifier??""}`);break;case"spending":s.push(`${t.spending?.satoshis??0} sats`),t.labels?.length&&s.push(`labels: ${t.labels.join(", ")}`);break}return t.privileged&&s.push("privileged"),t.reason&&s.push(`reason: ${t.reason}`),s.join(" · ")},uo=t=>{const s=[];let n;for(const r of t.items){if(r.type==="spending"){const m=r.spending?.satoshis??0;!n&&!r.addedLive?n={requestID:r.requestID,satoshis:m,description:r.spending?.lineItems?.find(x=>x.description)?.description??r.reason,detail:Ke(r),...r.labels?.length?{labels:[...r.labels]}:{},...r.recipients?.length||r.recipientsHash!==void 0?{recipients:(r.recipients??[]).map(x=>({...x}))}:{}}:s.push({requestID:r.requestID,text:`${r.addedLive?"New: pay":"Also pay"} ${m.toLocaleString()} sats`,detail:[Ke(r),...Ut(r.recipients).map(x=>`to ${x.to}: ${x.satoshis} sats`)].join(" · "),risky:!0,checked:!1,...r.addedLive?{isNew:!0}:{}});continue}const d=we(r)&&!r.addedLive&&t.items.length===1,c=d?!1:At(r),a=!!r.seal&&Bs(r.requestID)&&!r.addedLive&&t.items.length===1,f=d||a||!c&&!r.addedLive&&!st(r);s.push({requestID:r.requestID,...d?{once:!0}:{},text:r.addedLive?`New: ${jt(r)}`:jt(r),...r.addedLive?{isNew:!0}:{},detail:Ke(r),risky:c,checked:f,signIn:Ot(r),privateLabel:Lt(r),...be(r)||Xe(r)?{post:!0}:{}})}const o=n?s.length?"connectAndPay":"pay":"connect",i=t.items.some(be)||t.items.some(Xe);return{originator:t.originator,lines:s,payment:n,mode:o,...i?{purpose:"post"}:{}}},fo=(t,s)=>{const n=t.lines.filter(r=>!r.risky&&!r.isNew),o=n.find(r=>r.privateLabel)?.privateLabel,i=r=>{switch(s){case"signin":return r.signIn===!0;case"private":return r.signIn===!0&&r.checked||!!o&&r.privateLabel===o;case"post":return r.post===!0;case"connect":return r.checked;case"pay":case"mint":return r.signIn===!0&&r.checked;default:return!1}};return new Set(n.filter(i).map(r=>r.requestID))},ho=(t,s,n,o)=>({summarised:s?new Set:fo(t,o),faceTicks:new Set(t.lines.filter(i=>s||i.isNew).map(i=>i.requestID)),hidden:new Set(n?t.lines.filter(i=>!n.has(i.requestID)).map(i=>i.requestID):[])}),mo=(t,s)=>s?.hidden?.size?t.filter(n=>!s.hidden.has(n.requestID)):t,xo=(t,s,n,o,i={})=>{const r={};for(const d of t.lines){if(!o&&i.hidden?.has(d.requestID))continue;const c=o||!!i.faceTicks?.has(d.requestID);if(s&&d.isNew&&n[d.requestID]===void 0)continue;if(!c&&!d.isNew&&!i.summarised?.has(d.requestID)){r[d.requestID]=!1;continue}const a=n[d.requestID]??(d.isNew?!1:d.checked||!d.risky&&!c);r[d.requestID]=s&&a}return t.payment&&(r[t.payment.requestID]=s),r},go=(t,s,n,o,i={})=>({decisions:xo(t,s==="allow",n,o,i),block:s==="block",mayStore:s==="allow"}),yo=t=>At(t)||t.type==="protocol"&&t.counterparty==="anyone"?!1:t.type==="basket"?!!t.basket&&!ws(t.basket):!1,bo=t=>!t.items.some(s=>s.framePair)&&t.items.some(s=>yo(s)),vo=t=>{const{request:s,onResponse:n}=t,{theme:o}=W(),{handleSelect:i,hideMenu:r}=ve(),{addSnackbar:d}=De(),[c,a]=u.useState(!1),[f,m]=u.useState(""),{chromeStorageService:x}=Z(),{permissions:l}=s,[w,j]=u.useState(()=>l.protocols.map(()=>!0));u.useEffect(()=>{i("bsv"),r()},[i,r]);const p=()=>{const E=l.protocols.filter((R,U)=>w[U]);return E.length===0?{}:{protocols:E}},v=async()=>{a(!0),m("");try{const E=await pe(x);if(!E.ok){m(E.message),a(!1);return}Ae(s.originator),O({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:p()}),n()}catch(E){d(E instanceof Error?E.message:String(E),"error"),a(!1)}},S=async()=>{a(!0),O({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),n()},g=E=>j(R=>R.map((U,oe)=>oe===E?!U:U)),y=s.counterpartyLabel??`${s.counterparty.slice(0,8)}...${s.counterparty.slice(-8)}`;return e.jsxs(F.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(js,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Counterparty Permission"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","wants to interact with a counterparty"]})]})]}),e.jsxs(F.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all font-mono",style:{color:o.color.global.contrast},children:y})]}),e.jsx(G,{when:!!l.description,children:e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Purpose"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:l.description})]})}),e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),l.protocols.map((E,R)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:R<l.protocols.length-1?"1px solid rgba(255,255,255,0.04)":"none"},children:[e.jsx("input",{type:"checkbox",checked:w[R],onChange:()=>g(R),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[E.protocolID?.[1]," (level ",E.protocolID?.[0],")"]}),E.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:E.description})]})]},`proto-${R}`))]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[f&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:f}),e.jsxs(F.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:c?.6:1},disabled:c,onClick:v,whileHover:{scale:c?1:1.02},whileTap:{scale:c?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[c&&e.jsx(Ze,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(F.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:c?.5:1},disabled:c,onClick:S,whileHover:{scale:c?1:1.02},whileTap:{scale:c?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},wo={"2:3241645161d8":{label:"BRC-29 payment",description:"An application is requesting permission to derive payment addresses for a specific recipient."},...Object.fromEntries(zs.map(t=>[`${t.protocolID[0]}:${t.protocolID[1]}`,{label:t.label,description:t.description}]))},_t=t=>t?wo[`${t[0]}:${t[1]}`]:void 0,Bt=t=>_t(t)?.label??t?.[1],jo=t=>{switch(t){case 0:return"Level 0 · any app";case 1:return"Level 1 · same keys for any app using this protocol";case 2:return"Level 2 · same keys for any app using this protocol with this recipient";default:return`Level ${t??0}`}},ko=t=>{const{request:s,onResponse:n}=t,{theme:o}=W(),{handleSelect:i,hideMenu:r}=ve(),{addSnackbar:d}=De(),[c,a]=u.useState(!1),[f,m]=u.useState(""),{chromeStorageService:x}=Z(),l=x.getCurrentAccountObject().account?.pubKeys?.identityPubKey??"",{permissions:w}=s,j=x.getCurrentAccountObject().account,p=Ms(j?.addresses?.identityAddress,j?.name??"").payable?.trim()??"",v=p?p.startsWith("$")?p:`$${p}`:"",[S,g]=u.useState(!1);u.useEffect(()=>{i("bsv"),r()},[i,r]);const y=()=>{const C={},q=(w.protocolPermissions??[]).filter(Le=>!bt(Le.protocolID));return q.length>0&&(C.protocolPermissions=q),w.basketAccess?.length&&(C.basketAccess=w.basketAccess),C},E=async()=>{a(!0),m("");try{const C=await pe(x);if(!C.ok){m(C.message),a(!1);return}Ae(s.originator),O({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:y()}),n()}catch(C){d(C instanceof Error?C.message:String(C),"error"),a(!1)}},R=async()=>{a(!0),O({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),n()},U=(w.protocolPermissions??[]).filter(C=>!bt(C.protocolID)),oe=s.originator.replace(/^[a-z]+:\/\//i,"").split(/[/?#]/)[0],Oe=`${oe} wants to sign you in${v?` as ${v}`:""}`,je=[...U.map(C=>`Use your keys for “${Bt(C.protocolID)}”`),...(w.basketAccess??[]).map(C=>`See its own items in “${Ct(C.basket)}”`)];return e.jsxs(F.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsx("div",{className:"w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-4",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ks,{size:22,style:{color:"var(--bw-accent-hi)"}})}),e.jsx("h1",{className:"text-xl font-bold leading-snug text-center break-words",style:{color:o.color.global.contrast},"data-testid":"connect-title",children:Oe}),e.jsxs("p",{className:"text-xs mt-2 text-center break-all",style:{color:o.color.global.gray},children:["Request from"," ",e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})]}),e.jsxs("p",{className:"text-sm mt-4 text-center leading-relaxed",style:{color:o.color.global.gray},children:["Nothing is spent. If ",oe," later wants anything more, ",ce," will ask you then."]}),e.jsx(Ss,{site:ps(s.originator),account:l,style:{marginTop:12}}),e.jsxs(G,{when:je.length>0,children:[e.jsx("button",{type:"button",className:"text-xs mt-4 underline self-center",style:{color:o.color.global.gray,background:"transparent"},onClick:()=>g(C=>!C),children:S?"Hide details":"What does signing in allow?"}),e.jsx(G,{when:S,children:e.jsx("ul",{className:"text-xs mt-2 leading-relaxed list-disc pl-5",style:{color:o.color.global.gray},children:je.map((C,q)=>e.jsx("li",{children:C},q))})})]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-6",children:[f&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:f}),e.jsxs(F.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:c?.6:1},disabled:c,onClick:E,whileTap:{scale:c?1:.97},"data-testid":"connect-sign-in",children:[c&&e.jsx(Ze,{size:14,className:"animate-spin"}),"Sign in"]}),e.jsx(F.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:c?.5:1},disabled:c,onClick:R,whileTap:{scale:c?1:.97},children:"Cancel"})]})]})},So=2e3;async function Te(t,s=So){let n;try{return await Promise.race([t.catch(()=>{}),new Promise(o=>{n=setTimeout(()=>o(void 0),s)})])}catch{return}finally{n&&clearTimeout(n)}}function No(t,s){return t?.find(n=>n.startsWith(`${s}:`))?.slice(s.length+1)}async function Eo(t,s,n=[]){const o=t.ordfs;if(typeof o?.bulkMetadata!="function")return{state:"unverified"};const i=`${s}:-2`,r=await Te(o.bulkMetadata([i])),d=r?.[i]??r?.[s]??Object.values(r??{}).find(f=>!!f?.contentType);if(!d?.contentType)return{state:"unverified"};const c={contentType:d.contentType,origin:d.origin,name:typeof d.map?.name=="string"?d.map.name:void 0},a=n.find(f=>f.includes("/"));return a&&a!==d.contentType?{state:"mismatch",note:`Content type is ${d.contentType}, not ${a}`,...c}:{state:"verified",...c}}async function Po(t,s,n){const o=t.opns;if(typeof o?.getOrigin!="function")return{state:"unverified"};const i=await Te(o.getOrigin(s));return i?.outpoint?i.outpoint!==n?{state:"mismatch",note:`“${s}” currently resolves to a different output`}:{state:"verified"}:{state:"unverified"}}async function Ro(t,s,n,o=[]){const i=t.bsv21;if(typeof i?.getTokenDetails!="function")return{state:"unverified"};const r=await Te(i.getTokenDetails(s,{fresh:!0}));if(!r)return{state:"unverified"};if(r.status?.is_active===!1)return{state:"mismatch",note:"Token is not active on the overlay"};const d=r.token?.sym;if(n&&d&&n.toLowerCase()!==d.toLowerCase())return{state:"mismatch",note:`Token symbol is ${d}, not ${n}`};if(o.length>0&&typeof i.getOutputStatus=="function"){const c=await Te(i.getOutputStatus(s,o));if(!c)return{state:"unverified"};const a=c.filter(f=>f.state==="spent"||f.state==="unknown");if(a.length>0)return{state:"mismatch",note:a.length===1?"A spent token output is not valid on the overlay":`${a.length} spent token outputs are not valid on the overlay`};if(c.some(f=>f.state==="queued"))return{state:"unverified"}}return{state:"verified",...d?{name:d}:{}}}async function Co(t,s,n,o,i){if(!t||!s)return{state:"unverified"};const r=s==="purchase"||s.endsWith(".purchase"),d=s==="token-transfer"||s.startsWith("bsv21.");if(!r&&!d)return{state:"unverified"};const c={kindOrIntent:s,hasOrdfs:!!t.ordfs,hasBulk:typeof t.ordfs?.bulkMetadata=="function",inputTagSets:n.map(a=>a.tags),outputTagSets:o.map(a=>a.tags)};try{const a=[...n.map(p=>p.tags),...o.map(p=>p.tags)],f=p=>a.flatMap(v=>v.filter(S=>S.startsWith(`${p}:`)).map(S=>S.slice(p.length+1))),m=p=>{for(const v of a){const S=No(v,p);if(S)return S}},x=m("bsv21");if(x||s==="bsv21.purchase"||s==="token-transfer"||s.startsWith("bsv21.")){if(!x)return{state:"unverified"};const v=n.filter(g=>g.basket?.includes("bsv21")||g.tags.some(y=>y.startsWith("bsv21:"))).map(g=>g.outpoint).filter(Boolean);let S=m("sym");for(const g of n)if(g.customInstructions)try{const y=JSON.parse(g.customInstructions).sym;if(typeof y=="string"&&y.trim()){S=y.trim();break}}catch{}return await Ro(t,x,S,v)}const l=m("name"),w=m("origin");if(c.name=l,c.origin=w,l&&w&&o.some(p=>p.basket?.includes("opns"))||s==="opns.purchase")return!l||!w?{state:"unverified"}:await Po(t,l,w);if(!w)return c.reason="no-origin-tag",globalThis.__lastVerify=c,{state:"unverified"};const j=await Eo(t,w,f("type"));if(c.verifyOrdinal=j,j.origin&&i)try{j.contentUrl=i(j.origin)}catch(p){c.contentUrlError=String(p)}return globalThis.__lastVerify=c,j}catch(a){return c.error=String(a),globalThis.__lastVerify=c,{state:"unverified"}}}function zt(t){if(!t||typeof t!="object")return!1;const s=t;return Array.isArray(s.panels)&&typeof s.title=="string"}var Io=`
.opp-root {
  --opp-bg: #ffffff;
  --opp-fg: #111827;
  --opp-muted: #6b7280;
  --opp-card-bg: #f7f8fa;
  --opp-card-border: #eceef2;
  --opp-accent: #E5A920;
  --opp-approve-bg: #E5A920;
  --opp-approve-fg: #ffffff;
  --opp-reject-bg: #ffffff;
  --opp-reject-fg: #111827;
  --opp-reject-border: #d1d5db;
  --opp-status-bg: #FFFBE6;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #ECFDF5;
  --opp-trust-ok-fg: #059669;
  --opp-trust-warn-bg: #FFFBEB;
  --opp-trust-warn-fg: #D97706;
  --opp-trust-bad-bg: #FEF2F2;
  --opp-trust-bad-fg: #DC2626;

  font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--opp-bg);
  color: var(--opp-fg);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 480px;
  min-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
}

.opp-bottom {
  margin-top: auto;
  display: flex;
  flex-direction: column;
}

.opp-root.opp-dark {
  --opp-bg: #0F1117;
  --opp-fg: #F9FAFB;
  --opp-muted: #9ca3af;
  --opp-card-bg: #1A1D27;
  --opp-card-border: #232636;
  --opp-reject-bg: #0F1117;
  --opp-reject-fg: #F9FAFB;
  --opp-reject-border: #2D3142;
  --opp-status-bg: #2A2408;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #0A2E1F;
  --opp-trust-ok-fg: #34D399;
  --opp-trust-warn-bg: #2A2008;
  --opp-trust-warn-fg: #FBBF24;
  --opp-trust-bad-bg: #2A1215;
  --opp-trust-bad-fg: #F87171;
}

.opp-body {
  padding: 24px 20px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
}

.opp-coin {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
}

.opp-title {
  font-size: 16px;
  font-weight: 700;
  margin: 0;
  text-align: center;
}

.opp-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  margin: 0;
  text-align: center;
  line-height: 1.4;
}

.opp-status {
  background: var(--opp-status-bg);
  color: var(--opp-status-fg);
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
  margin-top: 4px;
  border: 1px solid var(--opp-card-border);
}

.opp-card {
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px;
  padding: 16px;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.opp-featured {
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px 8px;
  padding: 16px;
}

/* Subtle danger chrome for burn / destructive token ops */
.opp-featured-danger {
  border-color: rgba(220, 38, 38, 0.45);
  background: color-mix(in srgb, var(--opp-card-bg) 88%, #7f1d1d 12%);
}

.opp-featured-danger .opp-featured-title {
  color: #f87171;
}

.opp-featured-danger .opp-featured-image,
.opp-featured-danger .opp-featured-placeholder {
  border: 1px solid rgba(220, 38, 38, 0.35);
  background: rgba(127, 29, 29, 0.25);
  color: #fca5a5;
}

.opp-dark .opp-featured-danger {
  border-color: rgba(248, 113, 113, 0.4);
  background: color-mix(in srgb, var(--opp-card-bg) 85%, #450a0a 15%);
}

.opp-preview-pair {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.opp-preview-arrow {
  color: var(--opp-muted);
  font-size: 14px;
  line-height: 1;
}

.opp-preview-pair .opp-featured-image {
  width: 64px;
  height: 64px;
}

.opp-featured-image {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-featured-image-token {
  width: 48px;
  height: 48px;
  border-radius: 999px;
}

.opp-featured-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--opp-muted);
  font-size: 18px;
}

.opp-preview-opns {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
}

.opp-preview-opns-avatar {
  width: 36px;
  height: 36px;
  border-radius: 999px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-preview-opns-name {
  font-size: 11px;
  font-weight: 600;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  color: var(--opp-fg, inherit);
}

.opp-preview-text {
  margin: 0;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
  font-size: 9px;
  line-height: 1.25;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  color: var(--opp-muted);
}

.opp-preview-json {
  white-space: pre;
  overflow: auto;
}

.opp-preview-frame {
  border: 0;
  padding: 0;
  overflow: hidden;
  background: #fff;
  pointer-events: none;
}

.opp-preview-value {
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  background: rgba(229, 169, 32, 0.12);
  border: 1px solid rgba(229, 169, 32, 0.35);
  color: var(--opp-fg, inherit);
}

.opp-preview-value-icon {
  width: 32px;
  height: 32px;
  color: #E5A920;
}

/* Amount subtitles must never ellipsis — full sat counts are the point. */
.opp-featured-subtitle-text.opp-amount {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-variant-numeric: tabular-nums;
  white-space: normal;
  overflow: visible;
  text-overflow: unset;
  word-break: keep-all;
}

.opp-featured-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  flex: 1;
}

.opp-featured-title {
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.opp-featured-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.opp-featured-subtitle-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
}

.opp-featured-meta-line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  color: var(--opp-muted);
}

.opp-featured-meta-line-bare {
  align-items: center;
}

.opp-featured-meta-key {
  flex-shrink: 0;
  opacity: 0.75;
  min-width: 2.5em;
}

.opp-featured-meta-value {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  flex: 1;
}

.opp-featured-meta-value-mono {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 11px;
}

.opp-trust-wrap {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0 20px 8px;
}

.opp-trust {
  display: inline-flex;
  align-self: flex-start;
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 600;
}

.opp-trust-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-trust-note {
  padding: 10px;
  border-radius: 8px;
  font-size: 11px;
  line-height: 1.35;
}

.opp-trust-note-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-note-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-note-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.opp-row-key {
  color: var(--opp-muted);
  flex-shrink: 0;
}

.opp-row-value-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 70%;
  justify-content: flex-end;
}

.opp-row-value {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 12px;
  font-weight: 500;
  text-align: right;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.opp-copy {
  flex-shrink: 0;
  width: 22px;
  height: 22px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  border: 1px solid var(--opp-reject-border);
  background: var(--opp-bg);
  color: var(--opp-fg);
  cursor: pointer;
}

.opp-copy:hover {
  border-color: var(--opp-accent);
  color: var(--opp-accent);
}

.opp-fee-note {
  font-size: 11px;
  color: var(--opp-muted);
  line-height: 1.3;
  margin-top: -4px;
}

.opp-actions {
  display: flex;
  gap: 12px;
  padding: 20px 20px 12px;
}

.opp-button {
  flex: 1;
  padding: 0 16px;
  height: 48px;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid transparent;
  transition: opacity 120ms ease;
}

.opp-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.opp-button-reject {
  background: var(--opp-reject-bg);
  color: var(--opp-reject-fg);
  border-color: var(--opp-reject-border);
}

.opp-button-approve {
  background: var(--opp-approve-bg);
  color: var(--opp-approve-fg);
}

.opp-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 20px 16px;
  font-size: 11px;
  font-weight: 500;
  color: var(--opp-muted);
}
`;function $o({request:t,onApprove:s,onReject:n,theme:o="auto",services:i}){const r=Bo(o),d=To(t),[c,a]=u.useState(!1),[f,m]=u.useState(),x=t.kind==="transaction"&&zt(t.payload)?t.payload:void 0;u.useEffect(()=>{if(!i||!x?.trust||!x.verify)return;let p=!0;const v=i.ordfs?.getContentUrl?.bind(i.ordfs);return Co(i,x.verify.kind,x.verify.inputs,x.verify.outputs,v).then(S=>{p&&S&&m(S)}).catch(()=>{}),()=>{p=!1}},[i,x]);const l=f?Do(d,f):d,w=p=>()=>{if(!c){a(!0);try{p==="approve"?s():n()}finally{a(!1)}}};u.useEffect(()=>{const p=v=>{c||(v.key==="Escape"?n():v.key==="Enter"&&s())};return window.addEventListener("keydown",p),()=>window.removeEventListener("keydown",p)},[s,n,c]);const j=`opp-root${r==="dark"?" opp-dark":""}`;return e.jsxs("div",{className:j,children:[e.jsx("style",{children:Io}),e.jsxs("div",{className:"opp-body",children:[e.jsxs("svg",{className:"opp-coin",viewBox:"0 0 100 100","aria-label":"1Sat Ordinals",children:[e.jsx("circle",{cx:"50",cy:"50",r:"50",fill:"#222"}),e.jsx("circle",{cx:"50",cy:"50",r:"40",fill:"#fff"}),e.jsx("circle",{cx:"50",cy:"50",r:"32",fill:"#E5A920"}),e.jsx("rect",{x:"47",y:"28",width:"6",height:"28",rx:"3",fill:"#fff"})]}),e.jsx("h2",{className:"opp-title",children:l.title}),e.jsx("p",{className:"opp-subtitle",children:l.subtitle}),e.jsx("div",{className:"opp-status",children:"Awaiting Approval"})]}),l.panels.map((p,v)=>{const S=p.variant??"ordinal",g=["opp-featured"];return S==="token"&&g.push("opp-featured-token"),S==="value"&&g.push("opp-featured-value"),p.tone==="danger"&&g.push("opp-featured-danger"),e.jsxs("div",{className:g.join(" "),children:[p.prior?e.jsxs("div",{className:"opp-preview-pair","aria-label":"Previous and new inscription",children:[e.jsx(Ge,{panel:{...p,previewKind:p.prior.previewKind,imageUrl:p.prior.imageUrl,contentUrl:p.prior.contentUrl,previewText:p.prior.previewText,prior:void 0}}),e.jsx("span",{className:"opp-preview-arrow","aria-hidden":!0,children:"→"}),e.jsx(Ge,{panel:p})]}):e.jsx(Ge,{panel:p}),e.jsxs("div",{className:"opp-featured-meta",children:[e.jsx("div",{className:"opp-featured-title",children:p.title}),p.subtitle&&e.jsxs("div",{className:"opp-featured-subtitle",children:[e.jsx("span",{className:p.amountSats!=null?"opp-featured-subtitle-text opp-amount":"opp-featured-subtitle-text",children:p.subtitle}),p.subtitleCopy&&e.jsx(Ye,{text:p.subtitleCopy})]}),(p.meta??[]).map(y=>e.jsxs("div",{className:`opp-featured-meta-line${y.key?"":" opp-featured-meta-line-bare"}`,children:[y.key?e.jsx("span",{className:"opp-featured-meta-key",children:y.key}):null,e.jsx("span",{className:`opp-featured-meta-value${y.key?"":" opp-featured-meta-value-mono"}`,title:y.copyValue??y.value,children:y.value}),y.copyValue&&e.jsx(Ye,{text:y.copyValue})]},`${y.key}:${y.value}`))]})]},`panel-${v}-${p.title}`)}),l.trust&&e.jsxs("div",{className:"opp-trust-wrap",children:[e.jsx("span",{className:`opp-trust opp-trust-${l.trust.state}`,children:Lo(l.trust.state)}),l.trust.note&&e.jsx("div",{className:`opp-trust-note opp-trust-note-${l.trust.state}`,children:l.trust.note})]}),(l.rows.length>0||l.indexerFee||l.funding)&&e.jsxs("div",{className:"opp-card",children:[l.rows.map(p=>e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:p.key}),e.jsxs("span",{className:"opp-row-value-wrap",children:[e.jsx("span",{className:"opp-row-value",title:p.copyValue??p.value,children:p.value}),p.copyValue&&e.jsx(Ye,{text:p.copyValue})]})]},`${p.key}:${p.value}`)),l.indexerFee&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"1Sat Overlay Fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[kt(l.indexerFee.sats)," sats"]})]}),l.funding?.networkFeeSats!=null&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"Network fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[kt(l.funding.networkFeeSats)," sats"]})]}),l.funding?.note&&e.jsx("div",{className:"opp-fee-note",children:l.funding.note})]}),e.jsxs("div",{className:"opp-bottom",children:[e.jsxs("div",{className:"opp-actions",children:[e.jsx("button",{type:"button",className:"opp-button opp-button-reject",onClick:w("reject"),disabled:c,children:"Reject"}),e.jsx("button",{type:"button",className:"opp-button opp-button-approve",onClick:w("approve"),disabled:c,children:"Approve"})]}),e.jsx("div",{className:"opp-footer",children:e.jsx("span",{children:"Secured by 1Sat Ordinals"})})]})]})}function To(t){if(t.kind==="transaction"&&zt(t.payload))return{title:t.payload.title,subtitle:t.payload.subtitle,panels:t.payload.panels,rows:t.payload.rows,trust:t.payload.trust,indexerFee:t.payload.indexerFee,funding:t.payload.funding};if(t.kind==="basketAccess"){const s=t.payload.baskets??[],n=s.length>0&&s.every(r=>r.scope||r.basket.startsWith("p ")),o=s.filter(r=>r.imageUrl||r.name||r.value).map(r=>({title:r.scope==="collection"?r.name?`Collection · ${r.name}`:"Collection":r.scope?r.scope:"Basket",subtitle:r.value?r.value.length>24?`${r.value.slice(0,10)}…${r.value.slice(-10)}`:r.value:r.basket,subtitleCopy:r.value,...r.imageUrl&&{previewKind:"image",contentUrl:r.imageUrl,imageUrl:r.imageUrl},tone:"default"})),i=s.flatMap(r=>r.scope==="collection"?r.description?[{key:"Access",value:r.description}]:[]:[{key:r.basket,value:r.description??"List, insert, and remove outputs"}]);return{title:n?s.length===1?s[0].scope==="collection"?"Grant Collection View":"Grant Item View":`Grant View (${s.length})`:s.length===1?"Grant Basket Access":`Grant Access to ${s.length} Baskets`,subtitle:n?`${Pe(t.originator)} wants to view items in your wallet`:`${Pe(t.originator)} wants to read and write 1Sat baskets`,panels:o,rows:i}}return t.kind==="protocol"?{title:"Protocol Access",subtitle:`${Pe(t.originator)} wants protocol access`,panels:[],rows:[{key:"Detail",value:t.summary||"Protocol request"}]}:{title:"Signature Request",subtitle:`${Pe(t.originator)} wants a signature`,panels:[],rows:[{key:"Detail",value:t.summary||"Signature request"}]}}function Do(t,s){const n=t.panels.map((o,i)=>{if(i!==0)return o;const r=o.previewKind==="opns",d=s.contentType?Ao(s.contentType):void 0,c=r?"opns":d&&d!=="none"?d:o.previewKind,a=s.contentUrl??o.contentUrl??o.imageUrl;let f=o.subtitle;if(s.name&&!r)if(!f)f=s.name;else{const m=f.trim().split(/\s+/);m.length>=2&&(m[m.length-1]=s.name,f=m.join(" "))}return{...o,previewKind:c,...f?{subtitle:f}:{},...r?{...s.contentUrl&&!o.imageUrl?{imageUrl:s.contentUrl}:o.imageUrl?{imageUrl:o.imageUrl}:{}}:c==="image"?{imageUrl:a,contentUrl:a}:a?{contentUrl:a,imageUrl:void 0}:{}}});return{...t,panels:n,trust:{state:s.state,note:s.note}}}function Ao(t){const s=t.toLowerCase();return s==="image/svg+xml"||s==="svg"||s.endsWith("+svg")?"svg":s.startsWith("image/")?"image":s.includes("json")?"json":s.includes("html")||s==="application/xhtml+xml"?"html":s.startsWith("text/")?"text":"none"}function Oo(t){return`${t.toLocaleString("en-US")} sats`}function kt(t){return t.toLocaleString("en-US")}function Lo(t){return t==="verified"?"Verified":t==="mismatch"?"Mismatch":"Unverified"}function Ge({panel:t}){const s=t.variant??"ordinal",n=s==="token"?"opp-featured-image opp-featured-image-token":s==="value"?"opp-featured-image opp-preview-value":"opp-featured-image",o=t.previewKind??(t.imageUrl?"image":"none"),i=t.contentUrl??t.imageUrl,[r,d]=u.useState(!1);if(s==="value"){const c=t.valueIcon??"pay";return e.jsx("div",{className:n,title:t.amountSats!=null?Oo(t.amountSats):void 0,"aria-hidden":!0,children:e.jsx(Uo,{kind:c})})}if(o==="opns"){const c=!!t.imageUrl&&!r;return e.jsxs("div",{className:`${n} opp-preview-opns`,"aria-hidden":!t.opnsHero,children:[c?e.jsx("img",{className:"opp-preview-opns-avatar",src:t.imageUrl,alt:"",onError:()=>d(!0)}):e.jsx("div",{className:"opp-preview-opns-avatar opp-featured-placeholder",children:"◈"}),e.jsx("span",{className:"opp-preview-opns-name",title:t.opnsHero,children:t.opnsHero??"OpNS"})]})}return o==="image"&&t.imageUrl&&!r?e.jsx("img",{className:n,src:t.imageUrl,alt:t.title,onError:()=>d(!0)}):o==="image"&&r?e.jsx("div",{className:`${n} opp-featured-placeholder`,"aria-hidden":!0,children:"▭"}):(o==="text"||o==="json"||o==="html")&&t.previewText?e.jsx("pre",{className:`${n} opp-preview-text${o==="json"?" opp-preview-json":""}`,children:t.previewText}):(o==="text"||o==="json")&&i?e.jsx(_o,{url:i,kind:o,className:n}):(o==="html"||o==="svg")&&i?e.jsx("iframe",{className:`${n} opp-preview-frame`,src:i,title:`${t.title} preview`,sandbox:"",referrerPolicy:"no-referrer"}):e.jsx("div",{className:`${n} opp-featured-placeholder`,"aria-hidden":!0,children:s==="token"?"◎":Fo(o)})}function Fo(t){return t==="text"||t==="json"?"¶":t==="html"||t==="svg"?"⌂":"▭"}function Uo({kind:t}){return t==="lock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V8a4 4 0 018 0v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):t==="unlock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V7.5A4 4 0 0116 7",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("path",{d:"M16 4.5v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"9",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M12 7v10M9 10.5c0-1.4 1.3-2.5 3-2.5s3 1.1 3 2.5-1.3 2.5-3 2.5-3 1.1-3 2.5 1.3 2.5 3 2.5 3-1.1 3-2.5",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})}function _o({url:t,kind:s,className:n}){const[o,i]=u.useState(null),[r,d]=u.useState(!1);return u.useEffect(()=>{let c=!1;return i(null),d(!1),fetch(t).then(async a=>{if(!a.ok)throw new Error(String(a.status));const f=await a.text();if(!c){if(s==="json")try{i(JSON.stringify(JSON.parse(f),null,2));return}catch{}i(f.slice(0,800))}}).catch(()=>{c||d(!0)}),()=>{c=!0}},[t,s]),r?e.jsx("div",{className:`${n} opp-featured-placeholder`,"aria-hidden":!0,children:"¶"}):e.jsx("pre",{className:`${n} opp-preview-text${s==="json"?" opp-preview-json":""}`,children:o??"…"})}function Ye({text:t}){const[s,n]=u.useState(!1),o=()=>{navigator.clipboard?.writeText(t).then(()=>{n(!0),window.setTimeout(()=>n(!1),1200)})};return e.jsx("button",{type:"button",className:"opp-copy",onClick:o,"aria-label":s?"Copied":"Copy full value",title:s?"Copied":"Copy",children:s?e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:e.jsx("path",{d:"M5 13l4 4L19 7",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round"})}):e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"9",y:"9",width:"11",height:"11",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M5 15V5a2 2 0 012-2h10",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})})}function Bo(t){const[s,n]=u.useState(()=>t==="auto"?zo():t);return u.useEffect(()=>{if(t!=="auto"){n(t);return}const o=window.matchMedia("(prefers-color-scheme: dark)"),i=()=>n(o.matches?"dark":"light");return i(),o.addEventListener("change",i),()=>o.removeEventListener("change",i)},[t]),s}function zo(){return typeof window>"u"||!window.matchMedia?"light":window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function Pe(t){try{return new URL(t.includes("://")?t:`https://${t}`).host||t}catch{return t.length<=32?t:`${t.slice(0,14)}…${t.slice(-12)}`}}const Mo=({request:t,onResponse:s})=>{const{theme:n}=W(),{handleSelect:o,hideMenu:i}=ve(),{apiContext:r,chromeStorageService:d}=Z(),c=r?.services;u.useEffect(()=>{o("bsv"),i()},[o,i]);const[a,f]=u.useState(""),m=u.useRef(!1),x=async j=>{if(!m.current){if(m.current=!0,j){f("");const p=await pe(d);if(!p.ok){f(p.message),m.current=!1;return}}O({action:"ONE_SAT_PERMISSION_RESPONSE",requestID:t.requestID,approved:j}),s()}},w=n.color.global.walletBackground.toLowerCase()==="#000000"||/^#[01]/.test(n.color.global.walletBackground)?"dark":"light";return e.jsxs("div",{style:{width:"100%",height:"100%",overflowY:"auto",display:"flex",flexDirection:"column",alignItems:"stretch",justifyContent:"center"},children:[a&&e.jsx("p",{className:"text-xs text-center m-0 pt-2",style:{color:"#ef4444"},children:a}),e.jsx($o,{request:t.request,onApprove:()=>{x(!0)},onReject:()=>{x(!1)},theme:w,services:c})]})},Wo=t=>{switch(t){case"protocol":return"Protocol Permission";case"basket":return"Basket Access";case"certificate":return"Certificate Access";case"spending":return"Spending Authorization";default:return"Permission Request"}},qo=t=>{switch(t.type){case"protocol":{const s=_t(t.protocolID);return s?s.description:`An application is requesting permission to use protocol "${t.protocolID?.[1]||"unknown"}" with security level ${t.protocolID?.[0]||0}.`}case"basket":return`An application is requesting access to basket "${t.basket||"unknown"}".`;case"certificate":return"An application is requesting access to certificate data.";case"spending":return`An application is requesting authorization to spend ${t.spending?.satoshis||0} satoshis.`;default:return"An application is requesting a permission."}},Ho=t=>{const{request:s,onResponse:n}=t,{theme:o}=W(),i=It(),{handleSelect:r,hideMenu:d}=ve(),{addSnackbar:c}=De(),[a,f]=u.useState(!1),[m,x]=u.useState(""),{chromeStorageService:l}=Z();u.useEffect(()=>{r("bsv"),d()},[r,d]);const w=async()=>{f(!0),x("");try{const p=await pe(l);if(!p.ok){x(p.message),f(!1);return}Ae(s.originator),O({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!0}),n()}catch(p){const v=p instanceof Error?p.message:String(p);c(v,"error"),f(!1)}},j=async()=>{f(!0),O({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!1}),n()};return e.jsxs(F.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(Ns,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:Wo(s.type)}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:qo(s)})]})]}),e.jsxs(F.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"12rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Origin"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.displayOriginator||s.originator})]}),e.jsxs(G,{when:s.type==="protocol"&&!!s.protocolID,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Protocol"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:Bt(s.protocolID)})]}),e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.counterparty?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Security"}),e.jsx("span",{className:"text-xs",style:{color:o.color.global.contrast},children:jo(s.protocolID?.[0])})]}),e.jsx(G,{when:!!s.counterparty,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.counterparty})]})})]}),e.jsx(G,{when:s.type==="basket"&&!!s.basket,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Basket"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.basket})]})}),e.jsxs(G,{when:s.type==="certificate"&&!!s.certificate,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Cert Type"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.certType})]}),e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Fields"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.fields.join(", ")})]})]}),e.jsxs(G,{when:s.type==="spending"&&!!s.spending,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.spending?.lineItems?.length?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Amount"}),e.jsx(Es,{sats:s.spending?.satoshis||0,price:i,size:24,align:"left",color:"var(--bw-accent-hi)",mutedColor:o.color.global.gray})]}),e.jsx(G,{when:!!s.spending?.lineItems?.length,children:s.spending?.lineItems?.map((p,v)=>e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:v<(s.spending?.lineItems?.length??0)-1?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:p.type}),e.jsxs("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:[p.description," (",J(p.satoshis,i).main," ·"," ",J(p.satoshis,i).sub,")"]})]},v))})]}),e.jsx(G,{when:!!s.reason,children:e.jsxs("div",{className:"flex flex-row py-2",style:{borderTop:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Reason"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.reason})]})})]}),e.jsx(G,{when:!!s.privileged,children:e.jsxs(F.div,{className:"flex items-start gap-2 rounded-xl px-3 py-2.5 mb-4",style:{background:"rgba(245,166,35,0.08)",border:"1px solid rgba(245,166,35,0.15)"},initial:{opacity:0},animate:{opacity:1},transition:{delay:.12},children:[e.jsx(us,{size:14,className:"mt-0.5 flex-shrink-0",style:{color:"#f5a623"}}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:"#f5a623"},children:"This is a privileged operation"})]})}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[m&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:m}),e.jsxs(F.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:a?.6:1},disabled:a,onClick:w,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[a&&e.jsx(Ze,{size:14,className:"animate-spin"}),"Allow"]}),e.jsx(F.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:a?.5:1},disabled:a,onClick:j,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny"})]})]})},Vo=({request:t,onResponse:s})=>{const{theme:n}=W(),{chromeStorageService:o}=Z(),[i,r]=u.useState(""),[d,c]=u.useState(!1),a=async x=>{if(!d){if(c(!0),r(""),x){const l=await pe(o);if(!l.ok){r(l.message),c(!1);return}}O({action:"USB_CHECK_RESPONSE",requestID:t.requestID,ok:x}),s()}},f=n.color.global.gray,m=n.color.global.contrast;return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(fs,{size:40,style:{color:m}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:m},children:"Confirm your USB key"}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:f,maxWidth:"18rem"},children:[t.originator?`${t.originator} is asking bWallet to ${t.reason}.`:`A site is asking bWallet to ${t.reason}.`," ","Insert your USB key, then confirm."]}),i&&e.jsx("p",{className:"m-0 text-xs",style:{color:"#ef4444"},children:i}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(A,{theme:n,type:"primary",label:"Confirm USB key",disabled:d,onClick:()=>{a(!0)}}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Cancel",disabled:d,onClick:()=>{a(!1)}})]})]})},Ko=[.25,1,5],Go=1,ge=t=>t<1?`$${t.toFixed(2)}`:Number.isInteger(t)?`$${t}`:`$${t.toFixed(2)}`,Yo=10,Mt=t=>Math.max(1,Math.floor((Number.isFinite(t)?Math.max(0,t):0)/Yo)),Wt=t=>{const s=t.allowNone?[0,...t.presetsUsd]:[...t.presetsUsd];return e.jsx("div",{className:"flex flex-wrap",style:{gap:8},role:"radiogroup","aria-label":"Envelope amount",children:s.map(n=>{const o=t.value===n;return e.jsx("button",{type:"button",role:"radio","aria-checked":o,disabled:t.disabled,onClick:()=>t.onChange(n),style:{minHeight:44,padding:"0 16px",borderRadius:22,border:`1.5px solid ${o?b.gold:b.chip}`,background:o?b.gold:b.chip,color:o?b.bg:b.ink,fontSize:n?16:14,fontWeight:700,cursor:"pointer"},children:n?ge(n):"No envelope"},n)})})};function Jo(t){return{allowDisabled:t.busy||!t.armed||t.hold||t.mustRead,denyDisabled:t.busy}}const Xo=(t,s)=>t.key==="Escape"&&!t.defaultPrevented&&!s,Qo="One approval: signs and seals",Zo="Seal",en=({seal:t})=>e.jsx(Ce,{amount:`#${t.docHash.slice(0,8)}`,sub:"Document fingerprint, as under the document",badge:"SEAL",fontSize:"min(60px, 8vh)"}),tn=({seal:t})=>e.jsx("span",{style:{color:b.gold},children:t.title}),sn=t=>{const{seal:s,feeText:n,signingAs:o}=t;return e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"seal-sheet",children:[e.jsxs("div",{className:"flex items-center gap-2 flex-wrap",style:{fontSize:15,fontWeight:600},"data-testid":"seal-signer",children:[e.jsx(P,{size:18}),"Signed as ",e.jsxs("span",{style:{color:b.gold},children:["$",s.handle.replace(/^\$/,"")]}),s.roles.length>0&&e.jsxs("span",{style:{color:b.muted,fontWeight:400},children:["· ",s.roles.join(", ")]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:15,fontWeight:600},"data-testid":"seal-cost",children:[e.jsx(P,{size:18}),"Network fee only, at most ",n]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs(T,{children:[e.jsx(P,{}),"Only on ",s.site]}),e.jsxs(T,{children:[e.jsx(P,{}),"Hashes on chain, not the document"]}),e.jsxs(T,{children:[e.jsx(P,{}),"Next payment asks again"]})]}),o&&e.jsxs("p",{className:"m-0","data-testid":"signing-as",style:{fontSize:12,color:b.muted},children:["Signing with ",o]})]})},St=12,on=17,nn=({recipients:t})=>{if(!t)return null;const s=Ut(t);if(s.length===0)return e.jsx("li",{"data-testid":"pay-recipient",children:"no outputs: only the network fee"});const n=s.map((i,r)=>e.jsxs("li",{"data-testid":"pay-recipient",children:["to ",i.to,": ",i.satoshis.toLocaleString()," sats"]},`to-${r}`));if(s.length<=St)return e.jsx(e.Fragment,{children:n});const o=s.reduce((i,r)=>i+r.satoshis,0);return e.jsxs("li",{"data-testid":"pay-recipients-all",children:[s.length.toLocaleString()," outputs, ",o.toLocaleString()," sats in all, largest first:",e.jsx("ul",{className:"m-0 pl-4",style:{maxHeight:St*on,overflowY:"auto",overscrollBehavior:"contain"},children:n})]})},rn=3e3,an=t=>{const{request:s,onResponse:n,armed:o=!0}=t,{handleSelect:i,hideMenu:r}=ve(),{addSnackbar:d}=De(),{chromeStorageService:c}=Z(),a=c.getCurrentAccountObject().account,f=Ws(a?.addresses?.identityAddress,a?.name??"",a?.settings?.socialProfile?.displayName??"",!1),m=Ps(f.displayName,f.paymail,f.handle).tag,x=Rs(a?.pubKeys?.identityPubKey),l=u.useMemo(()=>uo(s),[s]),[w,j]=u.useState({}),[p,v]=u.useState(!1),S=u.useRef(s.items.length);u.useEffect(()=>{if(s.items.length===S.current)return;S.current=s.items.length,v(!0);const h=setTimeout(()=>v(!1),1e3);return()=>clearTimeout(h)},[s.items.length]);const g=u.useRef(!1),y=()=>{g.current||(g.current=!0,Q({action:"BUNDLE_SHEET_FREEZE",bundleID:s.bundleID}).catch(()=>{}))},E=(h,N)=>w[h]??N,[R,U]=u.useState(),[oe,Oe]=u.useState(oo),[je,C]=u.useState(!0),[q,Le]=u.useState(0),[ue,Ht]=u.useState(!0),nt=u.useMemo(()=>bo(s),[s]),[Fe,Vt]=u.useState(!0),[rt]=u.useState(()=>vt(l)!=="careful"),[fe,Ue]=u.useState(!1),[Kt,at]=u.useState("");u.useEffect(()=>{i("bsv"),r()},[i,r]),u.useEffect(()=>{Q({action:"GET_BUNDLE_ALLOWANCE",originator:s.originator}).then(h=>{!h?.success||!h.data||(U(h.data),Oe(h.data.defaultUsd))}).catch(()=>{})},[s.originator]);const H=s.mint&&l.payment&&l.lines.every(h=>!h.risky)?s.mint:void 0,Y=s.items.length===1?s.items[0].seal:void 0,it=!1,ne=!H&&l.payment&&R?.usdPerBsv?R.envelope:void 0,lt=!!ne?.offer,he=It(R?.usdPerBsv),ee=l.payment?J(l.payment.satoshis,he):void 0,re=async h=>{const N=h==="allow";Ue(!0),at("");try{if(N){const $=await pe(c);if(!$.ok){at($.message),Ue(!1);return}}N&&Ae(s.originator);const k=go(l,h,w,rt,Be),K=await Q({action:"BUNDLE_PERMISSION_RESPONSE",seenHash:ts(h),bundleID:s.bundleID,decisions:k.decisions,allowanceUsd:k.mayStore&&it&&je?oe:0,envelopeUsd:k.mayStore&&lt?q:0,remember:k.mayStore&&ue,trustSite:!H&&!Y&&k.mayStore&&ue&&nt&&Fe,block:k.block});K&&K.success===!1&&K.error&&(d(K.error,"error"),await new Promise($=>setTimeout($,rn))),n()}catch(k){d(k instanceof Error?k.message:String(k),"error"),Ue(!1)}},I=vt(l),L=Tt(s.originator),Gt=l.lines.length+(l.payment?1:0)>1,ae=l.payment?Se(l.payment.satoshis,he):"",Yt=0,_e=s.items.some(h=>h.reconnect),me=s.items.find(h=>h.framePair)?.framePair,Jt=me?"Allow inside this site":_e?"Reconnect":H?`${H.title.split(" ")[0]} · ${ae}`:Y?Zo:I==="post"?l.payment?`Allow & pay ${ae}`:"Allow posting":I==="signonce"?s.items[0]?.usageType==="hmac"?"Allow once":"Sign once":I==="private"?"Allow":I==="signin"?"Connect and sign in":I==="pay"?l.mode==="connectAndPay"?`Connect & pay ${ae}`:`Pay ${ae}`:Gt?"Allow all":"Connect",Xt=Hs(l.lines,h=>E(l.lines[h].requestID,l.lines[h].checked)),Qt=fe||!o||p,D=I==="careful",ct=l.lines.filter(h=>h.risky),dt=l.lines.filter(h=>h.isNew&&!(D&&h.risky)),[Zt,es]=u.useState(()=>new Set),pt=u.useRef(null);u.useEffect(()=>{const h=pt.current,N=h?.closest("[data-approval-scroll]");if(!D||!h||!N)return;const k=()=>{const $=N.querySelector('[data-testid="approval-choices"]'),qe=Math.max(N.getBoundingClientRect().top,0),as=Math.min($?$.getBoundingClientRect().top:window.innerHeight,window.innerHeight),He=[];N.querySelectorAll("[data-line-id]").forEach(le=>{const xe=le.getBoundingClientRect();xe.height>0&&xe.top>=qe-1&&xe.bottom<=as+1&&He.push(le.dataset.lineId??"")}),es(le=>He.every(xe=>le.has(xe))?le:new Set([...le,...He]))};k();const K=setTimeout(k,700);return N.addEventListener("scroll",k,{passive:!0}),window.addEventListener("resize",k),()=>{clearTimeout(K),N.removeEventListener("scroll",k),window.removeEventListener("resize",k)}},[D,l]);const Be=ho(l,D,D&&!rt?Zt:void 0,I),ut=D&&Be.hidden.size>0,ze=u.useRef({busy:fe,send:re});ze.current={busy:fe,send:re},u.useEffect(()=>{const h=N=>{Xo(N,ze.current.busy)&&(N.preventDefault(),ze.current.send("notNow"))};return window.addEventListener("keydown",h),()=>window.removeEventListener("keydown",h)},[]);const ft=D?l.lines.filter(h=>!h.risky&&!h.isNew):[],ts=h=>so(h==="allow"?mo(s.items,Be):s.items),ss=(h,N)=>j(k=>({...k,[h]:!E(h,N)})),ke=(h,N=!1)=>e.jsxs("label",{"data-line-id":h.requestID,className:"flex items-start gap-3 cursor-pointer",style:{minHeight:44,padding:N?"10px 14px":"8px 0",borderRadius:N?14:0,background:N?b.redChip:void 0,fontSize:15},children:[e.jsx("input",{type:"checkbox",checked:E(h.requestID,h.checked),onChange:()=>ss(h.requestID,h.checked),style:{width:22,height:22,accentColor:h.risky?b.red:b.gold,flexShrink:0,marginTop:1}}),e.jsxs("span",{className:"flex flex-col min-w-0",style:{gap:2},children:[e.jsx("span",{style:{color:h.risky?"#FF6B6B":void 0,fontWeight:600,lineHeight:1.3},children:h.text}),h.detail&&e.jsx("span",{className:"break-all",style:{fontSize:12,color:b.muted},children:h.detail})]})]},h.requestID),ie=(m||x)&&e.jsxs("span",{children:[e.jsx("span",{style:{color:b.gold},children:m||"this account"}),x&&e.jsxs("span",{className:"font-mono",style:{userSelect:"none",fontSize:12,color:b.muted},children:[" ","· ",x]})]}),os=e.jsxs("div",{className:"flex flex-col",style:{gap:4},children:[(m||x)&&e.jsxs("p",{className:"m-0","data-testid":"signing-as",style:{fontSize:12},children:["Signing in as ",ie]}),!D&&l.lines.some(h=>!h.isNew)&&e.jsxs("p",{className:"m-0",style:{fontSize:13,fontWeight:700,color:b.muted},children:["This lets ",L,":"]}),!D&&l.lines.filter(h=>!h.isNew).map(h=>ke(h)),l.payment&&e.jsxs("p",{className:"m-0",style:{padding:"6px 0"},children:["Pay ",e.jsx("span",{style:{color:b.gold,fontWeight:600},children:ae})," now to ",s.originator,l.payment.description&&e.jsxs(e.Fragment,{children:[" “",l.payment.description,"”"]})]}),l.payment?.labels?.length?e.jsxs("p",{className:"m-0",style:{fontSize:13,color:b.muted},"data-testid":"payment-labels",children:["Labels: ",l.payment.labels.join(", ")]}):null,it,e.jsxs("label",{className:"flex items-center gap-3 cursor-pointer",style:{minHeight:44},children:[e.jsx("input",{type:"checkbox",checked:ue,onChange:()=>Ht(!ue),style:{width:18,height:18,accentColor:b.gold,flexShrink:0}}),e.jsx("span",{children:"Remember this site"})]}),!H&&nt&&ue&&e.jsxs("label",{className:"flex items-start gap-3 cursor-pointer",style:{padding:"6px 0"},children:[e.jsx("input",{type:"checkbox",checked:Fe,onChange:()=>Vt(!Fe),style:{width:18,height:18,accentColor:b.gold,flexShrink:0,marginTop:1}}),e.jsxs("span",{children:["Don't ask again on ",s.originator," for sign-in and signing."," ",R?.allowances?"Payments stay within the allowance;":"Payments still ask, or use its envelope;"," ","your personal details always ask."]})]}),e.jsxs("ul",{className:"m-0 mt-1 pl-4 break-all",style:{fontSize:11,color:b.muted},children:[l.payment&&e.jsxs("li",{children:["pay: ",l.payment.detail]}),e.jsx(nn,{recipients:l.payment?.recipients}),Yt>0]})]}),{allowDisabled:ns,denyDisabled:Me}=Jo({busy:fe,armed:o,hold:p,mustRead:ut}),ht={label:"Not now",onClick:()=>{re("notNow")},disabled:Me},rs={label:"Block this site",onClick:()=>{re("block")},disabled:Me},mt={label:(D?"I trust it, allow":Jt)+(_e||H||Y?"":Xt),onClick:()=>{re("allow")},disabled:ns,busy:fe};let _,B,z=null,M;const V=h=>e.jsx("span",{style:{color:b.gold},children:h}),We=h=>Se(h,he);if(Y&&I!=="careful")_=e.jsx(en,{seal:Y}),M=Qo,B=e.jsx(tn,{seal:Y}),z=e.jsx(sn,{seal:Y,feeText:We(Y.maxSats),signingAs:ie||void 0});else if(H&&I!=="careful")_=e.jsx(Ce,{amount:ee?.main??"",sub:ee?.sub}),M="One approval for all of it",B=e.jsx(e.Fragment,{children:V(H.title)}),z=e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"mint-sheet",children:[e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:15,fontWeight:600},"data-testid":"mint-cost",children:[e.jsx(P,{size:18}),"Costs ",We(H.premiumSats)," + ",We(H.feeSats)," network fee"]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs(T,{children:[e.jsx(P,{}),"Locked with your keys"]}),e.jsxs(T,{children:[e.jsx(P,{}),"Only on ",H.site]}),e.jsxs(T,{children:[e.jsx(P,{}),"Next payment asks again"]})]})]});else if(I==="careful"){_=l.lines.length>0?null:e.jsx(Cs,{}),M="Check this carefully";const h=s.items.some($=>$.privileged),N=ct.some($=>s.items.find(qe=>qe.requestID===$.requestID)?.type==="certificate"),k=$=>e.jsx("span",{style:{color:"#FF6B6B"},children:$}),K=s.items.some($=>we($));B=h?e.jsxs(e.Fragment,{children:["Wants ",k("full control")," of your keys"]}):N?e.jsxs(e.Fragment,{children:["Wants your ",k("private details")]}):K?e.jsxs(e.Fragment,{children:["Wants a signature ",k("other sites accept")]}):e.jsxs(e.Fragment,{children:["Wants ",k("more than usual")]}),z=e.jsxs("div",{ref:pt,className:"flex flex-col",style:{gap:8},children:[h&&e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:b.redChip,fontSize:14},children:[e.jsx(Ne,{}),"Could move your money"]}),K&&e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"shared-key-warning",children:[e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:b.redChip,fontSize:14},children:[e.jsx(Ne,{}),"Other sites could accept these as you"]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:b.soft},children:[e.jsx(P,{size:18}),"Each one is just this once"]})]}),ct.map($=>ke($,!0)),ft.length>0&&e.jsxs("div",{className:"flex flex-col","data-testid":"careful-ordinary-lines",style:{padding:"0 4px"},children:[e.jsx("p",{className:"m-0",style:{fontSize:12,fontWeight:700,color:b.muted},children:"Also asks to"}),ft.map($=>ke($))]}),e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:b.redChip,fontSize:14},children:[e.jsx(Ne,{}),"Only allow apps you trust"]})]})}else if(I==="pay")_=e.jsx(Ce,{amount:ee?.main??"",sub:ee?.sub}),M=l.payment?.description||"Asks you to pay",B=e.jsxs(e.Fragment,{children:["Pay ",V(ae)," now to ",V(L)]}),z=e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex items-center gap-3",style:{padding:14,borderRadius:16,background:b.chip},children:[e.jsx(Is,{site:s.originator,size:44}),e.jsxs("div",{className:"flex flex-col min-w-0",style:{gap:2,lineHeight:1.25},children:[e.jsxs("span",{className:"truncate",style:{fontSize:15,fontWeight:600},children:["To ",s.originator]}),e.jsx("span",{className:"truncate",style:{fontSize:13,color:b.muted},children:l.payment?.description?`“${l.payment.description}”`:"Straight from your wallet"}),l.payment?.labels?.length?e.jsxs("span",{className:"truncate",style:{fontSize:12,color:b.muted},"data-testid":"payment-labels",children:["Labels: ",l.payment.labels.join(", ")]}):null]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:b.soft},children:[e.jsx(P,{size:18}),q>0?`Then payments up to ${Se(Mt((ne?.balanceSats??0)+et(q,R?.usdPerBsv??0)),he)} each come out of the envelope`:"Every payment asks you first"]}),lt&&ne&&e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"envelope-offer",children:[e.jsx("span",{style:{fontSize:15,fontWeight:600},children:ne.balanceSats!==void 0?e.jsxs(e.Fragment,{children:["Top up the envelope",e.jsxs("span",{style:{fontSize:13,fontWeight:400,color:b.muted},children:[" ","· ",Se(ne.balanceSats,he)," left; this payment needs a sheet"]})]}):e.jsxs(e.Fragment,{children:[q>0?`Also put ${ge(q)}`:"Also put money"," in ",V(L),"'s envelope?"]})}),e.jsx(Wt,{presetsUsd:ne.presetsUsd,value:q,onChange:Le,allowNone:!0,disabled:Qt}),e.jsxs("span",{style:{fontSize:12,color:b.muted},children:["Stays in your wallet. Payments from ",L," of up to a tenth of it come out without asking; Coin return any time."]})]})]});else if(I==="post")_=e.jsx(Ee,{site:s.originator}),M="Wants to post for you",B=e.jsxs(e.Fragment,{children:["Allow ",V(L)," to post for you"]}),z=e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs(T,{children:[e.jsx(P,{}),"Post and like as you"]}),e.jsxs(T,{children:[e.jsx(P,{}),"Nothing else moves"]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14},"data-testid":"post-cost",children:[e.jsx(P,{size:18}),ee?e.jsxs("span",{className:"flex flex-col",children:[e.jsxs("span",{children:["This post costs"," ",e.jsx("span",{style:{fontSize:20,fontWeight:800,color:b.gold},children:ee.main})]}),e.jsx("span",{style:{fontSize:12,color:b.muted},children:ee.sub})]}):"Each paid post asks you first"]})]});else if(I==="signonce"){const h=String(s.items[0]?.protocolID?.[1]??""),N=s.items[0]?.usageType==="hmac",k=K=>e.jsx("span",{style:{color:b.redSoft},children:K});_=null,M="One signature, check it",B=N?e.jsxs(e.Fragment,{children:["One code as you for ",k(L)]}):e.jsxs(e.Fragment,{children:["Sign once as you for ",k(L)]}),z=e.jsxs("div",{className:"flex flex-col",style:{gap:8,marginTop:4},"data-testid":"sign-once",children:[ie&&e.jsxs("span",{style:{fontSize:15},children:["as ",ie]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[h&&e.jsx(T,{tone:"red",children:e.jsxs("span",{"data-testid":"sign-once-protocol",children:["“",h,"”"]})}),e.jsxs(T,{tone:"red",children:[e.jsx(P,{}),"Just this once"]})]}),e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:b.redChip,fontSize:14},children:[e.jsx(Ne,{}),"Other sites could accept it as you. Only sign if you trust ",L,"."]})]})}else if(I==="private")_=e.jsx(gt,{}),M="Your data",B=e.jsx(e.Fragment,{children:V(Ve("private",L,l))}),z=e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs(T,{children:[e.jsx(P,{}),"Uses keys from your wallet"]}),e.jsxs(T,{children:[e.jsx(P,{}),"No money moves"]})]});else if(me)_=e.jsx(Ee,{site:s.originator}),M=`Inside ${me}`,B=e.jsxs(e.Fragment,{children:["Let ",V(L)," use your wallet inside ",V(me),"?"]}),z=e.jsxs("div",{className:"flex flex-col",style:{gap:8,marginTop:4,fontSize:13},children:[e.jsxs("span",{children:[s.originator," is shown inside ",me,". Only allow it if you opened it there yourself."]}),e.jsxs("span",{style:{color:b.muted,fontSize:12},children:["After this, what you already allowed ",s.originator," applies here too."]})]});else if(_e&&I==="signin")_=e.jsx(Ee,{site:s.originator}),M="You disconnected this site",B=e.jsxs(e.Fragment,{children:["Reconnect to ",V(L),"?"]}),z=e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs(T,{children:[e.jsx(P,{}),"Shares your public key"]}),e.jsxs(T,{children:[e.jsx(P,{}),"No money moves"]})]});else if(I==="signin")_=e.jsx(gt,{}),M="Connect and sign in",B=e.jsx(e.Fragment,{children:V(Ve("signin",L,l))}),z=e.jsxs(e.Fragment,{children:[ie&&e.jsxs("div",{className:"flex items-center gap-2.5",children:[e.jsx("div",{"aria-hidden":"true",style:{width:30,height:30,borderRadius:15,background:"conic-gradient(#F5C542, #B8860B, #FFE08A, #F5C542)",flexShrink:0}}),e.jsxs("span",{style:{fontSize:18,fontWeight:600},children:["as ",ie]})]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs(T,{children:[e.jsx(P,{}),"No password"]}),e.jsxs(T,{children:[e.jsx(P,{}),"No money moves"]})]})]});else{_=e.jsx(Ee,{site:s.originator}),M="Wants to connect",B=e.jsx(e.Fragment,{children:V(Ve("connect",L,l))});const h=new Set(s.items.map(k=>k.type)),N=[{label:h.has("certificate")?"Your details":"Your name",icon:e.jsx(ln,{})}];h.has("protocol")&&N.push({label:"Sign posts",icon:e.jsx(cn,{})}),h.has("basket")&&N.push({label:"Keep items",icon:e.jsx(dn,{})}),z=e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"grid",style:{gridTemplateColumns:`repeat(${N.length}, minmax(0, 1fr))`,gap:8},children:N.map(k=>e.jsxs("div",{className:"flex flex-col items-center",style:{gap:8,padding:"14px 6px",borderRadius:16,background:b.chip},children:[k.icon,e.jsx("span",{style:{fontSize:13,fontWeight:600,textAlign:"center"},children:k.label})]},k.label))}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:b.soft},children:[e.jsx(P,{size:18}),"Payments still ask you first"]})]})}return e.jsx(F.div,{className:"flex flex-col w-full h-full",style:{maxHeight:"100vh"},initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{type:"spring",damping:24,stiffness:260},"data-approval-kind":I,onPointerDownCapture:y,children:e.jsxs($t,{tone:D||I==="signonce"?"red":"gold",site:s.originator,siteSub:M,onClose:()=>{re("notNow")},closeLabel:"Deny and close",closeDisabled:Me,hero:_,title:B,primary:D?ht:mt,secondary:D?mt:ht,tertiary:D||I==="signonce"?rs:void 0,error:Kt||(ut?"Scroll to read every line before allowing":""),children:[z,!(Y&&!D)&&e.jsx("div",{"data-testid":"approval-lines",style:{marginTop:8},children:os}),dt.length>0&&e.jsx("div",{className:"flex flex-col","data-testid":"new-lines",style:{gap:4,marginTop:8},children:dt.map(h=>ke(h,!0))})]})})},ot={"aria-hidden":!0,width:28,height:28,viewBox:"0 0 24 24",fill:"none",stroke:b.gold,strokeWidth:1.8,strokeLinecap:"round",strokeLinejoin:"round"},ln=()=>e.jsxs("svg",{...ot,children:[e.jsx("circle",{cx:"12",cy:"8",r:"4"}),e.jsx("path",{d:"M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"})]}),cn=()=>e.jsxs("svg",{...ot,children:[e.jsx("path",{d:"M12 20h9"}),e.jsx("path",{d:"M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"})]}),dn=()=>e.jsxs("svg",{...ot,children:[e.jsx("rect",{x:"3",y:"7",width:"18",height:"13",rx:"2"}),e.jsx("path",{d:"M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"})]}),Nt=t=>`${(t/1e8).toFixed(8)} BSV`,Re=t=>`$${t.toFixed(2)}`;function pn(t){const s=t.symbol?`$${t.symbol}`:"tokens",n=`${Nt(t.priceSats)} (${Re(t.usdAtRate)})`,o=[[t.side==="offer"?"You give":"You get",`${t.tokens} ${s}`],[t.side==="offer"?"You get":"You pay",n],["Contract price",t.terms.priceSats!==void 0?`${t.terms.priceSats.toLocaleString("en-US")} sats`:Re(t.terms.priceUsd??0)],["Rate",`$${t.rate.toFixed(2)} per BSV (${t.rateSource})`]];t.overlayFeeSats>0&&o.push(["Indexing fee",Nt(t.overlayFeeSats)]),o.push(["Contract",t.terms.ref],["Document hash",`${t.terms.docHash.slice(0,16)}…`]),t.terms.sellerKey&&o.push(["Seller wallet",`${t.terms.sellerKey.slice(0,16)}…`]),t.terms.expiresAt&&o.push(["Offer expires",new Date(t.terms.expiresAt).toISOString().replace("T"," ").slice(0,16)+" UTC"]);const i=t.side==="offer"?`Offer ${t.tokens} ${s} for ${Re(t.usdAtRate)}`:`Swap ${Re(t.usdAtRate)} for ${t.tokens} ${s}`,r=t.side==="offer"?`${t.split?`First the wallet sets aside exactly ${t.tokens} ${s} (a small token send to yourself). `:""}Then it signs your half only: your tokens move only in the buyer's transaction, which must pay you ${n}. Nothing is broadcast now.`:"One transaction: the tokens come to you and the price goes to the seller, with the contract hash on chain. If it does not broadcast, nothing moves.";return{title:i,rows:o,note:r,action:t.side==="offer"?"Sign offer":"Pay and swap"}}const un=({request:t,onResponse:s})=>{const{theme:n}=W(),[o,i]=u.useState(!1),r=pn(t),d=n.color.global.gray,c=n.color.global.contrast,a=f=>{o||(i(!0),O({action:"SWAP_RESPONSE",requestID:t.requestID,allow:f}),s())};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 gap-3",children:[e.jsx(Vs,{size:32,style:{color:c}}),e.jsx("h2",{className:"m-0 text-lg font-semibold text-center",style:{color:c},children:r.title}),e.jsx("div",{className:"flex flex-col gap-1.5 w-full",style:{maxWidth:"20rem"},"data-testid":"swap-rows",children:r.rows.map(([f,m])=>e.jsxs("div",{className:"flex justify-between gap-3 text-sm",children:[e.jsx("span",{style:{color:d},children:f}),e.jsx("span",{className:"text-right break-all",style:{color:c},children:m})]},f))}),e.jsx("p",{className:"m-0 text-xs leading-relaxed text-center",style:{color:d,maxWidth:"20rem"},children:r.note}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"20rem"},children:[e.jsx(A,{theme:n,type:"primary",label:r.action,disabled:o,onClick:()=>a(!0)}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Decline",disabled:o,onClick:()=>a(!1)})]})]})},fn=({request:t,onResponse:s})=>{const{theme:n}=W(),{chromeStorageService:o}=Z(),[i,r]=u.useState(!1),{pack:d,originator:c}=t,a=d.look,f=n.color.global.gray,m=n.color.global.contrast,x=l=>{if(!i){if(r(!0),l==="used"){const w=o.getCurrentAccountObject().account?.pubKeys?.identityPubKey??"";hs(w,d)}O({action:"THEME_OFFER_RESPONSE",requestID:t.requestID,answer:l}),s()}};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 gap-3",children:[e.jsx($s,{size:32,style:{color:m}}),e.jsxs("h2",{className:"m-0 text-lg font-semibold text-center",style:{color:m},children:["Use the ",d.label," look?"]}),e.jsxs("p",{className:"m-0 text-xs text-center",style:{color:f},children:["Offered by ",e.jsx("strong",{style:{color:m},children:c})]}),e.jsxs("div",{"data-testid":"theme-offer-card","aria-hidden":"true",style:{width:"100%",maxWidth:"20rem",aspectRatio:"1.586",borderRadius:16,background:`linear-gradient(135deg, ${a.surface}, ${a.bg})`,border:`2px solid ${a.accent}`,padding:14,display:"flex",flexDirection:"column",justifyContent:"space-between",boxSizing:"border-box"},children:[e.jsx("span",{style:{display:"flex",gap:4},children:[a.accent,a.hi,a.lo,a.success,a.danger].map((l,w)=>e.jsx("i",{style:{width:18,height:18,borderRadius:999,background:l,display:"block"}},w))}),e.jsx("span",{style:{color:a.text,fontWeight:800,fontSize:18},children:d.label}),e.jsx("span",{style:{alignSelf:"flex-start",background:a.accent,color:a.on,borderRadius:999,padding:"4px 12px",fontSize:12,fontWeight:700},children:"$0.00"})]}),e.jsx("p",{className:"m-0 text-xs leading-relaxed text-center",style:{color:f,maxWidth:"20rem"},children:"Colours only. Switch back any time in Settings › Theme."}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"20rem"},children:[e.jsx(A,{theme:n,type:"primary",label:"Use it",disabled:i,onClick:()=>x("used")}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Not now",disabled:i,onClick:()=>x("declined")}),e.jsx(A,{theme:n,type:"secondary",label:"Never for this site",disabled:i,onClick:()=>x("never")})]})]})},hn=({request:t,onResponse:s})=>{const{theme:n}=W(),[o,i]=u.useState(!1),r=qs(t),d=n.color.global.gray,c=n.color.global.contrast,a=f=>{o||(i(!0),O({action:"TWETCH_RESPONSE",requestID:t.requestID,allow:f}),s())};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(Ts,{size:36,style:{color:c}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:c},children:r.title}),t.kind==="post"&&e.jsx("p",{className:"m-0 text-sm leading-relaxed whitespace-pre-wrap break-words",style:{color:c,maxWidth:"18rem"},"data-testid":"twetch-preview",children:t.preview}),e.jsx("p",{className:"m-0 text-xs leading-relaxed",style:{color:d,maxWidth:"18rem"},children:r.body}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(A,{theme:n,type:"primary",label:r.approve,disabled:o,onClick:()=>a(!0)}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Decline",disabled:o,onClick:()=>a(!1)})]})]})},mn=({request:t,onResponse:s})=>{const{theme:n}=W(),[o,i]=u.useState(!1),r=n.color.global.gray,d=n.color.global.contrast,c=a=>{o||(i(!0),O({action:"PROVE_HOLDINGS_RESPONSE",requestID:t.requestID,allow:a}),s())};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(Ks,{size:36,style:{color:d}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:d},children:"Show your tokens in bChatX?"}),e.jsx("p",{className:"m-0 text-xs leading-relaxed",style:{color:r,maxWidth:"18rem"},children:`${t.originator} can then see which wallet addresses hold your tokens, so your rooms and swaps work. Your wallet signs a message for each one. Nothing is spent.`}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(A,{theme:n,type:"primary",label:"Allow",disabled:o,onClick:()=>c(!0)}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Not now",disabled:o,onClick:()=>c(!1)})]})]})},xn=t=>{const s=t.sequence,n=s?s.totalPosts:t.posts,o=s?s.totalSats:t.sats,i=s?s.totalTxs:t.txs;return{title:n!==void 0?`Lock ${n.toLocaleString("en")} posts to you`:"Lock your posts to you",site:`${t.originator} is asking`,privacy:"Private: only you can see them. They are encrypted with your wallet’s keys before they leave this device.",cost:`About ${o.toLocaleString("en")} sats in ${i.toLocaleString("en")} transaction${i===1?"":"s"}`,chunks:s?`Sent in ${s.chunks.toLocaleString("en")} parts. One Allow covers the whole run for 2 hours, up to 10% over this estimate. Anything more asks again.`:void 0}},gn=({request:t,onResponse:s})=>{const{theme:n}=W(),[o,i]=u.useState(!1),r=xn(t),d=t.sequence?t.sequence.totalSats:t.sats,c=J(d,Ie(t.usdPerBsv,!0)),a=n.color.global.gray,f=n.color.global.contrast,m=x=>{o||(i(!0),O({action:"MINT_PRIVATE_RESPONSE",requestID:t.requestID,allow:x}),s())};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(Ds,{size:36,style:{color:f}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:f},children:r.title}),e.jsx("p",{className:"m-0 text-xs",style:{color:a},children:r.site}),e.jsxs("div",{className:"flex flex-col items-center","data-testid":"dollar-amount",children:[e.jsx("span",{style:{fontSize:32,fontWeight:800,lineHeight:1.1,color:f},children:c.main}),e.jsx("span",{className:"text-xs",style:{color:a},children:c.sub})]}),e.jsx("p",{className:"m-0 text-sm",style:{color:f},children:r.cost}),e.jsx("p",{className:"m-0 text-xs leading-relaxed",style:{color:a,maxWidth:"18rem"},children:r.privacy}),r.chunks&&e.jsx("p",{className:"m-0 text-xs leading-relaxed",style:{color:a,maxWidth:"18rem"},children:r.chunks}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(A,{theme:n,type:"primary",label:"Allow",disabled:o,onClick:()=>m(!0)}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Decline",disabled:o,onClick:()=>m(!1)})]})]})},yn=({request:t,onResponse:s})=>{const{theme:n}=W(),o=t.usdPerBsv,i=t.capSatsPerHour,r=o?i/1e8*o:void 0,[d,c]=u.useState(r!==void 0?r.toFixed(2):""),[a,f]=u.useState(String(i)),[m,x]=u.useState(!1),l=u.useMemo(()=>{const g=o?et(Number(d),o):Math.floor(Number(a));return Number.isFinite(g)&&g>=1?Math.min(g,i):0},[d,a,o,i]),w=g=>{m||(x(!0),O({action:"STREAM_GRANT_RESPONSE",requestID:t.requestID,capSatsPerHour:g?l:null}),s())},j=n.color.global.gray,p=n.color.global.contrast,v=new Date(t.expiresAt).toLocaleString(),S=J(i,Ie(o,!0));return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(As,{size:36,style:{color:p}}),e.jsxs("h2",{className:"m-0 text-lg font-semibold",style:{color:p},children:["Allow ",t.originator," to stream while you watch, up to"]}),e.jsxs("div",{className:"flex flex-col items-center","data-testid":"dollar-amount",children:[e.jsxs("span",{style:{fontSize:o?40:24,fontWeight:800,lineHeight:1.1,color:p},children:[S.main,e.jsx("span",{style:{fontSize:16,fontWeight:600},children:" an hour"})]}),e.jsx("span",{className:"text-xs",style:{color:j},children:S.sub})]}),t.description&&e.jsx("p",{className:"m-0 text-xs",style:{color:j,maxWidth:"18rem"},children:t.description}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:j,maxWidth:"18rem"},children:["Only “",t.protocolName,"” payments from ",t.originator," go through without asking, until ",v,". Anything else still asks you. Revoke any time in Settings › Streaming permissions."]}),e.jsxs("label",{className:"flex items-center gap-2 text-sm",style:{color:p},children:["Cap per hour ",o?"$":"",o?e.jsx("input",{"aria-label":"Cap in dollars per hour",inputMode:"decimal",value:d,onChange:g=>c(g.target.value),className:"w-24 px-2 py-1 rounded bg-transparent border",style:{color:p}}):e.jsx("input",{"aria-label":"Cap in sats per hour",inputMode:"numeric",value:a,onChange:g=>f(g.target.value),className:"w-28 px-2 py-1 rounded bg-transparent border",style:{color:p}}),!o&&"sats"]}),e.jsxs("p",{className:"m-0 text-xs",style:{color:j},children:[l?o?`${J(l,Ie(o,!0)).main} an hour · ${l.toLocaleString()} sats`:`${l.toLocaleString()} sats an hour ${Os}`:"Enter a cap above zero",l===i?" (the most this site asked for)":""]}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(A,{theme:n,type:"primary",label:"Allow",disabled:m||!l,onClick:()=>w(!0)}),e.jsx(A,{theme:n,type:"secondary-outline",label:"Not now",disabled:m,onClick:()=>w(!1)})]})]})},bn=({request:t,onResponse:s})=>{const n=t.usdPerBsv,[o,i]=u.useState(Go),[r,d]=u.useState(!1),c=n?et(o,n):0,a=t.envelope?.balanceSats??0,f=Ie(n,!0),m=J(c,f),x=Tt(t.originator),l=J(Mt(a+c),f).main,w=j=>{r||(d(!0),O({action:"STREAM_GRANT_RESPONSE",requestID:t.requestID,capSatsPerHour:j?c:null}),s())};return e.jsx($t,{site:t.originator,siteSub:t.description||"Many small payments",onClose:()=>w(!1),closeLabel:"Not now",closeDisabled:r,hero:e.jsx(Ce,{amount:n?ge(o):m.main,sub:m.sub,badge:"ENVELOPE"}),title:e.jsxs(e.Fragment,{children:["Put ",n?ge(o):"money"," in ",e.jsx("span",{style:{color:b.gold},children:x}),"'s envelope"]}),primary:{label:n?`Put ${ge(o)} in`:"Price unavailable",onClick:()=>w(!0),disabled:r||!c},secondary:{label:"Not now",onClick:()=>w(!1),disabled:r},testId:"envelope-sheet",children:e.jsxs("div",{className:"flex flex-col",style:{gap:10},children:[e.jsx(Wt,{presetsUsd:Ko,value:o,onChange:i,disabled:r}),a>0&&e.jsxs("span",{style:{fontSize:13,color:b.muted},"data-testid":"envelope-balance",children:["Already in it: ",J(a,f).main]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs(T,{children:[e.jsx(P,{}),"Stays in your wallet"]}),e.jsxs(T,{children:[e.jsx(P,{}),"Only ",x," can spend it"]}),e.jsxs(T,{children:[e.jsx(P,{}),"Coin return any time"]})]}),c>0&&e.jsxs("span",{style:{fontSize:14,fontWeight:600,color:b.ink},"data-testid":"envelope-limit",children:["Up to ",l," a payment without asking"]}),e.jsxs("span",{style:{fontSize:13,color:b.soft},children:["Payments from ",t.originator," of up to a tenth of the envelope come out of it without asking. A bigger one asks you first, and when it is empty it asks you again. Settings › Envelopes shows each payment and where it went."]})]})})},te={bg:"#0B0B0D",text:"#FFFFFF",muted:"#98A2B3",gold:"#F5C542",line:"#2B2F36"};function vn(t){const[s,n]=u.useState(null);return u.useEffect(()=>{if(!t)return;let o=!0;const i=()=>{if(!Ls(t)){n(null);return}Fs(t,{asking:!0,path:Us(t)}).then(r=>o&&n(r))};return i(),window.addEventListener(yt,i),window.addEventListener("storage",i),()=>{o=!1,window.removeEventListener(yt,i),window.removeEventListener("storage",i)}},[t]),s}const Je=t=>t.replace(/^https?:\/\//,"").replace(/\/.*$/,"").toLowerCase(),wn=(t,s)=>s?.length?`${Je(t)} (inside ${s.map(n=>Je(n)).join(", ")})`:Je(t),jn=1500,kn=({originator:t,themed:s,embeddedIn:n})=>e.jsxs("div",{"data-testid":"bwx-origin-strip",className:"flex items-center gap-2 px-3",style:{background:te.bg,color:te.text,borderBottom:`1px solid ${te.line}`,minHeight:32,fontFamily:"Inter, system-ui, sans-serif",fontSize:12,flexShrink:0},children:[e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24","aria-hidden":!0,fill:"none",stroke:te.gold,strokeWidth:"2.5",children:[e.jsx("rect",{x:"4",y:"11",width:"16",height:"10",rx:"2"}),e.jsx("path",{d:"M8 11V7a4 4 0 0 1 8 0v4"})]}),e.jsxs("span",{style:{color:te.muted},children:[ce," · request from"]}),e.jsx("span",{className:"font-bold truncate",style:{color:te.text},children:wn(t,n)}),s&&e.jsx("span",{className:"ml-auto whitespace-nowrap",style:{color:te.muted,fontSize:10},children:"site theme"})]}),Sn=({theme:t,originator:s})=>e.jsxs("div",{"data-testid":"bwx-site-banner",className:"flex items-center gap-3 px-4",style:{background:t.artData?`linear-gradient(90deg, ${t.bg} 35%, ${t.bg}99), url("${t.artData}") center / cover`:`linear-gradient(135deg, ${t.bg}, ${t.surface})`,color:t.text,borderBottom:`3px solid ${t.accent}`,minHeight:60,flexShrink:0},children:[t.logoData?e.jsx("img",{src:t.logoData,alt:"",width:36,height:36,style:{borderRadius:8,objectFit:"contain"}}):e.jsx("span",{"aria-hidden":!0,className:"flex items-center justify-center font-bold",style:{width:36,height:36,borderRadius:8,background:t.accent,color:t.onAccent},children:t.name.slice(0,1).toUpperCase()}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"font-bold truncate",style:{fontSize:15,color:t.text},children:t.name}),e.jsxs("div",{className:"truncate",style:{fontSize:11,color:t.accentHi},children:["Connected with ",ce," · ",_s(s)]})]})]}),Nn=({originator:t,children:s,theme:n,embeddedIn:o})=>{const i=vn(n===void 0?t:void 0),r=n===void 0?i:n,d=!!o?.length,[c,a]=u.useState(!d);return u.useEffect(()=>{if(!d)return a(!0);a(!1);const f=setTimeout(()=>a(!0),jn);return()=>clearTimeout(f)},[d,t]),t?e.jsxs("div",{className:"flex flex-col w-full h-full",style:r?{boxShadow:`inset 3px 0 0 ${r.accent}, inset -3px 0 0 ${r.accent}`}:void 0,children:[e.jsx(kn,{originator:t,themed:!!r,embeddedIn:o}),r&&e.jsx(Sn,{theme:r,originator:t}),e.jsx("div",{className:"flex-1 min-h-0 flex items-center justify-center relative","data-testid":"bwx-sheet-body","data-armed":c?"true":"false",style:c?void 0:{pointerEvents:"none"},children:s})]}):e.jsx(e.Fragment,{children:s})};is();Rt.Buffer=Pt;Rt.process=ds;window.Buffer=Pt;const En=t=>"payload"in t&&t.payload.originator||void 0,Pn=t=>{const s="payload"in t?t.payload.embeddedIn:void 0;return Array.isArray(s)?s.filter(n=>typeof n=="string"):void 0},Rn=1e4,Cn=2e3,X=new URLSearchParams(window.location.search).get("inpage"),Et=window.location.protocol==="chrome-extension:"&&window.top!==window&&!X&&!!window.location.ancestorOrigins?.length&&window.location.ancestorOrigins[0]!==window.location.origin,In=(t,s)=>{const[n,o]=u.useState(t?void 0:!0),[i,r]=u.useState(!t),[d,c]=u.useState(!1);return u.useEffect(()=>{t&&Q({action:"INPAGE_SHEET_CHECK",token:X}).then(a=>o(!!a?.success)).catch(()=>o(!1))},[t]),u.useEffect(()=>{if(!t||n!==!0||!s.current)return;let a;const f=new IntersectionObserver(m=>{const x=m[m.length-1];window.clearTimeout(a),x.isVisible&&x.intersectionRatio>=.99?a=window.setTimeout(()=>r(!0),500):r(!1)},{threshold:[0,.99,1],trackVisibility:!0,delay:100});return f.observe(s.current),()=>{window.clearTimeout(a),f.disconnect()}},[t,s,n]),u.useEffect(()=>{if(!t||i){c(!1);return}const a=window.setTimeout(()=>c(!0),1500);return()=>window.clearTimeout(a)},[t,i]),{tokenOk:n,armed:n===!0&&i,stuck:n===!0&&!i&&d}},$n=()=>{const{theme:t}=W(),{isLocked:s,isReady:n}=Z(),o=u.useRef(null),i=u.useRef(null),r=In(!!X,i),d=!Et&&r.tokenOk===!0,c=u.useRef(d);c.current=d;const[a,f]=u.useState({kind:"loading"}),m=u.useRef(void 0),x=u.useRef(void 0),l=()=>{m.current!==void 0&&(window.clearTimeout(m.current),m.current=void 0)},w=u.useRef(a);w.current=a;const j=u.useCallback(async(g,y)=>{l();const E=w.current;if(g==="bundle"&&E.kind==="bundle"&&E.requestID===y){try{const U=await Q({action:"GET_PROMPT_PAYLOAD",kind:g,requestID:y});U?.success&&U.data&&f({kind:"bundle",requestID:y,payload:U.data})}catch{}return}f({kind:"loading"});let R;try{R=await Q({action:"GET_PROMPT_PAYLOAD",kind:g,requestID:y})}catch{R=void 0}R?.success&&R.data?f({kind:g,requestID:y,payload:R.data}):(f({kind:"expired"}),window.setTimeout(()=>{x.current?.()},Cn))},[]),p=u.useCallback(async()=>{l();let g;try{g=await Q({action:"CLOSE_PROMPT_WINDOW"})}catch{g=void 0}if(g===void 0){window.close();return}const y=g.data?.prompt;y&&(y.kind==="unlock"?f({kind:"unlock"}):y.requestID&&await j(y.kind,y.requestID))},[j]),v=u.useCallback(async()=>{l();let g;try{g=await Q({action:"GET_NEXT_PROMPT"})}catch{g=void 0}if(g?.data?.prompt){await j(g.data.prompt.kind,g.data.prompt.requestID);return}if(g?.data?.busy){f({kind:"waiting"}),m.current=window.setTimeout(()=>{p()},Rn);return}await p()},[j,p]);x.current=v,u.useEffect(()=>{if(!n||!d)return;const g=new URLSearchParams(window.location.search),y=g.get("kind"),E=g.get("requestID");if(y==="unlock"){s?f({kind:"unlock"}):v();return}if(y&&E){j(y,E);return}v()},[n,d]),u.useEffect(()=>{const g=y=>{if(!(y?.action!=="SHOW_PROMPT"||!y.kind||!c.current)){if(y.kind==="unlock"){l(),f({kind:"unlock"});return}y.requestID&&j(y.kind,y.requestID)}};return chrome.runtime.onMessage.addListener(g),()=>chrome.runtime.onMessage.removeListener(g)},[j]);const S=t.color.global.walletBackground;return!Et&&X&&r.tokenOk===void 0?null:d?e.jsxs(bs,{children:[X&&e.jsxs("div",{className:"flex items-center justify-between px-3 py-2",style:{background:S,borderBottom:"1px solid #ffffff14"},children:[e.jsx("span",{className:"text-sm font-bold",style:{color:t.color.global.contrast},children:ce}),r.stuck&&e.jsxs("button",{type:"button",className:"text-xs font-bold border-0 rounded-full px-3 py-1",style:{background:"#F5C542",color:"#0b0a08"},onClick:()=>chrome.runtime.sendMessage({action:"MOVE_PROMPT_TO_WINDOW"}).catch(()=>{}),children:["Open in ",ce]}),e.jsx("button",{type:"button","aria-label":"Deny and close",className:"text-sm border-0 bg-transparent p-1",style:{color:t.color.global.gray},onClick:()=>chrome.runtime.sendMessage({action:"DISMISS_PROMPT_PANEL"}).catch(()=>{}),children:"✕"})]}),e.jsxs("div",{ref:o,className:"flex items-center justify-center relative p-0",style:{width:X?"100%":"var(--wallet-width)",height:X?"calc(100vh - 41px)":"var(--wallet-height)",backgroundColor:S,pointerEvents:r.armed?void 0:"none"},children:[X&&e.jsx("div",{ref:i,"aria-hidden":!0,style:{position:"absolute",top:0,left:0,width:24,height:24,pointerEvents:"none"}}),(!n||a.kind==="loading")&&e.jsx(xt,{message:"Loading...",theme:t}),a.kind==="waiting"&&e.jsx(xt,{message:"Waiting for request...",theme:t}),a.kind==="expired"&&e.jsx("p",{className:"text-xs",style:{color:t.color.global.gray},children:"This request expired or was already handled."}),a.kind==="unlock"&&e.jsx(vs,{onUnlock:()=>{v()}}),e.jsxs(Nn,{originator:En(a),embeddedIn:Pn(a),children:[a.kind==="permission"&&e.jsx(Ho,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="bundle"&&e.jsx(an,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="groupedPermission"&&e.jsx(ko,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="counterpartyPermission"&&e.jsx(vo,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="oneSatPermission"&&e.jsx(Mo,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="streamGrant"&&(a.payload.envelope?e.jsx(bn,{request:a.payload,onResponse:()=>{v()}},a.requestID):e.jsx(yn,{request:a.payload,onResponse:()=>{v()}},a.requestID)),a.kind==="mintPrivate"&&e.jsx(gn,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="swap"&&e.jsx(un,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="themeOffer"&&e.jsx(fn,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="proveHoldings"&&e.jsx(mn,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="twetch"&&e.jsx(hn,{request:a.payload,onResponse:()=>{v()}},a.requestID),a.kind==="usbCheck"&&e.jsx(Vo,{request:a.payload,onResponse:()=>{v()}},a.requestID)]})]})]}):e.jsxs("p",{className:"text-xs p-4",style:{color:"#98A2B3"},children:["Open ",ce," to answer this request."]})},qt=document.getElementById("root");if(!qt)throw new Error("Root element");ls.createRoot(qt).render(e.jsx(ms,{children:e.jsx(xs,{children:e.jsx(gs,{children:e.jsx(ys,{children:e.jsx($n,{})})})})}));
//# sourceMappingURL=prompt-tab-C12lWI2B.js.map
