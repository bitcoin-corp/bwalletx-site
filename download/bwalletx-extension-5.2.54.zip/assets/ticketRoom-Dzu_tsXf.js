import{e}from"./index-CZVpoFs0.js";import{j as a}from"./main-CRq7GuUP.js";const r=(o,t)=>{a(`bsv21:${o}`),t(e("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-Dzu_tsXf.js.map
