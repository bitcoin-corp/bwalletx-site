import{t as o}from"./crypto-KcxRl6yv.js";const r=[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]],a=o("arrow-up",r);export{a as A};
//# sourceMappingURL=arrow-up-D9k4tNDW.js.map
