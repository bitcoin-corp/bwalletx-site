import{r as t}from"./wocLimiter-CB1baL7K.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-DPC9nlob.js.map
