import{r as n}from"./wocLimiter-CB1baL7K.js";import{X as s}from"./index-CZVpoFs0.js";const u=(e,r)=>{const t=n.useRef(r);t.current=r,n.useEffect(()=>{const o=c=>c.detail===e&&t.current();return window.addEventListener(s,o),()=>window.removeEventListener(s,o)},[e])};export{u};
//# sourceMappingURL=useTabHome-DZ6LVD2a.js.map
