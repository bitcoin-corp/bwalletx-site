import{r as t}from"./wocLimiter-CB1baL7K.js";import{fetchPeopleTokens as l}from"./people-DJlHHbiG.js";const f=()=>{const[s,o]=t.useState(null);return t.useEffect(()=>{let e=!0;return l().then(r=>e&&o(r)),()=>{e=!1}},[]),s};export{f as u};
//# sourceMappingURL=usePeopleTokens-ClZt_7hR.js.map
