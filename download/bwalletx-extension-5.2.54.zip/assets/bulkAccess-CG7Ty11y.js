import{i as e}from"./sessions-CGrJEfby.js";import{aQ as i,aR as l,aS as n}from"./index-CZVpoFs0.js";const r=["b0asex"],c=(a,s=r)=>{const[t,o]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!s.includes(t)?!1:!o||o===l.toLowerCase()||(n??[]).includes(o)},m=(a,s=!1)=>s||e(a)||c(i(a??void 0));export{m as c};
//# sourceMappingURL=bulkAccess-CG7Ty11y.js.map
