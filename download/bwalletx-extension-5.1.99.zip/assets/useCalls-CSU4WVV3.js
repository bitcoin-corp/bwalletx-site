import{r as s}from"./index-BzS4xxnF.js";import{hH as r,hI as o}from"./main-rkBDxez0.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-CSU4WVV3.js.map
