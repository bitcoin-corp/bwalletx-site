import{r as s}from"./index-DY09yoPa.js";import{hH as r,hI as o}from"./main-Qw8qr6NB.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-CrnNv80O.js.map
