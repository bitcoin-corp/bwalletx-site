const n=[.55,1,.8,.45],r=.18;function i(t,o=4){const s=Number.isFinite(t)?Math.min(1,Math.max(0,t)):0,a=Math.min(1,Math.sqrt(s)*1.6);return Array.from({length:o},(e,h)=>{const c=r+(1-r)*a*(n[h%n.length]??1);return Math.round(c*100)/100})}export{i as l};
//# sourceMappingURL=levelMeter-B2DDul0R.js.map
