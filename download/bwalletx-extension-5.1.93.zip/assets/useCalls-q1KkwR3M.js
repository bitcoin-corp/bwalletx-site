import{r as s}from"./index-By6IlKoB.js";import{hP as r,hQ as o}from"./main-D52h_E1a.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-q1KkwR3M.js.map
