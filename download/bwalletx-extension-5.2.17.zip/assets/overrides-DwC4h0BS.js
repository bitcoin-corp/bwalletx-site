const e={},c=["342d637360569559810232fbbf9c4aea873e95c31d710396b0c9ac2e832ce628_1"],o=[],t={tokens:e,hidden:c,remotePlatforms:o};export{t as default,c as hidden,o as remotePlatforms,e as tokens};
//# sourceMappingURL=overrides-DwC4h0BS.js.map
