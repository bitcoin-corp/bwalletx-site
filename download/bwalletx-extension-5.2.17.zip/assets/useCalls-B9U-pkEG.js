import{r as s}from"./index-Czy6iWQC.js";import{hM as r,hN as o}from"./main-BY4MX1wT.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-B9U-pkEG.js.map
