import{r as t}from"./index-Czy6iWQC.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-BXLicYSk.js.map
