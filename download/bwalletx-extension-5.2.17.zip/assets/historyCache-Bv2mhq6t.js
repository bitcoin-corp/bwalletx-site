const e=new Map,n=t=>`bwx-history:${t.join(",")}`,a=t=>{const r=e.get(t);if(r)return r;try{const o=sessionStorage.getItem(t),s=o?JSON.parse(o):null;if(s&&Array.isArray(s.rows)&&typeof s.at=="number")return e.set(t,s),s}catch{}return null},c=(t,r)=>{e.set(t,r);try{sessionStorage.setItem(t,JSON.stringify(r))}catch{}};export{n as h,a as r,c as w};
//# sourceMappingURL=historyCache-Bv2mhq6t.js.map
