import{r as n}from"./wocLimiter-uHHeeIuD.js";import{W as s}from"./index-CnhhOIZa.js";const u=(e,r)=>{const t=n.useRef(r);t.current=r,n.useEffect(()=>{const o=c=>c.detail===e&&t.current();return window.addEventListener(s,o),()=>window.removeEventListener(s,o)},[e])};export{u};
//# sourceMappingURL=useTabHome-C4dg0YDl.js.map
