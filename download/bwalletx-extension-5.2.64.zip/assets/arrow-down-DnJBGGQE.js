import{t as o}from"./crypto-CpyaK_PA.js";const e=[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]],t=o("arrow-down",e);export{t as A};
//# sourceMappingURL=arrow-down-DnJBGGQE.js.map
