import{r as a}from"./wocLimiter-uHHeeIuD.js";let t=0;const s=new Set,i=e=>{const r=Math.max(0,Math.floor(Number(e)||0));r!==t&&(t=r,s.forEach(o=>o()))},n=()=>t,c=e=>(s.add(e),()=>{s.delete(e)}),u=()=>a.useSyncExternalStore(c,n,n);export{i as s,u};
//# sourceMappingURL=badge-hLhTnm4Y.js.map
