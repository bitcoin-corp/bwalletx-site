import{r as t}from"./wocLimiter-uHHeeIuD.js";import{fetchPeopleTokens as l}from"./people-BRCdZc61.js";const f=()=>{const[s,o]=t.useState(null);return t.useEffect(()=>{let e=!0;return l().then(r=>e&&o(r)),()=>{e=!1}},[]),s};export{f as u};
//# sourceMappingURL=usePeopleTokens-DoYMB2FE.js.map
