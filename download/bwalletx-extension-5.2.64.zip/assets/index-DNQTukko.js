const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B8r2l6wc.js","./index-CnhhOIZa.js","./crypto-CpyaK_PA.js","./wocLimiter-uHHeeIuD.js","./wocLimiter-Cw4eDz7L.css","./index-D7NokxBA.css"])))=>i.map(i=>d[i]);
import{aM as e,_ as t}from"./index-CnhhOIZa.js";import"./crypto-CpyaK_PA.js";import"./wocLimiter-uHHeeIuD.js";const _=e("Share",{web:()=>t(()=>import("./web-B8r2l6wc.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-DNQTukko.js.map
