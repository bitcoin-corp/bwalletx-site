import{i as e}from"./sessions-BXkfz2bm.js";import{aT as i,aU as l,aV as n}from"./index-CnhhOIZa.js";const r=["b0asex"],c=(a,s=r)=>{const[t,o]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!s.includes(t)?!1:!o||o===l.toLowerCase()||(n??[]).includes(o)},m=(a,s=!1)=>s||e(a)||c(i(a??void 0));export{m as c};
//# sourceMappingURL=bulkAccess-DzwB7z6i.js.map
