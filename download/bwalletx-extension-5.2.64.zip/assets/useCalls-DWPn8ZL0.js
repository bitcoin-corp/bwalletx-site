import{r as s}from"./wocLimiter-uHHeeIuD.js";import{Q as r,U as o}from"./index-CnhhOIZa.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-DWPn8ZL0.js.map
