import{e}from"./index-CnhhOIZa.js";import{j as a}from"./main-DWT-sH9M.js";const r=(o,t)=>{a(`bsv21:${o}`),t(e("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-zCOcEdiy.js.map
