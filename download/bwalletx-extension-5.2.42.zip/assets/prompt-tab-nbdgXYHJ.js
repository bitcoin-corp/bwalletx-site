import{r as d,j as e,b as Vt}from"./index-C7bJf09m.js";import{n as Ue,bl as pt,bm as ut,bn as Gt}from"./crypto-DcyUTPiL.js";import{H as oe,O as re,T as A,bN as O,he as ie,hf as _,bO as Kt,U as Xt,bP as ve,s as Y,g7 as ft,hc as Yt,hd as Jt,h3 as Zt,h4 as Qt,h5 as es,S as rt,h9 as ts}from"./index-C8N9O7V7.js";import{k as me,i as je,U as ss,Q as ke,z as Me,K as mt,S as os,v as rs,O as ns,D as xt,N as se,R as as,q as j,p as is,j as ls,n as cs,T as Ie,H as Le,w as T,x as $,V as ds,W as Ae,X as ps,Y as De,A as ht,y as nt,M as Be,P as us,Z as fs,C as at,_ as ms,l as xs,$ as hs,c as gt}from"./reservedBaskets-B2Lv8AaZ.js";import{a as gs,s as yt,p as ys}from"./approvalKind-BXkYFLHQ.js";import"./extensionMedia-Rm_l9uoo.js";import"./originKey-Dn2ka4Hc.js";const bs=t=>{const{request:s,onResponse:r}=t,{theme:o}=oe(),{handleSelect:l,hideMenu:n}=me(),{addSnackbar:p}=je(),[u,a]=d.useState(!1),[f,y]=d.useState(""),{chromeStorageService:b}=re(),{permissions:i}=s,[N,h]=d.useState(()=>i.protocols.map(()=>!0));d.useEffect(()=>{l("bsv"),n()},[l,n]);const c=()=>{const E=i.protocols.filter((C,L)=>N[L]);return E.length===0?{}:{protocols:E}},w=async()=>{a(!0),y("");try{const E=await ie(b);if(!E.ok){y(E.message),a(!1);return}ke(s.originator),_({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:c()}),r()}catch(E){p(E instanceof Error?E.message:String(E),"error"),a(!1)}},S=async()=>{a(!0),_({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),r()},x=E=>h(C=>C.map((L,le)=>le===E?!L:L)),g=s.counterpartyLabel??`${s.counterparty.slice(0,8)}...${s.counterparty.slice(-8)}`;return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ss,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Counterparty Permission"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","wants to interact with a counterparty"]})]})]}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all font-mono",style:{color:o.color.global.contrast},children:g})]}),e.jsx(O,{when:!!i.description,children:e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Purpose"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:i.description})]})}),e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),i.protocols.map((E,C)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:C<i.protocols.length-1?"1px solid rgba(255,255,255,0.04)":"none"},children:[e.jsx("input",{type:"checkbox",checked:N[C],onChange:()=>x(C),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[E.protocolID?.[1]," (level ",E.protocolID?.[0],")"]}),E.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:E.description})]})]},`proto-${C}`))]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[f&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:f}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:u?.6:1},disabled:u,onClick:w,whileHover:{scale:u?1:1.02},whileTap:{scale:u?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[u&&e.jsx(Ue,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:u?.5:1},disabled:u,onClick:S,whileHover:{scale:u?1:1.02},whileTap:{scale:u?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},bt=[{protocolID:[2,"bmintx archive"],origins:["bmintx.com","www.bmintx.com"],label:"Your private archive (bMintX)",description:"bMintX wants to lock your imported posts with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose."},{protocolID:[2,"bvideox records"],origins:["bvideox.com","www.bvideox.com"],label:"Your video records (bVideoX)",description:"bVideoX wants to lock your video records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"video",countFrom:/(\d+) private video records?/i}},{protocolID:[2,"bjobsx records"],origins:["bjobsx.com","www.bjobsx.com"],label:"Your work records (bJobsX)",description:"bJobsX wants to lock your profile records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"profile record",countFrom:/(\d+) private profile records?/i}},{protocolID:[2,"bdrivex records"],origins:["bdrivex.com","www.bdrivex.com"],label:"Your file records (bDriveX)",description:"bDriveX wants to lock your file records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"file record",countFrom:/(\d+) private file records?/i}},{protocolID:[2,"bcalx records"],origins:["bcalx.com","www.bcalx.com"],label:"Your calendar records (bCalX)",description:"bCalX wants to lock your calendar records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"calendar record",countFrom:/(\d+) private (?:calendar )?records?/i}}],vs=t=>`${t[0]}:${t[1].trim().toLowerCase()}`;new Map(bt.map(t=>[vs(t.protocolID),t]));const ws={"2:3241645161d8":{label:"BRC-29 payment",description:"An application is requesting permission to derive payment addresses for a specific recipient."},...Object.fromEntries(bt.map(t=>[`${t.protocolID[0]}:${t.protocolID[1]}`,{label:t.label,description:t.description}]))},vt=t=>t?ws[`${t[0]}:${t[1]}`]:void 0,wt=t=>vt(t)?.label??t?.[1],js=t=>{switch(t){case 0:return"Level 0 · any app";case 1:return"Level 1 · same keys for any app using this protocol";case 2:return"Level 2 · same keys for any app using this protocol with this recipient";default:return`Level ${t??0}`}},jt=t=>`${t[0]}:${t[1].trim().toLowerCase()}`,ks=new Set([2532803679,1545534606,3968644154,2559579298,983045898,2744301556,111268922,3445661247,2334321181,4156441831,3583153857,2398265928,1065214202,2451633495,1587406450,3495424783,2196479044,3172368687,3977290595,2110695608,2486468533,3947228137,3114316294,3407865888,2095595255,927149303,1269930738,2919298931,2255687340,329407381,2945469548,2194069484,2746709595].map(t=>t>>>0)),Ns=[[2,"3241645161d8"]],Ss=t=>{let s=2166136261;for(const r of new TextEncoder().encode(jt(t)))s=Math.imul(s^r,16777619)>>>0;return s>>>0};new Set(Ns.map(jt));const Es=t=>Array.isArray(t)&&t.length===2&&typeof t[0]=="number"&&typeof t[1]=="string"?[t[0],t[1]]:null,it=t=>{const s=Es(t);return!!s&&ks.has(Ss(s))},Cs=t=>{const{request:s,onResponse:r}=t,{theme:o}=oe(),l=Me(),{handleSelect:n,hideMenu:p}=me(),{addSnackbar:u}=je(),[a,f]=d.useState(!1),[y,b]=d.useState(""),{chromeStorageService:i}=re(),N=i.getCurrentAccountObject().account?.pubKeys?.identityPubKey??"",{permissions:h}=s,[c,w]=d.useState(()=>(h.protocolPermissions??[]).map(()=>!1)),[S,x]=d.useState(()=>(h.basketAccess??[]).map(()=>!0)),[g,E]=d.useState(()=>(h.certificateAccess??[]).map(()=>!0)),[C,L]=d.useState(!0);d.useEffect(()=>{n("bsv"),p()},[n,p]);const le=()=>{const v={},R=(h.protocolPermissions??[]).filter((ce,K)=>c[K]&&!it(ce.protocolID));R.length>0&&(v.protocolPermissions=R);const D=(h.basketAccess??[]).filter((ce,K)=>S[K]);D.length>0&&(v.basketAccess=D);const B=(h.certificateAccess??[]).filter((ce,K)=>g[K]);return B.length>0&&(v.certificateAccess=B),v},Ne=async()=>{f(!0),b("");try{const v=await ie(i);if(!v.ok){b(v.message),f(!1);return}ke(s.originator),_({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:le()}),r()}catch(v){u(v instanceof Error?v.message:String(v),"error"),f(!1)}},Se=async()=>{f(!0),_({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),r()},We=v=>w(R=>R.map((D,B)=>B===v?!D:D)),J=v=>x(R=>R.map((D,B)=>B===v?!D:D)),Ee=v=>E(R=>R.map((D,B)=>B===v?!D:D));return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(mt,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Permission Request"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","is requesting the following permissions"]})]})]}),e.jsx(os,{site:rs(s.originator),account:N,style:{marginBottom:12}}),e.jsx(O,{when:!!h.description,children:e.jsx("p",{className:"text-xs mb-3 leading-relaxed",style:{color:o.color.global.gray},children:h.description})}),e.jsx(O,{when:ns,children:e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-3",style:{background:"rgba(247,144,9,0.08)",border:"1px solid rgba(247,144,9,0.2)"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.06},children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pb-1",style:{color:"#F79009"},children:"Spending Authorization"}),e.jsxs("label",{className:"flex items-start gap-3 py-1 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:C,onChange:()=>L(!C),className:"mt-0.5 accent-orange-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-semibold",style:{color:"#F79009"},children:"This app wants to spend up to"}),e.jsx(xt,{sats:h.spendingAuthorization?.amount??0,price:l,size:24,align:"left",color:"#F79009",mutedColor:o.color.global.gray}),h.spendingAuthorization?.description&&e.jsxs("span",{className:"text-xs mt-1 opacity-70",style:{color:o.color.global.contrast},children:["App says: “",h.spendingAuthorization.description,"”"]})]})]})]})}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-2 mb-5",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs(O,{when:!!h.protocolPermissions?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),h.protocolPermissions?.map((v,R)=>it(v.protocolID)?e.jsxs("p",{className:"text-xs py-2",style:{color:o.color.global.gray},children:["Refused: “",v.protocolID[1],"” is used only by bWalletX itself."]},`proto-${R}`):e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:c[R],onChange:()=>We(R),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:["Let this app sign and encrypt with your keys for “",wt(v.protocolID),"”",v.counterparty?` (shared with ${v.counterparty.slice(0,10)}…)`:""]}),e.jsxs("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:["Any app that asks for this protocol gets the same keys (level ",v.protocolID[0],")."]}),v.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:v.description})]})]},`proto-${R}`))]}),e.jsxs(O,{when:!!h.basketAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Baskets"}),h.basketAccess?.map((v,R)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:S[R],onChange:()=>J(R),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:v.basket}),v.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:v.description})]})]},`basket-${R}`))]}),e.jsxs(O,{when:!!h.certificateAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Certificates"}),h.certificateAccess?.map((v,R)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:g[R],onChange:()=>Ee(R),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:v.type}),e.jsxs("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:[v.description," — fields: ",v.fields.join(", ")]})]})]},`cert-${R}`))]})]}),e.jsxs("div",{className:"flex flex-col gap-3",children:[y&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:y}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:a?.6:1},disabled:a,onClick:Ne,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[a&&e.jsx(Ue,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:a?.5:1},disabled:a,onClick:Se,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},Ps=2e3;async function we(t,s=Ps){let r;try{return await Promise.race([t.catch(()=>{}),new Promise(o=>{r=setTimeout(()=>o(void 0),s)})])}catch{return}finally{r&&clearTimeout(r)}}function Rs(t,s){return t?.find(r=>r.startsWith(`${s}:`))?.slice(s.length+1)}async function Ts(t,s,r=[]){const o=t.ordfs;if(typeof o?.bulkMetadata!="function")return{state:"unverified"};const l=`${s}:-2`,n=await we(o.bulkMetadata([l])),p=n?.[l]??n?.[s]??Object.values(n??{}).find(f=>!!f?.contentType);if(!p?.contentType)return{state:"unverified"};const u={contentType:p.contentType,origin:p.origin,name:typeof p.map?.name=="string"?p.map.name:void 0},a=r.find(f=>f.includes("/"));return a&&a!==p.contentType?{state:"mismatch",note:`Content type is ${p.contentType}, not ${a}`,...u}:{state:"verified",...u}}async function Is(t,s,r){const o=t.opns;if(typeof o?.getOrigin!="function")return{state:"unverified"};const l=await we(o.getOrigin(s));return l?.outpoint?l.outpoint!==r?{state:"mismatch",note:`“${s}” currently resolves to a different output`}:{state:"verified"}:{state:"unverified"}}async function As(t,s,r,o=[]){const l=t.bsv21;if(typeof l?.getTokenDetails!="function")return{state:"unverified"};const n=await we(l.getTokenDetails(s,{fresh:!0}));if(!n)return{state:"unverified"};if(n.status?.is_active===!1)return{state:"mismatch",note:"Token is not active on the overlay"};const p=n.token?.sym;if(r&&p&&r.toLowerCase()!==p.toLowerCase())return{state:"mismatch",note:`Token symbol is ${p}, not ${r}`};if(o.length>0&&typeof l.getOutputStatus=="function"){const u=await we(l.getOutputStatus(s,o));if(!u)return{state:"unverified"};const a=u.filter(f=>f.state==="spent"||f.state==="unknown");if(a.length>0)return{state:"mismatch",note:a.length===1?"A spent token output is not valid on the overlay":`${a.length} spent token outputs are not valid on the overlay`};if(u.some(f=>f.state==="queued"))return{state:"unverified"}}return{state:"verified",...p?{name:p}:{}}}async function Ds(t,s,r,o,l){if(!t||!s)return{state:"unverified"};const n=s==="purchase"||s.endsWith(".purchase"),p=s==="token-transfer"||s.startsWith("bsv21.");if(!n&&!p)return{state:"unverified"};const u={kindOrIntent:s,hasOrdfs:!!t.ordfs,hasBulk:typeof t.ordfs?.bulkMetadata=="function",inputTagSets:r.map(a=>a.tags),outputTagSets:o.map(a=>a.tags)};try{const a=[...r.map(c=>c.tags),...o.map(c=>c.tags)],f=c=>a.flatMap(w=>w.filter(S=>S.startsWith(`${c}:`)).map(S=>S.slice(c.length+1))),y=c=>{for(const w of a){const S=Rs(w,c);if(S)return S}},b=y("bsv21");if(b||s==="bsv21.purchase"||s==="token-transfer"||s.startsWith("bsv21.")){if(!b)return{state:"unverified"};const w=r.filter(x=>x.basket?.includes("bsv21")||x.tags.some(g=>g.startsWith("bsv21:"))).map(x=>x.outpoint).filter(Boolean);let S=y("sym");for(const x of r)if(x.customInstructions)try{const g=JSON.parse(x.customInstructions).sym;if(typeof g=="string"&&g.trim()){S=g.trim();break}}catch{}return await As(t,b,S,w)}const i=y("name"),N=y("origin");if(u.name=i,u.origin=N,i&&N&&o.some(c=>c.basket?.includes("opns"))||s==="opns.purchase")return!i||!N?{state:"unverified"}:await Is(t,i,N);if(!N)return u.reason="no-origin-tag",globalThis.__lastVerify=u,{state:"unverified"};const h=await Ts(t,N,f("type"));if(u.verifyOrdinal=h,h.origin&&l)try{h.contentUrl=l(h.origin)}catch(c){u.contentUrlError=String(c)}return globalThis.__lastVerify=u,h}catch(a){return u.error=String(a),globalThis.__lastVerify=u,{state:"unverified"}}}function kt(t){if(!t||typeof t!="object")return!1;const s=t;return Array.isArray(s.panels)&&typeof s.title=="string"}var $s=`
.opp-root {
  --opp-bg: #ffffff;
  --opp-fg: #111827;
  --opp-muted: #6b7280;
  --opp-card-bg: #f7f8fa;
  --opp-card-border: #eceef2;
  --opp-accent: #E5A920;
  --opp-approve-bg: #E5A920;
  --opp-approve-fg: #ffffff;
  --opp-reject-bg: #ffffff;
  --opp-reject-fg: #111827;
  --opp-reject-border: #d1d5db;
  --opp-status-bg: #FFFBE6;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #ECFDF5;
  --opp-trust-ok-fg: #059669;
  --opp-trust-warn-bg: #FFFBEB;
  --opp-trust-warn-fg: #D97706;
  --opp-trust-bad-bg: #FEF2F2;
  --opp-trust-bad-fg: #DC2626;

  font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--opp-bg);
  color: var(--opp-fg);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 480px;
  min-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
}

.opp-bottom {
  margin-top: auto;
  display: flex;
  flex-direction: column;
}

.opp-root.opp-dark {
  --opp-bg: #0F1117;
  --opp-fg: #F9FAFB;
  --opp-muted: #9ca3af;
  --opp-card-bg: #1A1D27;
  --opp-card-border: #232636;
  --opp-reject-bg: #0F1117;
  --opp-reject-fg: #F9FAFB;
  --opp-reject-border: #2D3142;
  --opp-status-bg: #2A2408;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #0A2E1F;
  --opp-trust-ok-fg: #34D399;
  --opp-trust-warn-bg: #2A2008;
  --opp-trust-warn-fg: #FBBF24;
  --opp-trust-bad-bg: #2A1215;
  --opp-trust-bad-fg: #F87171;
}

.opp-body {
  padding: 24px 20px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
}

.opp-coin {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
}

.opp-title {
  font-size: 16px;
  font-weight: 700;
  margin: 0;
  text-align: center;
}

.opp-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  margin: 0;
  text-align: center;
  line-height: 1.4;
}

.opp-status {
  background: var(--opp-status-bg);
  color: var(--opp-status-fg);
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
  margin-top: 4px;
  border: 1px solid var(--opp-card-border);
}

.opp-card {
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px;
  padding: 16px;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.opp-featured {
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px 8px;
  padding: 16px;
}

/* Subtle danger chrome for burn / destructive token ops */
.opp-featured-danger {
  border-color: rgba(220, 38, 38, 0.45);
  background: color-mix(in srgb, var(--opp-card-bg) 88%, #7f1d1d 12%);
}

.opp-featured-danger .opp-featured-title {
  color: #f87171;
}

.opp-featured-danger .opp-featured-image,
.opp-featured-danger .opp-featured-placeholder {
  border: 1px solid rgba(220, 38, 38, 0.35);
  background: rgba(127, 29, 29, 0.25);
  color: #fca5a5;
}

.opp-dark .opp-featured-danger {
  border-color: rgba(248, 113, 113, 0.4);
  background: color-mix(in srgb, var(--opp-card-bg) 85%, #450a0a 15%);
}

.opp-preview-pair {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.opp-preview-arrow {
  color: var(--opp-muted);
  font-size: 14px;
  line-height: 1;
}

.opp-preview-pair .opp-featured-image {
  width: 64px;
  height: 64px;
}

.opp-featured-image {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-featured-image-token {
  width: 48px;
  height: 48px;
  border-radius: 999px;
}

.opp-featured-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--opp-muted);
  font-size: 18px;
}

.opp-preview-opns {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
}

.opp-preview-opns-avatar {
  width: 36px;
  height: 36px;
  border-radius: 999px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-preview-opns-name {
  font-size: 11px;
  font-weight: 600;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  color: var(--opp-fg, inherit);
}

.opp-preview-text {
  margin: 0;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
  font-size: 9px;
  line-height: 1.25;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  color: var(--opp-muted);
}

.opp-preview-json {
  white-space: pre;
  overflow: auto;
}

.opp-preview-frame {
  border: 0;
  padding: 0;
  overflow: hidden;
  background: #fff;
  pointer-events: none;
}

.opp-preview-value {
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  background: rgba(229, 169, 32, 0.12);
  border: 1px solid rgba(229, 169, 32, 0.35);
  color: var(--opp-fg, inherit);
}

.opp-preview-value-icon {
  width: 32px;
  height: 32px;
  color: #E5A920;
}

/* Amount subtitles must never ellipsis — full sat counts are the point. */
.opp-featured-subtitle-text.opp-amount {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-variant-numeric: tabular-nums;
  white-space: normal;
  overflow: visible;
  text-overflow: unset;
  word-break: keep-all;
}

.opp-featured-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  flex: 1;
}

.opp-featured-title {
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.opp-featured-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.opp-featured-subtitle-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
}

.opp-featured-meta-line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  color: var(--opp-muted);
}

.opp-featured-meta-line-bare {
  align-items: center;
}

.opp-featured-meta-key {
  flex-shrink: 0;
  opacity: 0.75;
  min-width: 2.5em;
}

.opp-featured-meta-value {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  flex: 1;
}

.opp-featured-meta-value-mono {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 11px;
}

.opp-trust-wrap {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0 20px 8px;
}

.opp-trust {
  display: inline-flex;
  align-self: flex-start;
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 600;
}

.opp-trust-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-trust-note {
  padding: 10px;
  border-radius: 8px;
  font-size: 11px;
  line-height: 1.35;
}

.opp-trust-note-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-note-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-note-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.opp-row-key {
  color: var(--opp-muted);
  flex-shrink: 0;
}

.opp-row-value-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 70%;
  justify-content: flex-end;
}

.opp-row-value {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 12px;
  font-weight: 500;
  text-align: right;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.opp-copy {
  flex-shrink: 0;
  width: 22px;
  height: 22px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  border: 1px solid var(--opp-reject-border);
  background: var(--opp-bg);
  color: var(--opp-fg);
  cursor: pointer;
}

.opp-copy:hover {
  border-color: var(--opp-accent);
  color: var(--opp-accent);
}

.opp-fee-note {
  font-size: 11px;
  color: var(--opp-muted);
  line-height: 1.3;
  margin-top: -4px;
}

.opp-actions {
  display: flex;
  gap: 12px;
  padding: 20px 20px 12px;
}

.opp-button {
  flex: 1;
  padding: 0 16px;
  height: 48px;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid transparent;
  transition: opacity 120ms ease;
}

.opp-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.opp-button-reject {
  background: var(--opp-reject-bg);
  color: var(--opp-reject-fg);
  border-color: var(--opp-reject-border);
}

.opp-button-approve {
  background: var(--opp-approve-bg);
  color: var(--opp-approve-fg);
}

.opp-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 20px 16px;
  font-size: 11px;
  font-weight: 500;
  color: var(--opp-muted);
}
`;function Os({request:t,onApprove:s,onReject:r,theme:o="auto",services:l}){const n=qs(o),p=Fs(t),[u,a]=d.useState(!1),[f,y]=d.useState(),b=t.kind==="transaction"&&kt(t.payload)?t.payload:void 0;d.useEffect(()=>{if(!l||!b?.trust||!b.verify)return;let c=!0;const w=l.ordfs?.getContentUrl?.bind(l.ordfs);return Ds(l,b.verify.kind,b.verify.inputs,b.verify.outputs,w).then(S=>{c&&S&&y(S)}).catch(()=>{}),()=>{c=!1}},[l,b]);const i=f?Ls(p,f):p,N=c=>()=>{if(!u){a(!0);try{c==="approve"?s():r()}finally{a(!1)}}};d.useEffect(()=>{const c=w=>{u||(w.key==="Escape"?r():w.key==="Enter"&&s())};return window.addEventListener("keydown",c),()=>window.removeEventListener("keydown",c)},[s,r,u]);const h=`opp-root${n==="dark"?" opp-dark":""}`;return e.jsxs("div",{className:h,children:[e.jsx("style",{children:$s}),e.jsxs("div",{className:"opp-body",children:[e.jsxs("svg",{className:"opp-coin",viewBox:"0 0 100 100","aria-label":"1Sat Ordinals",children:[e.jsx("circle",{cx:"50",cy:"50",r:"50",fill:"#222"}),e.jsx("circle",{cx:"50",cy:"50",r:"40",fill:"#fff"}),e.jsx("circle",{cx:"50",cy:"50",r:"32",fill:"#E5A920"}),e.jsx("rect",{x:"47",y:"28",width:"6",height:"28",rx:"3",fill:"#fff"})]}),e.jsx("h2",{className:"opp-title",children:i.title}),e.jsx("p",{className:"opp-subtitle",children:i.subtitle}),e.jsx("div",{className:"opp-status",children:"Awaiting Approval"})]}),i.panels.map((c,w)=>{const S=c.variant??"ordinal",x=["opp-featured"];return S==="token"&&x.push("opp-featured-token"),S==="value"&&x.push("opp-featured-value"),c.tone==="danger"&&x.push("opp-featured-danger"),e.jsxs("div",{className:x.join(" "),children:[c.prior?e.jsxs("div",{className:"opp-preview-pair","aria-label":"Previous and new inscription",children:[e.jsx($e,{panel:{...c,previewKind:c.prior.previewKind,imageUrl:c.prior.imageUrl,contentUrl:c.prior.contentUrl,previewText:c.prior.previewText,prior:void 0}}),e.jsx("span",{className:"opp-preview-arrow","aria-hidden":!0,children:"→"}),e.jsx($e,{panel:c})]}):e.jsx($e,{panel:c}),e.jsxs("div",{className:"opp-featured-meta",children:[e.jsx("div",{className:"opp-featured-title",children:c.title}),c.subtitle&&e.jsxs("div",{className:"opp-featured-subtitle",children:[e.jsx("span",{className:c.amountSats!=null?"opp-featured-subtitle-text opp-amount":"opp-featured-subtitle-text",children:c.subtitle}),c.subtitleCopy&&e.jsx(Oe,{text:c.subtitleCopy})]}),(c.meta??[]).map(g=>e.jsxs("div",{className:`opp-featured-meta-line${g.key?"":" opp-featured-meta-line-bare"}`,children:[g.key?e.jsx("span",{className:"opp-featured-meta-key",children:g.key}):null,e.jsx("span",{className:`opp-featured-meta-value${g.key?"":" opp-featured-meta-value-mono"}`,title:g.copyValue??g.value,children:g.value}),g.copyValue&&e.jsx(Oe,{text:g.copyValue})]},`${g.key}:${g.value}`))]})]},`panel-${w}-${c.title}`)}),i.trust&&e.jsxs("div",{className:"opp-trust-wrap",children:[e.jsx("span",{className:`opp-trust opp-trust-${i.trust.state}`,children:Ms(i.trust.state)}),i.trust.note&&e.jsx("div",{className:`opp-trust-note opp-trust-note-${i.trust.state}`,children:i.trust.note})]}),(i.rows.length>0||i.indexerFee||i.funding)&&e.jsxs("div",{className:"opp-card",children:[i.rows.map(c=>e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:c.key}),e.jsxs("span",{className:"opp-row-value-wrap",children:[e.jsx("span",{className:"opp-row-value",title:c.copyValue??c.value,children:c.value}),c.copyValue&&e.jsx(Oe,{text:c.copyValue})]})]},`${c.key}:${c.value}`)),i.indexerFee&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"1Sat Overlay Fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[lt(i.indexerFee.sats)," sats"]})]}),i.funding?.networkFeeSats!=null&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"Network fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[lt(i.funding.networkFeeSats)," sats"]})]}),i.funding?.note&&e.jsx("div",{className:"opp-fee-note",children:i.funding.note})]}),e.jsxs("div",{className:"opp-bottom",children:[e.jsxs("div",{className:"opp-actions",children:[e.jsx("button",{type:"button",className:"opp-button opp-button-reject",onClick:N("reject"),disabled:u,children:"Reject"}),e.jsx("button",{type:"button",className:"opp-button opp-button-approve",onClick:N("approve"),disabled:u,children:"Approve"})]}),e.jsx("div",{className:"opp-footer",children:e.jsx("span",{children:"Secured by 1Sat Ordinals"})})]})]})}function Fs(t){if(t.kind==="transaction"&&kt(t.payload))return{title:t.payload.title,subtitle:t.payload.subtitle,panels:t.payload.panels,rows:t.payload.rows,trust:t.payload.trust,indexerFee:t.payload.indexerFee,funding:t.payload.funding};if(t.kind==="basketAccess"){const s=t.payload.baskets??[],r=s.length>0&&s.every(n=>n.scope||n.basket.startsWith("p ")),o=s.filter(n=>n.imageUrl||n.name||n.value).map(n=>({title:n.scope==="collection"?n.name?`Collection · ${n.name}`:"Collection":n.scope?n.scope:"Basket",subtitle:n.value?n.value.length>24?`${n.value.slice(0,10)}…${n.value.slice(-10)}`:n.value:n.basket,subtitleCopy:n.value,...n.imageUrl&&{previewKind:"image",contentUrl:n.imageUrl,imageUrl:n.imageUrl},tone:"default"})),l=s.flatMap(n=>n.scope==="collection"?n.description?[{key:"Access",value:n.description}]:[]:[{key:n.basket,value:n.description??"List, insert, and remove outputs"}]);return{title:r?s.length===1?s[0].scope==="collection"?"Grant Collection View":"Grant Item View":`Grant View (${s.length})`:s.length===1?"Grant Basket Access":`Grant Access to ${s.length} Baskets`,subtitle:r?`${be(t.originator)} wants to view items in your wallet`:`${be(t.originator)} wants to read and write 1Sat baskets`,panels:o,rows:l}}return t.kind==="protocol"?{title:"Protocol Access",subtitle:`${be(t.originator)} wants protocol access`,panels:[],rows:[{key:"Detail",value:t.summary||"Protocol request"}]}:{title:"Signature Request",subtitle:`${be(t.originator)} wants a signature`,panels:[],rows:[{key:"Detail",value:t.summary||"Signature request"}]}}function Ls(t,s){const r=t.panels.map((o,l)=>{if(l!==0)return o;const n=o.previewKind==="opns",p=s.contentType?Bs(s.contentType):void 0,u=n?"opns":p&&p!=="none"?p:o.previewKind,a=s.contentUrl??o.contentUrl??o.imageUrl;let f=o.subtitle;if(s.name&&!n)if(!f)f=s.name;else{const y=f.trim().split(/\s+/);y.length>=2&&(y[y.length-1]=s.name,f=y.join(" "))}return{...o,previewKind:u,...f?{subtitle:f}:{},...n?{...s.contentUrl&&!o.imageUrl?{imageUrl:s.contentUrl}:o.imageUrl?{imageUrl:o.imageUrl}:{}}:u==="image"?{imageUrl:a,contentUrl:a}:a?{contentUrl:a,imageUrl:void 0}:{}}});return{...t,panels:r,trust:{state:s.state,note:s.note}}}function Bs(t){const s=t.toLowerCase();return s==="image/svg+xml"||s==="svg"||s.endsWith("+svg")?"svg":s.startsWith("image/")?"image":s.includes("json")?"json":s.includes("html")||s==="application/xhtml+xml"?"html":s.startsWith("text/")?"text":"none"}function Us(t){return`${t.toLocaleString("en-US")} sats`}function lt(t){return t.toLocaleString("en-US")}function Ms(t){return t==="verified"?"Verified":t==="mismatch"?"Mismatch":"Unverified"}function $e({panel:t}){const s=t.variant??"ordinal",r=s==="token"?"opp-featured-image opp-featured-image-token":s==="value"?"opp-featured-image opp-preview-value":"opp-featured-image",o=t.previewKind??(t.imageUrl?"image":"none"),l=t.contentUrl??t.imageUrl,[n,p]=d.useState(!1);if(s==="value"){const u=t.valueIcon??"pay";return e.jsx("div",{className:r,title:t.amountSats!=null?Us(t.amountSats):void 0,"aria-hidden":!0,children:e.jsx(zs,{kind:u})})}if(o==="opns"){const u=!!t.imageUrl&&!n;return e.jsxs("div",{className:`${r} opp-preview-opns`,"aria-hidden":!t.opnsHero,children:[u?e.jsx("img",{className:"opp-preview-opns-avatar",src:t.imageUrl,alt:"",onError:()=>p(!0)}):e.jsx("div",{className:"opp-preview-opns-avatar opp-featured-placeholder",children:"◈"}),e.jsx("span",{className:"opp-preview-opns-name",title:t.opnsHero,children:t.opnsHero??"OpNS"})]})}return o==="image"&&t.imageUrl&&!n?e.jsx("img",{className:r,src:t.imageUrl,alt:t.title,onError:()=>p(!0)}):o==="image"&&n?e.jsx("div",{className:`${r} opp-featured-placeholder`,"aria-hidden":!0,children:"▭"}):(o==="text"||o==="json"||o==="html")&&t.previewText?e.jsx("pre",{className:`${r} opp-preview-text${o==="json"?" opp-preview-json":""}`,children:t.previewText}):(o==="text"||o==="json")&&l?e.jsx(Ws,{url:l,kind:o,className:r}):(o==="html"||o==="svg")&&l?e.jsx("iframe",{className:`${r} opp-preview-frame`,src:l,title:`${t.title} preview`,sandbox:"",referrerPolicy:"no-referrer"}):e.jsx("div",{className:`${r} opp-featured-placeholder`,"aria-hidden":!0,children:s==="token"?"◎":_s(o)})}function _s(t){return t==="text"||t==="json"?"¶":t==="html"||t==="svg"?"⌂":"▭"}function zs({kind:t}){return t==="lock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V8a4 4 0 018 0v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):t==="unlock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V7.5A4 4 0 0116 7",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("path",{d:"M16 4.5v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"9",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M12 7v10M9 10.5c0-1.4 1.3-2.5 3-2.5s3 1.1 3 2.5-1.3 2.5-3 2.5-3 1.1-3 2.5 1.3 2.5 3 2.5 3-1.1 3-2.5",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})}function Ws({url:t,kind:s,className:r}){const[o,l]=d.useState(null),[n,p]=d.useState(!1);return d.useEffect(()=>{let u=!1;return l(null),p(!1),fetch(t).then(async a=>{if(!a.ok)throw new Error(String(a.status));const f=await a.text();if(!u){if(s==="json")try{l(JSON.stringify(JSON.parse(f),null,2));return}catch{}l(f.slice(0,800))}}).catch(()=>{u||p(!0)}),()=>{u=!0}},[t,s]),n?e.jsx("div",{className:`${r} opp-featured-placeholder`,"aria-hidden":!0,children:"¶"}):e.jsx("pre",{className:`${r} opp-preview-text${s==="json"?" opp-preview-json":""}`,children:o??"…"})}function Oe({text:t}){const[s,r]=d.useState(!1),o=()=>{navigator.clipboard?.writeText(t).then(()=>{r(!0),window.setTimeout(()=>r(!1),1200)})};return e.jsx("button",{type:"button",className:"opp-copy",onClick:o,"aria-label":s?"Copied":"Copy full value",title:s?"Copied":"Copy",children:s?e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:e.jsx("path",{d:"M5 13l4 4L19 7",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round"})}):e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"9",y:"9",width:"11",height:"11",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M5 15V5a2 2 0 012-2h10",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})})}function qs(t){const[s,r]=d.useState(()=>t==="auto"?Hs():t);return d.useEffect(()=>{if(t!=="auto"){r(t);return}const o=window.matchMedia("(prefers-color-scheme: dark)"),l=()=>r(o.matches?"dark":"light");return l(),o.addEventListener("change",l),()=>o.removeEventListener("change",l)},[t]),s}function Hs(){return typeof window>"u"||!window.matchMedia?"light":window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function be(t){try{return new URL(t.includes("://")?t:`https://${t}`).host||t}catch{return t.length<=32?t:`${t.slice(0,14)}…${t.slice(-12)}`}}const Vs=({request:t,onResponse:s})=>{const{theme:r}=oe(),{handleSelect:o,hideMenu:l}=me(),{apiContext:n,chromeStorageService:p}=re(),u=n?.services;d.useEffect(()=>{o("bsv"),l()},[o,l]);const[a,f]=d.useState(""),y=d.useRef(!1),b=async h=>{if(!y.current){if(y.current=!0,h){f("");const c=await ie(p);if(!c.ok){f(c.message),y.current=!1;return}}_({action:"ONE_SAT_PERMISSION_RESPONSE",requestID:t.requestID,approved:h}),s()}},N=r.color.global.walletBackground.toLowerCase()==="#000000"||/^#[01]/.test(r.color.global.walletBackground)?"dark":"light";return e.jsxs("div",{style:{width:"100%",height:"100%",overflowY:"auto",display:"flex",flexDirection:"column",alignItems:"stretch",justifyContent:"center"},children:[a&&e.jsx("p",{className:"text-xs text-center m-0 pt-2",style:{color:"#ef4444"},children:a}),e.jsx(Os,{request:t.request,onApprove:()=>{b(!0)},onReject:()=>{b(!1)},theme:N,services:u})]})},Gs=t=>{switch(t){case"protocol":return"Protocol Permission";case"basket":return"Basket Access";case"certificate":return"Certificate Access";case"spending":return"Spending Authorization";default:return"Permission Request"}},Ks=t=>{switch(t.type){case"protocol":{const s=vt(t.protocolID);return s?s.description:`An application is requesting permission to use protocol "${t.protocolID?.[1]||"unknown"}" with security level ${t.protocolID?.[0]||0}.`}case"basket":return`An application is requesting access to basket "${t.basket||"unknown"}".`;case"certificate":return"An application is requesting access to certificate data.";case"spending":return`An application is requesting authorization to spend ${t.spending?.satoshis||0} satoshis.`;default:return"An application is requesting a permission."}},Xs=t=>{const{request:s,onResponse:r}=t,{theme:o}=oe(),l=Me(),{handleSelect:n,hideMenu:p}=me(),{addSnackbar:u}=je(),[a,f]=d.useState(!1),[y,b]=d.useState(""),{chromeStorageService:i}=re();d.useEffect(()=>{n("bsv"),p()},[n,p]);const N=async()=>{f(!0),b("");try{const c=await ie(i);if(!c.ok){b(c.message),f(!1);return}ke(s.originator),_({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!0}),r()}catch(c){const w=c instanceof Error?c.message:String(c);u(w,"error"),f(!1)}},h=async()=>{f(!0),_({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!1}),r()};return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(mt,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:Gs(s.type)}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:Ks(s)})]})]}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"12rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Origin"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.displayOriginator||s.originator})]}),e.jsxs(O,{when:s.type==="protocol"&&!!s.protocolID,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Protocol"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:wt(s.protocolID)})]}),e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.counterparty?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Security"}),e.jsx("span",{className:"text-xs",style:{color:o.color.global.contrast},children:js(s.protocolID?.[0])})]}),e.jsx(O,{when:!!s.counterparty,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.counterparty})]})})]}),e.jsx(O,{when:s.type==="basket"&&!!s.basket,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Basket"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.basket})]})}),e.jsxs(O,{when:s.type==="certificate"&&!!s.certificate,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Cert Type"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.certType})]}),e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Fields"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.fields.join(", ")})]})]}),e.jsxs(O,{when:s.type==="spending"&&!!s.spending,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.spending?.lineItems?.length?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Amount"}),e.jsx(xt,{sats:s.spending?.satoshis||0,price:l,size:24,align:"left",color:"var(--bw-accent-hi)",mutedColor:o.color.global.gray})]}),e.jsx(O,{when:!!s.spending?.lineItems?.length,children:s.spending?.lineItems?.map((c,w)=>e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:w<(s.spending?.lineItems?.length??0)-1?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:c.type}),e.jsxs("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:[c.description," (",se(c.satoshis,l).main," ·"," ",se(c.satoshis,l).sub,")"]})]},w))})]}),e.jsx(O,{when:!!s.reason,children:e.jsxs("div",{className:"flex flex-row py-2",style:{borderTop:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Reason"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.reason})]})})]}),e.jsx(O,{when:!!s.privileged,children:e.jsxs(A.div,{className:"flex items-start gap-2 rounded-xl px-3 py-2.5 mb-4",style:{background:"rgba(245,166,35,0.08)",border:"1px solid rgba(245,166,35,0.15)"},initial:{opacity:0},animate:{opacity:1},transition:{delay:.12},children:[e.jsx(Kt,{size:14,className:"mt-0.5 flex-shrink-0",style:{color:"#f5a623"}}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:"#f5a623"},children:"This is a privileged operation"})]})}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[y&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:y}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:a?.6:1},disabled:a,onClick:N,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[a&&e.jsx(Ue,{size:14,className:"animate-spin"}),"Allow"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:a?.5:1},disabled:a,onClick:h,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny"})]})]})},Ys=({request:t,onResponse:s})=>{const{theme:r}=oe(),{chromeStorageService:o}=re(),[l,n]=d.useState(""),[p,u]=d.useState(!1),a=async b=>{if(!p){if(u(!0),n(""),b){const i=await ie(o);if(!i.ok){n(i.message),u(!1);return}}_({action:"USB_CHECK_RESPONSE",requestID:t.requestID,ok:b}),s()}},f=r.color.global.gray,y=r.color.global.contrast;return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(Xt,{size:40,style:{color:y}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:y},children:"Confirm your USB key"}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:f,maxWidth:"18rem"},children:[t.originator?`${t.originator} is asking bWallet to ${t.reason}.`:`A site is asking bWallet to ${t.reason}.`," ","Insert your USB key, then confirm."]}),l&&e.jsx("p",{className:"m-0 text-xs",style:{color:"#ef4444"},children:l}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(ve,{theme:r,type:"primary",label:"Confirm USB key",disabled:p,onClick:()=>{a(!0)}}),e.jsx(ve,{theme:r,type:"secondary-outline",label:"Cancel",disabled:p,onClick:()=>{a(!1)}})]})]})},Js=t=>{const s=t.map(o=>o.requestID).sort().join(`
`);let r=2166136261;for(let o=0;o<s.length;o++)r^=s.charCodeAt(o),r=Math.imul(r,16777619)>>>0;return`${t.length}:${r.toString(16)}`},Zs=5,Qs=/e-?mail|phone|mobile|kyc|passport|licen[cs]e|birth|dob|address|ssn|national|tax|id_?number/i,ae=t=>String(t.protocolID?.[1]??"unknown"),Nt=t=>Number(t.protocolID?.[0]??0),St=t=>!!(t.privileged||t.type==="certificate"&&(t.certificate?.fields??[]).some(s=>Qs.test(s))),_e=t=>t.type==="protocol"&&!t.privileged&&t.protocolID?.[1]==="identity key retrieval"&&(t.counterparty===void 0||t.counterparty==="self"),eo=/\b(auth|authentication|sign[- ]?in|login|log[- ]?in)\b/i,Et=t=>t.type==="protocol"&&!t.privileged&&(t.counterparty==="anyone"||_e(t)||eo.test(ae(t))&&(t.counterparty===void 0||t.counterparty==="self"||t.counterparty==="anyone")),to=[[/agent history/i,"Ask b chats"],[/\b(chat|message)s?\b/i,"chats"],[/\bnotes?\b/i,"notes"],[/\b(history|private|backup|vault|encrypt)/i,"data"]],Ct=t=>{if(t.type!=="protocol"||t.privileged||t.counterparty!=="self"||Et(t))return;const s=ae(t);return to.find(([r])=>r.test(s))?.[1]},so="bap",oo=[1,"sigma"],Pt=t=>t.type==="protocol"&&!t.privileged&&ae(t).toLowerCase()===oo[1],Rt=t=>t.type==="basket"&&t.basket===so,ct=t=>{switch(t.type){case"protocol":{if(_e(t))return"See your public identity (the key that names you)";if(t.counterparty==="anyone")return"Prove it's you (a signature anyone can check)";if(Pt(t))return"Sign your posts and likes as you";const s=Ct(t);return s?`Use keys from your wallet for your ${s}`:Nt(t)===2&&t.counterparty&&t.counterparty!=="self"?`Sign and encrypt with your "${ae(t)}" keys, shared with one named person or service`:`Sign and encrypt anything with your "${ae(t)}" keys`}case"basket":return Rt(t)?"Use your public profile (name and picture) on its posts":"Keep its tickets and tokens in your wallet";case"certificate":{const s=t.certificate?.fields??[];return s.length?`See your certificate details (${s.join(", ")})`:"See your certificates"}default:return"Spend from your wallet"}},Fe=t=>{const s=[];switch(t.type){case"protocol":s.push(`protocol "${ae(t)}" level ${Nt(t)}`),t.counterparty&&s.push(`counterparty ${t.counterparty}`);break;case"basket":s.push(`basket "${t.basket??""}"`);break;case"certificate":s.push(`certificate ${t.certificate?.certType??""}`,`verifier ${t.certificate?.verifier??""}`);break;case"spending":s.push(`${t.spending?.satoshis??0} sats`),t.labels?.length&&s.push(`labels: ${t.labels.join(", ")}`);break}return t.privileged&&s.push("privileged"),t.reason&&s.push(`reason: ${t.reason}`),s.join(" · ")},ro=t=>{const s=[];let r;for(const n of t.items){if(n.type==="spending"){const a=n.spending?.satoshis??0;!r&&!n.addedLive?r={requestID:n.requestID,satoshis:a,description:n.spending?.lineItems?.find(f=>f.description)?.description??n.reason,detail:Fe(n),...n.labels?.length?{labels:[...n.labels]}:{}}:s.push({requestID:n.requestID,text:`${n.addedLive?"New: pay":"Also pay"} ${a.toLocaleString()} sats`,detail:Fe(n),risky:!0,checked:!1,...n.addedLive?{isNew:!0}:{}});continue}const p=St(n),u=!p&&!n.addedLive&&(n.type!=="protocol"||n.counterparty==="anyone"||_e(n));s.push({requestID:n.requestID,text:n.addedLive?`New: ${ct(n)}`:ct(n),...n.addedLive?{isNew:!0}:{},detail:Fe(n),risky:p,checked:u,signIn:Et(n),privateLabel:Ct(n)})}const o=r?s.length?"connectAndPay":"pay":"connect",l=t.items.some(Pt)||t.items.some(Rt);return{originator:t.originator,lines:s,payment:r,mode:o,...l?{purpose:"post"}:{}}},no=(t,s,r)=>({faceTicks:new Set(t.lines.filter(o=>s||o.isNew).map(o=>o.requestID)),hidden:new Set(r?t.lines.filter(o=>!r.has(o.requestID)).map(o=>o.requestID):[])}),ao=(t,s)=>s?.hidden?.size?t.filter(r=>!s.hidden.has(r.requestID)):t,io=(t,s,r,o,l={})=>{const n={};for(const p of t.lines){if(!o&&l.hidden?.has(p.requestID))continue;const u=o||!!l.faceTicks?.has(p.requestID);if(s&&p.isNew&&r[p.requestID]===void 0)continue;const a=r[p.requestID]??(p.isNew?!1:p.checked||!p.risky&&!u);n[p.requestID]=s&&a}return t.payment&&(n[t.payment.requestID]=s),n},lo=(t,s,r,o,l={})=>({decisions:io(t,s==="allow",r,o,l),block:s==="block",mayStore:s==="allow"}),co=t=>St(t)||t.type==="protocol"&&t.counterparty==="anyone"?!1:t.type==="basket"?!!t.basket&&!as(t.basket):!1,po=t=>t.items.some(s=>co(s)),uo=[.25,1,5],fo=1,fe=t=>t<1?`$${t.toFixed(2)}`:Number.isInteger(t)?`$${t}`:`$${t.toFixed(2)}`,Tt=t=>{const s=t.allowNone?[0,...t.presetsUsd]:[...t.presetsUsd];return e.jsx("div",{className:"flex flex-wrap",style:{gap:8},role:"radiogroup","aria-label":"Envelope amount",children:s.map(r=>{const o=t.value===r;return e.jsx("button",{type:"button",role:"radio","aria-checked":o,disabled:t.disabled,onClick:()=>t.onChange(r),style:{minHeight:44,padding:"0 16px",borderRadius:22,border:`1.5px solid ${o?j.gold:j.chip}`,background:o?j.gold:j.chip,color:o?j.bg:j.ink,fontSize:r?16:14,fontWeight:700,cursor:"pointer"},children:r?fe(r):"No envelope"},r)})})},mo=t=>t<1?`${Math.round(t*100)}¢`:`$${t.toFixed(2)}`,xo=3e3,ho=t=>{const{request:s,onResponse:r,armed:o=!0}=t,{handleSelect:l,hideMenu:n}=me(),{addSnackbar:p}=je(),{chromeStorageService:u}=re(),a=u.getCurrentAccountObject().account,f=is(a?.addresses?.identityAddress,a?.name??"",a?.settings?.socialProfile?.displayName??"",!1),y=ls(f.displayName,f.paymail,f.handle).tag,b=cs(a?.pubKeys?.identityPubKey),i=d.useMemo(()=>ro(s),[s]),[N,h]=d.useState({}),[c,w]=d.useState(!1),S=d.useRef(s.items.length);d.useEffect(()=>{if(s.items.length===S.current)return;S.current=s.items.length,w(!0);const m=setTimeout(()=>w(!1),1e3);return()=>clearTimeout(m)},[s.items.length]);const x=d.useRef(!1),g=()=>{x.current||(x.current=!0,Y({action:"BUNDLE_SHEET_FREEZE",bundleID:s.bundleID}).catch(()=>{}))},E=(m,P)=>N[m]??P,[C,L]=d.useState(),[le,Ne]=d.useState(Zs),[Se,We]=d.useState(!0),[J,Ee]=d.useState(0),[v,R]=d.useState(!0),D=d.useMemo(()=>po(s),[s]),[B,ce]=d.useState(!0),[K,At]=d.useState(!1),[qe,Dt]=d.useState(!1),[He,Ce]=d.useState(!1),[$t,Ve]=d.useState("");d.useEffect(()=>{l("bsv"),n()},[l,n]),d.useEffect(()=>{Y({action:"GET_BUNDLE_ALLOWANCE",originator:s.originator}).then(m=>{!m?.success||!m.data||(L(m.data),Ne(m.data.defaultUsd))}).catch(()=>{})},[s.originator]);const M=s.mint&&i.payment&&i.lines.every(m=>!m.risky)?s.mint:void 0,Ge=!1,de=!M&&i.payment&&C?.usdPerBsv?C.envelope:void 0,Ke=!!de?.offer,xe=Me(C?.usdPerBsv),Z=i.payment?se(i.payment.satoshis,xe):void 0,he=async m=>{const P=m==="allow";Ce(!0),Ve("");try{if(P){const G=await ie(u);if(!G.ok){Ve(G.message),Ce(!1);return}}P&&ke(s.originator);const k=lo(i,m,N,qe,Pe),I=await Y({action:"BUNDLE_PERMISSION_RESPONSE",seenHash:Mt(m),bundleID:s.bundleID,decisions:k.decisions,allowanceUsd:k.mayStore&&Ge&&Se?le:0,envelopeUsd:k.mayStore&&Ke?J:0,remember:k.mayStore&&v,trustSite:!M&&k.mayStore&&v&&D&&B,block:k.block});I&&I.success===!1&&I.error&&(p(I.error,"error"),await new Promise(G=>setTimeout(G,xo))),r()}catch(k){p(k instanceof Error?k.message:String(k),"error"),Ce(!1)}},F=gs(i,{existingAllowanceSats:C?.existingSats}),Q=yt(s.originator),Ot=i.lines.length+(i.payment?1:0)>1,ee=i.payment?Ie(i.payment.satoshis,xe):"",Ft=0,Xe=C?.existingSats!==void 0&&C.usdPerBsv?C.existingSats/1e8*C.usdPerBsv:void 0,Ye=s.items.some(m=>m.reconnect),Lt=Ye?"Reconnect":M?`${M.title.split(" ")[0]} · ${ee}`:F==="post"?i.payment?`Allow & pay ${ee}`:"Allow posting":F==="private"?"Allow":F==="signin"?"Sign in":F==="pay"?i.mode==="connectAndPay"?`Connect & pay ${ee}`:`Pay ${ee}`:Ot?"Allow all":"Connect",pe=He||!o||c,U=F==="careful",ge=i.lines.filter(m=>m.risky),Je=i.lines.filter(m=>m.isNew&&!(U&&m.risky)),[Bt,Ut]=d.useState(()=>new Set),Ze=d.useRef(null);d.useEffect(()=>{const m=Ze.current,P=m?.closest("[data-approval-scroll]");if(!U||!m||!P)return;const k=()=>{const G=P.querySelector('[data-testid="approval-choices"]'),qt=Math.max(P.getBoundingClientRect().top,0),Ht=Math.min(G?G.getBoundingClientRect().top:window.innerHeight,window.innerHeight),Te=[];P.querySelectorAll("[data-line-id]").forEach(ne=>{const ue=ne.getBoundingClientRect();ue.height>0&&ue.top>=qt-1&&ue.bottom<=Ht+1&&Te.push(ne.dataset.lineId??"")}),Ut(ne=>Te.every(ue=>ne.has(ue))?ne:new Set([...ne,...Te]))};k();const I=setTimeout(k,700);return P.addEventListener("scroll",k,{passive:!0}),window.addEventListener("resize",k),()=>{clearTimeout(I),P.removeEventListener("scroll",k),window.removeEventListener("resize",k)}},[U,i]);const Pe=no(i,U,U&&!qe?Bt:void 0),Qe=U&&Pe.hidden.size>0,et=U?i.lines.filter(m=>!m.risky&&!m.isNew):[],Mt=m=>Js(m==="allow"?ao(s.items,Pe):s.items),_t=(m,P)=>h(k=>({...k,[m]:!E(m,P)})),ye=(m,P=!1)=>e.jsxs("label",{"data-line-id":m.requestID,className:"flex items-center gap-3 cursor-pointer",style:{minHeight:44,padding:P?"10px 14px":"6px 0",borderRadius:P?14:0,background:P?j.redChip:void 0,fontSize:P?14:13},children:[e.jsx("input",{type:"checkbox",checked:E(m.requestID,m.checked),onChange:()=>_t(m.requestID,m.checked),style:{width:18,height:18,accentColor:m.risky?j.red:j.gold,flexShrink:0}}),e.jsx("span",{style:{color:m.risky?"#FF6B6B":void 0},children:m.text})]},m.requestID),Re=(y||b)&&e.jsxs("span",{children:[e.jsx("span",{style:{color:j.gold},children:y||"this account"}),b&&e.jsxs("span",{className:"font-mono",style:{userSelect:"none",fontSize:12,color:j.muted},children:[" ","· ",b]})]}),zt=e.jsxs("div",{className:"flex flex-col",style:{gap:4},children:[(y||b)&&e.jsxs("p",{className:"m-0","data-testid":"signing-as",style:{fontSize:12},children:["Signing in as ",Re]}),i.lines.length>0&&e.jsx("p",{className:"m-0",style:{fontSize:12,fontWeight:700,color:j.muted},children:"Allow this app"}),i.lines.map(m=>ye(m)),i.payment&&e.jsxs("p",{className:"m-0",style:{padding:"6px 0"},children:["Pay ",e.jsx("span",{style:{color:j.gold,fontWeight:600},children:ee})," now to ",s.originator,i.payment.description&&e.jsxs(e.Fragment,{children:[" “",i.payment.description,"”"]})]}),i.payment?.labels?.length?e.jsxs("p",{className:"m-0",style:{fontSize:13,color:j.muted},"data-testid":"payment-labels",children:["Labels: ",i.payment.labels.join(", ")]}):null,Ge,e.jsxs("label",{className:"flex items-center gap-3 cursor-pointer",style:{minHeight:44},children:[e.jsx("input",{type:"checkbox",checked:v,onChange:()=>R(!v),style:{width:18,height:18,accentColor:j.gold,flexShrink:0}}),e.jsx("span",{children:"Remember this site"})]}),!M&&D&&v&&e.jsxs("label",{className:"flex items-start gap-3 cursor-pointer",style:{padding:"6px 0"},children:[e.jsx("input",{type:"checkbox",checked:B,onChange:()=>ce(!B),style:{width:18,height:18,accentColor:j.gold,flexShrink:0,marginTop:1}}),e.jsxs("span",{children:["Don't ask again on ",s.originator," for sign-in and signing."," ",C?.allowances?"Payments stay within the allowance;":"Payments still ask, or use its envelope;"," ","your personal details always ask."]})]}),e.jsxs("ul",{className:"m-0 mt-1 pl-4 break-all",style:{fontSize:11,color:j.muted},children:[i.payment&&e.jsxs("li",{children:["pay: ",i.payment.detail]}),i.lines.map(m=>e.jsx("li",{children:m.detail},m.requestID)),Ft>0]})]}),tt={label:"Not now",onClick:()=>{he("notNow")},disabled:pe},Wt={label:"Block this site",onClick:()=>{he("block")},disabled:pe},st={label:U?"I trust it, allow":Lt,onClick:()=>{he("allow")},disabled:pe||Qe,busy:He};let z,W,q=null,H;const V=m=>e.jsx("span",{style:{color:j.gold},children:m}),ot=m=>Ie(m,xe);if(M&&F!=="careful")z=e.jsx(Le,{amount:Z?.main??"",sub:Z?.sub}),H="One approval for all of it",W=e.jsx(e.Fragment,{children:V(M.title)}),q=e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"mint-sheet",children:[e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:15,fontWeight:600},"data-testid":"mint-cost",children:[e.jsx(T,{size:18}),"Costs ",ot(M.premiumSats)," + ",ot(M.feeSats)," network fee"]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs($,{children:[e.jsx(T,{}),"Locked with your keys"]}),e.jsxs($,{children:[e.jsx(T,{}),"Only on ",M.site]}),e.jsxs($,{children:[e.jsx(T,{}),"Next payment asks again"]})]})]});else if(F==="careful"){z=i.lines.length>0?null:e.jsx(ds,{}),H="Check this carefully";const m=s.items.some(I=>I.privileged),P=ge.some(I=>s.items.find(G=>G.requestID===I.requestID)?.type==="certificate"),k=I=>e.jsx("span",{style:{color:"#FF6B6B"},children:I});W=m?e.jsxs(e.Fragment,{children:["Wants ",k("full control")," of your keys"]}):P?e.jsxs(e.Fragment,{children:["Wants your ",k("private details")]}):i.payment&&ge.length===0?e.jsxs(e.Fragment,{children:[k(ee)," is over your allowance"]}):e.jsxs(e.Fragment,{children:["Wants ",k("more than usual")]}),q=e.jsxs("div",{ref:Ze,className:"flex flex-col",style:{gap:8},children:[m&&e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:j.redChip,fontSize:14},children:[e.jsx(Ae,{}),"Could move your money"]}),ge.length===0&&i.payment&&e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:j.redChip,fontSize:14},children:[e.jsx(Ae,{}),Xe!==void 0?`Your allowance here is ${mo(Xe)} a month`:"More than this site may spend"]}),ge.map(I=>ye(I,!0)),et.length>0&&e.jsxs("div",{className:"flex flex-col","data-testid":"careful-ordinary-lines",style:{padding:"0 4px"},children:[e.jsx("p",{className:"m-0",style:{fontSize:12,fontWeight:700,color:j.muted},children:"Also asks to"}),et.map(I=>ye(I))]}),e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:j.redChip,fontSize:14},children:[e.jsx(Ae,{}),"Only allow apps you trust"]})]})}else if(F==="pay")z=e.jsx(Le,{amount:Z?.main??"",sub:Z?.sub}),H=i.payment?.description||"Asks you to pay",W=e.jsxs(e.Fragment,{children:["Pay ",V(ee)," now to ",V(Q)]}),q=e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex items-center gap-3",style:{padding:14,borderRadius:16,background:j.chip},children:[e.jsx(ps,{site:s.originator,size:44}),e.jsxs("div",{className:"flex flex-col min-w-0",style:{gap:2,lineHeight:1.25},children:[e.jsxs("span",{className:"truncate",style:{fontSize:15,fontWeight:600},children:["To ",s.originator]}),e.jsx("span",{className:"truncate",style:{fontSize:13,color:j.muted},children:i.payment?.description?`“${i.payment.description}”`:"Straight from your wallet"}),i.payment?.labels?.length?e.jsxs("span",{className:"truncate",style:{fontSize:12,color:j.muted},"data-testid":"payment-labels",children:["Labels: ",i.payment.labels.join(", ")]}):null]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:j.soft},children:[e.jsx(T,{size:18}),J>0?"Then small payments come out of the envelope":"Every payment asks you first"]}),Ke&&de&&e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"envelope-offer",children:[e.jsx("span",{style:{fontSize:15,fontWeight:600},children:de.balanceSats!==void 0?e.jsxs(e.Fragment,{children:["Top up the envelope",e.jsxs("span",{style:{fontSize:13,fontWeight:400,color:j.muted},children:[" ","· ",Ie(de.balanceSats,xe)," left, not enough for this"]})]}):e.jsxs(e.Fragment,{children:[J>0?`Also put ${fe(J)}`:"Also put money"," in ",V(Q),"'s envelope?"]})}),e.jsx(Tt,{presetsUsd:de.presetsUsd,value:J,onChange:Ee,allowNone:!0,disabled:pe}),e.jsxs("span",{style:{fontSize:12,color:j.muted},children:["Stays in your wallet. Small payments from ",Q," come out of it without asking; Coin return any time."]})]})]});else if(F==="post")z=e.jsx(De,{site:s.originator}),H="Wants to post for you",W=e.jsxs(e.Fragment,{children:["Allow ",V(Q)," to post for you"]}),q=e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs($,{children:[e.jsx(T,{}),"Post and like as you"]}),e.jsxs($,{children:[e.jsx(T,{}),"Nothing else moves"]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14},"data-testid":"post-cost",children:[e.jsx(T,{size:18}),Z?e.jsxs("span",{className:"flex flex-col",children:[e.jsxs("span",{children:["This post costs"," ",e.jsx("span",{style:{fontSize:20,fontWeight:800,color:j.gold},children:Z.main})]}),e.jsx("span",{style:{fontSize:12,color:j.muted},children:Z.sub})]}):"Each paid post asks you first"]})]});else if(F==="private")z=e.jsx(nt,{}),H="Your data",W=e.jsxs(e.Fragment,{children:["Use your wallet keys for your ",V(ys(i))]}),q=e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs($,{children:[e.jsx(T,{}),"Uses keys from your wallet"]}),e.jsxs($,{children:[e.jsx(T,{}),"No money moves"]})]});else if(Ye&&F==="signin")z=e.jsx(De,{site:s.originator}),H="You disconnected this site",W=e.jsxs(e.Fragment,{children:["Reconnect to ",V(Q),"?"]}),q=e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs($,{children:[e.jsx(T,{}),"Shares your public key"]}),e.jsxs($,{children:[e.jsx(T,{}),"No money moves"]})]});else if(F==="signin")z=e.jsx(nt,{}),H="Sign-in request",W=e.jsxs(e.Fragment,{children:["Sign in to ",V(Q)]}),q=e.jsxs(e.Fragment,{children:[Re&&e.jsxs("div",{className:"flex items-center gap-2.5",children:[e.jsx("div",{"aria-hidden":"true",style:{width:30,height:30,borderRadius:15,background:"conic-gradient(#F5C542, #B8860B, #FFE08A, #F5C542)",flexShrink:0}}),e.jsxs("span",{style:{fontSize:18,fontWeight:600},children:["as ",Re]})]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs($,{children:[e.jsx(T,{}),"No password"]}),e.jsxs($,{children:[e.jsx(T,{}),"No money moves"]})]})]});else{z=e.jsx(De,{site:s.originator}),H="Wants to connect",W=e.jsxs(e.Fragment,{children:["Use ",V("bWalletX")," on ",Q]});const m=new Set(s.items.map(k=>k.type)),P=[{label:m.has("certificate")?"Your details":"Your name",icon:e.jsx(go,{})}];m.has("protocol")&&P.push({label:"Sign posts",icon:e.jsx(yo,{})}),m.has("basket")&&P.push({label:"Keep items",icon:e.jsx(bo,{})}),q=e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"grid",style:{gridTemplateColumns:`repeat(${P.length}, minmax(0, 1fr))`,gap:8},children:P.map(k=>e.jsxs("div",{className:"flex flex-col items-center",style:{gap:8,padding:"14px 6px",borderRadius:16,background:j.chip},children:[k.icon,e.jsx("span",{style:{fontSize:13,fontWeight:600,textAlign:"center"},children:k.label})]},k.label))}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:j.soft},children:[e.jsx(T,{size:18}),"Payments still ask you first"]})]})}return e.jsx(A.div,{className:"flex flex-col w-full h-full",style:{maxHeight:"100vh"},initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{type:"spring",damping:24,stiffness:260},"data-approval-kind":F,onPointerDownCapture:g,children:e.jsxs(ht,{tone:U?"red":"gold",site:s.originator,siteSub:H,onClose:()=>{he("notNow")},closeLabel:"Deny and close",closeDisabled:pe,hero:z,title:W,primary:U?tt:st,secondary:U?st:tt,tertiary:U?Wt:void 0,details:zt,detailsOpen:K,onToggleDetails:()=>{Dt(!0),At(!K)},error:$t||(Qe?"Scroll to read every line before allowing":""),children:[q,Je.length>0&&e.jsx("div",{className:"flex flex-col","data-testid":"new-lines",style:{gap:4,marginTop:8},children:Je.map(m=>ye(m,!0))})]})})},ze={"aria-hidden":!0,width:28,height:28,viewBox:"0 0 24 24",fill:"none",stroke:j.gold,strokeWidth:1.8,strokeLinecap:"round",strokeLinejoin:"round"},go=()=>e.jsxs("svg",{...ze,children:[e.jsx("circle",{cx:"12",cy:"8",r:"4"}),e.jsx("path",{d:"M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"})]}),yo=()=>e.jsxs("svg",{...ze,children:[e.jsx("path",{d:"M12 20h9"}),e.jsx("path",{d:"M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"})]}),bo=()=>e.jsxs("svg",{...ze,children:[e.jsx("rect",{x:"3",y:"7",width:"18",height:"13",rx:"2"}),e.jsx("path",{d:"M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"})]}),vo=({request:t,onResponse:s})=>{const{theme:r}=oe(),o=t.usdPerBsv,l=t.capSatsPerHour,n=o?l/1e8*o:void 0,[p,u]=d.useState(n!==void 0?n.toFixed(2):""),[a,f]=d.useState(String(l)),[y,b]=d.useState(!1),i=d.useMemo(()=>{const x=o?ft(Number(p),o):Math.floor(Number(a));return Number.isFinite(x)&&x>=1?Math.min(x,l):0},[p,a,o,l]),N=x=>{y||(b(!0),_({action:"STREAM_GRANT_RESPONSE",requestID:t.requestID,capSatsPerHour:x?i:null}),s())},h=r.color.global.gray,c=r.color.global.contrast,w=new Date(t.expiresAt).toLocaleString(),S=se(l,Be(o,!0));return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(us,{size:36,style:{color:c}}),e.jsxs("h2",{className:"m-0 text-lg font-semibold",style:{color:c},children:["Allow ",t.originator," to stream while you watch, up to"]}),e.jsxs("div",{className:"flex flex-col items-center","data-testid":"dollar-amount",children:[e.jsxs("span",{style:{fontSize:o?40:24,fontWeight:800,lineHeight:1.1,color:c},children:[S.main,e.jsx("span",{style:{fontSize:16,fontWeight:600},children:" an hour"})]}),e.jsx("span",{className:"text-xs",style:{color:h},children:S.sub})]}),t.description&&e.jsx("p",{className:"m-0 text-xs",style:{color:h,maxWidth:"18rem"},children:t.description}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:h,maxWidth:"18rem"},children:["Only “",t.protocolName,"” payments from ",t.originator," go through without asking, until ",w,". Anything else still asks you. Revoke any time in Settings › Streaming permissions."]}),e.jsxs("label",{className:"flex items-center gap-2 text-sm",style:{color:c},children:["Cap per hour ",o?"$":"",o?e.jsx("input",{"aria-label":"Cap in dollars per hour",inputMode:"decimal",value:p,onChange:x=>u(x.target.value),className:"w-24 px-2 py-1 rounded bg-transparent border",style:{color:c}}):e.jsx("input",{"aria-label":"Cap in sats per hour",inputMode:"numeric",value:a,onChange:x=>f(x.target.value),className:"w-28 px-2 py-1 rounded bg-transparent border",style:{color:c}}),!o&&"sats"]}),e.jsxs("p",{className:"m-0 text-xs",style:{color:h},children:[i?o?`${se(i,Be(o,!0)).main} an hour · ${i.toLocaleString()} sats`:`${i.toLocaleString()} sats an hour ${fs}`:"Enter a cap above zero",i===l?" (the most this site asked for)":""]}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(ve,{theme:r,type:"primary",label:"Allow",disabled:y||!i,onClick:()=>N(!0)}),e.jsx(ve,{theme:r,type:"secondary-outline",label:"Not now",disabled:y,onClick:()=>N(!1)})]})]})},wo=({request:t,onResponse:s})=>{const r=t.usdPerBsv,[o,l]=d.useState(fo),[n,p]=d.useState(!1),u=r?ft(o,r):0,a=t.envelope?.balanceSats??0,f=Be(r,!0),y=se(u,f),b=yt(t.originator),i=N=>{n||(p(!0),_({action:"STREAM_GRANT_RESPONSE",requestID:t.requestID,capSatsPerHour:N?u:null}),s())};return e.jsx(ht,{site:t.originator,siteSub:t.description||"Many small payments",onClose:()=>i(!1),closeLabel:"Not now",closeDisabled:n,hero:e.jsx(Le,{amount:r?fe(o):y.main,sub:y.sub,badge:"ENVELOPE"}),title:e.jsxs(e.Fragment,{children:["Put ",r?fe(o):"money"," in ",e.jsx("span",{style:{color:j.gold},children:b}),"'s envelope"]}),primary:{label:r?`Put ${fe(o)} in`:"Price unavailable",onClick:()=>i(!0),disabled:n||!u},secondary:{label:"Not now",onClick:()=>i(!1),disabled:n},testId:"envelope-sheet",children:e.jsxs("div",{className:"flex flex-col",style:{gap:10},children:[e.jsx(Tt,{presetsUsd:uo,value:o,onChange:l,disabled:n}),a>0&&e.jsxs("span",{style:{fontSize:13,color:j.muted},"data-testid":"envelope-balance",children:["Already in it: ",se(a,f).main]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs($,{children:[e.jsx(T,{}),"Stays in your wallet"]}),e.jsxs($,{children:[e.jsx(T,{}),"Only ",b," can spend it"]}),e.jsxs($,{children:[e.jsx(T,{}),"Coin return any time"]})]}),e.jsxs("span",{style:{fontSize:13,color:j.soft},children:["Small payments from ",t.originator," come out of the envelope without asking. When it is empty, it asks you again. Settings › Envelopes shows what is left."]})]})})},te={bg:"#0B0B0D",text:"#FFFFFF",muted:"#98A2B3",gold:"#F5C542",line:"#2B2F36"};function jo(t){const[s,r]=d.useState(null);return d.useEffect(()=>{if(!t)return;let o=!0;const l=()=>{if(!ms(t)){r(null);return}xs(t,{asking:!0,path:hs(t)}).then(n=>o&&r(n))};return l(),window.addEventListener(at,l),window.addEventListener("storage",l),()=>{o=!1,window.removeEventListener(at,l),window.removeEventListener("storage",l)}},[t]),s}const ko=({originator:t,themed:s})=>e.jsxs("div",{"data-testid":"bwx-origin-strip",className:"flex items-center gap-2 px-3",style:{background:te.bg,color:te.text,borderBottom:`1px solid ${te.line}`,minHeight:32,fontFamily:"Inter, system-ui, sans-serif",fontSize:12,flexShrink:0},children:[e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24","aria-hidden":!0,fill:"none",stroke:te.gold,strokeWidth:"2.5",children:[e.jsx("rect",{x:"4",y:"11",width:"16",height:"10",rx:"2"}),e.jsx("path",{d:"M8 11V7a4 4 0 0 1 8 0v4"})]}),e.jsx("span",{style:{color:te.muted},children:"bWalletX · request from"}),e.jsx("span",{className:"font-bold truncate",style:{color:te.text},children:gt(t)}),s&&e.jsx("span",{className:"ml-auto whitespace-nowrap",style:{color:te.muted,fontSize:10},children:"site theme"})]}),No=({theme:t,originator:s})=>e.jsxs("div",{"data-testid":"bwx-site-banner",className:"flex items-center gap-3 px-4",style:{background:t.artData?`linear-gradient(90deg, ${t.bg} 35%, ${t.bg}99), url("${t.artData}") center / cover`:`linear-gradient(135deg, ${t.bg}, ${t.surface})`,color:t.text,borderBottom:`3px solid ${t.accent}`,minHeight:60,flexShrink:0},children:[t.logoData?e.jsx("img",{src:t.logoData,alt:"",width:36,height:36,style:{borderRadius:8,objectFit:"contain"}}):e.jsx("span",{"aria-hidden":!0,className:"flex items-center justify-center font-bold",style:{width:36,height:36,borderRadius:8,background:t.accent,color:t.onAccent},children:t.name.slice(0,1).toUpperCase()}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"font-bold truncate",style:{fontSize:15,color:t.text},children:t.name}),e.jsxs("div",{className:"truncate",style:{fontSize:11,color:t.accentHi},children:["Connected with bWalletX · ",gt(s)]})]})]}),So=({originator:t,children:s,theme:r})=>{const o=jo(r===void 0?t:void 0),l=r===void 0?o:r;return t?e.jsxs("div",{className:"flex flex-col w-full h-full",style:l?{boxShadow:`inset 3px 0 0 ${l.accent}, inset -3px 0 0 ${l.accent}`}:void 0,children:[e.jsx(ko,{originator:t,themed:!!l}),l&&e.jsx(No,{theme:l,originator:t}),e.jsx("div",{className:"flex-1 min-h-0 flex items-center justify-center relative",children:s})]}):e.jsx(e.Fragment,{children:s})};ut.Buffer=pt;ut.process=Gt;window.Buffer=pt;const Eo=t=>"payload"in t&&t.payload.originator||void 0,Co=1e4,Po=2e3,X=new URLSearchParams(window.location.search).get("inpage"),dt=window.location.protocol==="chrome-extension:"&&window.top!==window&&!X&&!!window.location.ancestorOrigins?.length&&window.location.ancestorOrigins[0]!==window.location.origin,Ro=(t,s)=>{const[r,o]=d.useState(t?void 0:!0),[l,n]=d.useState(!t),[p,u]=d.useState(!1);return d.useEffect(()=>{t&&Y({action:"INPAGE_SHEET_CHECK",token:X}).then(a=>o(!!a?.success)).catch(()=>o(!1))},[t]),d.useEffect(()=>{if(!t||r!==!0||!s.current)return;let a;const f=new IntersectionObserver(y=>{const b=y[y.length-1];window.clearTimeout(a),b.isVisible&&b.intersectionRatio>=.99?a=window.setTimeout(()=>n(!0),500):n(!1)},{threshold:[0,.99,1],trackVisibility:!0,delay:100});return f.observe(s.current),()=>{window.clearTimeout(a),f.disconnect()}},[t,s,r]),d.useEffect(()=>{if(!t||l){u(!1);return}const a=window.setTimeout(()=>u(!0),1500);return()=>window.clearTimeout(a)},[t,l]),{tokenOk:r,armed:r===!0&&l,stuck:r===!0&&!l&&p}},To=()=>{const{theme:t}=oe(),{isLocked:s,isReady:r}=re(),o=d.useRef(null),l=d.useRef(null),n=Ro(!!X,l),p=!dt&&n.tokenOk===!0,u=d.useRef(p);u.current=p;const[a,f]=d.useState({kind:"loading"}),y=d.useRef(void 0),b=d.useRef(void 0),i=()=>{y.current!==void 0&&(window.clearTimeout(y.current),y.current=void 0)},N=d.useRef(a);N.current=a;const h=d.useCallback(async(x,g)=>{i();const E=N.current;if(x==="bundle"&&E.kind==="bundle"&&E.requestID===g){try{const L=await Y({action:"GET_PROMPT_PAYLOAD",kind:x,requestID:g});L?.success&&L.data&&f({kind:"bundle",requestID:g,payload:L.data})}catch{}return}f({kind:"loading"});let C;try{C=await Y({action:"GET_PROMPT_PAYLOAD",kind:x,requestID:g})}catch{C=void 0}C?.success&&C.data?f({kind:x,requestID:g,payload:C.data}):(f({kind:"expired"}),window.setTimeout(()=>{b.current?.()},Po))},[]),c=d.useCallback(async()=>{i();let x;try{x=await Y({action:"CLOSE_PROMPT_WINDOW"})}catch{x=void 0}if(x===void 0){window.close();return}const g=x.data?.prompt;g&&(g.kind==="unlock"?f({kind:"unlock"}):g.requestID&&await h(g.kind,g.requestID))},[h]),w=d.useCallback(async()=>{i();let x;try{x=await Y({action:"GET_NEXT_PROMPT"})}catch{x=void 0}if(x?.data?.prompt){await h(x.data.prompt.kind,x.data.prompt.requestID);return}if(x?.data?.busy){f({kind:"waiting"}),y.current=window.setTimeout(()=>{c()},Co);return}await c()},[h,c]);b.current=w,d.useEffect(()=>{if(!r||!p)return;const x=new URLSearchParams(window.location.search),g=x.get("kind"),E=x.get("requestID");if(g==="unlock"){s?f({kind:"unlock"}):w();return}if(g&&E){h(g,E);return}w()},[r,p]),d.useEffect(()=>{const x=g=>{if(!(g?.action!=="SHOW_PROMPT"||!g.kind||!u.current)){if(g.kind==="unlock"){i(),f({kind:"unlock"});return}g.requestID&&h(g.kind,g.requestID)}};return chrome.runtime.onMessage.addListener(x),()=>chrome.runtime.onMessage.removeListener(x)},[h]);const S=t.color.global.walletBackground;return!dt&&X&&n.tokenOk===void 0?null:p?e.jsxs(es,{children:[X&&e.jsxs("div",{className:"flex items-center justify-between px-3 py-2",style:{background:S,borderBottom:"1px solid #ffffff14"},children:[e.jsx("span",{className:"text-sm font-bold",style:{color:t.color.global.contrast},children:"bWalletX"}),n.stuck&&e.jsx("button",{type:"button",className:"text-xs font-bold border-0 rounded-full px-3 py-1",style:{background:"#F5C542",color:"#0b0a08"},onClick:()=>chrome.runtime.sendMessage({action:"MOVE_PROMPT_TO_WINDOW"}).catch(()=>{}),children:"Open in bWalletX"}),e.jsx("button",{type:"button","aria-label":"Deny and close",className:"text-sm border-0 bg-transparent p-1",style:{color:t.color.global.gray},onClick:()=>chrome.runtime.sendMessage({action:"DISMISS_PROMPT_PANEL"}).catch(()=>{}),children:"✕"})]}),e.jsxs("div",{ref:o,className:"flex items-center justify-center relative p-0",style:{width:X?"100%":"var(--wallet-width)",height:X?"calc(100vh - 41px)":"var(--wallet-height)",backgroundColor:S,pointerEvents:n.armed?void 0:"none"},children:[X&&e.jsx("div",{ref:l,"aria-hidden":!0,style:{position:"absolute",top:0,left:0,width:24,height:24,pointerEvents:"none"}}),(!r||a.kind==="loading")&&e.jsx(rt,{message:"Loading...",theme:t}),a.kind==="waiting"&&e.jsx(rt,{message:"Waiting for request...",theme:t}),a.kind==="expired"&&e.jsx("p",{className:"text-xs",style:{color:t.color.global.gray},children:"This request expired or was already handled."}),a.kind==="unlock"&&e.jsx(ts,{onUnlock:()=>{w()}}),e.jsxs(So,{originator:Eo(a),children:[a.kind==="permission"&&e.jsx(Xs,{request:a.payload,onResponse:()=>{w()}},a.requestID),a.kind==="bundle"&&e.jsx(ho,{request:a.payload,onResponse:()=>{w()}},a.requestID),a.kind==="groupedPermission"&&e.jsx(Cs,{request:a.payload,onResponse:()=>{w()}},a.requestID),a.kind==="counterpartyPermission"&&e.jsx(bs,{request:a.payload,onResponse:()=>{w()}},a.requestID),a.kind==="oneSatPermission"&&e.jsx(Vs,{request:a.payload,onResponse:()=>{w()}},a.requestID),a.kind==="streamGrant"&&(a.payload.envelope?e.jsx(wo,{request:a.payload,onResponse:()=>{w()}},a.requestID):e.jsx(vo,{request:a.payload,onResponse:()=>{w()}},a.requestID)),a.kind==="usbCheck"&&e.jsx(Ys,{request:a.payload,onResponse:()=>{w()}},a.requestID)]})]})]}):e.jsx("p",{className:"text-xs p-4",style:{color:"#98A2B3"},children:"Open bWalletX to answer this request."})},It=document.getElementById("root");if(!It)throw new Error("Root element");Vt.createRoot(It).render(e.jsx(Yt,{children:e.jsx(Jt,{children:e.jsx(Zt,{children:e.jsx(Qt,{children:e.jsx(To,{})})})})}));
//# sourceMappingURL=prompt-tab-nbdgXYHJ.js.map
