import{i}from"./sessions-SxSszLcz.js";import{c1 as e,aI as c,ci as l}from"./index-C8N9O7V7.js";const n=["b0asex"],r=(a,s=n)=>{const[t,o]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!s.includes(t)?!1:!o||o===c.toLowerCase()||(l??[]).includes(o)},m=(a,s=!1)=>s||i(a)||r(e(a??void 0));export{m as c};
//# sourceMappingURL=bulkAccess-DHQOGXQB.js.map
