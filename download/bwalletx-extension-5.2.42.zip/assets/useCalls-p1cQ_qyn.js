import{r as s}from"./index-C7bJf09m.js";import{jY as r,bs as o}from"./index-C8N9O7V7.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-p1cQ_qyn.js.map
