const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Du18B4PO.js","./index-C8N9O7V7.js","./crypto-DcyUTPiL.js","./index-C7bJf09m.js","./index-B4qM1JYa.css","./extensionMedia-Rm_l9uoo.js","./index-BtfmPB89.css"])))=>i.map(i=>d[i]);
import{ay as e,ae as t}from"./index-C8N9O7V7.js";import"./crypto-DcyUTPiL.js";import"./index-C7bJf09m.js";import"./extensionMedia-Rm_l9uoo.js";const p=e("Share",{web:()=>t(()=>import("./web-Du18B4PO.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{p as Share};
//# sourceMappingURL=index-DpYI6ZW7.js.map
