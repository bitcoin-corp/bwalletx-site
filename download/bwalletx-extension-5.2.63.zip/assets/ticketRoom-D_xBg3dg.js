import{e}from"./index-GQgbfFIC.js";import{j as a}from"./main-CTVlG_ld.js";const r=(o,t)=>{a(`bsv21:${o}`),t(e("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-D_xBg3dg.js.map
