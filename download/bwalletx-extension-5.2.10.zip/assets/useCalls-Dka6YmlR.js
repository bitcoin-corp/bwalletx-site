import{r as s}from"./index-D-CKA__T.js";import{hy as r,hz as o}from"./main-C54Cpj4_.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-Dka6YmlR.js.map
