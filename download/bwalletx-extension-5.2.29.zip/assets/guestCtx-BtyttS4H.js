import{r as t}from"./index-UUJpKimX.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-BtyttS4H.js.map
