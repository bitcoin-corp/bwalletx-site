import{r as s}from"./index-UUJpKimX.js";import{hT as r,aK as a}from"./index-p9VC3tJI.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-BvzBmqgX.js.map
