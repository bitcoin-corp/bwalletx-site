import{c}from"./crypto-BtJNqGP6.js";const e=[["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}],["circle",{cx:"19",cy:"12",r:"1",key:"1wjl8i"}],["circle",{cx:"5",cy:"12",r:"1",key:"1pcz8c"}]],r=c("ellipsis",e);export{r as E};
//# sourceMappingURL=ellipsis-DvxoD0XC.js.map
