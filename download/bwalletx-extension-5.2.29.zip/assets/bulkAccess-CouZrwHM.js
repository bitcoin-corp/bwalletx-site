import{gs as r}from"./main-CpJOp5nc.js";import{g as e}from"./ApprovalHeroes-DsnasvLp.js";import{b0 as i}from"./index-p9VC3tJI.js";const l=["b0asex"],n=(o,a=l)=>{const[s,t]=o.trim().toLowerCase().replace(/^\$/,"").split("@");return!s||!a.includes(s)?!1:!t||t===i.toLowerCase()},A=(o,a=!1)=>a||r(o)||n(e(o??void 0));export{A as c};
//# sourceMappingURL=bulkAccess-CouZrwHM.js.map
