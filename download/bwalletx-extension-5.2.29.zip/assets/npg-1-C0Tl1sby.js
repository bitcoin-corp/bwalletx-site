const n=""+new URL("npg-1-D8l5kY63.webp",import.meta.url).href;export{n};
//# sourceMappingURL=npg-1-C0Tl1sby.js.map
