import{r as s}from"./index-D-CKA__T.js";import{hN as r,hO as o}from"./main-CjFS7-sd.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-ChgvI5TP.js.map
