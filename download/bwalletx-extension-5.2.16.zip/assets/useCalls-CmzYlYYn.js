import{r as s}from"./index-CD6kEMFr.js";import{hV as r,hW as o}from"./main-ChA8H-SZ.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-CmzYlYYn.js.map
