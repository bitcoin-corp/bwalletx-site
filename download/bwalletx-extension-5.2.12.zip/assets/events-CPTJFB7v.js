const o="bwallet:phone-add-to-dock",t="bwallet:phone-toast",a="bwallet:phone-go",s="bwallet:phone-apps-top";export{a as P,o as a,t as b,s as c};
//# sourceMappingURL=events-CPTJFB7v.js.map
