import{r as t}from"./index-BCfd9xtL.js";import{fetchPeopleTokens as l}from"./people-CDqRb1Td.js";const f=()=>{const[s,o]=t.useState(null);return t.useEffect(()=>{let e=!0;return l().then(r=>e&&o(r)),()=>{e=!1}},[]),s};export{f as u};
//# sourceMappingURL=usePeopleTokens-ohH6X87F.js.map
