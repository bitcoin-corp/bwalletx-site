const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BfLP8k6o.js","./index-CkqD3En7.js","./crypto-DZfDIKRG.js","./index-BCfd9xtL.js","./index-Bwr_iOPv.css","./extensionMedia-Rm_l9uoo.js","./index-Dd_k8F-T.css"])))=>i.map(i=>d[i]);
import{ah as e,_ as t}from"./index-CkqD3En7.js";import"./crypto-DZfDIKRG.js";import"./index-BCfd9xtL.js";import"./extensionMedia-Rm_l9uoo.js";const _=e("Share",{web:()=>t(()=>import("./web-BfLP8k6o.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-LYxvgV5p.js.map
