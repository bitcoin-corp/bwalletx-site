import{gL as e}from"./main-D5pDzeWS.js";import{bG as i,b9 as l,bW as n}from"./index-CkqD3En7.js";const r=["b0asex"],c=(a,s=r)=>{const[t,o]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!s.includes(t)?!1:!o||o===l.toLowerCase()||(n??[]).includes(o)},m=(a,s=!1)=>s||e(a)||c(i(a??void 0));export{m as c};
//# sourceMappingURL=bulkAccess-Cfy7tKVO.js.map
