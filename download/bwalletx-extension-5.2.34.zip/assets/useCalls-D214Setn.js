import{r as s}from"./index-BCfd9xtL.js";import{iQ as r,aT as a}from"./index-CkqD3En7.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-D214Setn.js.map
