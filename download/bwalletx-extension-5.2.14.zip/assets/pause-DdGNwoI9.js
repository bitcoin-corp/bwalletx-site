import{c as e}from"./index-DfeJGFhR.js";const t=[["rect",{x:"14",y:"3",width:"5",height:"18",rx:"1",key:"kaeet6"}],["rect",{x:"5",y:"3",width:"5",height:"18",rx:"1",key:"1wsw3u"}]],o=e("pause",t);export{o as P};
//# sourceMappingURL=pause-DdGNwoI9.js.map
