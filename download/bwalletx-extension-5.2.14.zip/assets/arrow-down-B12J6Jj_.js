import{c as o}from"./index-DfeJGFhR.js";const e=[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]],c=o("arrow-down",e);export{c as A};
//# sourceMappingURL=arrow-down-B12J6Jj_.js.map
