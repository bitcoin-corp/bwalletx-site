import{r as s}from"./index-B-FU0in-.js";import{l as r,n as o}from"./main-BtT_f0vK.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-B01cUaGL.js.map
