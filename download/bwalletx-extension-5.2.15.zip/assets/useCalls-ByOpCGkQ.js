import{r as s}from"./index-D-CKA__T.js";import{hR as r,hS as o}from"./main-C3RCyocr.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-ByOpCGkQ.js.map
