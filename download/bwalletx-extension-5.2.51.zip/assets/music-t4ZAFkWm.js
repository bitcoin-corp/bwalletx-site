import{t as c}from"./crypto-DSKy9X69.js";const e=[["path",{d:"M9 18V5l12-2v13",key:"1jmyc2"}],["circle",{cx:"6",cy:"18",r:"3",key:"fqmcym"}],["circle",{cx:"18",cy:"16",r:"3",key:"1hluhg"}]],r=c("music",e);export{r as M};
//# sourceMappingURL=music-t4ZAFkWm.js.map
