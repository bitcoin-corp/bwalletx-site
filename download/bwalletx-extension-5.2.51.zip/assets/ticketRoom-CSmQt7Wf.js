import{e}from"./index-B66Pjyeu.js";import{j as a}from"./main-DXH6nv5p.js";const r=(o,t)=>{a(`bsv21:${o}`),t(e("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-CSmQt7Wf.js.map
