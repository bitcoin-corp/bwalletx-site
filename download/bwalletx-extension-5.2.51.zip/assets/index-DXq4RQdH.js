const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BhxgnaM0.js","./index-B66Pjyeu.js","./crypto-DSKy9X69.js","./wocLimiter-CB1baL7K.js","./wocLimiter-BZfJYSu4.css","./index-w-0CMC4r.css"])))=>i.map(i=>d[i]);
import{n as e,_ as t}from"./index-B66Pjyeu.js";import"./crypto-DSKy9X69.js";import"./wocLimiter-CB1baL7K.js";const a=e("Share",{web:()=>t(()=>import("./web-BhxgnaM0.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{a as Share};
//# sourceMappingURL=index-DXq4RQdH.js.map
