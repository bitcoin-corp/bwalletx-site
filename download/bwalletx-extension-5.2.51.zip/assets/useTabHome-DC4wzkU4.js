import{r as n}from"./wocLimiter-CB1baL7K.js";import{X as s}from"./index-B66Pjyeu.js";const u=(e,r)=>{const t=n.useRef(r);t.current=r,n.useEffect(()=>{const o=c=>c.detail===e&&t.current();return window.addEventListener(s,o),()=>window.removeEventListener(s,o)},[e])};export{u};
//# sourceMappingURL=useTabHome-DC4wzkU4.js.map
