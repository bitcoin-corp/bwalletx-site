import{r as s}from"./wocLimiter-CB1baL7K.js";import{U as r,V as o}from"./index-B66Pjyeu.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-BSyCDRx1.js.map
