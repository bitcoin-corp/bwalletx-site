const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BCpqx1WX.js","./index-BVtmvveg.js","./crypto-BaEBpRme.js","./index-numRYSTi.js","./index-DU2cSw24.css","./extensionMedia-Rm_l9uoo.js","./index-BTWoDmtB.css"])))=>i.map(i=>d[i]);
import{ai as e,_ as t}from"./index-BVtmvveg.js";import"./crypto-BaEBpRme.js";import"./index-numRYSTi.js";import"./extensionMedia-Rm_l9uoo.js";const _=e("Share",{web:()=>t(()=>import("./web-BCpqx1WX.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-DHiK964Z.js.map
