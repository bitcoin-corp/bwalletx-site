import{r as s}from"./index-numRYSTi.js";import{iX as r,aU as a}from"./index-BVtmvveg.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-DfRmrRPx.js.map
