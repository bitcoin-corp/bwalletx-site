import{r as d,j as e,b as et}from"./index-numRYSTi.js";import{m as ke,bq as Ue,br as Fe,bs as tt}from"./crypto-BaEBpRme.js";import{j as H,k as z,r as A,bp as I,go as V,gp as U,bq as st,U as ot,br as Ae,B as _,gm as rt,gn as nt,ge as at,gf as it,gg as lt,P as Re,gk as ct}from"./index-BVtmvveg.js";import{a as te,u as ie,U as pt,l as Me,c as dt,i as ut,k as ft,C as P,m as me,P as xt,n as ht,d as re,o as mt,A as gt,p as yt,S as bt,e as Ie}from"./ApprovalHeroes-BN59kI7A.js";import{a as vt,s as wt}from"./approvalKind-BQjbcmk8.js";import"./extensionMedia-Rm_l9uoo.js";const kt=t=>{const{request:s,onResponse:i}=t,{theme:o}=H(),{handleSelect:n,hideMenu:l}=te(),{addSnackbar:f}=ie(),[a,p]=d.useState(!1),[u,b]=d.useState(""),{chromeStorageService:g}=z(),{permissions:r}=s,[S,j]=d.useState(()=>r.protocols.map(()=>!0));d.useEffect(()=>{n("bsv"),l()},[n,l]);const c=()=>{const w=r.protocols.filter((T,D)=>S[D]);return w.length===0?{}:{protocols:w}},h=async()=>{p(!0),b("");try{const w=await V(g);if(!w.ok){b(w.message),p(!1);return}U({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:c()}),i()}catch(w){f(w instanceof Error?w.message:String(w),"error"),p(!1)}},x=async()=>{p(!0),U({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),i()},v=w=>j(T=>T.map((D,q)=>q===w?!D:D)),k=s.counterpartyLabel??`${s.counterparty.slice(0,8)}...${s.counterparty.slice(-8)}`;return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(pt,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Counterparty Permission"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","wants to interact with a counterparty"]})]})]}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all font-mono",style:{color:o.color.global.contrast},children:k})]}),e.jsx(I,{when:!!r.description,children:e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Purpose"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:r.description})]})}),e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),r.protocols.map((w,T)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:T<r.protocols.length-1?"1px solid rgba(255,255,255,0.04)":"none"},children:[e.jsx("input",{type:"checkbox",checked:S[T],onChange:()=>v(T),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[w.protocolID?.[1]," (level ",w.protocolID?.[0],")"]}),w.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:w.description})]})]},`proto-${T}`))]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[u&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:u}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:a?.6:1},disabled:a,onClick:h,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[a&&e.jsx(ke,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:a?.5:1},disabled:a,onClick:x,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},jt={"2:3241645161d8":{label:"BRC-29 payment",description:"An application is requesting permission to derive payment addresses for a specific recipient."}},Oe=t=>t?jt[`${t[0]}:${t[1]}`]:void 0,Le=t=>Oe(t)?.label??t?.[1],Nt=t=>{switch(t){case 0:return"Level 0 · any app";case 1:return"Level 1 · same keys for any app using this protocol";case 2:return"Level 2 · same keys for any app using this protocol with this recipient";default:return`Level ${t??0}`}},_e=t=>`${t[0]}:${t[1].trim().toLowerCase()}`,St=new Set([2532803679,1545534606,3968644154,2559579298,983045898,2744301556,111268922,3445661247,2334321181,4156441831,3583153857,2398265928,1065214202,2451633495,1587406450,3495424783,2196479044,3172368687,3977290595,2110695608,2486468533,3947228137,3114316294,3407865888,2095595255,927149303,1269930738].map(t=>t>>>0)),Ct=[[2,"3241645161d8"]],Pt=t=>{let s=2166136261;for(const i of new TextEncoder().encode(_e(t)))s=Math.imul(s^i,16777619)>>>0;return s>>>0};new Set(Ct.map(_e));const Et=t=>Array.isArray(t)&&t.length===2&&typeof t[0]=="number"&&typeof t[1]=="string"?[t[0],t[1]]:null,Te=t=>{const s=Et(t);return!!s&&St.has(Pt(s))},At=t=>{const{request:s,onResponse:i}=t,{theme:o}=H(),{handleSelect:n,hideMenu:l}=te(),{addSnackbar:f}=ie(),[a,p]=d.useState(!1),[u,b]=d.useState(""),{chromeStorageService:g}=z(),{permissions:r}=s,[S,j]=d.useState(()=>(r.protocolPermissions??[]).map(()=>!1)),[c,h]=d.useState(()=>(r.basketAccess??[]).map(()=>!0)),[x,v]=d.useState(()=>(r.certificateAccess??[]).map(()=>!0)),[k,w]=d.useState(!0);d.useEffect(()=>{n("bsv"),l()},[n,l]);const T=()=>{const y={},C=(r.protocolPermissions??[]).filter((W,B)=>S[B]&&!Te(W.protocolID));C.length>0&&(y.protocolPermissions=C);const R=(r.basketAccess??[]).filter((W,B)=>c[B]);R.length>0&&(y.basketAccess=R);const $=(r.certificateAccess??[]).filter((W,B)=>x[B]);return $.length>0&&(y.certificateAccess=$),k&&r.spendingAuthorization&&(y.spendingAuthorization=r.spendingAuthorization),y},D=async()=>{p(!0),b("");try{const y=await V(g);if(!y.ok){b(y.message),p(!1);return}U({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:T()}),i()}catch(y){f(y instanceof Error?y.message:String(y),"error"),p(!1)}},q=async()=>{p(!0),U({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),i()},F=y=>j(C=>C.map((R,$)=>$===y?!R:R)),le=y=>h(C=>C.map((R,$)=>$===y?!R:R)),se=y=>v(C=>C.map((R,$)=>$===y?!R:R));return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(Me,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Permission Request"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","is requesting the following permissions"]})]})]}),e.jsx(I,{when:!!r.description,children:e.jsx("p",{className:"text-xs mb-3 leading-relaxed",style:{color:o.color.global.gray},children:r.description})}),e.jsx(I,{when:!!r.spendingAuthorization,children:e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-3",style:{background:"rgba(247,144,9,0.08)",border:"1px solid rgba(247,144,9,0.2)"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.06},children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pb-1",style:{color:"#F79009"},children:"Spending Authorization"}),e.jsxs("label",{className:"flex items-start gap-3 py-1 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:k,onChange:()=>w(!k),className:"mt-0.5 accent-orange-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-semibold",style:{color:"#F79009"},children:["This app wants to spend up to ",((r.spendingAuthorization?.amount??0)/1e8).toFixed(8)," BSV"," ","(",(r.spendingAuthorization?.amount??0).toLocaleString()," satoshis)"]}),r.spendingAuthorization?.description&&e.jsxs("span",{className:"text-xs mt-1 opacity-70",style:{color:o.color.global.contrast},children:["App says: “",r.spendingAuthorization.description,"”"]})]})]})]})}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-2 mb-5",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs(I,{when:!!r.protocolPermissions?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),r.protocolPermissions?.map((y,C)=>Te(y.protocolID)?e.jsxs("p",{className:"text-xs py-2",style:{color:o.color.global.gray},children:["Refused: “",y.protocolID[1],"” is used only by bWalletX itself."]},`proto-${C}`):e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:S[C],onChange:()=>F(C),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:["Let this app sign and encrypt with your keys for “",Le(y.protocolID),"”",y.counterparty?` (shared with ${y.counterparty.slice(0,10)}…)`:""]}),e.jsxs("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:["Any app that asks for this protocol gets the same keys (level ",y.protocolID[0],")."]}),y.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:y.description})]})]},`proto-${C}`))]}),e.jsxs(I,{when:!!r.basketAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Baskets"}),r.basketAccess?.map((y,C)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:c[C],onChange:()=>le(C),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:y.basket}),y.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:y.description})]})]},`basket-${C}`))]}),e.jsxs(I,{when:!!r.certificateAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Certificates"}),r.certificateAccess?.map((y,C)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:x[C],onChange:()=>se(C),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:y.type}),e.jsxs("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:[y.description," — fields: ",y.fields.join(", ")]})]})]},`cert-${C}`))]})]}),e.jsxs("div",{className:"flex flex-col gap-3",children:[u&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:u}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:a?.6:1},disabled:a,onClick:D,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[a&&e.jsx(ke,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:a?.5:1},disabled:a,onClick:q,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},Rt=2e3;async function ae(t,s=Rt){let i;try{return await Promise.race([t.catch(()=>{}),new Promise(o=>{i=setTimeout(()=>o(void 0),s)})])}catch{return}finally{i&&clearTimeout(i)}}function It(t,s){return t?.find(i=>i.startsWith(`${s}:`))?.slice(s.length+1)}async function Tt(t,s,i=[]){const o=t.ordfs;if(typeof o?.bulkMetadata!="function")return{state:"unverified"};const n=`${s}:-2`,l=await ae(o.bulkMetadata([n])),f=l?.[n]??l?.[s]??Object.values(l??{}).find(u=>!!u?.contentType);if(!f?.contentType)return{state:"unverified"};const a={contentType:f.contentType,origin:f.origin,name:typeof f.map?.name=="string"?f.map.name:void 0},p=i.find(u=>u.includes("/"));return p&&p!==f.contentType?{state:"mismatch",note:`Content type is ${f.contentType}, not ${p}`,...a}:{state:"verified",...a}}async function Dt(t,s,i){const o=t.opns;if(typeof o?.getOrigin!="function")return{state:"unverified"};const n=await ae(o.getOrigin(s));return n?.outpoint?n.outpoint!==i?{state:"mismatch",note:`“${s}” currently resolves to a different output`}:{state:"verified"}:{state:"unverified"}}async function $t(t,s,i,o=[]){const n=t.bsv21;if(typeof n?.getTokenDetails!="function")return{state:"unverified"};const l=await ae(n.getTokenDetails(s,{fresh:!0}));if(!l)return{state:"unverified"};if(l.status?.is_active===!1)return{state:"mismatch",note:"Token is not active on the overlay"};const f=l.token?.sym;if(i&&f&&i.toLowerCase()!==f.toLowerCase())return{state:"mismatch",note:`Token symbol is ${f}, not ${i}`};if(o.length>0&&typeof n.getOutputStatus=="function"){const a=await ae(n.getOutputStatus(s,o));if(!a)return{state:"unverified"};const p=a.filter(u=>u.state==="spent"||u.state==="unknown");if(p.length>0)return{state:"mismatch",note:p.length===1?"A spent token output is not valid on the overlay":`${p.length} spent token outputs are not valid on the overlay`};if(a.some(u=>u.state==="queued"))return{state:"unverified"}}return{state:"verified",...f?{name:f}:{}}}async function Bt(t,s,i,o,n){if(!t||!s)return{state:"unverified"};const l=s==="purchase"||s.endsWith(".purchase"),f=s==="token-transfer"||s.startsWith("bsv21.");if(!l&&!f)return{state:"unverified"};const a={kindOrIntent:s,hasOrdfs:!!t.ordfs,hasBulk:typeof t.ordfs?.bulkMetadata=="function",inputTagSets:i.map(p=>p.tags),outputTagSets:o.map(p=>p.tags)};try{const p=[...i.map(c=>c.tags),...o.map(c=>c.tags)],u=c=>p.flatMap(h=>h.filter(x=>x.startsWith(`${c}:`)).map(x=>x.slice(c.length+1))),b=c=>{for(const h of p){const x=It(h,c);if(x)return x}},g=b("bsv21");if(g||s==="bsv21.purchase"||s==="token-transfer"||s.startsWith("bsv21.")){if(!g)return{state:"unverified"};const h=i.filter(v=>v.basket?.includes("bsv21")||v.tags.some(k=>k.startsWith("bsv21:"))).map(v=>v.outpoint).filter(Boolean);let x=b("sym");for(const v of i)if(v.customInstructions)try{const k=JSON.parse(v.customInstructions).sym;if(typeof k=="string"&&k.trim()){x=k.trim();break}}catch{}return await $t(t,g,x,h)}const r=b("name"),S=b("origin");if(a.name=r,a.origin=S,r&&S&&o.some(c=>c.basket?.includes("opns"))||s==="opns.purchase")return!r||!S?{state:"unverified"}:await Dt(t,r,S);if(!S)return a.reason="no-origin-tag",globalThis.__lastVerify=a,{state:"unverified"};const j=await Tt(t,S,u("type"));if(a.verifyOrdinal=j,j.origin&&n)try{j.contentUrl=n(j.origin)}catch(c){a.contentUrlError=String(c)}return globalThis.__lastVerify=a,j}catch(p){return a.error=String(p),globalThis.__lastVerify=a,{state:"unverified"}}}function ze(t){if(!t||typeof t!="object")return!1;const s=t;return Array.isArray(s.panels)&&typeof s.title=="string"}var Ut=`
.opp-root {
  --opp-bg: #ffffff;
  --opp-fg: #111827;
  --opp-muted: #6b7280;
  --opp-card-bg: #f7f8fa;
  --opp-card-border: #eceef2;
  --opp-accent: #E5A920;
  --opp-approve-bg: #E5A920;
  --opp-approve-fg: #ffffff;
  --opp-reject-bg: #ffffff;
  --opp-reject-fg: #111827;
  --opp-reject-border: #d1d5db;
  --opp-status-bg: #FFFBE6;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #ECFDF5;
  --opp-trust-ok-fg: #059669;
  --opp-trust-warn-bg: #FFFBEB;
  --opp-trust-warn-fg: #D97706;
  --opp-trust-bad-bg: #FEF2F2;
  --opp-trust-bad-fg: #DC2626;

  font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--opp-bg);
  color: var(--opp-fg);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 480px;
  min-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
}

.opp-bottom {
  margin-top: auto;
  display: flex;
  flex-direction: column;
}

.opp-root.opp-dark {
  --opp-bg: #0F1117;
  --opp-fg: #F9FAFB;
  --opp-muted: #9ca3af;
  --opp-card-bg: #1A1D27;
  --opp-card-border: #232636;
  --opp-reject-bg: #0F1117;
  --opp-reject-fg: #F9FAFB;
  --opp-reject-border: #2D3142;
  --opp-status-bg: #2A2408;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #0A2E1F;
  --opp-trust-ok-fg: #34D399;
  --opp-trust-warn-bg: #2A2008;
  --opp-trust-warn-fg: #FBBF24;
  --opp-trust-bad-bg: #2A1215;
  --opp-trust-bad-fg: #F87171;
}

.opp-body {
  padding: 24px 20px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
}

.opp-coin {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
}

.opp-title {
  font-size: 16px;
  font-weight: 700;
  margin: 0;
  text-align: center;
}

.opp-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  margin: 0;
  text-align: center;
  line-height: 1.4;
}

.opp-status {
  background: var(--opp-status-bg);
  color: var(--opp-status-fg);
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
  margin-top: 4px;
  border: 1px solid var(--opp-card-border);
}

.opp-card {
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px;
  padding: 16px;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.opp-featured {
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px 8px;
  padding: 16px;
}

/* Subtle danger chrome for burn / destructive token ops */
.opp-featured-danger {
  border-color: rgba(220, 38, 38, 0.45);
  background: color-mix(in srgb, var(--opp-card-bg) 88%, #7f1d1d 12%);
}

.opp-featured-danger .opp-featured-title {
  color: #f87171;
}

.opp-featured-danger .opp-featured-image,
.opp-featured-danger .opp-featured-placeholder {
  border: 1px solid rgba(220, 38, 38, 0.35);
  background: rgba(127, 29, 29, 0.25);
  color: #fca5a5;
}

.opp-dark .opp-featured-danger {
  border-color: rgba(248, 113, 113, 0.4);
  background: color-mix(in srgb, var(--opp-card-bg) 85%, #450a0a 15%);
}

.opp-preview-pair {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.opp-preview-arrow {
  color: var(--opp-muted);
  font-size: 14px;
  line-height: 1;
}

.opp-preview-pair .opp-featured-image {
  width: 64px;
  height: 64px;
}

.opp-featured-image {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-featured-image-token {
  width: 48px;
  height: 48px;
  border-radius: 999px;
}

.opp-featured-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--opp-muted);
  font-size: 18px;
}

.opp-preview-opns {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
}

.opp-preview-opns-avatar {
  width: 36px;
  height: 36px;
  border-radius: 999px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-preview-opns-name {
  font-size: 11px;
  font-weight: 600;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  color: var(--opp-fg, inherit);
}

.opp-preview-text {
  margin: 0;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
  font-size: 9px;
  line-height: 1.25;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  color: var(--opp-muted);
}

.opp-preview-json {
  white-space: pre;
  overflow: auto;
}

.opp-preview-frame {
  border: 0;
  padding: 0;
  overflow: hidden;
  background: #fff;
  pointer-events: none;
}

.opp-preview-value {
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  background: rgba(229, 169, 32, 0.12);
  border: 1px solid rgba(229, 169, 32, 0.35);
  color: var(--opp-fg, inherit);
}

.opp-preview-value-icon {
  width: 32px;
  height: 32px;
  color: #E5A920;
}

/* Amount subtitles must never ellipsis — full sat counts are the point. */
.opp-featured-subtitle-text.opp-amount {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-variant-numeric: tabular-nums;
  white-space: normal;
  overflow: visible;
  text-overflow: unset;
  word-break: keep-all;
}

.opp-featured-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  flex: 1;
}

.opp-featured-title {
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.opp-featured-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.opp-featured-subtitle-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
}

.opp-featured-meta-line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  color: var(--opp-muted);
}

.opp-featured-meta-line-bare {
  align-items: center;
}

.opp-featured-meta-key {
  flex-shrink: 0;
  opacity: 0.75;
  min-width: 2.5em;
}

.opp-featured-meta-value {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  flex: 1;
}

.opp-featured-meta-value-mono {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 11px;
}

.opp-trust-wrap {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0 20px 8px;
}

.opp-trust {
  display: inline-flex;
  align-self: flex-start;
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 600;
}

.opp-trust-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-trust-note {
  padding: 10px;
  border-radius: 8px;
  font-size: 11px;
  line-height: 1.35;
}

.opp-trust-note-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-note-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-note-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.opp-row-key {
  color: var(--opp-muted);
  flex-shrink: 0;
}

.opp-row-value-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 70%;
  justify-content: flex-end;
}

.opp-row-value {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 12px;
  font-weight: 500;
  text-align: right;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.opp-copy {
  flex-shrink: 0;
  width: 22px;
  height: 22px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  border: 1px solid var(--opp-reject-border);
  background: var(--opp-bg);
  color: var(--opp-fg);
  cursor: pointer;
}

.opp-copy:hover {
  border-color: var(--opp-accent);
  color: var(--opp-accent);
}

.opp-fee-note {
  font-size: 11px;
  color: var(--opp-muted);
  line-height: 1.3;
  margin-top: -4px;
}

.opp-actions {
  display: flex;
  gap: 12px;
  padding: 20px 20px 12px;
}

.opp-button {
  flex: 1;
  padding: 0 16px;
  height: 48px;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid transparent;
  transition: opacity 120ms ease;
}

.opp-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.opp-button-reject {
  background: var(--opp-reject-bg);
  color: var(--opp-reject-fg);
  border-color: var(--opp-reject-border);
}

.opp-button-approve {
  background: var(--opp-approve-bg);
  color: var(--opp-approve-fg);
}

.opp-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 20px 16px;
  font-size: 11px;
  font-weight: 500;
  color: var(--opp-muted);
}
`;function Ft({request:t,onApprove:s,onReject:i,theme:o="auto",services:n}){const l=Vt(o),f=Mt(t),[a,p]=d.useState(!1),[u,b]=d.useState(),g=t.kind==="transaction"&&ze(t.payload)?t.payload:void 0;d.useEffect(()=>{if(!n||!g?.trust||!g.verify)return;let c=!0;const h=n.ordfs?.getContentUrl?.bind(n.ordfs);return Bt(n,g.verify.kind,g.verify.inputs,g.verify.outputs,h).then(x=>{c&&x&&b(x)}).catch(()=>{}),()=>{c=!1}},[n,g]);const r=u?Ot(f,u):f,S=c=>()=>{if(!a){p(!0);try{c==="approve"?s():i()}finally{p(!1)}}};d.useEffect(()=>{const c=h=>{a||(h.key==="Escape"?i():h.key==="Enter"&&s())};return window.addEventListener("keydown",c),()=>window.removeEventListener("keydown",c)},[s,i,a]);const j=`opp-root${l==="dark"?" opp-dark":""}`;return e.jsxs("div",{className:j,children:[e.jsx("style",{children:Ut}),e.jsxs("div",{className:"opp-body",children:[e.jsxs("svg",{className:"opp-coin",viewBox:"0 0 100 100","aria-label":"1Sat Ordinals",children:[e.jsx("circle",{cx:"50",cy:"50",r:"50",fill:"#222"}),e.jsx("circle",{cx:"50",cy:"50",r:"40",fill:"#fff"}),e.jsx("circle",{cx:"50",cy:"50",r:"32",fill:"#E5A920"}),e.jsx("rect",{x:"47",y:"28",width:"6",height:"28",rx:"3",fill:"#fff"})]}),e.jsx("h2",{className:"opp-title",children:r.title}),e.jsx("p",{className:"opp-subtitle",children:r.subtitle}),e.jsx("div",{className:"opp-status",children:"Awaiting Approval"})]}),r.panels.map((c,h)=>{const x=c.variant??"ordinal",v=["opp-featured"];return x==="token"&&v.push("opp-featured-token"),x==="value"&&v.push("opp-featured-value"),c.tone==="danger"&&v.push("opp-featured-danger"),e.jsxs("div",{className:v.join(" "),children:[c.prior?e.jsxs("div",{className:"opp-preview-pair","aria-label":"Previous and new inscription",children:[e.jsx(ge,{panel:{...c,previewKind:c.prior.previewKind,imageUrl:c.prior.imageUrl,contentUrl:c.prior.contentUrl,previewText:c.prior.previewText,prior:void 0}}),e.jsx("span",{className:"opp-preview-arrow","aria-hidden":!0,children:"→"}),e.jsx(ge,{panel:c})]}):e.jsx(ge,{panel:c}),e.jsxs("div",{className:"opp-featured-meta",children:[e.jsx("div",{className:"opp-featured-title",children:c.title}),c.subtitle&&e.jsxs("div",{className:"opp-featured-subtitle",children:[e.jsx("span",{className:c.amountSats!=null?"opp-featured-subtitle-text opp-amount":"opp-featured-subtitle-text",children:c.subtitle}),c.subtitleCopy&&e.jsx(ye,{text:c.subtitleCopy})]}),(c.meta??[]).map(k=>e.jsxs("div",{className:`opp-featured-meta-line${k.key?"":" opp-featured-meta-line-bare"}`,children:[k.key?e.jsx("span",{className:"opp-featured-meta-key",children:k.key}):null,e.jsx("span",{className:`opp-featured-meta-value${k.key?"":" opp-featured-meta-value-mono"}`,title:k.copyValue??k.value,children:k.value}),k.copyValue&&e.jsx(ye,{text:k.copyValue})]},`${k.key}:${k.value}`))]})]},`panel-${h}-${c.title}`)}),r.trust&&e.jsxs("div",{className:"opp-trust-wrap",children:[e.jsx("span",{className:`opp-trust opp-trust-${r.trust.state}`,children:zt(r.trust.state)}),r.trust.note&&e.jsx("div",{className:`opp-trust-note opp-trust-note-${r.trust.state}`,children:r.trust.note})]}),(r.rows.length>0||r.indexerFee||r.funding)&&e.jsxs("div",{className:"opp-card",children:[r.rows.map(c=>e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:c.key}),e.jsxs("span",{className:"opp-row-value-wrap",children:[e.jsx("span",{className:"opp-row-value",title:c.copyValue??c.value,children:c.value}),c.copyValue&&e.jsx(ye,{text:c.copyValue})]})]},`${c.key}:${c.value}`)),r.indexerFee&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"1Sat Overlay Fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[De(r.indexerFee.sats)," sats"]})]}),r.funding?.networkFeeSats!=null&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"Network fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[De(r.funding.networkFeeSats)," sats"]})]}),r.funding?.note&&e.jsx("div",{className:"opp-fee-note",children:r.funding.note})]}),e.jsxs("div",{className:"opp-bottom",children:[e.jsxs("div",{className:"opp-actions",children:[e.jsx("button",{type:"button",className:"opp-button opp-button-reject",onClick:S("reject"),disabled:a,children:"Reject"}),e.jsx("button",{type:"button",className:"opp-button opp-button-approve",onClick:S("approve"),disabled:a,children:"Approve"})]}),e.jsx("div",{className:"opp-footer",children:e.jsx("span",{children:"Secured by 1Sat Ordinals"})})]})]})}function Mt(t){if(t.kind==="transaction"&&ze(t.payload))return{title:t.payload.title,subtitle:t.payload.subtitle,panels:t.payload.panels,rows:t.payload.rows,trust:t.payload.trust,indexerFee:t.payload.indexerFee,funding:t.payload.funding};if(t.kind==="basketAccess"){const s=t.payload.baskets??[],i=s.length>0&&s.every(l=>l.scope||l.basket.startsWith("p ")),o=s.filter(l=>l.imageUrl||l.name||l.value).map(l=>({title:l.scope==="collection"?l.name?`Collection · ${l.name}`:"Collection":l.scope?l.scope:"Basket",subtitle:l.value?l.value.length>24?`${l.value.slice(0,10)}…${l.value.slice(-10)}`:l.value:l.basket,subtitleCopy:l.value,...l.imageUrl&&{previewKind:"image",contentUrl:l.imageUrl,imageUrl:l.imageUrl},tone:"default"})),n=s.flatMap(l=>l.scope==="collection"?l.description?[{key:"Access",value:l.description}]:[]:[{key:l.basket,value:l.description??"List, insert, and remove outputs"}]);return{title:i?s.length===1?s[0].scope==="collection"?"Grant Collection View":"Grant Item View":`Grant View (${s.length})`:s.length===1?"Grant Basket Access":`Grant Access to ${s.length} Baskets`,subtitle:i?`${ne(t.originator)} wants to view items in your wallet`:`${ne(t.originator)} wants to read and write 1Sat baskets`,panels:o,rows:n}}return t.kind==="protocol"?{title:"Protocol Access",subtitle:`${ne(t.originator)} wants protocol access`,panels:[],rows:[{key:"Detail",value:t.summary||"Protocol request"}]}:{title:"Signature Request",subtitle:`${ne(t.originator)} wants a signature`,panels:[],rows:[{key:"Detail",value:t.summary||"Signature request"}]}}function Ot(t,s){const i=t.panels.map((o,n)=>{if(n!==0)return o;const l=o.previewKind==="opns",f=s.contentType?Lt(s.contentType):void 0,a=l?"opns":f&&f!=="none"?f:o.previewKind,p=s.contentUrl??o.contentUrl??o.imageUrl;let u=o.subtitle;if(s.name&&!l)if(!u)u=s.name;else{const b=u.trim().split(/\s+/);b.length>=2&&(b[b.length-1]=s.name,u=b.join(" "))}return{...o,previewKind:a,...u?{subtitle:u}:{},...l?{...s.contentUrl&&!o.imageUrl?{imageUrl:s.contentUrl}:o.imageUrl?{imageUrl:o.imageUrl}:{}}:a==="image"?{imageUrl:p,contentUrl:p}:p?{contentUrl:p,imageUrl:void 0}:{}}});return{...t,panels:i,trust:{state:s.state,note:s.note}}}function Lt(t){const s=t.toLowerCase();return s==="image/svg+xml"||s==="svg"||s.endsWith("+svg")?"svg":s.startsWith("image/")?"image":s.includes("json")?"json":s.includes("html")||s==="application/xhtml+xml"?"html":s.startsWith("text/")?"text":"none"}function _t(t){return`${t.toLocaleString("en-US")} sats`}function De(t){return t.toLocaleString("en-US")}function zt(t){return t==="verified"?"Verified":t==="mismatch"?"Mismatch":"Unverified"}function ge({panel:t}){const s=t.variant??"ordinal",i=s==="token"?"opp-featured-image opp-featured-image-token":s==="value"?"opp-featured-image opp-preview-value":"opp-featured-image",o=t.previewKind??(t.imageUrl?"image":"none"),n=t.contentUrl??t.imageUrl,[l,f]=d.useState(!1);if(s==="value"){const a=t.valueIcon??"pay";return e.jsx("div",{className:i,title:t.amountSats!=null?_t(t.amountSats):void 0,"aria-hidden":!0,children:e.jsx(Wt,{kind:a})})}if(o==="opns"){const a=!!t.imageUrl&&!l;return e.jsxs("div",{className:`${i} opp-preview-opns`,"aria-hidden":!t.opnsHero,children:[a?e.jsx("img",{className:"opp-preview-opns-avatar",src:t.imageUrl,alt:"",onError:()=>f(!0)}):e.jsx("div",{className:"opp-preview-opns-avatar opp-featured-placeholder",children:"◈"}),e.jsx("span",{className:"opp-preview-opns-name",title:t.opnsHero,children:t.opnsHero??"OpNS"})]})}return o==="image"&&t.imageUrl&&!l?e.jsx("img",{className:i,src:t.imageUrl,alt:t.title,onError:()=>f(!0)}):o==="image"&&l?e.jsx("div",{className:`${i} opp-featured-placeholder`,"aria-hidden":!0,children:"▭"}):(o==="text"||o==="json"||o==="html")&&t.previewText?e.jsx("pre",{className:`${i} opp-preview-text${o==="json"?" opp-preview-json":""}`,children:t.previewText}):(o==="text"||o==="json")&&n?e.jsx(Ht,{url:n,kind:o,className:i}):(o==="html"||o==="svg")&&n?e.jsx("iframe",{className:`${i} opp-preview-frame`,src:n,title:`${t.title} preview`,sandbox:"",referrerPolicy:"no-referrer"}):e.jsx("div",{className:`${i} opp-featured-placeholder`,"aria-hidden":!0,children:s==="token"?"◎":qt(o)})}function qt(t){return t==="text"||t==="json"?"¶":t==="html"||t==="svg"?"⌂":"▭"}function Wt({kind:t}){return t==="lock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V8a4 4 0 018 0v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):t==="unlock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V7.5A4 4 0 0116 7",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("path",{d:"M16 4.5v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"9",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M12 7v10M9 10.5c0-1.4 1.3-2.5 3-2.5s3 1.1 3 2.5-1.3 2.5-3 2.5-3 1.1-3 2.5 1.3 2.5 3 2.5 3-1.1 3-2.5",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})}function Ht({url:t,kind:s,className:i}){const[o,n]=d.useState(null),[l,f]=d.useState(!1);return d.useEffect(()=>{let a=!1;return n(null),f(!1),fetch(t).then(async p=>{if(!p.ok)throw new Error(String(p.status));const u=await p.text();if(!a){if(s==="json")try{n(JSON.stringify(JSON.parse(u),null,2));return}catch{}n(u.slice(0,800))}}).catch(()=>{a||f(!0)}),()=>{a=!0}},[t,s]),l?e.jsx("div",{className:`${i} opp-featured-placeholder`,"aria-hidden":!0,children:"¶"}):e.jsx("pre",{className:`${i} opp-preview-text${s==="json"?" opp-preview-json":""}`,children:o??"…"})}function ye({text:t}){const[s,i]=d.useState(!1),o=()=>{navigator.clipboard?.writeText(t).then(()=>{i(!0),window.setTimeout(()=>i(!1),1200)})};return e.jsx("button",{type:"button",className:"opp-copy",onClick:o,"aria-label":s?"Copied":"Copy full value",title:s?"Copied":"Copy",children:s?e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:e.jsx("path",{d:"M5 13l4 4L19 7",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round"})}):e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"9",y:"9",width:"11",height:"11",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M5 15V5a2 2 0 012-2h10",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})})}function Vt(t){const[s,i]=d.useState(()=>t==="auto"?Gt():t);return d.useEffect(()=>{if(t!=="auto"){i(t);return}const o=window.matchMedia("(prefers-color-scheme: dark)"),n=()=>i(o.matches?"dark":"light");return n(),o.addEventListener("change",n),()=>o.removeEventListener("change",n)},[t]),s}function Gt(){return typeof window>"u"||!window.matchMedia?"light":window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function ne(t){try{return new URL(t.includes("://")?t:`https://${t}`).host||t}catch{return t.length<=32?t:`${t.slice(0,14)}…${t.slice(-12)}`}}const Kt=({request:t,onResponse:s})=>{const{theme:i}=H(),{handleSelect:o,hideMenu:n}=te(),{apiContext:l,chromeStorageService:f}=z(),a=l?.services;d.useEffect(()=>{o("bsv"),n()},[o,n]);const[p,u]=d.useState(""),b=d.useRef(!1),g=async j=>{if(!b.current){if(b.current=!0,j){u("");const c=await V(f);if(!c.ok){u(c.message),b.current=!1;return}}U({action:"ONE_SAT_PERMISSION_RESPONSE",requestID:t.requestID,approved:j}),s()}},S=i.color.global.walletBackground.toLowerCase()==="#000000"||/^#[01]/.test(i.color.global.walletBackground)?"dark":"light";return e.jsxs("div",{style:{width:"100%",height:"100%",overflowY:"auto",display:"flex",flexDirection:"column",alignItems:"stretch",justifyContent:"center"},children:[p&&e.jsx("p",{className:"text-xs text-center m-0 pt-2",style:{color:"#ef4444"},children:p}),e.jsx(Ft,{request:t.request,onApprove:()=>{g(!0)},onReject:()=>{g(!1)},theme:S,services:a})]})},Yt=t=>{switch(t){case"protocol":return"Protocol Permission";case"basket":return"Basket Access";case"certificate":return"Certificate Access";case"spending":return"Spending Authorization";default:return"Permission Request"}},Xt=t=>{switch(t.type){case"protocol":{const s=Oe(t.protocolID);return s?s.description:`An application is requesting permission to use protocol "${t.protocolID?.[1]||"unknown"}" with security level ${t.protocolID?.[0]||0}.`}case"basket":return`An application is requesting access to basket "${t.basket||"unknown"}".`;case"certificate":return"An application is requesting access to certificate data.";case"spending":return`An application is requesting authorization to spend ${t.spending?.satoshis||0} satoshis.`;default:return"An application is requesting a permission."}},$e=t=>t>=1e8?`${(t/1e8).toFixed(8)} BSV`:`${t.toLocaleString()} satoshis`,Jt=t=>{const{request:s,onResponse:i}=t,{theme:o}=H(),{handleSelect:n,hideMenu:l}=te(),{addSnackbar:f}=ie(),[a,p]=d.useState(!1),[u,b]=d.useState(""),{chromeStorageService:g}=z();d.useEffect(()=>{n("bsv"),l()},[n,l]);const r=async()=>{p(!0),b("");try{const j=await V(g);if(!j.ok){b(j.message),p(!1);return}U({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!0}),i()}catch(j){const c=j instanceof Error?j.message:String(j);f(c,"error"),p(!1)}},S=async()=>{p(!0),U({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!1}),i()};return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(Me,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:Yt(s.type)}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:Xt(s)})]})]}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"12rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Origin"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.displayOriginator||s.originator})]}),e.jsxs(I,{when:s.type==="protocol"&&!!s.protocolID,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Protocol"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:Le(s.protocolID)})]}),e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.counterparty?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Security"}),e.jsx("span",{className:"text-xs",style:{color:o.color.global.contrast},children:Nt(s.protocolID?.[0])})]}),e.jsx(I,{when:!!s.counterparty,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.counterparty})]})})]}),e.jsx(I,{when:s.type==="basket"&&!!s.basket,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Basket"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.basket})]})}),e.jsxs(I,{when:s.type==="certificate"&&!!s.certificate,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Cert Type"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.certType})]}),e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Fields"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.fields.join(", ")})]})]}),e.jsxs(I,{when:s.type==="spending"&&!!s.spending,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.spending?.lineItems?.length?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Amount"}),e.jsx("span",{className:"text-xs font-semibold",style:{color:"var(--bw-accent-hi)"},children:$e(s.spending?.satoshis||0)})]}),e.jsx(I,{when:!!s.spending?.lineItems?.length,children:s.spending?.lineItems?.map((j,c)=>e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:c<(s.spending?.lineItems?.length??0)-1?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:j.type}),e.jsxs("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:[j.description," (",$e(j.satoshis),")"]})]},c))})]}),e.jsx(I,{when:!!s.reason,children:e.jsxs("div",{className:"flex flex-row py-2",style:{borderTop:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Reason"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.reason})]})})]}),e.jsx(I,{when:!!s.privileged,children:e.jsxs(A.div,{className:"flex items-start gap-2 rounded-xl px-3 py-2.5 mb-4",style:{background:"rgba(245,166,35,0.08)",border:"1px solid rgba(245,166,35,0.15)"},initial:{opacity:0},animate:{opacity:1},transition:{delay:.12},children:[e.jsx(st,{size:14,className:"mt-0.5 flex-shrink-0",style:{color:"#f5a623"}}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:"#f5a623"},children:"This is a privileged operation"})]})}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[u&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:u}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:a?.6:1},disabled:a,onClick:r,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[a&&e.jsx(ke,{size:14,className:"animate-spin"}),"Allow"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:a?.5:1},disabled:a,onClick:S,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny"})]})]})},Zt=({request:t,onResponse:s})=>{const{theme:i}=H(),{chromeStorageService:o}=z(),[n,l]=d.useState(""),[f,a]=d.useState(!1),p=async g=>{if(!f){if(a(!0),l(""),g){const r=await V(o);if(!r.ok){l(r.message),a(!1);return}}U({action:"USB_CHECK_RESPONSE",requestID:t.requestID,ok:g}),s()}},u=i.color.global.gray,b=i.color.global.contrast;return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(ot,{size:40,style:{color:b}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:b},children:"Confirm your USB key"}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:u,maxWidth:"18rem"},children:[t.originator?`${t.originator} is asking bWallet to ${t.reason}.`:`A site is asking bWallet to ${t.reason}.`," ","Insert your USB key, then confirm."]}),n&&e.jsx("p",{className:"m-0 text-xs",style:{color:"#ef4444"},children:n}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(Ae,{theme:i,type:"primary",label:"Confirm USB key",disabled:f,onClick:()=>{p(!0)}}),e.jsx(Ae,{theme:i,type:"secondary-outline",label:"Cancel",disabled:f,onClick:()=>{p(!1)}})]})]})},Be=5,be=[0,1,5,20],Qt=/e-?mail|phone|mobile|kyc|passport|licen[cs]e|birth|dob|address|ssn|national|tax|id_?number/i,we=t=>String(t.protocolID?.[1]??"unknown"),qe=t=>Number(t.protocolID?.[0]??0),We=t=>!!(t.privileged||t.type==="certificate"&&(t.certificate?.fields??[]).some(s=>Qt.test(s))),He=t=>t.type==="protocol"&&!t.privileged&&t.protocolID?.[1]==="identity key retrieval"&&(t.counterparty===void 0||t.counterparty==="self"),es=t=>{switch(t.type){case"protocol":return He(t)?"See your public identity (the key that names you)":t.counterparty==="anyone"?"Prove it's you (a signature anyone can check)":qe(t)===2&&t.counterparty&&t.counterparty!=="self"?`Sign and encrypt with your "${we(t)}" keys, shared with one named person or service`:`Sign and encrypt anything with your "${we(t)}" keys`;case"basket":return"Keep its tickets and tokens in your wallet";case"certificate":{const s=t.certificate?.fields??[];return s.length?`See your certificate details (${s.join(", ")})`:"See your certificates"}default:return"Spend from your wallet"}},ve=t=>{const s=[];switch(t.type){case"protocol":s.push(`protocol "${we(t)}" level ${qe(t)}`),t.counterparty&&s.push(`counterparty ${t.counterparty}`);break;case"basket":s.push(`basket "${t.basket??""}"`);break;case"certificate":s.push(`certificate ${t.certificate?.certType??""}`,`verifier ${t.certificate?.verifier??""}`);break;case"spending":s.push(`${t.spending?.satoshis??0} sats`);break}return t.privileged&&s.push("privileged"),t.reason&&s.push(`reason: ${t.reason}`),s.join(" · ")},ts=t=>{const s=[];let i;for(const n of t.items){if(n.type==="spending"){const a=n.spending?.satoshis??0;i?s.push({requestID:n.requestID,text:`Also pay ${a.toLocaleString()} sats`,detail:ve(n),risky:!0,checked:!1}):i={requestID:n.requestID,satoshis:a,description:n.spending?.lineItems?.find(p=>p.description)?.description??n.reason,detail:ve(n)};continue}const l=We(n),f=!l&&(n.type!=="protocol"||n.counterparty==="anyone"||He(n));s.push({requestID:n.requestID,text:es(n),detail:ve(n),risky:l,checked:f})}const o=i?s.length?"connectAndPay":"pay":"connect";return{originator:t.originator,lines:s,payment:i,mode:o}},ss="bwalletx.trust-site",os=t=>We(t)||t.type==="protocol"&&t.counterparty==="anyone"?!1:t.type==="basket"?!!t.basket&&t.basket!==ss:!1,rs=t=>t.items.some(s=>os(s)),ee=t=>t<1?`${Math.round(t*100)}¢`:`$${t.toFixed(2)}`,ns=t=>t>=1e8?`${(t/1e8).toFixed(8)} BSV`:`${t.toLocaleString()} sats`,as=t=>{const{request:s,onResponse:i,armed:o=!0}=t,{handleSelect:n,hideMenu:l}=te(),{addSnackbar:f}=ie(),{chromeStorageService:a}=z(),p=a.getCurrentAccountObject().account,u=dt(p?.addresses?.identityAddress,p?.name??"",p?.settings?.socialProfile?.displayName??"",!1),b=ut(u.displayName,u.paymail,u.handle).tag,g=ft(p?.pubKeys?.identityPubKey),r=d.useMemo(()=>ts(s),[s]),[S,j]=d.useState({}),c=d.useRef(s.items.length),h=Math.max(0,s.items.length-c.current),x=(m,N)=>S[m]??N,[v,k]=d.useState(),[w,T]=d.useState(Be),[D,q]=d.useState(!0),[F,le]=d.useState(!0),se=d.useMemo(()=>rs(s),[s]),[y,C]=d.useState(!0),[R,$]=d.useState(!1),[W,B]=d.useState(!1),[Ge,Ne]=d.useState("");d.useEffect(()=>{n("bsv"),l()},[n,l]),d.useEffect(()=>{_({action:"GET_BUNDLE_ALLOWANCE",originator:s.originator}).then(m=>{!m?.success||!m.data||(k(m.data),T(m.data.defaultUsd))}).catch(()=>{})},[s.originator]);const ce=!!v?.usdPerBsv&&v.existingSats===void 0,pe=r.payment&&v?.usdPerBsv?r.payment.satoshis/1e8*v.usdPerBsv:void 0,de=async m=>{B(!0),Ne("");try{if(m){const E=await V(a);if(!E.ok){Ne(E.message),B(!1);return}}const N={};for(const E of r.lines)N[E.requestID]=m&&x(E.requestID,E.checked);r.payment&&(N[r.payment.requestID]=m),await _({action:"BUNDLE_PERMISSION_RESPONSE",bundleID:s.bundleID,decisions:N,allowanceUsd:m&&ce&&D?w:0,remember:F,trustSite:m&&F&&se&&y}),i()}catch(N){f(N instanceof Error?N.message:String(N),"error"),B(!1)}},M=vt(r,{existingAllowanceSats:v?.existingSats}),ue=wt(s.originator),Ke=r.lines.length+(r.payment?1:0)>1,G=pe!==void 0?ee(pe):r.payment?ns(r.payment.satoshis):"",K=ce&&D&&w>0?w:0,Se=v?.existingSats!==void 0&&v.usdPerBsv?v.existingSats/1e8*v.usdPerBsv:void 0,Ye=M==="signin"?"Sign in":M==="pay"?r.mode==="connectAndPay"?`Connect & pay ${G}`:`Pay ${G}`:Ke?"Allow all":"Connect",Xe=()=>{const m=be.indexOf(w),N=be[(m+1)%be.length];T(N),q(N>0)},fe=W||!o,Y=M==="careful",oe=r.lines.filter(m=>m.risky),Je=(m,N)=>j(E=>({...E,[m]:!x(m,N)})),Ce=(m,N=!1)=>e.jsxs("label",{className:"flex items-center gap-3 cursor-pointer",style:{minHeight:44,padding:N?"10px 14px":"6px 0",borderRadius:N?14:0,background:N?P.redChip:void 0,fontSize:N?14:13},children:[e.jsx("input",{type:"checkbox",checked:x(m.requestID,m.checked),onChange:()=>Je(m.requestID,m.checked),style:{width:18,height:18,accentColor:m.risky?P.red:P.gold,flexShrink:0}}),e.jsx("span",{style:{color:m.risky?"#FF6B6B":void 0},children:m.text})]},m.requestID),xe=(b||g)&&e.jsxs("span",{children:[e.jsx("span",{style:{color:P.gold},children:b||"this account"}),g&&e.jsxs("span",{className:"font-mono",style:{userSelect:"none",fontSize:12,color:P.muted},children:[" ","· ",g]})]}),Ze=e.jsxs("div",{className:"flex flex-col",style:{gap:4},children:[(b||g)&&e.jsxs("p",{className:"m-0","data-testid":"signing-as",style:{fontSize:12},children:["Signing in as ",xe]}),h>0&&e.jsxs("p",{className:"m-0",style:{fontSize:12,color:P.green},children:["+",h," more added while this was open"]}),r.lines.map(m=>Ce(m)),r.payment&&e.jsxs("p",{className:"m-0",style:{padding:"6px 0"},children:["Pay now: ",e.jsx("span",{style:{color:P.gold,fontWeight:600},children:G})," to ",s.originator,r.payment.description&&e.jsxs(e.Fragment,{children:[" “",r.payment.description,"”"]})]}),ce&&e.jsxs("div",{className:"flex items-center gap-3",style:{minHeight:44},children:[e.jsx("input",{type:"checkbox",checked:D&&w>0,onChange:()=>{w===0&&T(Be),q(!(D&&w>0))},style:{width:18,height:18,accentColor:P.gold,flexShrink:0},"aria-label":"Monthly allowance"}),e.jsx("span",{className:"flex-1",children:w>0?`Spend up to ${ee(w)} a month without asking`:"Ask me before every payment"}),e.jsx("button",{type:"button",className:"border-0 bg-transparent underline",style:{color:P.gold,minHeight:44,padding:"0 4px",fontSize:13},onClick:Xe,children:"change"})]}),e.jsxs("label",{className:"flex items-center gap-3 cursor-pointer",style:{minHeight:44},children:[e.jsx("input",{type:"checkbox",checked:F,onChange:()=>le(!F),style:{width:18,height:18,accentColor:P.gold,flexShrink:0}}),e.jsx("span",{children:"Remember this site"})]}),se&&F&&e.jsxs("label",{className:"flex items-start gap-3 cursor-pointer",style:{padding:"6px 0"},children:[e.jsx("input",{type:"checkbox",checked:y,onChange:()=>C(!y),style:{width:18,height:18,accentColor:P.gold,flexShrink:0,marginTop:1}}),e.jsxs("span",{children:["Don't ask again on ",s.originator," for sign-in and signing. Payments stay within the allowance; your personal details always ask."]})]}),e.jsxs("ul",{className:"m-0 mt-1 pl-4 break-all",style:{fontSize:11,color:P.muted},children:[r.payment&&e.jsxs("li",{children:["pay: ",r.payment.detail]}),r.lines.map(m=>e.jsx("li",{children:m.detail},m.requestID)),K>0&&e.jsxs("li",{children:["allowance: monthly spending cap for ",s.originator]})]})]}),Pe={label:Y?"No, block it":"Not now",onClick:()=>{de(!1)},disabled:fe},Ee={label:Y?"I trust it, allow":Ye,onClick:()=>{de(!0)},disabled:fe,busy:W};let X,J,Z=null,Q;const he=m=>e.jsx("span",{style:{color:P.gold},children:m});if(M==="careful"){X=e.jsx(yt,{}),Q="Check this carefully";const m=s.items.some(O=>O.privileged),N=oe.some(O=>s.items.find(Qe=>Qe.requestID===O.requestID)?.type==="certificate"),E=O=>e.jsx("span",{style:{color:"#FF6B6B"},children:O});J=m?e.jsxs(e.Fragment,{children:["Wants ",E("full control")," of your keys"]}):N?e.jsxs(e.Fragment,{children:["Wants your ",E("private details")]}):r.payment&&oe.length===0?e.jsxs(e.Fragment,{children:[E(G)," is over your allowance"]}):e.jsxs(e.Fragment,{children:["Wants ",E("more than usual")]}),Z=e.jsxs("div",{className:"flex flex-col",style:{gap:8},children:[m&&e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:P.redChip,fontSize:14},children:[e.jsx(me,{}),"Could move your money"]}),oe.length===0&&r.payment&&e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:P.redChip,fontSize:14},children:[e.jsx(me,{}),Se!==void 0?`Your allowance here is ${ee(Se)} a month`:"More than this site may spend"]}),oe.map(O=>Ce(O,!0)),e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:P.redChip,fontSize:14},children:[e.jsx(me,{}),"Only allow apps you trust"]})]})}else if(M==="pay")X=e.jsx(xt,{amount:G,sub:pe!==void 0&&r.payment?`${r.payment.satoshis.toLocaleString()} sats`:void 0}),Q=r.payment?.description||"Asks you to pay",J=e.jsxs(e.Fragment,{children:["Pay ",he(ue)]}),Z=e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex items-center gap-3",style:{padding:14,borderRadius:16,background:P.chip},children:[e.jsx(ht,{site:s.originator,size:44}),e.jsxs("div",{className:"flex flex-col min-w-0",style:{gap:2,lineHeight:1.25},children:[e.jsxs("span",{className:"truncate",style:{fontSize:15,fontWeight:600},children:["To ",s.originator]}),e.jsx("span",{className:"truncate",style:{fontSize:13,color:P.muted},children:r.payment?.description?`“${r.payment.description}”`:"Straight from your wallet"})]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:P.soft},children:[e.jsx(re,{size:18}),K>0?`Then up to ${ee(K)} a month without asking`:"Every payment asks you first"]})]});else if(M==="signin")X=e.jsx(bt,{}),Q="Sign-in request",J=e.jsxs(e.Fragment,{children:["Sign in to ",he(ue)]}),Z=e.jsxs(e.Fragment,{children:[xe&&e.jsxs("div",{className:"flex items-center gap-2.5",children:[e.jsx("div",{"aria-hidden":"true",style:{width:30,height:30,borderRadius:15,background:"conic-gradient(#F5C542, #B8860B, #FFE08A, #F5C542)",flexShrink:0}}),e.jsxs("span",{style:{fontSize:18,fontWeight:600},children:["as ",xe]})]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs(Ie,{children:[e.jsx(re,{}),"No password"]}),e.jsxs(Ie,{children:[e.jsx(re,{}),"No money moves"]})]})]});else{X=e.jsx(mt,{site:s.originator}),Q="Wants to connect",J=e.jsxs(e.Fragment,{children:["Use ",he("bWalletX")," on ",ue]});const m=new Set(s.items.map(E=>E.type)),N=[{label:m.has("certificate")?"Your details":"Your name",icon:e.jsx(is,{})}];m.has("protocol")&&N.push({label:"Sign posts",icon:e.jsx(ls,{})}),m.has("basket")&&N.push({label:"Keep items",icon:e.jsx(cs,{})}),Z=e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"grid",style:{gridTemplateColumns:`repeat(${N.length}, minmax(0, 1fr))`,gap:8},children:N.map(E=>e.jsxs("div",{className:"flex flex-col items-center",style:{gap:8,padding:"14px 6px",borderRadius:16,background:P.chip},children:[E.icon,e.jsx("span",{style:{fontSize:13,fontWeight:600,textAlign:"center"},children:E.label})]},E.label))}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:P.soft},children:[e.jsx(re,{size:18}),K>0?`Payments over ${ee(K)} a month ask you first`:"Payments still ask you first"]})]})}return e.jsx(A.div,{className:"flex flex-col w-full h-full",style:{maxHeight:"100vh"},initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{type:"spring",damping:24,stiffness:260},"data-approval-kind":M,children:e.jsx(gt,{tone:Y?"red":"gold",site:s.originator,siteSub:Q,onClose:()=>{de(!1)},closeLabel:"Deny and close",closeDisabled:fe,hero:X,title:J,primary:Y?Pe:Ee,secondary:Y?Ee:Pe,details:Ze,detailsOpen:R,onToggleDetails:()=>$(!R),error:Ge,children:Z})})},je={"aria-hidden":!0,width:28,height:28,viewBox:"0 0 24 24",fill:"none",stroke:P.gold,strokeWidth:1.8,strokeLinecap:"round",strokeLinejoin:"round"},is=()=>e.jsxs("svg",{...je,children:[e.jsx("circle",{cx:"12",cy:"8",r:"4"}),e.jsx("path",{d:"M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"})]}),ls=()=>e.jsxs("svg",{...je,children:[e.jsx("path",{d:"M12 20h9"}),e.jsx("path",{d:"M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"})]}),cs=()=>e.jsxs("svg",{...je,children:[e.jsx("rect",{x:"3",y:"7",width:"18",height:"13",rx:"2"}),e.jsx("path",{d:"M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"})]});Fe.Buffer=Ue;Fe.process=tt;window.Buffer=Ue;const ps=1e4,ds=2e3,L=new URLSearchParams(window.location.search).get("inpage"),us=window.location.protocol==="chrome-extension:"&&window.top!==window&&!L&&!!window.location.ancestorOrigins?.length&&window.location.ancestorOrigins[0]!==window.location.origin,fs=(t,s)=>{const[i,o]=d.useState(t?void 0:!0),[n,l]=d.useState(!t),[f,a]=d.useState(!1);return d.useEffect(()=>{t&&_({action:"INPAGE_SHEET_CHECK",token:L}).then(p=>o(!!p?.success)).catch(()=>o(!1))},[t]),d.useEffect(()=>{if(!t||!s.current)return;let p;const u=new IntersectionObserver(b=>{const g=b[b.length-1];window.clearTimeout(p),g.isVisible&&g.intersectionRatio>=.99?p=window.setTimeout(()=>l(!0),500):l(!1)},{threshold:[0,.99,1],trackVisibility:!0,delay:100});return u.observe(s.current),()=>{window.clearTimeout(p),u.disconnect()}},[t,s]),d.useEffect(()=>{if(!t||n){a(!1);return}const p=window.setTimeout(()=>a(!0),1500);return()=>window.clearTimeout(p)},[t,n]),{tokenOk:i,armed:i===!0&&n,stuck:i===!0&&!n&&f}},xs=()=>{const{theme:t}=H(),{isLocked:s,isReady:i}=z(),[o,n]=d.useState({kind:"loading"}),l=d.useRef(void 0),f=d.useRef(void 0),a=()=>{l.current!==void 0&&(window.clearTimeout(l.current),l.current=void 0)},p=d.useRef(o);p.current=o;const u=d.useCallback(async(h,x)=>{a();const v=p.current;if(h==="bundle"&&v.kind==="bundle"&&v.requestID===x){try{const w=await _({action:"GET_PROMPT_PAYLOAD",kind:h,requestID:x});w?.success&&w.data&&n({kind:"bundle",requestID:x,payload:w.data})}catch{}return}n({kind:"loading"});let k;try{k=await _({action:"GET_PROMPT_PAYLOAD",kind:h,requestID:x})}catch{k=void 0}k?.success&&k.data?n({kind:h,requestID:x,payload:k.data}):(n({kind:"expired"}),window.setTimeout(()=>{f.current?.()},ds))},[]),b=d.useCallback(async()=>{a();let h;try{h=await _({action:"CLOSE_PROMPT_WINDOW"})}catch{h=void 0}if(h===void 0){window.close();return}const x=h.data?.prompt;x&&(x.kind==="unlock"?n({kind:"unlock"}):x.requestID&&await u(x.kind,x.requestID))},[u]),g=d.useCallback(async()=>{a();let h;try{h=await _({action:"GET_NEXT_PROMPT"})}catch{h=void 0}if(h?.data?.prompt){await u(h.data.prompt.kind,h.data.prompt.requestID);return}if(h?.data?.busy){n({kind:"waiting"}),l.current=window.setTimeout(()=>{b()},ps);return}await b()},[u,b]);f.current=g,d.useEffect(()=>{if(!i)return;const h=new URLSearchParams(window.location.search),x=h.get("kind"),v=h.get("requestID");if(x==="unlock"){s?n({kind:"unlock"}):g();return}if(x&&v){u(x,v);return}g()},[i]),d.useEffect(()=>{const h=x=>{if(!(x?.action!=="SHOW_PROMPT"||!x.kind)){if(x.kind==="unlock"){a(),n({kind:"unlock"});return}x.requestID&&u(x.kind,x.requestID)}};return chrome.runtime.onMessage.addListener(h),()=>chrome.runtime.onMessage.removeListener(h)},[u]);const r=t.color.global.walletBackground,S=d.useRef(null),j=d.useRef(null),c=fs(!!L,j);return us||c.tokenOk===!1?e.jsx("p",{className:"text-xs p-4",style:{color:"#98A2B3"},children:"Open bWalletX to answer this request."}):e.jsxs(lt,{children:[L&&e.jsxs("div",{className:"flex items-center justify-between px-3 py-2",style:{background:r,borderBottom:"1px solid #ffffff14"},children:[e.jsx("span",{className:"text-sm font-bold",style:{color:t.color.global.contrast},children:"bWalletX"}),c.stuck&&e.jsx("button",{type:"button",className:"text-xs font-bold border-0 rounded-full px-3 py-1",style:{background:"#F5C542",color:"#0b0a08"},onClick:()=>chrome.runtime.sendMessage({action:"MOVE_PROMPT_TO_WINDOW"}).catch(()=>{}),children:"Open in bWalletX"}),e.jsx("button",{type:"button","aria-label":"Deny and close",className:"text-sm border-0 bg-transparent p-1",style:{color:t.color.global.gray},onClick:()=>chrome.runtime.sendMessage({action:"DISMISS_PROMPT_PANEL"}).catch(()=>{}),children:"✕"})]}),e.jsxs("div",{ref:S,className:"flex items-center justify-center relative p-0",style:{width:L?"100%":"var(--wallet-width)",height:L?"calc(100vh - 41px)":"var(--wallet-height)",backgroundColor:r,pointerEvents:c.armed?void 0:"none"},children:[L&&e.jsx("div",{ref:j,"aria-hidden":!0,style:{position:"absolute",top:0,left:0,width:24,height:24,pointerEvents:"none"}}),(!i||o.kind==="loading")&&e.jsx(Re,{message:"Loading...",theme:t}),o.kind==="waiting"&&e.jsx(Re,{message:"Waiting for request...",theme:t}),o.kind==="expired"&&e.jsx("p",{className:"text-xs",style:{color:t.color.global.gray},children:"This request expired or was already handled."}),o.kind==="unlock"&&e.jsx(ct,{onUnlock:()=>{g()}}),o.kind==="permission"&&e.jsx(Jt,{request:o.payload,onResponse:()=>{g()}},o.requestID),o.kind==="bundle"&&e.jsx(as,{request:o.payload,onResponse:()=>{g()}},o.requestID),o.kind==="groupedPermission"&&e.jsx(At,{request:o.payload,onResponse:()=>{g()}},o.requestID),o.kind==="counterpartyPermission"&&e.jsx(kt,{request:o.payload,onResponse:()=>{g()}},o.requestID),o.kind==="oneSatPermission"&&e.jsx(Kt,{request:o.payload,onResponse:()=>{g()}},o.requestID),o.kind==="usbCheck"&&e.jsx(Zt,{request:o.payload,onResponse:()=>{g()}},o.requestID)]})]})},Ve=document.getElementById("root");if(!Ve)throw new Error("Root element");et.createRoot(Ve).render(e.jsx(rt,{children:e.jsx(nt,{children:e.jsx(at,{children:e.jsx(it,{children:e.jsx(xs,{})})})})}));
//# sourceMappingURL=prompt-tab-B5odkON0.js.map
