import{G as o}from"./index-wzdPIhXX.js";const t=`${o()} (beta) by The Bitcoin Corporation Ltd. Based on the open-source Yours Wallet (MIT licence); not affiliated with or endorsed by its authors.`;export{t as U};
//# sourceMappingURL=brandText-BbKCV1Sk.js.map
