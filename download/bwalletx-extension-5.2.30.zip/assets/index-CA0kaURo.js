const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B7nKeIIK.js","./index-DfnFVwhw.js","./crypto-C0Mtv_ph.js","./index-DvwB3iNZ.js","./index-BOs1uvky.css","./extensionMedia-Rm_l9uoo.js","./index-DqBF7sht.css"])))=>i.map(i=>d[i]);
import{af as e,_ as t}from"./index-DfnFVwhw.js";import"./crypto-C0Mtv_ph.js";import"./index-DvwB3iNZ.js";import"./extensionMedia-Rm_l9uoo.js";const _=e("Share",{web:()=>t(()=>import("./web-B7nKeIIK.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-CA0kaURo.js.map
