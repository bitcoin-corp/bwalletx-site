import{gt as e}from"./main-jrkCCuQ1.js";import{bB as i,b4 as l}from"./index-DfnFVwhw.js";const n=["b0asex"],r=(a,o=n)=>{const[t,s]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!o.includes(t)?!1:!s||s===l.toLowerCase()},A=(a,o=!1)=>o||e(a)||r(i(a??void 0));export{A as c};
//# sourceMappingURL=bulkAccess-Ct4j-NUP.js.map
