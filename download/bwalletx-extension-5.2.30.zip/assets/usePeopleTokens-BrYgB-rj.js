import{r as t}from"./index-DvwB3iNZ.js";import{fetchPeopleTokens as l}from"./people-iZYyVy0u.js";const f=()=>{const[s,o]=t.useState(null);return t.useEffect(()=>{let e=!0;return l().then(r=>e&&o(r)),()=>{e=!1}},[]),s};export{f as u};
//# sourceMappingURL=usePeopleTokens-BrYgB-rj.js.map
