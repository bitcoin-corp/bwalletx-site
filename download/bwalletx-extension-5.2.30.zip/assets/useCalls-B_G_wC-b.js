import{r as s}from"./index-DvwB3iNZ.js";import{it as r,aO as a}from"./index-DfnFVwhw.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-B_G_wC-b.js.map
