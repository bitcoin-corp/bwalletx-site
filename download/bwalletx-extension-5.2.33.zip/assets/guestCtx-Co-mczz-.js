import{r as t}from"./index-BCfd9xtL.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-Co-mczz-.js.map
