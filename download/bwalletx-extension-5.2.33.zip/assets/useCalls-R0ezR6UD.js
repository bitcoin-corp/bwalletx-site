import{r as s}from"./index-BCfd9xtL.js";import{iQ as r,aT as a}from"./index-CQUftyzV.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-R0ezR6UD.js.map
