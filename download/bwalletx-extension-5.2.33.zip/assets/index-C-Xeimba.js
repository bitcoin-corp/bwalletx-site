const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Cj7hugWA.js","./index-CQUftyzV.js","./crypto-DUGVnWhd.js","./index-BCfd9xtL.js","./index-Bwr_iOPv.css","./extensionMedia-Rm_l9uoo.js","./index-BaMgDKNL.css"])))=>i.map(i=>d[i]);
import{ah as e,_ as t}from"./index-CQUftyzV.js";import"./crypto-DUGVnWhd.js";import"./index-BCfd9xtL.js";import"./extensionMedia-Rm_l9uoo.js";const _=e("Share",{web:()=>t(()=>import("./web-Cj7hugWA.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-C-Xeimba.js.map
