import{c}from"./crypto-DUGVnWhd.js";const o=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 6v6l4 2",key:"mmk7yg"}]],r=c("clock",o);export{r as C};
//# sourceMappingURL=clock-B_RqBwWg.js.map
