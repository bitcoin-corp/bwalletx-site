import{i as e}from"./sessions-C_PrQy9z.js";import{bH as i,b8 as l,b_ as n}from"./index-G4GCesQs.js";const r=["b0asex"],c=(a,s=r)=>{const[t,o]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!s.includes(t)?!1:!o||o===l.toLowerCase()||(n??[]).includes(o)},m=(a,s=!1)=>s||e(a)||c(i(a??void 0));export{m as c};
//# sourceMappingURL=bulkAccess-DhVtviAh.js.map
