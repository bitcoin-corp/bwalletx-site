import{r as p,j as e,b as at}from"./index-numRYSTi.js";import{m as Ce,bj as ze,bk as We,bl as it}from"./crypto-Je5Wy8Z2.js";import{j as q,t as H,z as R,bp as I,gM as G,gN as B,bq as lt,U as ct,br as le,I as W,fH as De,fG as dt,gK as pt,gL as ut,gB as ft,gC as xt,gD as mt,P as $e,gH as ht}from"./index-G4GCesQs.js";import{a as oe,u as de,U as gt,r as pe,q as qe,S as yt,f as bt,c as vt,i as wt,k as kt,C as E,t as ve,m as jt,v as Nt,d as ae,w as St,A as Ct,x as Et,g as Pt,e as Be,P as At,y as Fe,z as Tt,B as Rt,D as He}from"./connectSiteTheme-BvVnEIMs.js";import{a as It,s as Dt}from"./approvalKind-BQjbcmk8.js";import"./extensionMedia-Rm_l9uoo.js";import"./originKey-kDoqBWA_.js";const $t=t=>{const{request:s,onResponse:a}=t,{theme:o}=q(),{handleSelect:r,hideMenu:i}=oe(),{addSnackbar:f}=de(),[l,n]=p.useState(!1),[x,g]=p.useState(""),{chromeStorageService:w}=H(),{permissions:c}=s,[m,b]=p.useState(()=>c.protocols.map(()=>!0));p.useEffect(()=>{r("bsv"),i()},[r,i]);const d=()=>{const k=c.protocols.filter((P,T)=>m[T]);return k.length===0?{}:{protocols:k}},j=async()=>{n(!0),g("");try{const k=await G(w);if(!k.ok){g(k.message),n(!1);return}pe(s.originator),B({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:d()}),a()}catch(k){f(k instanceof Error?k.message:String(k),"error"),n(!1)}},N=async()=>{n(!0),B({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),a()},u=k=>b(P=>P.map((T,V)=>V===k?!T:T)),h=s.counterpartyLabel??`${s.counterparty.slice(0,8)}...${s.counterparty.slice(-8)}`;return e.jsxs(R.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(gt,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Counterparty Permission"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","wants to interact with a counterparty"]})]})]}),e.jsxs(R.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all font-mono",style:{color:o.color.global.contrast},children:h})]}),e.jsx(I,{when:!!c.description,children:e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Purpose"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:c.description})]})}),e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),c.protocols.map((k,P)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:P<c.protocols.length-1?"1px solid rgba(255,255,255,0.04)":"none"},children:[e.jsx("input",{type:"checkbox",checked:m[P],onChange:()=>u(P),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[k.protocolID?.[1]," (level ",k.protocolID?.[0],")"]}),k.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:k.description})]})]},`proto-${P}`))]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[x&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:x}),e.jsxs(R.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:l?.6:1},disabled:l,onClick:j,whileHover:{scale:l?1:1.02},whileTap:{scale:l?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[l&&e.jsx(Ce,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(R.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:l?.5:1},disabled:l,onClick:N,whileHover:{scale:l?1:1.02},whileTap:{scale:l?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},Bt={"2:3241645161d8":{label:"BRC-29 payment",description:"An application is requesting permission to derive payment addresses for a specific recipient."}},Ve=t=>t?Bt[`${t[0]}:${t[1]}`]:void 0,Ge=t=>Ve(t)?.label??t?.[1],Ft=t=>{switch(t){case 0:return"Level 0 · any app";case 1:return"Level 1 · same keys for any app using this protocol";case 2:return"Level 2 · same keys for any app using this protocol with this recipient";default:return`Level ${t??0}`}},Ke=t=>`${t[0]}:${t[1].trim().toLowerCase()}`,Mt=new Set([2532803679,1545534606,3968644154,2559579298,983045898,2744301556,111268922,3445661247,2334321181,4156441831,3583153857,2398265928,1065214202,2451633495,1587406450,3495424783,2196479044,3172368687,3977290595,2110695608,2486468533,3947228137,3114316294,3407865888,2095595255,927149303,1269930738,2919298931,2255687340,329407381,2945469548].map(t=>t>>>0)),Ot=[[2,"3241645161d8"]],Ut=t=>{let s=2166136261;for(const a of new TextEncoder().encode(Ke(t)))s=Math.imul(s^a,16777619)>>>0;return s>>>0};new Set(Ot.map(Ke));const Lt=t=>Array.isArray(t)&&t.length===2&&typeof t[0]=="number"&&typeof t[1]=="string"?[t[0],t[1]]:null,Me=t=>{const s=Lt(t);return!!s&&Mt.has(Ut(s))},_t=t=>{const{request:s,onResponse:a}=t,{theme:o}=q(),{handleSelect:r,hideMenu:i}=oe(),{addSnackbar:f}=de(),[l,n]=p.useState(!1),[x,g]=p.useState(""),{chromeStorageService:w}=H(),c=w.getCurrentAccountObject().account?.pubKeys?.identityPubKey??"",{permissions:m}=s,[b,d]=p.useState(()=>(m.protocolPermissions??[]).map(()=>!1)),[j,N]=p.useState(()=>(m.basketAccess??[]).map(()=>!0)),[u,h]=p.useState(()=>(m.certificateAccess??[]).map(()=>!0)),[k,P]=p.useState(!0);p.useEffect(()=>{r("bsv"),i()},[r,i]);const T=()=>{const v={},C=(m.protocolPermissions??[]).filter((O,U)=>b[U]&&!Me(O.protocolID));C.length>0&&(v.protocolPermissions=C);const D=(m.basketAccess??[]).filter((O,U)=>j[U]);D.length>0&&(v.basketAccess=D);const $=(m.certificateAccess??[]).filter((O,U)=>u[U]);return $.length>0&&(v.certificateAccess=$),k&&m.spendingAuthorization&&(v.spendingAuthorization=m.spendingAuthorization),v},V=async()=>{n(!0),g("");try{const v=await G(w);if(!v.ok){g(v.message),n(!1);return}pe(s.originator),B({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:T()}),a()}catch(v){f(v instanceof Error?v.message:String(v),"error"),n(!1)}},M=async()=>{n(!0),B({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),a()},ue=v=>d(C=>C.map((D,$)=>$===v?!D:D)),re=v=>N(C=>C.map((D,$)=>$===v?!D:D)),K=v=>h(C=>C.map((D,$)=>$===v?!D:D));return e.jsxs(R.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(qe,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Permission Request"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","is requesting the following permissions"]})]})]}),e.jsx(yt,{site:bt(s.originator),account:c,style:{marginBottom:12}}),e.jsx(I,{when:!!m.description,children:e.jsx("p",{className:"text-xs mb-3 leading-relaxed",style:{color:o.color.global.gray},children:m.description})}),e.jsx(I,{when:!!m.spendingAuthorization,children:e.jsxs(R.div,{className:"w-full rounded-2xl px-4 py-3 mb-3",style:{background:"rgba(247,144,9,0.08)",border:"1px solid rgba(247,144,9,0.2)"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.06},children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pb-1",style:{color:"#F79009"},children:"Spending Authorization"}),e.jsxs("label",{className:"flex items-start gap-3 py-1 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:k,onChange:()=>P(!k),className:"mt-0.5 accent-orange-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-semibold",style:{color:"#F79009"},children:["This app wants to spend up to ",((m.spendingAuthorization?.amount??0)/1e8).toFixed(8)," BSV"," ","(",(m.spendingAuthorization?.amount??0).toLocaleString()," satoshis)"]}),m.spendingAuthorization?.description&&e.jsxs("span",{className:"text-xs mt-1 opacity-70",style:{color:o.color.global.contrast},children:["App says: “",m.spendingAuthorization.description,"”"]})]})]})]})}),e.jsxs(R.div,{className:"w-full rounded-2xl px-4 py-2 mb-5",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs(I,{when:!!m.protocolPermissions?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),m.protocolPermissions?.map((v,C)=>Me(v.protocolID)?e.jsxs("p",{className:"text-xs py-2",style:{color:o.color.global.gray},children:["Refused: “",v.protocolID[1],"” is used only by bWalletX itself."]},`proto-${C}`):e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:b[C],onChange:()=>ue(C),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:["Let this app sign and encrypt with your keys for “",Ge(v.protocolID),"”",v.counterparty?` (shared with ${v.counterparty.slice(0,10)}…)`:""]}),e.jsxs("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:["Any app that asks for this protocol gets the same keys (level ",v.protocolID[0],")."]}),v.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:v.description})]})]},`proto-${C}`))]}),e.jsxs(I,{when:!!m.basketAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Baskets"}),m.basketAccess?.map((v,C)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:j[C],onChange:()=>re(C),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:v.basket}),v.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:v.description})]})]},`basket-${C}`))]}),e.jsxs(I,{when:!!m.certificateAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Certificates"}),m.certificateAccess?.map((v,C)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:u[C],onChange:()=>K(C),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:v.type}),e.jsxs("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:[v.description," — fields: ",v.fields.join(", ")]})]})]},`cert-${C}`))]})]}),e.jsxs("div",{className:"flex flex-col gap-3",children:[x&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:x}),e.jsxs(R.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:l?.6:1},disabled:l,onClick:V,whileHover:{scale:l?1:1.02},whileTap:{scale:l?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[l&&e.jsx(Ce,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(R.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:l?.5:1},disabled:l,onClick:M,whileHover:{scale:l?1:1.02},whileTap:{scale:l?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},zt=2e3;async function ce(t,s=zt){let a;try{return await Promise.race([t.catch(()=>{}),new Promise(o=>{a=setTimeout(()=>o(void 0),s)})])}catch{return}finally{a&&clearTimeout(a)}}function Wt(t,s){return t?.find(a=>a.startsWith(`${s}:`))?.slice(s.length+1)}async function qt(t,s,a=[]){const o=t.ordfs;if(typeof o?.bulkMetadata!="function")return{state:"unverified"};const r=`${s}:-2`,i=await ce(o.bulkMetadata([r])),f=i?.[r]??i?.[s]??Object.values(i??{}).find(x=>!!x?.contentType);if(!f?.contentType)return{state:"unverified"};const l={contentType:f.contentType,origin:f.origin,name:typeof f.map?.name=="string"?f.map.name:void 0},n=a.find(x=>x.includes("/"));return n&&n!==f.contentType?{state:"mismatch",note:`Content type is ${f.contentType}, not ${n}`,...l}:{state:"verified",...l}}async function Ht(t,s,a){const o=t.opns;if(typeof o?.getOrigin!="function")return{state:"unverified"};const r=await ce(o.getOrigin(s));return r?.outpoint?r.outpoint!==a?{state:"mismatch",note:`“${s}” currently resolves to a different output`}:{state:"verified"}:{state:"unverified"}}async function Vt(t,s,a,o=[]){const r=t.bsv21;if(typeof r?.getTokenDetails!="function")return{state:"unverified"};const i=await ce(r.getTokenDetails(s,{fresh:!0}));if(!i)return{state:"unverified"};if(i.status?.is_active===!1)return{state:"mismatch",note:"Token is not active on the overlay"};const f=i.token?.sym;if(a&&f&&a.toLowerCase()!==f.toLowerCase())return{state:"mismatch",note:`Token symbol is ${f}, not ${a}`};if(o.length>0&&typeof r.getOutputStatus=="function"){const l=await ce(r.getOutputStatus(s,o));if(!l)return{state:"unverified"};const n=l.filter(x=>x.state==="spent"||x.state==="unknown");if(n.length>0)return{state:"mismatch",note:n.length===1?"A spent token output is not valid on the overlay":`${n.length} spent token outputs are not valid on the overlay`};if(l.some(x=>x.state==="queued"))return{state:"unverified"}}return{state:"verified",...f?{name:f}:{}}}async function Gt(t,s,a,o,r){if(!t||!s)return{state:"unverified"};const i=s==="purchase"||s.endsWith(".purchase"),f=s==="token-transfer"||s.startsWith("bsv21.");if(!i&&!f)return{state:"unverified"};const l={kindOrIntent:s,hasOrdfs:!!t.ordfs,hasBulk:typeof t.ordfs?.bulkMetadata=="function",inputTagSets:a.map(n=>n.tags),outputTagSets:o.map(n=>n.tags)};try{const n=[...a.map(d=>d.tags),...o.map(d=>d.tags)],x=d=>n.flatMap(j=>j.filter(N=>N.startsWith(`${d}:`)).map(N=>N.slice(d.length+1))),g=d=>{for(const j of n){const N=Wt(j,d);if(N)return N}},w=g("bsv21");if(w||s==="bsv21.purchase"||s==="token-transfer"||s.startsWith("bsv21.")){if(!w)return{state:"unverified"};const j=a.filter(u=>u.basket?.includes("bsv21")||u.tags.some(h=>h.startsWith("bsv21:"))).map(u=>u.outpoint).filter(Boolean);let N=g("sym");for(const u of a)if(u.customInstructions)try{const h=JSON.parse(u.customInstructions).sym;if(typeof h=="string"&&h.trim()){N=h.trim();break}}catch{}return await Vt(t,w,N,j)}const c=g("name"),m=g("origin");if(l.name=c,l.origin=m,c&&m&&o.some(d=>d.basket?.includes("opns"))||s==="opns.purchase")return!c||!m?{state:"unverified"}:await Ht(t,c,m);if(!m)return l.reason="no-origin-tag",globalThis.__lastVerify=l,{state:"unverified"};const b=await qt(t,m,x("type"));if(l.verifyOrdinal=b,b.origin&&r)try{b.contentUrl=r(b.origin)}catch(d){l.contentUrlError=String(d)}return globalThis.__lastVerify=l,b}catch(n){return l.error=String(n),globalThis.__lastVerify=l,{state:"unverified"}}}function Ye(t){if(!t||typeof t!="object")return!1;const s=t;return Array.isArray(s.panels)&&typeof s.title=="string"}var Kt=`
.opp-root {
  --opp-bg: #ffffff;
  --opp-fg: #111827;
  --opp-muted: #6b7280;
  --opp-card-bg: #f7f8fa;
  --opp-card-border: #eceef2;
  --opp-accent: #E5A920;
  --opp-approve-bg: #E5A920;
  --opp-approve-fg: #ffffff;
  --opp-reject-bg: #ffffff;
  --opp-reject-fg: #111827;
  --opp-reject-border: #d1d5db;
  --opp-status-bg: #FFFBE6;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #ECFDF5;
  --opp-trust-ok-fg: #059669;
  --opp-trust-warn-bg: #FFFBEB;
  --opp-trust-warn-fg: #D97706;
  --opp-trust-bad-bg: #FEF2F2;
  --opp-trust-bad-fg: #DC2626;

  font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--opp-bg);
  color: var(--opp-fg);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 480px;
  min-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
}

.opp-bottom {
  margin-top: auto;
  display: flex;
  flex-direction: column;
}

.opp-root.opp-dark {
  --opp-bg: #0F1117;
  --opp-fg: #F9FAFB;
  --opp-muted: #9ca3af;
  --opp-card-bg: #1A1D27;
  --opp-card-border: #232636;
  --opp-reject-bg: #0F1117;
  --opp-reject-fg: #F9FAFB;
  --opp-reject-border: #2D3142;
  --opp-status-bg: #2A2408;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #0A2E1F;
  --opp-trust-ok-fg: #34D399;
  --opp-trust-warn-bg: #2A2008;
  --opp-trust-warn-fg: #FBBF24;
  --opp-trust-bad-bg: #2A1215;
  --opp-trust-bad-fg: #F87171;
}

.opp-body {
  padding: 24px 20px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
}

.opp-coin {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
}

.opp-title {
  font-size: 16px;
  font-weight: 700;
  margin: 0;
  text-align: center;
}

.opp-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  margin: 0;
  text-align: center;
  line-height: 1.4;
}

.opp-status {
  background: var(--opp-status-bg);
  color: var(--opp-status-fg);
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
  margin-top: 4px;
  border: 1px solid var(--opp-card-border);
}

.opp-card {
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px;
  padding: 16px;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.opp-featured {
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px 8px;
  padding: 16px;
}

/* Subtle danger chrome for burn / destructive token ops */
.opp-featured-danger {
  border-color: rgba(220, 38, 38, 0.45);
  background: color-mix(in srgb, var(--opp-card-bg) 88%, #7f1d1d 12%);
}

.opp-featured-danger .opp-featured-title {
  color: #f87171;
}

.opp-featured-danger .opp-featured-image,
.opp-featured-danger .opp-featured-placeholder {
  border: 1px solid rgba(220, 38, 38, 0.35);
  background: rgba(127, 29, 29, 0.25);
  color: #fca5a5;
}

.opp-dark .opp-featured-danger {
  border-color: rgba(248, 113, 113, 0.4);
  background: color-mix(in srgb, var(--opp-card-bg) 85%, #450a0a 15%);
}

.opp-preview-pair {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.opp-preview-arrow {
  color: var(--opp-muted);
  font-size: 14px;
  line-height: 1;
}

.opp-preview-pair .opp-featured-image {
  width: 64px;
  height: 64px;
}

.opp-featured-image {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-featured-image-token {
  width: 48px;
  height: 48px;
  border-radius: 999px;
}

.opp-featured-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--opp-muted);
  font-size: 18px;
}

.opp-preview-opns {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
}

.opp-preview-opns-avatar {
  width: 36px;
  height: 36px;
  border-radius: 999px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-preview-opns-name {
  font-size: 11px;
  font-weight: 600;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  color: var(--opp-fg, inherit);
}

.opp-preview-text {
  margin: 0;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
  font-size: 9px;
  line-height: 1.25;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  color: var(--opp-muted);
}

.opp-preview-json {
  white-space: pre;
  overflow: auto;
}

.opp-preview-frame {
  border: 0;
  padding: 0;
  overflow: hidden;
  background: #fff;
  pointer-events: none;
}

.opp-preview-value {
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  background: rgba(229, 169, 32, 0.12);
  border: 1px solid rgba(229, 169, 32, 0.35);
  color: var(--opp-fg, inherit);
}

.opp-preview-value-icon {
  width: 32px;
  height: 32px;
  color: #E5A920;
}

/* Amount subtitles must never ellipsis — full sat counts are the point. */
.opp-featured-subtitle-text.opp-amount {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-variant-numeric: tabular-nums;
  white-space: normal;
  overflow: visible;
  text-overflow: unset;
  word-break: keep-all;
}

.opp-featured-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  flex: 1;
}

.opp-featured-title {
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.opp-featured-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.opp-featured-subtitle-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
}

.opp-featured-meta-line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  color: var(--opp-muted);
}

.opp-featured-meta-line-bare {
  align-items: center;
}

.opp-featured-meta-key {
  flex-shrink: 0;
  opacity: 0.75;
  min-width: 2.5em;
}

.opp-featured-meta-value {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  flex: 1;
}

.opp-featured-meta-value-mono {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 11px;
}

.opp-trust-wrap {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0 20px 8px;
}

.opp-trust {
  display: inline-flex;
  align-self: flex-start;
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 600;
}

.opp-trust-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-trust-note {
  padding: 10px;
  border-radius: 8px;
  font-size: 11px;
  line-height: 1.35;
}

.opp-trust-note-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-note-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-note-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.opp-row-key {
  color: var(--opp-muted);
  flex-shrink: 0;
}

.opp-row-value-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 70%;
  justify-content: flex-end;
}

.opp-row-value {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 12px;
  font-weight: 500;
  text-align: right;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.opp-copy {
  flex-shrink: 0;
  width: 22px;
  height: 22px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  border: 1px solid var(--opp-reject-border);
  background: var(--opp-bg);
  color: var(--opp-fg);
  cursor: pointer;
}

.opp-copy:hover {
  border-color: var(--opp-accent);
  color: var(--opp-accent);
}

.opp-fee-note {
  font-size: 11px;
  color: var(--opp-muted);
  line-height: 1.3;
  margin-top: -4px;
}

.opp-actions {
  display: flex;
  gap: 12px;
  padding: 20px 20px 12px;
}

.opp-button {
  flex: 1;
  padding: 0 16px;
  height: 48px;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid transparent;
  transition: opacity 120ms ease;
}

.opp-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.opp-button-reject {
  background: var(--opp-reject-bg);
  color: var(--opp-reject-fg);
  border-color: var(--opp-reject-border);
}

.opp-button-approve {
  background: var(--opp-approve-bg);
  color: var(--opp-approve-fg);
}

.opp-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 20px 16px;
  font-size: 11px;
  font-weight: 500;
  color: var(--opp-muted);
}
`;function Yt({request:t,onApprove:s,onReject:a,theme:o="auto",services:r}){const i=rs(o),f=Xt(t),[l,n]=p.useState(!1),[x,g]=p.useState(),w=t.kind==="transaction"&&Ye(t.payload)?t.payload:void 0;p.useEffect(()=>{if(!r||!w?.trust||!w.verify)return;let d=!0;const j=r.ordfs?.getContentUrl?.bind(r.ordfs);return Gt(r,w.verify.kind,w.verify.inputs,w.verify.outputs,j).then(N=>{d&&N&&g(N)}).catch(()=>{}),()=>{d=!1}},[r,w]);const c=x?Jt(f,x):f,m=d=>()=>{if(!l){n(!0);try{d==="approve"?s():a()}finally{n(!1)}}};p.useEffect(()=>{const d=j=>{l||(j.key==="Escape"?a():j.key==="Enter"&&s())};return window.addEventListener("keydown",d),()=>window.removeEventListener("keydown",d)},[s,a,l]);const b=`opp-root${i==="dark"?" opp-dark":""}`;return e.jsxs("div",{className:b,children:[e.jsx("style",{children:Kt}),e.jsxs("div",{className:"opp-body",children:[e.jsxs("svg",{className:"opp-coin",viewBox:"0 0 100 100","aria-label":"1Sat Ordinals",children:[e.jsx("circle",{cx:"50",cy:"50",r:"50",fill:"#222"}),e.jsx("circle",{cx:"50",cy:"50",r:"40",fill:"#fff"}),e.jsx("circle",{cx:"50",cy:"50",r:"32",fill:"#E5A920"}),e.jsx("rect",{x:"47",y:"28",width:"6",height:"28",rx:"3",fill:"#fff"})]}),e.jsx("h2",{className:"opp-title",children:c.title}),e.jsx("p",{className:"opp-subtitle",children:c.subtitle}),e.jsx("div",{className:"opp-status",children:"Awaiting Approval"})]}),c.panels.map((d,j)=>{const N=d.variant??"ordinal",u=["opp-featured"];return N==="token"&&u.push("opp-featured-token"),N==="value"&&u.push("opp-featured-value"),d.tone==="danger"&&u.push("opp-featured-danger"),e.jsxs("div",{className:u.join(" "),children:[d.prior?e.jsxs("div",{className:"opp-preview-pair","aria-label":"Previous and new inscription",children:[e.jsx(we,{panel:{...d,previewKind:d.prior.previewKind,imageUrl:d.prior.imageUrl,contentUrl:d.prior.contentUrl,previewText:d.prior.previewText,prior:void 0}}),e.jsx("span",{className:"opp-preview-arrow","aria-hidden":!0,children:"→"}),e.jsx(we,{panel:d})]}):e.jsx(we,{panel:d}),e.jsxs("div",{className:"opp-featured-meta",children:[e.jsx("div",{className:"opp-featured-title",children:d.title}),d.subtitle&&e.jsxs("div",{className:"opp-featured-subtitle",children:[e.jsx("span",{className:d.amountSats!=null?"opp-featured-subtitle-text opp-amount":"opp-featured-subtitle-text",children:d.subtitle}),d.subtitleCopy&&e.jsx(ke,{text:d.subtitleCopy})]}),(d.meta??[]).map(h=>e.jsxs("div",{className:`opp-featured-meta-line${h.key?"":" opp-featured-meta-line-bare"}`,children:[h.key?e.jsx("span",{className:"opp-featured-meta-key",children:h.key}):null,e.jsx("span",{className:`opp-featured-meta-value${h.key?"":" opp-featured-meta-value-mono"}`,title:h.copyValue??h.value,children:h.value}),h.copyValue&&e.jsx(ke,{text:h.copyValue})]},`${h.key}:${h.value}`))]})]},`panel-${j}-${d.title}`)}),c.trust&&e.jsxs("div",{className:"opp-trust-wrap",children:[e.jsx("span",{className:`opp-trust opp-trust-${c.trust.state}`,children:es(c.trust.state)}),c.trust.note&&e.jsx("div",{className:`opp-trust-note opp-trust-note-${c.trust.state}`,children:c.trust.note})]}),(c.rows.length>0||c.indexerFee||c.funding)&&e.jsxs("div",{className:"opp-card",children:[c.rows.map(d=>e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:d.key}),e.jsxs("span",{className:"opp-row-value-wrap",children:[e.jsx("span",{className:"opp-row-value",title:d.copyValue??d.value,children:d.value}),d.copyValue&&e.jsx(ke,{text:d.copyValue})]})]},`${d.key}:${d.value}`)),c.indexerFee&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"1Sat Overlay Fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[Oe(c.indexerFee.sats)," sats"]})]}),c.funding?.networkFeeSats!=null&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"Network fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[Oe(c.funding.networkFeeSats)," sats"]})]}),c.funding?.note&&e.jsx("div",{className:"opp-fee-note",children:c.funding.note})]}),e.jsxs("div",{className:"opp-bottom",children:[e.jsxs("div",{className:"opp-actions",children:[e.jsx("button",{type:"button",className:"opp-button opp-button-reject",onClick:m("reject"),disabled:l,children:"Reject"}),e.jsx("button",{type:"button",className:"opp-button opp-button-approve",onClick:m("approve"),disabled:l,children:"Approve"})]}),e.jsx("div",{className:"opp-footer",children:e.jsx("span",{children:"Secured by 1Sat Ordinals"})})]})]})}function Xt(t){if(t.kind==="transaction"&&Ye(t.payload))return{title:t.payload.title,subtitle:t.payload.subtitle,panels:t.payload.panels,rows:t.payload.rows,trust:t.payload.trust,indexerFee:t.payload.indexerFee,funding:t.payload.funding};if(t.kind==="basketAccess"){const s=t.payload.baskets??[],a=s.length>0&&s.every(i=>i.scope||i.basket.startsWith("p ")),o=s.filter(i=>i.imageUrl||i.name||i.value).map(i=>({title:i.scope==="collection"?i.name?`Collection · ${i.name}`:"Collection":i.scope?i.scope:"Basket",subtitle:i.value?i.value.length>24?`${i.value.slice(0,10)}…${i.value.slice(-10)}`:i.value:i.basket,subtitleCopy:i.value,...i.imageUrl&&{previewKind:"image",contentUrl:i.imageUrl,imageUrl:i.imageUrl},tone:"default"})),r=s.flatMap(i=>i.scope==="collection"?i.description?[{key:"Access",value:i.description}]:[]:[{key:i.basket,value:i.description??"List, insert, and remove outputs"}]);return{title:a?s.length===1?s[0].scope==="collection"?"Grant Collection View":"Grant Item View":`Grant View (${s.length})`:s.length===1?"Grant Basket Access":`Grant Access to ${s.length} Baskets`,subtitle:a?`${ie(t.originator)} wants to view items in your wallet`:`${ie(t.originator)} wants to read and write 1Sat baskets`,panels:o,rows:r}}return t.kind==="protocol"?{title:"Protocol Access",subtitle:`${ie(t.originator)} wants protocol access`,panels:[],rows:[{key:"Detail",value:t.summary||"Protocol request"}]}:{title:"Signature Request",subtitle:`${ie(t.originator)} wants a signature`,panels:[],rows:[{key:"Detail",value:t.summary||"Signature request"}]}}function Jt(t,s){const a=t.panels.map((o,r)=>{if(r!==0)return o;const i=o.previewKind==="opns",f=s.contentType?Zt(s.contentType):void 0,l=i?"opns":f&&f!=="none"?f:o.previewKind,n=s.contentUrl??o.contentUrl??o.imageUrl;let x=o.subtitle;if(s.name&&!i)if(!x)x=s.name;else{const g=x.trim().split(/\s+/);g.length>=2&&(g[g.length-1]=s.name,x=g.join(" "))}return{...o,previewKind:l,...x?{subtitle:x}:{},...i?{...s.contentUrl&&!o.imageUrl?{imageUrl:s.contentUrl}:o.imageUrl?{imageUrl:o.imageUrl}:{}}:l==="image"?{imageUrl:n,contentUrl:n}:n?{contentUrl:n,imageUrl:void 0}:{}}});return{...t,panels:a,trust:{state:s.state,note:s.note}}}function Zt(t){const s=t.toLowerCase();return s==="image/svg+xml"||s==="svg"||s.endsWith("+svg")?"svg":s.startsWith("image/")?"image":s.includes("json")?"json":s.includes("html")||s==="application/xhtml+xml"?"html":s.startsWith("text/")?"text":"none"}function Qt(t){return`${t.toLocaleString("en-US")} sats`}function Oe(t){return t.toLocaleString("en-US")}function es(t){return t==="verified"?"Verified":t==="mismatch"?"Mismatch":"Unverified"}function we({panel:t}){const s=t.variant??"ordinal",a=s==="token"?"opp-featured-image opp-featured-image-token":s==="value"?"opp-featured-image opp-preview-value":"opp-featured-image",o=t.previewKind??(t.imageUrl?"image":"none"),r=t.contentUrl??t.imageUrl,[i,f]=p.useState(!1);if(s==="value"){const l=t.valueIcon??"pay";return e.jsx("div",{className:a,title:t.amountSats!=null?Qt(t.amountSats):void 0,"aria-hidden":!0,children:e.jsx(ss,{kind:l})})}if(o==="opns"){const l=!!t.imageUrl&&!i;return e.jsxs("div",{className:`${a} opp-preview-opns`,"aria-hidden":!t.opnsHero,children:[l?e.jsx("img",{className:"opp-preview-opns-avatar",src:t.imageUrl,alt:"",onError:()=>f(!0)}):e.jsx("div",{className:"opp-preview-opns-avatar opp-featured-placeholder",children:"◈"}),e.jsx("span",{className:"opp-preview-opns-name",title:t.opnsHero,children:t.opnsHero??"OpNS"})]})}return o==="image"&&t.imageUrl&&!i?e.jsx("img",{className:a,src:t.imageUrl,alt:t.title,onError:()=>f(!0)}):o==="image"&&i?e.jsx("div",{className:`${a} opp-featured-placeholder`,"aria-hidden":!0,children:"▭"}):(o==="text"||o==="json"||o==="html")&&t.previewText?e.jsx("pre",{className:`${a} opp-preview-text${o==="json"?" opp-preview-json":""}`,children:t.previewText}):(o==="text"||o==="json")&&r?e.jsx(os,{url:r,kind:o,className:a}):(o==="html"||o==="svg")&&r?e.jsx("iframe",{className:`${a} opp-preview-frame`,src:r,title:`${t.title} preview`,sandbox:"",referrerPolicy:"no-referrer"}):e.jsx("div",{className:`${a} opp-featured-placeholder`,"aria-hidden":!0,children:s==="token"?"◎":ts(o)})}function ts(t){return t==="text"||t==="json"?"¶":t==="html"||t==="svg"?"⌂":"▭"}function ss({kind:t}){return t==="lock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V8a4 4 0 018 0v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):t==="unlock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V7.5A4 4 0 0116 7",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("path",{d:"M16 4.5v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"9",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M12 7v10M9 10.5c0-1.4 1.3-2.5 3-2.5s3 1.1 3 2.5-1.3 2.5-3 2.5-3 1.1-3 2.5 1.3 2.5 3 2.5 3-1.1 3-2.5",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})}function os({url:t,kind:s,className:a}){const[o,r]=p.useState(null),[i,f]=p.useState(!1);return p.useEffect(()=>{let l=!1;return r(null),f(!1),fetch(t).then(async n=>{if(!n.ok)throw new Error(String(n.status));const x=await n.text();if(!l){if(s==="json")try{r(JSON.stringify(JSON.parse(x),null,2));return}catch{}r(x.slice(0,800))}}).catch(()=>{l||f(!0)}),()=>{l=!0}},[t,s]),i?e.jsx("div",{className:`${a} opp-featured-placeholder`,"aria-hidden":!0,children:"¶"}):e.jsx("pre",{className:`${a} opp-preview-text${s==="json"?" opp-preview-json":""}`,children:o??"…"})}function ke({text:t}){const[s,a]=p.useState(!1),o=()=>{navigator.clipboard?.writeText(t).then(()=>{a(!0),window.setTimeout(()=>a(!1),1200)})};return e.jsx("button",{type:"button",className:"opp-copy",onClick:o,"aria-label":s?"Copied":"Copy full value",title:s?"Copied":"Copy",children:s?e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:e.jsx("path",{d:"M5 13l4 4L19 7",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round"})}):e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"9",y:"9",width:"11",height:"11",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M5 15V5a2 2 0 012-2h10",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})})}function rs(t){const[s,a]=p.useState(()=>t==="auto"?ns():t);return p.useEffect(()=>{if(t!=="auto"){a(t);return}const o=window.matchMedia("(prefers-color-scheme: dark)"),r=()=>a(o.matches?"dark":"light");return r(),o.addEventListener("change",r),()=>o.removeEventListener("change",r)},[t]),s}function ns(){return typeof window>"u"||!window.matchMedia?"light":window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function ie(t){try{return new URL(t.includes("://")?t:`https://${t}`).host||t}catch{return t.length<=32?t:`${t.slice(0,14)}…${t.slice(-12)}`}}const as=({request:t,onResponse:s})=>{const{theme:a}=q(),{handleSelect:o,hideMenu:r}=oe(),{apiContext:i,chromeStorageService:f}=H(),l=i?.services;p.useEffect(()=>{o("bsv"),r()},[o,r]);const[n,x]=p.useState(""),g=p.useRef(!1),w=async b=>{if(!g.current){if(g.current=!0,b){x("");const d=await G(f);if(!d.ok){x(d.message),g.current=!1;return}}B({action:"ONE_SAT_PERMISSION_RESPONSE",requestID:t.requestID,approved:b}),s()}},m=a.color.global.walletBackground.toLowerCase()==="#000000"||/^#[01]/.test(a.color.global.walletBackground)?"dark":"light";return e.jsxs("div",{style:{width:"100%",height:"100%",overflowY:"auto",display:"flex",flexDirection:"column",alignItems:"stretch",justifyContent:"center"},children:[n&&e.jsx("p",{className:"text-xs text-center m-0 pt-2",style:{color:"#ef4444"},children:n}),e.jsx(Yt,{request:t.request,onApprove:()=>{w(!0)},onReject:()=>{w(!1)},theme:m,services:l})]})},is=t=>{switch(t){case"protocol":return"Protocol Permission";case"basket":return"Basket Access";case"certificate":return"Certificate Access";case"spending":return"Spending Authorization";default:return"Permission Request"}},ls=t=>{switch(t.type){case"protocol":{const s=Ve(t.protocolID);return s?s.description:`An application is requesting permission to use protocol "${t.protocolID?.[1]||"unknown"}" with security level ${t.protocolID?.[0]||0}.`}case"basket":return`An application is requesting access to basket "${t.basket||"unknown"}".`;case"certificate":return"An application is requesting access to certificate data.";case"spending":return`An application is requesting authorization to spend ${t.spending?.satoshis||0} satoshis.`;default:return"An application is requesting a permission."}},Ue=t=>t>=1e8?`${(t/1e8).toFixed(8)} BSV`:`${t.toLocaleString()} satoshis`,cs=t=>{const{request:s,onResponse:a}=t,{theme:o}=q(),{handleSelect:r,hideMenu:i}=oe(),{addSnackbar:f}=de(),[l,n]=p.useState(!1),[x,g]=p.useState(""),{chromeStorageService:w}=H();p.useEffect(()=>{r("bsv"),i()},[r,i]);const c=async()=>{n(!0),g("");try{const b=await G(w);if(!b.ok){g(b.message),n(!1);return}pe(s.originator),B({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!0}),a()}catch(b){const d=b instanceof Error?b.message:String(b);f(d,"error"),n(!1)}},m=async()=>{n(!0),B({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!1}),a()};return e.jsxs(R.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(qe,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:is(s.type)}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:ls(s)})]})]}),e.jsxs(R.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"12rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Origin"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.displayOriginator||s.originator})]}),e.jsxs(I,{when:s.type==="protocol"&&!!s.protocolID,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Protocol"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:Ge(s.protocolID)})]}),e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.counterparty?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Security"}),e.jsx("span",{className:"text-xs",style:{color:o.color.global.contrast},children:Ft(s.protocolID?.[0])})]}),e.jsx(I,{when:!!s.counterparty,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.counterparty})]})})]}),e.jsx(I,{when:s.type==="basket"&&!!s.basket,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Basket"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.basket})]})}),e.jsxs(I,{when:s.type==="certificate"&&!!s.certificate,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Cert Type"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.certType})]}),e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Fields"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.fields.join(", ")})]})]}),e.jsxs(I,{when:s.type==="spending"&&!!s.spending,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.spending?.lineItems?.length?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Amount"}),e.jsx("span",{className:"text-xs font-semibold",style:{color:"var(--bw-accent-hi)"},children:Ue(s.spending?.satoshis||0)})]}),e.jsx(I,{when:!!s.spending?.lineItems?.length,children:s.spending?.lineItems?.map((b,d)=>e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:d<(s.spending?.lineItems?.length??0)-1?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:b.type}),e.jsxs("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:[b.description," (",Ue(b.satoshis),")"]})]},d))})]}),e.jsx(I,{when:!!s.reason,children:e.jsxs("div",{className:"flex flex-row py-2",style:{borderTop:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Reason"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.reason})]})})]}),e.jsx(I,{when:!!s.privileged,children:e.jsxs(R.div,{className:"flex items-start gap-2 rounded-xl px-3 py-2.5 mb-4",style:{background:"rgba(245,166,35,0.08)",border:"1px solid rgba(245,166,35,0.15)"},initial:{opacity:0},animate:{opacity:1},transition:{delay:.12},children:[e.jsx(lt,{size:14,className:"mt-0.5 flex-shrink-0",style:{color:"#f5a623"}}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:"#f5a623"},children:"This is a privileged operation"})]})}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[x&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:x}),e.jsxs(R.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:l?.6:1},disabled:l,onClick:c,whileHover:{scale:l?1:1.02},whileTap:{scale:l?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[l&&e.jsx(Ce,{size:14,className:"animate-spin"}),"Allow"]}),e.jsx(R.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:l?.5:1},disabled:l,onClick:m,whileHover:{scale:l?1:1.02},whileTap:{scale:l?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny"})]})]})},ds=({request:t,onResponse:s})=>{const{theme:a}=q(),{chromeStorageService:o}=H(),[r,i]=p.useState(""),[f,l]=p.useState(!1),n=async w=>{if(!f){if(l(!0),i(""),w){const c=await G(o);if(!c.ok){i(c.message),l(!1);return}}B({action:"USB_CHECK_RESPONSE",requestID:t.requestID,ok:w}),s()}},x=a.color.global.gray,g=a.color.global.contrast;return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(ct,{size:40,style:{color:g}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:g},children:"Confirm your USB key"}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:x,maxWidth:"18rem"},children:[t.originator?`${t.originator} is asking bWallet to ${t.reason}.`:`A site is asking bWallet to ${t.reason}.`," ","Insert your USB key, then confirm."]}),r&&e.jsx("p",{className:"m-0 text-xs",style:{color:"#ef4444"},children:r}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(le,{theme:a,type:"primary",label:"Confirm USB key",disabled:f,onClick:()=>{n(!0)}}),e.jsx(le,{theme:a,type:"secondary-outline",label:"Cancel",disabled:f,onClick:()=>{n(!1)}})]})]})},ps="bwalletx.trust-site",us=new Set(["default","1sat","bsv21","lock","opns","fund","funding","vesting",ps]),fs=t=>{if(typeof t!="string")return!1;const s=t.trim().toLowerCase();return s?us.has(s)||s.startsWith("admin")||s.startsWith("bwalletx."):!1},Le=5,je=[0,1,5,20],xs=/e-?mail|phone|mobile|kyc|passport|licen[cs]e|birth|dob|address|ssn|national|tax|id_?number/i,Se=t=>String(t.protocolID?.[1]??"unknown"),Xe=t=>Number(t.protocolID?.[0]??0),Je=t=>!!(t.privileged||t.type==="certificate"&&(t.certificate?.fields??[]).some(s=>xs.test(s))),Ze=t=>t.type==="protocol"&&!t.privileged&&t.protocolID?.[1]==="identity key retrieval"&&(t.counterparty===void 0||t.counterparty==="self"),ms=t=>{switch(t.type){case"protocol":return Ze(t)?"See your public identity (the key that names you)":t.counterparty==="anyone"?"Prove it's you (a signature anyone can check)":Xe(t)===2&&t.counterparty&&t.counterparty!=="self"?`Sign and encrypt with your "${Se(t)}" keys, shared with one named person or service`:`Sign and encrypt anything with your "${Se(t)}" keys`;case"basket":return"Keep its tickets and tokens in your wallet";case"certificate":{const s=t.certificate?.fields??[];return s.length?`See your certificate details (${s.join(", ")})`:"See your certificates"}default:return"Spend from your wallet"}},Ne=t=>{const s=[];switch(t.type){case"protocol":s.push(`protocol "${Se(t)}" level ${Xe(t)}`),t.counterparty&&s.push(`counterparty ${t.counterparty}`);break;case"basket":s.push(`basket "${t.basket??""}"`);break;case"certificate":s.push(`certificate ${t.certificate?.certType??""}`,`verifier ${t.certificate?.verifier??""}`);break;case"spending":s.push(`${t.spending?.satoshis??0} sats`);break}return t.privileged&&s.push("privileged"),t.reason&&s.push(`reason: ${t.reason}`),s.join(" · ")},hs=t=>{const s=[];let a;for(const r of t.items){if(r.type==="spending"){const l=r.spending?.satoshis??0;a?s.push({requestID:r.requestID,text:`Also pay ${l.toLocaleString()} sats`,detail:Ne(r),risky:!0,checked:!1}):a={requestID:r.requestID,satoshis:l,description:r.spending?.lineItems?.find(n=>n.description)?.description??r.reason,detail:Ne(r)};continue}const i=Je(r),f=!i&&(r.type!=="protocol"||r.counterparty==="anyone"||Ze(r));s.push({requestID:r.requestID,text:ms(r),detail:Ne(r),risky:i,checked:f})}const o=a?s.length?"connectAndPay":"pay":"connect";return{originator:t.originator,lines:s,payment:a,mode:o}},gs=t=>Je(t)||t.type==="protocol"&&t.counterparty==="anyone"?!1:t.type==="basket"?!!t.basket&&!fs(t.basket):!1,ys=t=>t.items.some(s=>gs(s)),se=t=>t<1?`${Math.round(t*100)}¢`:`$${t.toFixed(2)}`,bs=t=>t>=1e8?`${(t/1e8).toFixed(8)} BSV`:`${t.toLocaleString()} sats`,vs=t=>{const{request:s,onResponse:a,armed:o=!0}=t,{handleSelect:r,hideMenu:i}=oe(),{addSnackbar:f}=de(),{chromeStorageService:l}=H(),n=l.getCurrentAccountObject().account,x=vt(n?.addresses?.identityAddress,n?.name??"",n?.settings?.socialProfile?.displayName??"",!1),g=wt(x.displayName,x.paymail,x.handle).tag,w=kt(n?.pubKeys?.identityPubKey),c=p.useMemo(()=>hs(s),[s]),[m,b]=p.useState({}),d=p.useRef(s.items.length),j=Math.max(0,s.items.length-d.current),N=(y,S)=>m[y]??S,[u,h]=p.useState(),[k,P]=p.useState(Le),[T,V]=p.useState(!0),[M,ue]=p.useState(!0),re=p.useMemo(()=>ys(s),[s]),[K,v]=p.useState(!0),[C,D]=p.useState(!1),[$,O]=p.useState(!1),[U,Pe]=p.useState("");p.useEffect(()=>{r("bsv"),i()},[r,i]),p.useEffect(()=>{W({action:"GET_BUNDLE_ALLOWANCE",originator:s.originator}).then(y=>{!y?.success||!y.data||(h(y.data),P(y.data.defaultUsd))}).catch(()=>{})},[s.originator]);const fe=!!u?.usdPerBsv&&u.existingSats===void 0,xe=c.payment&&u?.usdPerBsv?c.payment.satoshis/1e8*u.usdPerBsv:void 0,me=async y=>{O(!0),Pe("");try{if(y){const A=await G(l);if(!A.ok){Pe(A.message),O(!1);return}}y&&pe(s.originator);const S={};for(const A of c.lines)S[A.requestID]=y&&N(A.requestID,A.checked);c.payment&&(S[c.payment.requestID]=y),await W({action:"BUNDLE_PERMISSION_RESPONSE",bundleID:s.bundleID,decisions:S,allowanceUsd:y&&fe&&T?k:0,remember:M,trustSite:y&&M&&re&&K}),a()}catch(S){f(S instanceof Error?S.message:String(S),"error"),O(!1)}},L=It(c,{existingAllowanceSats:u?.existingSats}),he=Dt(s.originator),et=c.lines.length+(c.payment?1:0)>1,Y=xe!==void 0?se(xe):c.payment?bs(c.payment.satoshis):"",X=fe&&T&&k>0?k:0,Ae=u?.existingSats!==void 0&&u.usdPerBsv?u.existingSats/1e8*u.usdPerBsv:void 0,tt=L==="signin"?"Sign in":L==="pay"?c.mode==="connectAndPay"?`Connect & pay ${Y}`:`Pay ${Y}`:et?"Allow all":"Connect",st=()=>{const y=je.indexOf(k),S=je[(y+1)%je.length];P(S),V(S>0)},ge=$||!o,J=L==="careful",ne=c.lines.filter(y=>y.risky),ot=(y,S)=>b(A=>({...A,[y]:!N(y,S)})),Te=(y,S=!1)=>e.jsxs("label",{className:"flex items-center gap-3 cursor-pointer",style:{minHeight:44,padding:S?"10px 14px":"6px 0",borderRadius:S?14:0,background:S?E.redChip:void 0,fontSize:S?14:13},children:[e.jsx("input",{type:"checkbox",checked:N(y.requestID,y.checked),onChange:()=>ot(y.requestID,y.checked),style:{width:18,height:18,accentColor:y.risky?E.red:E.gold,flexShrink:0}}),e.jsx("span",{style:{color:y.risky?"#FF6B6B":void 0},children:y.text})]},y.requestID),ye=(g||w)&&e.jsxs("span",{children:[e.jsx("span",{style:{color:E.gold},children:g||"this account"}),w&&e.jsxs("span",{className:"font-mono",style:{userSelect:"none",fontSize:12,color:E.muted},children:[" ","· ",w]})]}),rt=e.jsxs("div",{className:"flex flex-col",style:{gap:4},children:[(g||w)&&e.jsxs("p",{className:"m-0","data-testid":"signing-as",style:{fontSize:12},children:["Signing in as ",ye]}),j>0&&e.jsxs("p",{className:"m-0",style:{fontSize:12,color:E.green},children:["+",j," more added while this was open"]}),c.lines.map(y=>Te(y)),c.payment&&e.jsxs("p",{className:"m-0",style:{padding:"6px 0"},children:["Pay now: ",e.jsx("span",{style:{color:E.gold,fontWeight:600},children:Y})," to ",s.originator,c.payment.description&&e.jsxs(e.Fragment,{children:[" “",c.payment.description,"”"]})]}),fe&&e.jsxs("div",{className:"flex items-center gap-3",style:{minHeight:44},children:[e.jsx("input",{type:"checkbox",checked:T&&k>0,onChange:()=>{k===0&&P(Le),V(!(T&&k>0))},style:{width:18,height:18,accentColor:E.gold,flexShrink:0},"aria-label":"Monthly allowance"}),e.jsx("span",{className:"flex-1",children:k>0?`Spend up to ${se(k)} a month without asking`:"Ask me before every payment"}),e.jsx("button",{type:"button",className:"border-0 bg-transparent underline",style:{color:E.gold,minHeight:44,padding:"0 4px",fontSize:13},onClick:st,children:"change"})]}),e.jsxs("label",{className:"flex items-center gap-3 cursor-pointer",style:{minHeight:44},children:[e.jsx("input",{type:"checkbox",checked:M,onChange:()=>ue(!M),style:{width:18,height:18,accentColor:E.gold,flexShrink:0}}),e.jsx("span",{children:"Remember this site"})]}),re&&M&&e.jsxs("label",{className:"flex items-start gap-3 cursor-pointer",style:{padding:"6px 0"},children:[e.jsx("input",{type:"checkbox",checked:K,onChange:()=>v(!K),style:{width:18,height:18,accentColor:E.gold,flexShrink:0,marginTop:1}}),e.jsxs("span",{children:["Don't ask again on ",s.originator," for sign-in and signing. Payments stay within the allowance; your personal details always ask."]})]}),e.jsxs("ul",{className:"m-0 mt-1 pl-4 break-all",style:{fontSize:11,color:E.muted},children:[c.payment&&e.jsxs("li",{children:["pay: ",c.payment.detail]}),c.lines.map(y=>e.jsx("li",{children:y.detail},y.requestID)),X>0&&e.jsxs("li",{children:["allowance: monthly spending cap for ",s.originator]})]})]}),Re={label:J?"No, block it":"Not now",onClick:()=>{me(!1)},disabled:ge},Ie={label:J?"I trust it, allow":tt,onClick:()=>{me(!0)},disabled:ge,busy:$};let Z,Q,ee=null,te;const be=y=>e.jsx("span",{style:{color:E.gold},children:y});if(L==="careful"){Z=e.jsx(Et,{}),te="Check this carefully";const y=s.items.some(_=>_.privileged),S=ne.some(_=>s.items.find(nt=>nt.requestID===_.requestID)?.type==="certificate"),A=_=>e.jsx("span",{style:{color:"#FF6B6B"},children:_});Q=y?e.jsxs(e.Fragment,{children:["Wants ",A("full control")," of your keys"]}):S?e.jsxs(e.Fragment,{children:["Wants your ",A("private details")]}):c.payment&&ne.length===0?e.jsxs(e.Fragment,{children:[A(Y)," is over your allowance"]}):e.jsxs(e.Fragment,{children:["Wants ",A("more than usual")]}),ee=e.jsxs("div",{className:"flex flex-col",style:{gap:8},children:[y&&e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:E.redChip,fontSize:14},children:[e.jsx(ve,{}),"Could move your money"]}),ne.length===0&&c.payment&&e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:E.redChip,fontSize:14},children:[e.jsx(ve,{}),Ae!==void 0?`Your allowance here is ${se(Ae)} a month`:"More than this site may spend"]}),ne.map(_=>Te(_,!0)),e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:E.redChip,fontSize:14},children:[e.jsx(ve,{}),"Only allow apps you trust"]})]})}else if(L==="pay")Z=e.jsx(jt,{amount:Y,sub:xe!==void 0&&c.payment?`${c.payment.satoshis.toLocaleString()} sats`:void 0}),te=c.payment?.description||"Asks you to pay",Q=e.jsxs(e.Fragment,{children:["Pay ",be(he)]}),ee=e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex items-center gap-3",style:{padding:14,borderRadius:16,background:E.chip},children:[e.jsx(Nt,{site:s.originator,size:44}),e.jsxs("div",{className:"flex flex-col min-w-0",style:{gap:2,lineHeight:1.25},children:[e.jsxs("span",{className:"truncate",style:{fontSize:15,fontWeight:600},children:["To ",s.originator]}),e.jsx("span",{className:"truncate",style:{fontSize:13,color:E.muted},children:c.payment?.description?`“${c.payment.description}”`:"Straight from your wallet"})]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:E.soft},children:[e.jsx(ae,{size:18}),X>0?`Then up to ${se(X)} a month without asking`:"Every payment asks you first"]})]});else if(L==="signin")Z=e.jsx(Pt,{}),te="Sign-in request",Q=e.jsxs(e.Fragment,{children:["Sign in to ",be(he)]}),ee=e.jsxs(e.Fragment,{children:[ye&&e.jsxs("div",{className:"flex items-center gap-2.5",children:[e.jsx("div",{"aria-hidden":"true",style:{width:30,height:30,borderRadius:15,background:"conic-gradient(#F5C542, #B8860B, #FFE08A, #F5C542)",flexShrink:0}}),e.jsxs("span",{style:{fontSize:18,fontWeight:600},children:["as ",ye]})]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs(Be,{children:[e.jsx(ae,{}),"No password"]}),e.jsxs(Be,{children:[e.jsx(ae,{}),"No money moves"]})]})]});else{Z=e.jsx(St,{site:s.originator}),te="Wants to connect",Q=e.jsxs(e.Fragment,{children:["Use ",be("bWalletX")," on ",he]});const y=new Set(s.items.map(A=>A.type)),S=[{label:y.has("certificate")?"Your details":"Your name",icon:e.jsx(ws,{})}];y.has("protocol")&&S.push({label:"Sign posts",icon:e.jsx(ks,{})}),y.has("basket")&&S.push({label:"Keep items",icon:e.jsx(js,{})}),ee=e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"grid",style:{gridTemplateColumns:`repeat(${S.length}, minmax(0, 1fr))`,gap:8},children:S.map(A=>e.jsxs("div",{className:"flex flex-col items-center",style:{gap:8,padding:"14px 6px",borderRadius:16,background:E.chip},children:[A.icon,e.jsx("span",{style:{fontSize:13,fontWeight:600,textAlign:"center"},children:A.label})]},A.label))}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:E.soft},children:[e.jsx(ae,{size:18}),X>0?`Payments over ${se(X)} a month ask you first`:"Payments still ask you first"]})]})}return e.jsx(R.div,{className:"flex flex-col w-full h-full",style:{maxHeight:"100vh"},initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{type:"spring",damping:24,stiffness:260},"data-approval-kind":L,children:e.jsx(Ct,{tone:J?"red":"gold",site:s.originator,siteSub:te,onClose:()=>{me(!1)},closeLabel:"Deny and close",closeDisabled:ge,hero:Z,title:Q,primary:J?Re:Ie,secondary:J?Ie:Re,details:rt,detailsOpen:C,onToggleDetails:()=>D(!C),error:U,children:ee})})},Ee={"aria-hidden":!0,width:28,height:28,viewBox:"0 0 24 24",fill:"none",stroke:E.gold,strokeWidth:1.8,strokeLinecap:"round",strokeLinejoin:"round"},ws=()=>e.jsxs("svg",{...Ee,children:[e.jsx("circle",{cx:"12",cy:"8",r:"4"}),e.jsx("path",{d:"M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"})]}),ks=()=>e.jsxs("svg",{...Ee,children:[e.jsx("path",{d:"M12 20h9"}),e.jsx("path",{d:"M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"})]}),js=()=>e.jsxs("svg",{...Ee,children:[e.jsx("rect",{x:"3",y:"7",width:"18",height:"13",rx:"2"}),e.jsx("path",{d:"M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"})]}),Ns=({request:t,onResponse:s})=>{const{theme:a}=q(),o=t.usdPerBsv,r=t.capSatsPerHour,i=o?r/1e8*o:void 0,[f,l]=p.useState(i!==void 0?i.toFixed(2):""),[n,x]=p.useState(String(r)),[g,w]=p.useState(!1),c=p.useMemo(()=>{const u=o?dt(Number(f),o):Math.floor(Number(n));return Number.isFinite(u)&&u>=1?Math.min(u,r):0},[f,n,o,r]),m=u=>{g||(w(!0),B({action:"STREAM_GRANT_RESPONSE",requestID:t.requestID,capSatsPerHour:u?c:null}),s())},b=a.color.global.gray,d=a.color.global.contrast,j=new Date(t.expiresAt).toLocaleString(),N=De(r,o)??`${r.toLocaleString()} sats`;return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(At,{size:36,style:{color:d}}),e.jsxs("h2",{className:"m-0 text-lg font-semibold",style:{color:d},children:["Allow ",t.originator," to stream up to ",N,"/hour while you watch"]}),o&&e.jsxs("p",{className:"m-0 text-xs",style:{color:b},children:[r.toLocaleString()," sats an hour at most"]}),t.description&&e.jsx("p",{className:"m-0 text-xs",style:{color:b,maxWidth:"18rem"},children:t.description}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:b,maxWidth:"18rem"},children:["Only “",t.protocolName,"” payments from ",t.originator," go through without asking, until ",j,". Anything else still asks you. Revoke any time in Settings › Streaming permissions."]}),e.jsxs("label",{className:"flex items-center gap-2 text-sm",style:{color:d},children:["Cap per hour ",o?"$":"",o?e.jsx("input",{"aria-label":"Cap in dollars per hour",inputMode:"decimal",value:f,onChange:u=>l(u.target.value),className:"w-24 px-2 py-1 rounded bg-transparent border",style:{color:d}}):e.jsx("input",{"aria-label":"Cap in sats per hour",inputMode:"numeric",value:n,onChange:u=>x(u.target.value),className:"w-28 px-2 py-1 rounded bg-transparent border",style:{color:d}}),!o&&"sats"]}),e.jsxs("p",{className:"m-0 text-xs",style:{color:b},children:[c?`${De(c,o)??""} ${c.toLocaleString()} sats/hour`:"Enter a cap above zero",c===r?" (the most this site asked for)":""]}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(le,{theme:a,type:"primary",label:"Allow",disabled:g||!c,onClick:()=>m(!0)}),e.jsx(le,{theme:a,type:"secondary-outline",label:"Not now",disabled:g,onClick:()=>m(!1)})]})]})},z={bg:"#0B0B0D",text:"#FFFFFF",muted:"#98A2B3",gold:"#F5C542",line:"#2B2F36"};function Ss(t){const[s,a]=p.useState(null);return p.useEffect(()=>{if(!t)return;let o=!0;const r=()=>{if(!Tt(t)){a(null);return}Rt(t).then(i=>o&&a(i))};return r(),window.addEventListener(Fe,r),window.addEventListener("storage",r),()=>{o=!1,window.removeEventListener(Fe,r),window.removeEventListener("storage",r)}},[t]),s}const Cs=({originator:t,themed:s})=>e.jsxs("div",{"data-testid":"bwx-origin-strip",className:"flex items-center gap-2 px-3",style:{background:z.bg,color:z.text,borderBottom:`1px solid ${z.line}`,minHeight:32,fontFamily:"Inter, system-ui, sans-serif",fontSize:12,flexShrink:0},children:[e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24","aria-hidden":!0,fill:"none",stroke:z.gold,strokeWidth:"2.5",children:[e.jsx("rect",{x:"4",y:"11",width:"16",height:"10",rx:"2"}),e.jsx("path",{d:"M8 11V7a4 4 0 0 1 8 0v4"})]}),e.jsx("span",{style:{color:z.muted},children:"bWalletX · request from"}),e.jsx("span",{className:"font-bold truncate",style:{color:z.text},children:He(t)}),s&&e.jsx("span",{className:"ml-auto whitespace-nowrap",style:{color:z.muted,fontSize:10},children:"site theme"})]}),Es=({theme:t,originator:s})=>e.jsxs("div",{"data-testid":"bwx-site-banner",className:"flex items-center gap-3 px-4",style:{background:t.artData?`linear-gradient(90deg, ${t.bg} 35%, ${t.bg}99), url("${t.artData}") center / cover`:`linear-gradient(135deg, ${t.bg}, ${t.surface})`,color:t.text,borderBottom:`3px solid ${t.accent}`,minHeight:60,flexShrink:0},children:[t.logoData?e.jsx("img",{src:t.logoData,alt:"",width:36,height:36,style:{borderRadius:8,objectFit:"contain"}}):e.jsx("span",{"aria-hidden":!0,className:"flex items-center justify-center font-bold",style:{width:36,height:36,borderRadius:8,background:t.accent,color:t.onAccent},children:t.name.slice(0,1).toUpperCase()}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"font-bold truncate",style:{fontSize:15,color:t.text},children:t.name}),e.jsxs("div",{className:"truncate",style:{fontSize:11,color:t.accentHi},children:["Connected with bWalletX · ",He(s)]})]})]}),Ps=({originator:t,children:s,theme:a})=>{const o=Ss(a===void 0?t:void 0),r=a===void 0?o:a;return t?e.jsxs("div",{className:"flex flex-col w-full h-full",style:r?{boxShadow:`inset 3px 0 0 ${r.accent}, inset -3px 0 0 ${r.accent}`}:void 0,children:[e.jsx(Cs,{originator:t,themed:!!r}),r&&e.jsx(Es,{theme:r,originator:t}),e.jsx("div",{className:"flex-1 min-h-0 flex items-center justify-center relative",children:s})]}):e.jsx(e.Fragment,{children:s})};We.Buffer=ze;We.process=it;window.Buffer=ze;const As=t=>"payload"in t&&t.payload.originator||void 0,Ts=1e4,Rs=2e3,F=new URLSearchParams(window.location.search).get("inpage"),_e=window.location.protocol==="chrome-extension:"&&window.top!==window&&!F&&!!window.location.ancestorOrigins?.length&&window.location.ancestorOrigins[0]!==window.location.origin,Is=(t,s)=>{const[a,o]=p.useState(t?void 0:!0),[r,i]=p.useState(!t),[f,l]=p.useState(!1);return p.useEffect(()=>{t&&W({action:"INPAGE_SHEET_CHECK",token:F}).then(n=>o(!!n?.success)).catch(()=>o(!1))},[t]),p.useEffect(()=>{if(!t||a!==!0||!s.current)return;let n;const x=new IntersectionObserver(g=>{const w=g[g.length-1];window.clearTimeout(n),w.isVisible&&w.intersectionRatio>=.99?n=window.setTimeout(()=>i(!0),500):i(!1)},{threshold:[0,.99,1],trackVisibility:!0,delay:100});return x.observe(s.current),()=>{window.clearTimeout(n),x.disconnect()}},[t,s,a]),p.useEffect(()=>{if(!t||r){l(!1);return}const n=window.setTimeout(()=>l(!0),1500);return()=>window.clearTimeout(n)},[t,r]),{tokenOk:a,armed:a===!0&&r,stuck:a===!0&&!r&&f}},Ds=()=>{const{theme:t}=q(),{isLocked:s,isReady:a}=H(),o=p.useRef(null),r=p.useRef(null),i=Is(!!F,r),f=!_e&&i.tokenOk===!0,l=p.useRef(f);l.current=f;const[n,x]=p.useState({kind:"loading"}),g=p.useRef(void 0),w=p.useRef(void 0),c=()=>{g.current!==void 0&&(window.clearTimeout(g.current),g.current=void 0)},m=p.useRef(n);m.current=n;const b=p.useCallback(async(u,h)=>{c();const k=m.current;if(u==="bundle"&&k.kind==="bundle"&&k.requestID===h){try{const T=await W({action:"GET_PROMPT_PAYLOAD",kind:u,requestID:h});T?.success&&T.data&&x({kind:"bundle",requestID:h,payload:T.data})}catch{}return}x({kind:"loading"});let P;try{P=await W({action:"GET_PROMPT_PAYLOAD",kind:u,requestID:h})}catch{P=void 0}P?.success&&P.data?x({kind:u,requestID:h,payload:P.data}):(x({kind:"expired"}),window.setTimeout(()=>{w.current?.()},Rs))},[]),d=p.useCallback(async()=>{c();let u;try{u=await W({action:"CLOSE_PROMPT_WINDOW"})}catch{u=void 0}if(u===void 0){window.close();return}const h=u.data?.prompt;h&&(h.kind==="unlock"?x({kind:"unlock"}):h.requestID&&await b(h.kind,h.requestID))},[b]),j=p.useCallback(async()=>{c();let u;try{u=await W({action:"GET_NEXT_PROMPT"})}catch{u=void 0}if(u?.data?.prompt){await b(u.data.prompt.kind,u.data.prompt.requestID);return}if(u?.data?.busy){x({kind:"waiting"}),g.current=window.setTimeout(()=>{d()},Ts);return}await d()},[b,d]);w.current=j,p.useEffect(()=>{if(!a||!f)return;const u=new URLSearchParams(window.location.search),h=u.get("kind"),k=u.get("requestID");if(h==="unlock"){s?x({kind:"unlock"}):j();return}if(h&&k){b(h,k);return}j()},[a,f]),p.useEffect(()=>{const u=h=>{if(!(h?.action!=="SHOW_PROMPT"||!h.kind||!l.current)){if(h.kind==="unlock"){c(),x({kind:"unlock"});return}h.requestID&&b(h.kind,h.requestID)}};return chrome.runtime.onMessage.addListener(u),()=>chrome.runtime.onMessage.removeListener(u)},[b]);const N=t.color.global.walletBackground;return!_e&&F&&i.tokenOk===void 0?null:f?e.jsxs(mt,{children:[F&&e.jsxs("div",{className:"flex items-center justify-between px-3 py-2",style:{background:N,borderBottom:"1px solid #ffffff14"},children:[e.jsx("span",{className:"text-sm font-bold",style:{color:t.color.global.contrast},children:"bWalletX"}),i.stuck&&e.jsx("button",{type:"button",className:"text-xs font-bold border-0 rounded-full px-3 py-1",style:{background:"#F5C542",color:"#0b0a08"},onClick:()=>chrome.runtime.sendMessage({action:"MOVE_PROMPT_TO_WINDOW"}).catch(()=>{}),children:"Open in bWalletX"}),e.jsx("button",{type:"button","aria-label":"Deny and close",className:"text-sm border-0 bg-transparent p-1",style:{color:t.color.global.gray},onClick:()=>chrome.runtime.sendMessage({action:"DISMISS_PROMPT_PANEL"}).catch(()=>{}),children:"✕"})]}),e.jsxs("div",{ref:o,className:"flex items-center justify-center relative p-0",style:{width:F?"100%":"var(--wallet-width)",height:F?"calc(100vh - 41px)":"var(--wallet-height)",backgroundColor:N,pointerEvents:i.armed?void 0:"none"},children:[F&&e.jsx("div",{ref:r,"aria-hidden":!0,style:{position:"absolute",top:0,left:0,width:24,height:24,pointerEvents:"none"}}),(!a||n.kind==="loading")&&e.jsx($e,{message:"Loading...",theme:t}),n.kind==="waiting"&&e.jsx($e,{message:"Waiting for request...",theme:t}),n.kind==="expired"&&e.jsx("p",{className:"text-xs",style:{color:t.color.global.gray},children:"This request expired or was already handled."}),n.kind==="unlock"&&e.jsx(ht,{onUnlock:()=>{j()}}),e.jsxs(Ps,{originator:As(n),children:[n.kind==="permission"&&e.jsx(cs,{request:n.payload,onResponse:()=>{j()}},n.requestID),n.kind==="bundle"&&e.jsx(vs,{request:n.payload,onResponse:()=>{j()}},n.requestID),n.kind==="groupedPermission"&&e.jsx(_t,{request:n.payload,onResponse:()=>{j()}},n.requestID),n.kind==="counterpartyPermission"&&e.jsx($t,{request:n.payload,onResponse:()=>{j()}},n.requestID),n.kind==="oneSatPermission"&&e.jsx(as,{request:n.payload,onResponse:()=>{j()}},n.requestID),n.kind==="streamGrant"&&e.jsx(Ns,{request:n.payload,onResponse:()=>{j()}},n.requestID),n.kind==="usbCheck"&&e.jsx(ds,{request:n.payload,onResponse:()=>{j()}},n.requestID)]})]})]}):e.jsx("p",{className:"text-xs p-4",style:{color:"#98A2B3"},children:"Open bWalletX to answer this request."})},Qe=document.getElementById("root");if(!Qe)throw new Error("Root element");at.createRoot(Qe).render(e.jsx(pt,{children:e.jsx(ut,{children:e.jsx(ft,{children:e.jsx(xt,{children:e.jsx(Ds,{})})})})}));
//# sourceMappingURL=prompt-tab-BsF4GVz7.js.map
