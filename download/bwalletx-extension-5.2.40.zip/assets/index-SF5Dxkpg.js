const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Dlcoa6kB.js","./index-G4GCesQs.js","./crypto-Je5Wy8Z2.js","./index-numRYSTi.js","./index-DU2cSw24.css","./extensionMedia-Rm_l9uoo.js","./index-BZbwIrVb.css"])))=>i.map(i=>d[i]);
import{ad as e,_ as t}from"./index-G4GCesQs.js";import"./crypto-Je5Wy8Z2.js";import"./index-numRYSTi.js";import"./extensionMedia-Rm_l9uoo.js";const _=e("Share",{web:()=>t(()=>import("./web-Dlcoa6kB.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-SF5Dxkpg.js.map
