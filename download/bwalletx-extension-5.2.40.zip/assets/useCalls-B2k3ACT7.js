import{r as s}from"./index-numRYSTi.js";import{jr as e,aS as a}from"./index-G4GCesQs.js";const c=()=>{const[t,r]=s.useState(e);return s.useEffect(()=>a(r),[]),t};export{c as u};
//# sourceMappingURL=useCalls-B2k3ACT7.js.map
