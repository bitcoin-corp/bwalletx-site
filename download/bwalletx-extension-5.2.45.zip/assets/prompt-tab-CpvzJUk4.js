import{r as u,j as e,a as Jt}from"./index-t5CcWpUk.js";import{o as qe,b1 as ht,b2 as xt,b3 as Zt}from"./crypto-D-3Mmd3B.js";import{z as G,G as ee,L as A,bi as U,eY as ae,eZ as L,aE as Qt,bj as es,U as ts,bk as V,co as X,cp as gt,eW as ss,eX as os,eL as ns,eM as rs,eN as as,P as rt,eR as is}from"./index-CNyUi-To.js";import{o as fe,m as je,U as ls,N as ke,O as yt,L as cs,S as ds,D as bt,G as ps,E as us,J,Q as fs,v,n as ms,q as hs,R as Ae,T as _e,x as I,y as $,V as xs,W as at,X as gs,Y as ge,A as vt,z as it,B as ys,I as ve,F as bs,P as vs,Z as ws,C as lt,_ as js,l as ks,$ as Ss,d as Ns}from"./reservedBaskets-De-2MpTb.js";import{a as Es,u as Ps,s as Cs}from"./twetchCalls-Df6jchKf.js";import{a as ct,s as wt,w as Is,b as Le}from"./approvalKind-BHOaKR0V.js";import{A as Rs}from"./arrow-left-right-CMi84Ned.js";const Ts=t=>{const{request:s,onResponse:r}=t,{theme:o}=G(),{handleSelect:i,hideMenu:n}=fe(),{addSnackbar:d}=je(),[c,a]=u.useState(!1),[f,x]=u.useState(""),{chromeStorageService:y}=ee(),{permissions:l}=s,[w,j]=u.useState(()=>l.protocols.map(()=>!0));u.useEffect(()=>{i("bsv"),n()},[i,n]);const p=()=>{const E=l.protocols.filter((C,O)=>w[O]);return E.length===0?{}:{protocols:E}},b=async()=>{a(!0),x("");try{const E=await ae(y);if(!E.ok){x(E.message),a(!1);return}ke(s.originator),L({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:p()}),r()}catch(E){d(E instanceof Error?E.message:String(E),"error"),a(!1)}},k=async()=>{a(!0),L({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),r()},h=E=>j(C=>C.map((O,te)=>te===E?!O:O)),g=s.counterpartyLabel??`${s.counterparty.slice(0,8)}...${s.counterparty.slice(-8)}`;return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ls,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Counterparty Permission"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","wants to interact with a counterparty"]})]})]}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all font-mono",style:{color:o.color.global.contrast},children:g})]}),e.jsx(U,{when:!!l.description,children:e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Purpose"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:l.description})]})}),e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),l.protocols.map((E,C)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:C<l.protocols.length-1?"1px solid rgba(255,255,255,0.04)":"none"},children:[e.jsx("input",{type:"checkbox",checked:w[C],onChange:()=>h(C),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[E.protocolID?.[1]," (level ",E.protocolID?.[0],")"]}),E.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:E.description})]})]},`proto-${C}`))]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[f&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:f}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:c?.6:1},disabled:c,onClick:b,whileHover:{scale:c?1:1.02},whileTap:{scale:c?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[c&&e.jsx(qe,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:c?.5:1},disabled:c,onClick:k,whileHover:{scale:c?1:1.02},whileTap:{scale:c?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},jt=[{protocolID:[2,"bmintx archive"],origins:["bmintx.com","www.bmintx.com"],label:"Your private archive (bMintX)",description:"bMintX wants to lock your imported posts with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose."},{protocolID:[2,"bvideox records"],origins:["bvideox.com","www.bvideox.com"],label:"Your video records (bVideoX)",description:"bVideoX wants to lock your video records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"video",countFrom:/(\d+) private video records?/i}},{protocolID:[2,"bjobsx records"],origins:["bjobsx.com","www.bjobsx.com"],label:"Your work records (bJobsX)",description:"bJobsX wants to lock your profile records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"profile record",countFrom:/(\d+) private profile records?/i}},{protocolID:[2,"bdrivex records"],origins:["bdrivex.com","www.bdrivex.com"],label:"Your file records (bDriveX)",description:"bDriveX wants to lock your file records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"file record",countFrom:/(\d+) private file records?/i}},{protocolID:[2,"bcalx records"],origins:["bcalx.com","www.bcalx.com"],label:"Your calendar records (bCalX)",description:"bCalX wants to lock your calendar records with your own keys before they go on chain. Only your 12 words can open them; nothing is made public unless you choose.",mint:{verb:"Mint",noun:"calendar record",countFrom:/(\d+) private (?:calendar )?records?/i}}],Ds=t=>`${t[0]}:${t[1].trim().toLowerCase()}`;new Map(jt.map(t=>[Ds(t.protocolID),t]));const $s={"2:3241645161d8":{label:"BRC-29 payment",description:"An application is requesting permission to derive payment addresses for a specific recipient."},...Object.fromEntries(jt.map(t=>[`${t.protocolID[0]}:${t.protocolID[1]}`,{label:t.label,description:t.description}]))},kt=t=>t?$s[`${t[0]}:${t[1]}`]:void 0,St=t=>kt(t)?.label??t?.[1],As=t=>{switch(t){case 0:return"Level 0 · any app";case 1:return"Level 1 · same keys for any app using this protocol";case 2:return"Level 2 · same keys for any app using this protocol with this recipient";default:return`Level ${t??0}`}},Nt=t=>`${t[0]}:${t[1].trim().toLowerCase()}`,Ls=new Set([2532803679,1545534606,3968644154,2559579298,983045898,2744301556,111268922,3445661247,2334321181,4156441831,3583153857,2398265928,1065214202,2451633495,1587406450,3495424783,2196479044,3172368687,3977290595,2110695608,2486468533,3947228137,3114316294,3407865888,2095595255,927149303,1269930738,2919298931,2255687340,329407381,2945469548,2194069484,2746709595,2032425612,2219561992,2168751551,2928392842].map(t=>t>>>0)),Os=[[2,"3241645161d8"]],Fs=t=>{let s=2166136261;for(const r of new TextEncoder().encode(Nt(t)))s=Math.imul(s^r,16777619)>>>0;return s>>>0};new Set(Os.map(Nt));const Ms=t=>Array.isArray(t)&&t.length===2&&typeof t[0]=="number"&&typeof t[1]=="string"?[t[0],t[1]]:null,dt=t=>{const s=Ms(t);return!!s&&Ls.has(Fs(s))},Us=t=>{const{request:s,onResponse:r}=t,{theme:o}=G(),{handleSelect:i,hideMenu:n}=fe(),{addSnackbar:d}=je(),[c,a]=u.useState(!1),[f,x]=u.useState(""),{chromeStorageService:y}=ee(),l=y.getCurrentAccountObject().account?.pubKeys?.identityPubKey??"",{permissions:w}=s,j=y.getCurrentAccountObject().account,p=Es(j?.addresses?.identityAddress,j?.name??"").payable?.trim()??"",b=p?p.startsWith("$")?p:`$${p}`:"",[k,h]=u.useState(!1);u.useEffect(()=>{i("bsv"),n()},[i,n]);const g=()=>{const P={},B=(w.protocolPermissions??[]).filter(Ne=>!dt(Ne.protocolID));return B.length>0&&(P.protocolPermissions=B),w.basketAccess?.length&&(P.basketAccess=w.basketAccess),P},E=async()=>{a(!0),x("");try{const P=await ae(y);if(!P.ok){x(P.message),a(!1);return}ke(s.originator),L({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:g()}),r()}catch(P){d(P instanceof Error?P.message:String(P),"error"),a(!1)}},C=async()=>{a(!0),L({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),r()},O=(w.protocolPermissions??[]).filter(P=>!dt(P.protocolID)),te=s.originator.replace(/^[a-z]+:\/\//i,"").split(/[/?#]/)[0],Se=`${te} wants to sign you in${b?` as ${b}`:""}`,me=[...O.map(P=>`Use your keys for “${St(P.protocolID)}”`),...(w.basketAccess??[]).map(P=>`See its own items in “${yt(P.basket)}”`)];return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsx("div",{className:"w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-4",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(cs,{size:22,style:{color:"var(--bw-accent-hi)"}})}),e.jsx("h1",{className:"text-xl font-bold leading-snug text-center break-words",style:{color:o.color.global.contrast},"data-testid":"connect-title",children:Se}),e.jsxs("p",{className:"text-xs mt-2 text-center break-all",style:{color:o.color.global.gray},children:["Request from"," ",e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})]}),e.jsxs("p",{className:"text-sm mt-4 text-center leading-relaxed",style:{color:o.color.global.gray},children:["Nothing is spent. If ",te," later wants anything more, bWalletX will ask you then."]}),e.jsx(ds,{site:Qt(s.originator),account:l,style:{marginTop:12}}),e.jsxs(U,{when:me.length>0,children:[e.jsx("button",{type:"button",className:"text-xs mt-4 underline self-center",style:{color:o.color.global.gray,background:"transparent"},onClick:()=>h(P=>!P),children:k?"Hide details":"What does signing in allow?"}),e.jsx(U,{when:k,children:e.jsx("ul",{className:"text-xs mt-2 leading-relaxed list-disc pl-5",style:{color:o.color.global.gray},children:me.map((P,B)=>e.jsx("li",{children:P},B))})})]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-6",children:[f&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:f}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:c?.6:1},disabled:c,onClick:E,whileTap:{scale:c?1:.97},"data-testid":"connect-sign-in",children:[c&&e.jsx(qe,{size:14,className:"animate-spin"}),"Sign in"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:c?.5:1},disabled:c,onClick:C,whileTap:{scale:c?1:.97},children:"Cancel"})]})]})},Bs=2e3;async function we(t,s=Bs){let r;try{return await Promise.race([t.catch(()=>{}),new Promise(o=>{r=setTimeout(()=>o(void 0),s)})])}catch{return}finally{r&&clearTimeout(r)}}function _s(t,s){return t?.find(r=>r.startsWith(`${s}:`))?.slice(s.length+1)}async function zs(t,s,r=[]){const o=t.ordfs;if(typeof o?.bulkMetadata!="function")return{state:"unverified"};const i=`${s}:-2`,n=await we(o.bulkMetadata([i])),d=n?.[i]??n?.[s]??Object.values(n??{}).find(f=>!!f?.contentType);if(!d?.contentType)return{state:"unverified"};const c={contentType:d.contentType,origin:d.origin,name:typeof d.map?.name=="string"?d.map.name:void 0},a=r.find(f=>f.includes("/"));return a&&a!==d.contentType?{state:"mismatch",note:`Content type is ${d.contentType}, not ${a}`,...c}:{state:"verified",...c}}async function Ws(t,s,r){const o=t.opns;if(typeof o?.getOrigin!="function")return{state:"unverified"};const i=await we(o.getOrigin(s));return i?.outpoint?i.outpoint!==r?{state:"mismatch",note:`“${s}” currently resolves to a different output`}:{state:"verified"}:{state:"unverified"}}async function qs(t,s,r,o=[]){const i=t.bsv21;if(typeof i?.getTokenDetails!="function")return{state:"unverified"};const n=await we(i.getTokenDetails(s,{fresh:!0}));if(!n)return{state:"unverified"};if(n.status?.is_active===!1)return{state:"mismatch",note:"Token is not active on the overlay"};const d=n.token?.sym;if(r&&d&&r.toLowerCase()!==d.toLowerCase())return{state:"mismatch",note:`Token symbol is ${d}, not ${r}`};if(o.length>0&&typeof i.getOutputStatus=="function"){const c=await we(i.getOutputStatus(s,o));if(!c)return{state:"unverified"};const a=c.filter(f=>f.state==="spent"||f.state==="unknown");if(a.length>0)return{state:"mismatch",note:a.length===1?"A spent token output is not valid on the overlay":`${a.length} spent token outputs are not valid on the overlay`};if(c.some(f=>f.state==="queued"))return{state:"unverified"}}return{state:"verified",...d?{name:d}:{}}}async function Hs(t,s,r,o,i){if(!t||!s)return{state:"unverified"};const n=s==="purchase"||s.endsWith(".purchase"),d=s==="token-transfer"||s.startsWith("bsv21.");if(!n&&!d)return{state:"unverified"};const c={kindOrIntent:s,hasOrdfs:!!t.ordfs,hasBulk:typeof t.ordfs?.bulkMetadata=="function",inputTagSets:r.map(a=>a.tags),outputTagSets:o.map(a=>a.tags)};try{const a=[...r.map(p=>p.tags),...o.map(p=>p.tags)],f=p=>a.flatMap(b=>b.filter(k=>k.startsWith(`${p}:`)).map(k=>k.slice(p.length+1))),x=p=>{for(const b of a){const k=_s(b,p);if(k)return k}},y=x("bsv21");if(y||s==="bsv21.purchase"||s==="token-transfer"||s.startsWith("bsv21.")){if(!y)return{state:"unverified"};const b=r.filter(h=>h.basket?.includes("bsv21")||h.tags.some(g=>g.startsWith("bsv21:"))).map(h=>h.outpoint).filter(Boolean);let k=x("sym");for(const h of r)if(h.customInstructions)try{const g=JSON.parse(h.customInstructions).sym;if(typeof g=="string"&&g.trim()){k=g.trim();break}}catch{}return await qs(t,y,k,b)}const l=x("name"),w=x("origin");if(c.name=l,c.origin=w,l&&w&&o.some(p=>p.basket?.includes("opns"))||s==="opns.purchase")return!l||!w?{state:"unverified"}:await Ws(t,l,w);if(!w)return c.reason="no-origin-tag",globalThis.__lastVerify=c,{state:"unverified"};const j=await zs(t,w,f("type"));if(c.verifyOrdinal=j,j.origin&&i)try{j.contentUrl=i(j.origin)}catch(p){c.contentUrlError=String(p)}return globalThis.__lastVerify=c,j}catch(a){return c.error=String(a),globalThis.__lastVerify=c,{state:"unverified"}}}function Et(t){if(!t||typeof t!="object")return!1;const s=t;return Array.isArray(s.panels)&&typeof s.title=="string"}var Vs=`
.opp-root {
  --opp-bg: #ffffff;
  --opp-fg: #111827;
  --opp-muted: #6b7280;
  --opp-card-bg: #f7f8fa;
  --opp-card-border: #eceef2;
  --opp-accent: #E5A920;
  --opp-approve-bg: #E5A920;
  --opp-approve-fg: #ffffff;
  --opp-reject-bg: #ffffff;
  --opp-reject-fg: #111827;
  --opp-reject-border: #d1d5db;
  --opp-status-bg: #FFFBE6;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #ECFDF5;
  --opp-trust-ok-fg: #059669;
  --opp-trust-warn-bg: #FFFBEB;
  --opp-trust-warn-fg: #D97706;
  --opp-trust-bad-bg: #FEF2F2;
  --opp-trust-bad-fg: #DC2626;

  font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--opp-bg);
  color: var(--opp-fg);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 480px;
  min-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
}

.opp-bottom {
  margin-top: auto;
  display: flex;
  flex-direction: column;
}

.opp-root.opp-dark {
  --opp-bg: #0F1117;
  --opp-fg: #F9FAFB;
  --opp-muted: #9ca3af;
  --opp-card-bg: #1A1D27;
  --opp-card-border: #232636;
  --opp-reject-bg: #0F1117;
  --opp-reject-fg: #F9FAFB;
  --opp-reject-border: #2D3142;
  --opp-status-bg: #2A2408;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #0A2E1F;
  --opp-trust-ok-fg: #34D399;
  --opp-trust-warn-bg: #2A2008;
  --opp-trust-warn-fg: #FBBF24;
  --opp-trust-bad-bg: #2A1215;
  --opp-trust-bad-fg: #F87171;
}

.opp-body {
  padding: 24px 20px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
}

.opp-coin {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
}

.opp-title {
  font-size: 16px;
  font-weight: 700;
  margin: 0;
  text-align: center;
}

.opp-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  margin: 0;
  text-align: center;
  line-height: 1.4;
}

.opp-status {
  background: var(--opp-status-bg);
  color: var(--opp-status-fg);
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
  margin-top: 4px;
  border: 1px solid var(--opp-card-border);
}

.opp-card {
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px;
  padding: 16px;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.opp-featured {
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px 8px;
  padding: 16px;
}

/* Subtle danger chrome for burn / destructive token ops */
.opp-featured-danger {
  border-color: rgba(220, 38, 38, 0.45);
  background: color-mix(in srgb, var(--opp-card-bg) 88%, #7f1d1d 12%);
}

.opp-featured-danger .opp-featured-title {
  color: #f87171;
}

.opp-featured-danger .opp-featured-image,
.opp-featured-danger .opp-featured-placeholder {
  border: 1px solid rgba(220, 38, 38, 0.35);
  background: rgba(127, 29, 29, 0.25);
  color: #fca5a5;
}

.opp-dark .opp-featured-danger {
  border-color: rgba(248, 113, 113, 0.4);
  background: color-mix(in srgb, var(--opp-card-bg) 85%, #450a0a 15%);
}

.opp-preview-pair {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.opp-preview-arrow {
  color: var(--opp-muted);
  font-size: 14px;
  line-height: 1;
}

.opp-preview-pair .opp-featured-image {
  width: 64px;
  height: 64px;
}

.opp-featured-image {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-featured-image-token {
  width: 48px;
  height: 48px;
  border-radius: 999px;
}

.opp-featured-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--opp-muted);
  font-size: 18px;
}

.opp-preview-opns {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
}

.opp-preview-opns-avatar {
  width: 36px;
  height: 36px;
  border-radius: 999px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-preview-opns-name {
  font-size: 11px;
  font-weight: 600;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  color: var(--opp-fg, inherit);
}

.opp-preview-text {
  margin: 0;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
  font-size: 9px;
  line-height: 1.25;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  color: var(--opp-muted);
}

.opp-preview-json {
  white-space: pre;
  overflow: auto;
}

.opp-preview-frame {
  border: 0;
  padding: 0;
  overflow: hidden;
  background: #fff;
  pointer-events: none;
}

.opp-preview-value {
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  background: rgba(229, 169, 32, 0.12);
  border: 1px solid rgba(229, 169, 32, 0.35);
  color: var(--opp-fg, inherit);
}

.opp-preview-value-icon {
  width: 32px;
  height: 32px;
  color: #E5A920;
}

/* Amount subtitles must never ellipsis — full sat counts are the point. */
.opp-featured-subtitle-text.opp-amount {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-variant-numeric: tabular-nums;
  white-space: normal;
  overflow: visible;
  text-overflow: unset;
  word-break: keep-all;
}

.opp-featured-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  flex: 1;
}

.opp-featured-title {
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.opp-featured-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.opp-featured-subtitle-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
}

.opp-featured-meta-line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  color: var(--opp-muted);
}

.opp-featured-meta-line-bare {
  align-items: center;
}

.opp-featured-meta-key {
  flex-shrink: 0;
  opacity: 0.75;
  min-width: 2.5em;
}

.opp-featured-meta-value {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  flex: 1;
}

.opp-featured-meta-value-mono {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 11px;
}

.opp-trust-wrap {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0 20px 8px;
}

.opp-trust {
  display: inline-flex;
  align-self: flex-start;
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 600;
}

.opp-trust-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-trust-note {
  padding: 10px;
  border-radius: 8px;
  font-size: 11px;
  line-height: 1.35;
}

.opp-trust-note-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-note-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-note-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.opp-row-key {
  color: var(--opp-muted);
  flex-shrink: 0;
}

.opp-row-value-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 70%;
  justify-content: flex-end;
}

.opp-row-value {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 12px;
  font-weight: 500;
  text-align: right;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.opp-copy {
  flex-shrink: 0;
  width: 22px;
  height: 22px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  border: 1px solid var(--opp-reject-border);
  background: var(--opp-bg);
  color: var(--opp-fg);
  cursor: pointer;
}

.opp-copy:hover {
  border-color: var(--opp-accent);
  color: var(--opp-accent);
}

.opp-fee-note {
  font-size: 11px;
  color: var(--opp-muted);
  line-height: 1.3;
  margin-top: -4px;
}

.opp-actions {
  display: flex;
  gap: 12px;
  padding: 20px 20px 12px;
}

.opp-button {
  flex: 1;
  padding: 0 16px;
  height: 48px;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid transparent;
  transition: opacity 120ms ease;
}

.opp-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.opp-button-reject {
  background: var(--opp-reject-bg);
  color: var(--opp-reject-fg);
  border-color: var(--opp-reject-border);
}

.opp-button-approve {
  background: var(--opp-approve-bg);
  color: var(--opp-approve-fg);
}

.opp-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 20px 16px;
  font-size: 11px;
  font-weight: 500;
  color: var(--opp-muted);
}
`;function Gs({request:t,onApprove:s,onReject:r,theme:o="auto",services:i}){const n=so(o),d=Ks(t),[c,a]=u.useState(!1),[f,x]=u.useState(),y=t.kind==="transaction"&&Et(t.payload)?t.payload:void 0;u.useEffect(()=>{if(!i||!y?.trust||!y.verify)return;let p=!0;const b=i.ordfs?.getContentUrl?.bind(i.ordfs);return Hs(i,y.verify.kind,y.verify.inputs,y.verify.outputs,b).then(k=>{p&&k&&x(k)}).catch(()=>{}),()=>{p=!1}},[i,y]);const l=f?Ys(d,f):d,w=p=>()=>{if(!c){a(!0);try{p==="approve"?s():r()}finally{a(!1)}}};u.useEffect(()=>{const p=b=>{c||(b.key==="Escape"?r():b.key==="Enter"&&s())};return window.addEventListener("keydown",p),()=>window.removeEventListener("keydown",p)},[s,r,c]);const j=`opp-root${n==="dark"?" opp-dark":""}`;return e.jsxs("div",{className:j,children:[e.jsx("style",{children:Vs}),e.jsxs("div",{className:"opp-body",children:[e.jsxs("svg",{className:"opp-coin",viewBox:"0 0 100 100","aria-label":"1Sat Ordinals",children:[e.jsx("circle",{cx:"50",cy:"50",r:"50",fill:"#222"}),e.jsx("circle",{cx:"50",cy:"50",r:"40",fill:"#fff"}),e.jsx("circle",{cx:"50",cy:"50",r:"32",fill:"#E5A920"}),e.jsx("rect",{x:"47",y:"28",width:"6",height:"28",rx:"3",fill:"#fff"})]}),e.jsx("h2",{className:"opp-title",children:l.title}),e.jsx("p",{className:"opp-subtitle",children:l.subtitle}),e.jsx("div",{className:"opp-status",children:"Awaiting Approval"})]}),l.panels.map((p,b)=>{const k=p.variant??"ordinal",h=["opp-featured"];return k==="token"&&h.push("opp-featured-token"),k==="value"&&h.push("opp-featured-value"),p.tone==="danger"&&h.push("opp-featured-danger"),e.jsxs("div",{className:h.join(" "),children:[p.prior?e.jsxs("div",{className:"opp-preview-pair","aria-label":"Previous and new inscription",children:[e.jsx(Oe,{panel:{...p,previewKind:p.prior.previewKind,imageUrl:p.prior.imageUrl,contentUrl:p.prior.contentUrl,previewText:p.prior.previewText,prior:void 0}}),e.jsx("span",{className:"opp-preview-arrow","aria-hidden":!0,children:"→"}),e.jsx(Oe,{panel:p})]}):e.jsx(Oe,{panel:p}),e.jsxs("div",{className:"opp-featured-meta",children:[e.jsx("div",{className:"opp-featured-title",children:p.title}),p.subtitle&&e.jsxs("div",{className:"opp-featured-subtitle",children:[e.jsx("span",{className:p.amountSats!=null?"opp-featured-subtitle-text opp-amount":"opp-featured-subtitle-text",children:p.subtitle}),p.subtitleCopy&&e.jsx(Fe,{text:p.subtitleCopy})]}),(p.meta??[]).map(g=>e.jsxs("div",{className:`opp-featured-meta-line${g.key?"":" opp-featured-meta-line-bare"}`,children:[g.key?e.jsx("span",{className:"opp-featured-meta-key",children:g.key}):null,e.jsx("span",{className:`opp-featured-meta-value${g.key?"":" opp-featured-meta-value-mono"}`,title:g.copyValue??g.value,children:g.value}),g.copyValue&&e.jsx(Fe,{text:g.copyValue})]},`${g.key}:${g.value}`))]})]},`panel-${b}-${p.title}`)}),l.trust&&e.jsxs("div",{className:"opp-trust-wrap",children:[e.jsx("span",{className:`opp-trust opp-trust-${l.trust.state}`,children:Zs(l.trust.state)}),l.trust.note&&e.jsx("div",{className:`opp-trust-note opp-trust-note-${l.trust.state}`,children:l.trust.note})]}),(l.rows.length>0||l.indexerFee||l.funding)&&e.jsxs("div",{className:"opp-card",children:[l.rows.map(p=>e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:p.key}),e.jsxs("span",{className:"opp-row-value-wrap",children:[e.jsx("span",{className:"opp-row-value",title:p.copyValue??p.value,children:p.value}),p.copyValue&&e.jsx(Fe,{text:p.copyValue})]})]},`${p.key}:${p.value}`)),l.indexerFee&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"1Sat Overlay Fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[pt(l.indexerFee.sats)," sats"]})]}),l.funding?.networkFeeSats!=null&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"Network fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[pt(l.funding.networkFeeSats)," sats"]})]}),l.funding?.note&&e.jsx("div",{className:"opp-fee-note",children:l.funding.note})]}),e.jsxs("div",{className:"opp-bottom",children:[e.jsxs("div",{className:"opp-actions",children:[e.jsx("button",{type:"button",className:"opp-button opp-button-reject",onClick:w("reject"),disabled:c,children:"Reject"}),e.jsx("button",{type:"button",className:"opp-button opp-button-approve",onClick:w("approve"),disabled:c,children:"Approve"})]}),e.jsx("div",{className:"opp-footer",children:e.jsx("span",{children:"Secured by 1Sat Ordinals"})})]})]})}function Ks(t){if(t.kind==="transaction"&&Et(t.payload))return{title:t.payload.title,subtitle:t.payload.subtitle,panels:t.payload.panels,rows:t.payload.rows,trust:t.payload.trust,indexerFee:t.payload.indexerFee,funding:t.payload.funding};if(t.kind==="basketAccess"){const s=t.payload.baskets??[],r=s.length>0&&s.every(n=>n.scope||n.basket.startsWith("p ")),o=s.filter(n=>n.imageUrl||n.name||n.value).map(n=>({title:n.scope==="collection"?n.name?`Collection · ${n.name}`:"Collection":n.scope?n.scope:"Basket",subtitle:n.value?n.value.length>24?`${n.value.slice(0,10)}…${n.value.slice(-10)}`:n.value:n.basket,subtitleCopy:n.value,...n.imageUrl&&{previewKind:"image",contentUrl:n.imageUrl,imageUrl:n.imageUrl},tone:"default"})),i=s.flatMap(n=>n.scope==="collection"?n.description?[{key:"Access",value:n.description}]:[]:[{key:n.basket,value:n.description??"List, insert, and remove outputs"}]);return{title:r?s.length===1?s[0].scope==="collection"?"Grant Collection View":"Grant Item View":`Grant View (${s.length})`:s.length===1?"Grant Basket Access":`Grant Access to ${s.length} Baskets`,subtitle:r?`${ye(t.originator)} wants to view items in your wallet`:`${ye(t.originator)} wants to read and write 1Sat baskets`,panels:o,rows:i}}return t.kind==="protocol"?{title:"Protocol Access",subtitle:`${ye(t.originator)} wants protocol access`,panels:[],rows:[{key:"Detail",value:t.summary||"Protocol request"}]}:{title:"Signature Request",subtitle:`${ye(t.originator)} wants a signature`,panels:[],rows:[{key:"Detail",value:t.summary||"Signature request"}]}}function Ys(t,s){const r=t.panels.map((o,i)=>{if(i!==0)return o;const n=o.previewKind==="opns",d=s.contentType?Xs(s.contentType):void 0,c=n?"opns":d&&d!=="none"?d:o.previewKind,a=s.contentUrl??o.contentUrl??o.imageUrl;let f=o.subtitle;if(s.name&&!n)if(!f)f=s.name;else{const x=f.trim().split(/\s+/);x.length>=2&&(x[x.length-1]=s.name,f=x.join(" "))}return{...o,previewKind:c,...f?{subtitle:f}:{},...n?{...s.contentUrl&&!o.imageUrl?{imageUrl:s.contentUrl}:o.imageUrl?{imageUrl:o.imageUrl}:{}}:c==="image"?{imageUrl:a,contentUrl:a}:a?{contentUrl:a,imageUrl:void 0}:{}}});return{...t,panels:r,trust:{state:s.state,note:s.note}}}function Xs(t){const s=t.toLowerCase();return s==="image/svg+xml"||s==="svg"||s.endsWith("+svg")?"svg":s.startsWith("image/")?"image":s.includes("json")?"json":s.includes("html")||s==="application/xhtml+xml"?"html":s.startsWith("text/")?"text":"none"}function Js(t){return`${t.toLocaleString("en-US")} sats`}function pt(t){return t.toLocaleString("en-US")}function Zs(t){return t==="verified"?"Verified":t==="mismatch"?"Mismatch":"Unverified"}function Oe({panel:t}){const s=t.variant??"ordinal",r=s==="token"?"opp-featured-image opp-featured-image-token":s==="value"?"opp-featured-image opp-preview-value":"opp-featured-image",o=t.previewKind??(t.imageUrl?"image":"none"),i=t.contentUrl??t.imageUrl,[n,d]=u.useState(!1);if(s==="value"){const c=t.valueIcon??"pay";return e.jsx("div",{className:r,title:t.amountSats!=null?Js(t.amountSats):void 0,"aria-hidden":!0,children:e.jsx(eo,{kind:c})})}if(o==="opns"){const c=!!t.imageUrl&&!n;return e.jsxs("div",{className:`${r} opp-preview-opns`,"aria-hidden":!t.opnsHero,children:[c?e.jsx("img",{className:"opp-preview-opns-avatar",src:t.imageUrl,alt:"",onError:()=>d(!0)}):e.jsx("div",{className:"opp-preview-opns-avatar opp-featured-placeholder",children:"◈"}),e.jsx("span",{className:"opp-preview-opns-name",title:t.opnsHero,children:t.opnsHero??"OpNS"})]})}return o==="image"&&t.imageUrl&&!n?e.jsx("img",{className:r,src:t.imageUrl,alt:t.title,onError:()=>d(!0)}):o==="image"&&n?e.jsx("div",{className:`${r} opp-featured-placeholder`,"aria-hidden":!0,children:"▭"}):(o==="text"||o==="json"||o==="html")&&t.previewText?e.jsx("pre",{className:`${r} opp-preview-text${o==="json"?" opp-preview-json":""}`,children:t.previewText}):(o==="text"||o==="json")&&i?e.jsx(to,{url:i,kind:o,className:r}):(o==="html"||o==="svg")&&i?e.jsx("iframe",{className:`${r} opp-preview-frame`,src:i,title:`${t.title} preview`,sandbox:"",referrerPolicy:"no-referrer"}):e.jsx("div",{className:`${r} opp-featured-placeholder`,"aria-hidden":!0,children:s==="token"?"◎":Qs(o)})}function Qs(t){return t==="text"||t==="json"?"¶":t==="html"||t==="svg"?"⌂":"▭"}function eo({kind:t}){return t==="lock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V8a4 4 0 018 0v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):t==="unlock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V7.5A4 4 0 0116 7",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("path",{d:"M16 4.5v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"9",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M12 7v10M9 10.5c0-1.4 1.3-2.5 3-2.5s3 1.1 3 2.5-1.3 2.5-3 2.5-3 1.1-3 2.5 1.3 2.5 3 2.5 3-1.1 3-2.5",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})}function to({url:t,kind:s,className:r}){const[o,i]=u.useState(null),[n,d]=u.useState(!1);return u.useEffect(()=>{let c=!1;return i(null),d(!1),fetch(t).then(async a=>{if(!a.ok)throw new Error(String(a.status));const f=await a.text();if(!c){if(s==="json")try{i(JSON.stringify(JSON.parse(f),null,2));return}catch{}i(f.slice(0,800))}}).catch(()=>{c||d(!0)}),()=>{c=!0}},[t,s]),n?e.jsx("div",{className:`${r} opp-featured-placeholder`,"aria-hidden":!0,children:"¶"}):e.jsx("pre",{className:`${r} opp-preview-text${s==="json"?" opp-preview-json":""}`,children:o??"…"})}function Fe({text:t}){const[s,r]=u.useState(!1),o=()=>{navigator.clipboard?.writeText(t).then(()=>{r(!0),window.setTimeout(()=>r(!1),1200)})};return e.jsx("button",{type:"button",className:"opp-copy",onClick:o,"aria-label":s?"Copied":"Copy full value",title:s?"Copied":"Copy",children:s?e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:e.jsx("path",{d:"M5 13l4 4L19 7",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round"})}):e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"9",y:"9",width:"11",height:"11",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M5 15V5a2 2 0 012-2h10",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})})}function so(t){const[s,r]=u.useState(()=>t==="auto"?oo():t);return u.useEffect(()=>{if(t!=="auto"){r(t);return}const o=window.matchMedia("(prefers-color-scheme: dark)"),i=()=>r(o.matches?"dark":"light");return i(),o.addEventListener("change",i),()=>o.removeEventListener("change",i)},[t]),s}function oo(){return typeof window>"u"||!window.matchMedia?"light":window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function ye(t){try{return new URL(t.includes("://")?t:`https://${t}`).host||t}catch{return t.length<=32?t:`${t.slice(0,14)}…${t.slice(-12)}`}}const no=({request:t,onResponse:s})=>{const{theme:r}=G(),{handleSelect:o,hideMenu:i}=fe(),{apiContext:n,chromeStorageService:d}=ee(),c=n?.services;u.useEffect(()=>{o("bsv"),i()},[o,i]);const[a,f]=u.useState(""),x=u.useRef(!1),y=async j=>{if(!x.current){if(x.current=!0,j){f("");const p=await ae(d);if(!p.ok){f(p.message),x.current=!1;return}}L({action:"ONE_SAT_PERMISSION_RESPONSE",requestID:t.requestID,approved:j}),s()}},w=r.color.global.walletBackground.toLowerCase()==="#000000"||/^#[01]/.test(r.color.global.walletBackground)?"dark":"light";return e.jsxs("div",{style:{width:"100%",height:"100%",overflowY:"auto",display:"flex",flexDirection:"column",alignItems:"stretch",justifyContent:"center"},children:[a&&e.jsx("p",{className:"text-xs text-center m-0 pt-2",style:{color:"#ef4444"},children:a}),e.jsx(Gs,{request:t.request,onApprove:()=>{y(!0)},onReject:()=>{y(!1)},theme:w,services:c})]})},ro=t=>{switch(t){case"protocol":return"Protocol Permission";case"basket":return"Basket Access";case"certificate":return"Certificate Access";case"spending":return"Spending Authorization";default:return"Permission Request"}},ao=t=>{switch(t.type){case"protocol":{const s=kt(t.protocolID);return s?s.description:`An application is requesting permission to use protocol "${t.protocolID?.[1]||"unknown"}" with security level ${t.protocolID?.[0]||0}.`}case"basket":return`An application is requesting access to basket "${t.basket||"unknown"}".`;case"certificate":return"An application is requesting access to certificate data.";case"spending":return`An application is requesting authorization to spend ${t.spending?.satoshis||0} satoshis.`;default:return"An application is requesting a permission."}},io=t=>{const{request:s,onResponse:r}=t,{theme:o}=G(),i=bt(),{handleSelect:n,hideMenu:d}=fe(),{addSnackbar:c}=je(),[a,f]=u.useState(!1),[x,y]=u.useState(""),{chromeStorageService:l}=ee();u.useEffect(()=>{n("bsv"),d()},[n,d]);const w=async()=>{f(!0),y("");try{const p=await ae(l);if(!p.ok){y(p.message),f(!1);return}ke(s.originator),L({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!0}),r()}catch(p){const b=p instanceof Error?p.message:String(p);c(b,"error"),f(!1)}},j=async()=>{f(!0),L({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!1}),r()};return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ps,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:ro(s.type)}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:ao(s)})]})]}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"12rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Origin"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.displayOriginator||s.originator})]}),e.jsxs(U,{when:s.type==="protocol"&&!!s.protocolID,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Protocol"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:St(s.protocolID)})]}),e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.counterparty?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Security"}),e.jsx("span",{className:"text-xs",style:{color:o.color.global.contrast},children:As(s.protocolID?.[0])})]}),e.jsx(U,{when:!!s.counterparty,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.counterparty})]})})]}),e.jsx(U,{when:s.type==="basket"&&!!s.basket,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Basket"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.basket})]})}),e.jsxs(U,{when:s.type==="certificate"&&!!s.certificate,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Cert Type"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.certType})]}),e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Fields"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.fields.join(", ")})]})]}),e.jsxs(U,{when:s.type==="spending"&&!!s.spending,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.spending?.lineItems?.length?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Amount"}),e.jsx(us,{sats:s.spending?.satoshis||0,price:i,size:24,align:"left",color:"var(--bw-accent-hi)",mutedColor:o.color.global.gray})]}),e.jsx(U,{when:!!s.spending?.lineItems?.length,children:s.spending?.lineItems?.map((p,b)=>e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:b<(s.spending?.lineItems?.length??0)-1?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:p.type}),e.jsxs("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:[p.description," (",J(p.satoshis,i).main," ·"," ",J(p.satoshis,i).sub,")"]})]},b))})]}),e.jsx(U,{when:!!s.reason,children:e.jsxs("div",{className:"flex flex-row py-2",style:{borderTop:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Reason"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.reason})]})})]}),e.jsx(U,{when:!!s.privileged,children:e.jsxs(A.div,{className:"flex items-start gap-2 rounded-xl px-3 py-2.5 mb-4",style:{background:"rgba(245,166,35,0.08)",border:"1px solid rgba(245,166,35,0.15)"},initial:{opacity:0},animate:{opacity:1},transition:{delay:.12},children:[e.jsx(es,{size:14,className:"mt-0.5 flex-shrink-0",style:{color:"#f5a623"}}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:"#f5a623"},children:"This is a privileged operation"})]})}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[x&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:x}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:a?.6:1},disabled:a,onClick:w,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[a&&e.jsx(qe,{size:14,className:"animate-spin"}),"Allow"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:a?.5:1},disabled:a,onClick:j,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny"})]})]})},lo=({request:t,onResponse:s})=>{const{theme:r}=G(),{chromeStorageService:o}=ee(),[i,n]=u.useState(""),[d,c]=u.useState(!1),a=async y=>{if(!d){if(c(!0),n(""),y){const l=await ae(o);if(!l.ok){n(l.message),c(!1);return}}L({action:"USB_CHECK_RESPONSE",requestID:t.requestID,ok:y}),s()}},f=r.color.global.gray,x=r.color.global.contrast;return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(ts,{size:40,style:{color:x}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:x},children:"Confirm your USB key"}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:f,maxWidth:"18rem"},children:[t.originator?`${t.originator} is asking bWallet to ${t.reason}.`:`A site is asking bWallet to ${t.reason}.`," ","Insert your USB key, then confirm."]}),i&&e.jsx("p",{className:"m-0 text-xs",style:{color:"#ef4444"},children:i}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(V,{theme:r,type:"primary",label:"Confirm USB key",disabled:d,onClick:()=>{a(!0)}}),e.jsx(V,{theme:r,type:"secondary-outline",label:"Cancel",disabled:d,onClick:()=>{a(!1)}})]})]})},co=t=>{const s=t.map(o=>o.requestID).sort().join(`
`);let r=2166136261;for(let o=0;o<s.length;o++)r^=s.charCodeAt(o),r=Math.imul(r,16777619)>>>0;return`${t.length}:${r.toString(16)}`},po=5,uo=/e-?mail|phone|mobile|kyc|passport|licen[cs]e|birth|dob|address|ssn|national|tax|id_?number/i,re=t=>String(t.protocolID?.[1]??"unknown"),Pt=t=>Number(t.protocolID?.[0]??0),Ct=t=>!!(t.privileged||t.type==="certificate"&&(t.certificate?.fields??[]).some(s=>uo.test(s))),It=t=>t.type==="protocol"&&!t.privileged&&t.protocolID?.[1]==="identity key retrieval"&&(t.counterparty===void 0||t.counterparty==="self"),fo=/\b(auth|authentication|sign[- ]?in|login|log[- ]?in)\b/i,Rt=t=>t.type==="protocol"&&!t.privileged&&(t.counterparty==="anyone"||It(t)||fo.test(re(t))&&(t.counterparty===void 0||t.counterparty==="self"||t.counterparty==="anyone")),mo=[[/agent history/i,"Ask b chats"],[/\b(chat|message)s?\b/i,"chats"],[/\bnotes?\b/i,"notes"],[/\b(history|private|backup|vault|encrypt)/i,"data"]],Tt=t=>{if(t.type!=="protocol"||t.privileged||t.counterparty!=="self"||Rt(t))return;const s=re(t);return mo.find(([r])=>r.test(s))?.[1]},ho="bap",xo=[1,"sigma"],ze=t=>t.type==="protocol"&&!t.privileged&&re(t).toLowerCase()===xo[1],We=t=>t.type==="basket"&&t.basket===ho,ut=t=>{switch(t.type){case"protocol":{if(It(t))return"See your public identity (the key that names you)";if(t.counterparty==="anyone")return"Prove it's you (a signature anyone can check)";if(ze(t))return"Sign your posts and likes as you";const s=Tt(t);return s?`Use keys from your wallet for your ${s}`:Pt(t)===2&&t.counterparty&&t.counterparty!=="self"?`Sign and encrypt with your "${re(t)}" keys, shared with one named person or service`:`Sign and encrypt anything with your "${re(t)}" keys`}case"basket":return We(t)?"Use your public profile (name and picture) on its posts":"Keep its tickets and tokens in your wallet";case"certificate":{const s=t.certificate?.fields??[];return s.length?`See your certificate details (${s.join(", ")})`:"See your certificates"}default:return"Spend from your wallet"}},Me=t=>{const s=[];switch(t.type){case"protocol":s.push(`protocol "${re(t)}" level ${Pt(t)}`),t.counterparty&&s.push(`counterparty ${t.counterparty}`);break;case"basket":s.push(yt(t.basket)==="Unknown basket"?"Unknown basket":`basket "${t.basket}"`);break;case"certificate":s.push(`certificate ${t.certificate?.certType??""}`,`verifier ${t.certificate?.verifier??""}`);break;case"spending":s.push(`${t.spending?.satoshis??0} sats`),t.labels?.length&&s.push(`labels: ${t.labels.join(", ")}`);break}return t.privileged&&s.push("privileged"),t.reason&&s.push(`reason: ${t.reason}`),s.join(" · ")},go=t=>{const s=[];let r;for(const n of t.items){if(n.type==="spending"){const a=n.spending?.satoshis??0;!r&&!n.addedLive?r={requestID:n.requestID,satoshis:a,description:n.spending?.lineItems?.find(f=>f.description)?.description??n.reason,detail:Me(n),...n.labels?.length?{labels:[...n.labels]}:{},...n.recipients?.length?{recipients:n.recipients.map(f=>({...f}))}:{}}:s.push({requestID:n.requestID,text:`${n.addedLive?"New: pay":"Also pay"} ${a.toLocaleString()} sats`,detail:Me(n),risky:!0,checked:!1,...n.addedLive?{isNew:!0}:{}});continue}const d=Ct(n),c=!d&&!n.addedLive;s.push({requestID:n.requestID,text:n.addedLive?`New: ${ut(n)}`:ut(n),...n.addedLive?{isNew:!0}:{},detail:Me(n),risky:d,checked:c,signIn:Rt(n),privateLabel:Tt(n),...ze(n)||We(n)?{post:!0}:{}})}const o=r?s.length?"connectAndPay":"pay":"connect",i=t.items.some(ze)||t.items.some(We);return{originator:t.originator,lines:s,payment:r,mode:o,...i?{purpose:"post"}:{}}},yo=(t,s)=>{const r=t.lines.filter(n=>!n.risky&&!n.isNew),o=r.find(n=>n.privateLabel)?.privateLabel,i=n=>{switch(s){case"signin":return n.signIn===!0;case"private":return n.signIn===!0&&n.checked||!!o&&n.privateLabel===o;case"post":return n.post===!0;case"connect":return n.checked;case"pay":case"mint":return n.signIn===!0&&n.checked;default:return!1}};return new Set(r.filter(i).map(n=>n.requestID))},bo=(t,s,r,o)=>({summarised:s?new Set:yo(t,o),faceTicks:new Set(t.lines.filter(i=>s||i.isNew).map(i=>i.requestID)),hidden:new Set(r?t.lines.filter(i=>!r.has(i.requestID)).map(i=>i.requestID):[])}),vo=(t,s)=>s?.hidden?.size?t.filter(r=>!s.hidden.has(r.requestID)):t,wo=(t,s,r,o,i={})=>{const n={};for(const d of t.lines){if(!o&&i.hidden?.has(d.requestID))continue;const c=o||!!i.faceTicks?.has(d.requestID);if(s&&d.isNew&&r[d.requestID]===void 0)continue;if(!c&&!d.isNew&&!i.summarised?.has(d.requestID)){n[d.requestID]=!1;continue}const a=r[d.requestID]??(d.isNew?!1:d.checked||!d.risky&&!c);n[d.requestID]=s&&a}return t.payment&&(n[t.payment.requestID]=s),n},jo=(t,s,r,o,i={})=>({decisions:wo(t,s==="allow",r,o,i),block:s==="block",mayStore:s==="allow"}),ko=t=>Ct(t)||t.type==="protocol"&&t.counterparty==="anyone"?!1:t.type==="basket"?!!t.basket&&!fs(t.basket):!1,So=t=>!t.items.some(s=>s.framePair)&&t.items.some(s=>ko(s)),No=[.25,1,5],Eo=1,ue=t=>t<1?`$${t.toFixed(2)}`:Number.isInteger(t)?`$${t}`:`$${t.toFixed(2)}`,Dt=t=>{const s=t.allowNone?[0,...t.presetsUsd]:[...t.presetsUsd];return e.jsx("div",{className:"flex flex-wrap",style:{gap:8},role:"radiogroup","aria-label":"Envelope amount",children:s.map(r=>{const o=t.value===r;return e.jsx("button",{type:"button",role:"radio","aria-checked":o,disabled:t.disabled,onClick:()=>t.onChange(r),style:{minHeight:44,padding:"0 16px",borderRadius:22,border:`1.5px solid ${o?v.gold:v.chip}`,background:o?v.gold:v.chip,color:o?v.bg:v.ink,fontSize:r?16:14,fontWeight:700,cursor:"pointer"},children:r?ue(r):"No envelope"},r)})})};function Po(t){return{allowDisabled:t.busy||!t.armed||t.hold||t.mustRead,denyDisabled:t.busy}}const Co=(t,s)=>t.key==="Escape"&&!t.defaultPrevented&&!s,Ue=12,Io=3e3,Ro=t=>{const{request:s,onResponse:r,armed:o=!0}=t,{handleSelect:i,hideMenu:n}=fe(),{addSnackbar:d}=je(),{chromeStorageService:c}=ee(),a=c.getCurrentAccountObject().account,f=Ps(a?.addresses?.identityAddress,a?.name??"",a?.settings?.socialProfile?.displayName??"",!1),x=ms(f.displayName,f.paymail,f.handle).tag,y=hs(a?.pubKeys?.identityPubKey),l=u.useMemo(()=>go(s),[s]),[w,j]=u.useState({}),[p,b]=u.useState(!1),k=u.useRef(s.items.length);u.useEffect(()=>{if(s.items.length===k.current)return;k.current=s.items.length,b(!0);const m=setTimeout(()=>b(!1),1e3);return()=>clearTimeout(m)},[s.items.length]);const h=u.useRef(!1),g=()=>{h.current||(h.current=!0,X({action:"BUNDLE_SHEET_FREEZE",bundleID:s.bundleID}).catch(()=>{}))},E=(m,S)=>w[m]??S,[C,O]=u.useState(),[te,Se]=u.useState(po),[me,P]=u.useState(!0),[B,Ne]=u.useState(0),[ie,At]=u.useState(!0),Ve=u.useMemo(()=>So(s),[s]),[Ee,Lt]=u.useState(!0),[Ge]=u.useState(()=>ct(l)!=="careful"),[le,Pe]=u.useState(!1),[Ot,Ke]=u.useState("");u.useEffect(()=>{i("bsv"),n()},[i,n]),u.useEffect(()=>{X({action:"GET_BUNDLE_ALLOWANCE",originator:s.originator}).then(m=>{!m?.success||!m.data||(O(m.data),Se(m.data.defaultUsd))}).catch(()=>{})},[s.originator]);const F=s.mint&&l.payment&&l.lines.every(m=>!m.risky)?s.mint:void 0,Ye=!1,ce=!F&&l.payment&&C?.usdPerBsv?C.envelope:void 0,Xe=!!ce?.offer,he=bt(C?.usdPerBsv),Z=l.payment?J(l.payment.satoshis,he):void 0,se=async m=>{const S=m==="allow";Pe(!0),Ke("");try{if(S){const K=await ae(c);if(!K.ok){Ke(K.message),Pe(!1);return}}S&&ke(s.originator);const N=jo(l,m,w,Ge,Ie),R=await X({action:"BUNDLE_PERMISSION_RESPONSE",seenHash:qt(m),bundleID:s.bundleID,decisions:N.decisions,allowanceUsd:N.mayStore&&Ye&&me?te:0,envelopeUsd:N.mayStore&&Xe?B:0,remember:N.mayStore&&ie,trustSite:!F&&N.mayStore&&ie&&Ve&&Ee,block:N.block});R&&R.success===!1&&R.error&&(d(R.error,"error"),await new Promise(K=>setTimeout(K,Io))),r()}catch(N){d(N instanceof Error?N.message:String(N),"error"),Pe(!1)}},T=ct(l),_=wt(s.originator),Ft=l.lines.length+(l.payment?1:0)>1,oe=l.payment?Ae(l.payment.satoshis,he):"",Mt=0,Ce=s.items.some(m=>m.reconnect),de=s.items.find(m=>m.framePair)?.framePair,Ut=de?"Allow inside this site":Ce?"Reconnect":F?`${F.title.split(" ")[0]} · ${oe}`:T==="post"?l.payment?`Allow & pay ${oe}`:"Allow posting":T==="private"?"Allow":T==="signin"?"Connect and sign in":T==="pay"?l.mode==="connectAndPay"?`Connect & pay ${oe}`:`Pay ${oe}`:Ft?"Allow all":"Connect",Bt=Is(l.lines,m=>E(l.lines[m].requestID,l.lines[m].checked)),_t=le||!o||p,D=T==="careful",Je=l.lines.filter(m=>m.risky),Ze=l.lines.filter(m=>m.isNew&&!(D&&m.risky)),[zt,Wt]=u.useState(()=>new Set),Qe=u.useRef(null);u.useEffect(()=>{const m=Qe.current,S=m?.closest("[data-approval-scroll]");if(!D||!m||!S)return;const N=()=>{const K=S.querySelector('[data-testid="approval-choices"]'),Yt=Math.max(S.getBoundingClientRect().top,0),Xt=Math.min(K?K.getBoundingClientRect().top:window.innerHeight,window.innerHeight),$e=[];S.querySelectorAll("[data-line-id]").forEach(ne=>{const pe=ne.getBoundingClientRect();pe.height>0&&pe.top>=Yt-1&&pe.bottom<=Xt+1&&$e.push(ne.dataset.lineId??"")}),Wt(ne=>$e.every(pe=>ne.has(pe))?ne:new Set([...ne,...$e]))};N();const R=setTimeout(N,700);return S.addEventListener("scroll",N,{passive:!0}),window.addEventListener("resize",N),()=>{clearTimeout(R),S.removeEventListener("scroll",N),window.removeEventListener("resize",N)}},[D,l]);const Ie=bo(l,D,D&&!Ge?zt:void 0,T),et=D&&Ie.hidden.size>0,Re=u.useRef({busy:le,send:se});Re.current={busy:le,send:se},u.useEffect(()=>{const m=S=>{Co(S,Re.current.busy)&&(S.preventDefault(),Re.current.send("notNow"))};return window.addEventListener("keydown",m),()=>window.removeEventListener("keydown",m)},[]);const tt=D?l.lines.filter(m=>!m.risky&&!m.isNew):[],qt=m=>co(m==="allow"?vo(s.items,Ie):s.items),Ht=(m,S)=>j(N=>({...N,[m]:!E(m,S)})),xe=(m,S=!1)=>e.jsxs("label",{"data-line-id":m.requestID,className:"flex items-start gap-3 cursor-pointer",style:{minHeight:44,padding:S?"10px 14px":"8px 0",borderRadius:S?14:0,background:S?v.redChip:void 0,fontSize:15},children:[e.jsx("input",{type:"checkbox",checked:E(m.requestID,m.checked),onChange:()=>Ht(m.requestID,m.checked),style:{width:22,height:22,accentColor:m.risky?v.red:v.gold,flexShrink:0,marginTop:1}}),e.jsxs("span",{className:"flex flex-col min-w-0",style:{gap:2},children:[e.jsx("span",{style:{color:m.risky?"#FF6B6B":void 0,fontWeight:600,lineHeight:1.3},children:m.text}),m.detail&&e.jsx("span",{className:"break-all",style:{fontSize:12,color:v.muted},children:m.detail})]})]},m.requestID),Te=(x||y)&&e.jsxs("span",{children:[e.jsx("span",{style:{color:v.gold},children:x||"this account"}),y&&e.jsxs("span",{className:"font-mono",style:{userSelect:"none",fontSize:12,color:v.muted},children:[" ","· ",y]})]}),Vt=e.jsxs("div",{className:"flex flex-col",style:{gap:4},children:[(x||y)&&e.jsxs("p",{className:"m-0","data-testid":"signing-as",style:{fontSize:12},children:["Signing in as ",Te]}),!D&&l.lines.some(m=>!m.isNew)&&e.jsxs("p",{className:"m-0",style:{fontSize:13,fontWeight:700,color:v.muted},children:["This lets ",_,":"]}),!D&&l.lines.filter(m=>!m.isNew).map(m=>xe(m)),l.payment&&e.jsxs("p",{className:"m-0",style:{padding:"6px 0"},children:["Pay ",e.jsx("span",{style:{color:v.gold,fontWeight:600},children:oe})," now to ",s.originator,l.payment.description&&e.jsxs(e.Fragment,{children:[" “",l.payment.description,"”"]})]}),l.payment?.labels?.length?e.jsxs("p",{className:"m-0",style:{fontSize:13,color:v.muted},"data-testid":"payment-labels",children:["Labels: ",l.payment.labels.join(", ")]}):null,Ye,e.jsxs("label",{className:"flex items-center gap-3 cursor-pointer",style:{minHeight:44},children:[e.jsx("input",{type:"checkbox",checked:ie,onChange:()=>At(!ie),style:{width:18,height:18,accentColor:v.gold,flexShrink:0}}),e.jsx("span",{children:"Remember this site"})]}),!F&&Ve&&ie&&e.jsxs("label",{className:"flex items-start gap-3 cursor-pointer",style:{padding:"6px 0"},children:[e.jsx("input",{type:"checkbox",checked:Ee,onChange:()=>Lt(!Ee),style:{width:18,height:18,accentColor:v.gold,flexShrink:0,marginTop:1}}),e.jsxs("span",{children:["Don't ask again on ",s.originator," for sign-in and signing."," ",C?.allowances?"Payments stay within the allowance;":"Payments still ask, or use its envelope;"," ","your personal details always ask."]})]}),e.jsxs("ul",{className:"m-0 mt-1 pl-4 break-all",style:{fontSize:11,color:v.muted},children:[l.payment&&e.jsxs("li",{children:["pay: ",l.payment.detail]}),l.payment?.recipients?.slice(0,Ue).map((m,S)=>e.jsxs("li",{"data-testid":"pay-recipient",children:["to ",m.to,": ",m.satoshis.toLocaleString()," sats"]},`to-${S}`)),(l.payment?.recipients?.length??0)>Ue&&e.jsxs("li",{children:["and ",(l.payment.recipients.length-Ue).toLocaleString()," more outputs"]}),Mt>0]})]}),{allowDisabled:Gt,denyDisabled:De}=Po({busy:le,armed:o,hold:p,mustRead:et}),st={label:"Not now",onClick:()=>{se("notNow")},disabled:De},Kt={label:"Block this site",onClick:()=>{se("block")},disabled:De},ot={label:(D?"I trust it, allow":Ut)+(Ce||F?"":Bt),onClick:()=>{se("allow")},disabled:Gt,busy:le};let z,W,q=null,H;const M=m=>e.jsx("span",{style:{color:v.gold},children:m}),nt=m=>Ae(m,he);if(F&&T!=="careful")z=e.jsx(_e,{amount:Z?.main??"",sub:Z?.sub}),H="One approval for all of it",W=e.jsx(e.Fragment,{children:M(F.title)}),q=e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"mint-sheet",children:[e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:15,fontWeight:600},"data-testid":"mint-cost",children:[e.jsx(I,{size:18}),"Costs ",nt(F.premiumSats)," + ",nt(F.feeSats)," network fee"]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs($,{children:[e.jsx(I,{}),"Locked with your keys"]}),e.jsxs($,{children:[e.jsx(I,{}),"Only on ",F.site]}),e.jsxs($,{children:[e.jsx(I,{}),"Next payment asks again"]})]})]});else if(T==="careful"){z=l.lines.length>0?null:e.jsx(xs,{}),H="Check this carefully";const m=s.items.some(R=>R.privileged),S=Je.some(R=>s.items.find(K=>K.requestID===R.requestID)?.type==="certificate"),N=R=>e.jsx("span",{style:{color:"#FF6B6B"},children:R});W=m?e.jsxs(e.Fragment,{children:["Wants ",N("full control")," of your keys"]}):S?e.jsxs(e.Fragment,{children:["Wants your ",N("private details")]}):e.jsxs(e.Fragment,{children:["Wants ",N("more than usual")]}),q=e.jsxs("div",{ref:Qe,className:"flex flex-col",style:{gap:8},children:[m&&e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:v.redChip,fontSize:14},children:[e.jsx(at,{}),"Could move your money"]}),Je.map(R=>xe(R,!0)),tt.length>0&&e.jsxs("div",{className:"flex flex-col","data-testid":"careful-ordinary-lines",style:{padding:"0 4px"},children:[e.jsx("p",{className:"m-0",style:{fontSize:12,fontWeight:700,color:v.muted},children:"Also asks to"}),tt.map(R=>xe(R))]}),e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:v.redChip,fontSize:14},children:[e.jsx(at,{}),"Only allow apps you trust"]})]})}else if(T==="pay")z=e.jsx(_e,{amount:Z?.main??"",sub:Z?.sub}),H=l.payment?.description||"Asks you to pay",W=e.jsxs(e.Fragment,{children:["Pay ",M(oe)," now to ",M(_)]}),q=e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex items-center gap-3",style:{padding:14,borderRadius:16,background:v.chip},children:[e.jsx(gs,{site:s.originator,size:44}),e.jsxs("div",{className:"flex flex-col min-w-0",style:{gap:2,lineHeight:1.25},children:[e.jsxs("span",{className:"truncate",style:{fontSize:15,fontWeight:600},children:["To ",s.originator]}),e.jsx("span",{className:"truncate",style:{fontSize:13,color:v.muted},children:l.payment?.description?`“${l.payment.description}”`:"Straight from your wallet"}),l.payment?.labels?.length?e.jsxs("span",{className:"truncate",style:{fontSize:12,color:v.muted},"data-testid":"payment-labels",children:["Labels: ",l.payment.labels.join(", ")]}):null]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:v.soft},children:[e.jsx(I,{size:18}),B>0?"Then small payments come out of the envelope":"Every payment asks you first"]}),Xe&&ce&&e.jsxs("div",{className:"flex flex-col",style:{gap:8},"data-testid":"envelope-offer",children:[e.jsx("span",{style:{fontSize:15,fontWeight:600},children:ce.balanceSats!==void 0?e.jsxs(e.Fragment,{children:["Top up the envelope",e.jsxs("span",{style:{fontSize:13,fontWeight:400,color:v.muted},children:[" ","· ",Ae(ce.balanceSats,he)," left, not enough for this"]})]}):e.jsxs(e.Fragment,{children:[B>0?`Also put ${ue(B)}`:"Also put money"," in ",M(_),"'s envelope?"]})}),e.jsx(Dt,{presetsUsd:ce.presetsUsd,value:B,onChange:Ne,allowNone:!0,disabled:_t}),e.jsxs("span",{style:{fontSize:12,color:v.muted},children:["Stays in your wallet. Small payments from ",_," come out of it without asking; Coin return any time."]})]})]});else if(T==="post")z=e.jsx(ge,{site:s.originator}),H="Wants to post for you",W=e.jsxs(e.Fragment,{children:["Allow ",M(_)," to post for you"]}),q=e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs($,{children:[e.jsx(I,{}),"Post and like as you"]}),e.jsxs($,{children:[e.jsx(I,{}),"Nothing else moves"]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14},"data-testid":"post-cost",children:[e.jsx(I,{size:18}),Z?e.jsxs("span",{className:"flex flex-col",children:[e.jsxs("span",{children:["This post costs"," ",e.jsx("span",{style:{fontSize:20,fontWeight:800,color:v.gold},children:Z.main})]}),e.jsx("span",{style:{fontSize:12,color:v.muted},children:Z.sub})]}):"Each paid post asks you first"]})]});else if(T==="private")z=e.jsx(it,{}),H="Your data",W=e.jsx(e.Fragment,{children:M(Le("private",_,l))}),q=e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs($,{children:[e.jsx(I,{}),"Uses keys from your wallet"]}),e.jsxs($,{children:[e.jsx(I,{}),"No money moves"]})]});else if(de)z=e.jsx(ge,{site:s.originator}),H=`Inside ${de}`,W=e.jsxs(e.Fragment,{children:["Let ",M(_)," use your wallet inside ",M(de),"?"]}),q=e.jsxs("div",{className:"flex flex-col",style:{gap:8,marginTop:4,fontSize:13},children:[e.jsxs("span",{children:[s.originator," is shown inside ",de,". Only allow it if you opened it there yourself."]}),e.jsxs("span",{style:{color:v.muted,fontSize:12},children:["After this, what you already allowed ",s.originator," applies here too."]})]});else if(Ce&&T==="signin")z=e.jsx(ge,{site:s.originator}),H="You disconnected this site",W=e.jsxs(e.Fragment,{children:["Reconnect to ",M(_),"?"]}),q=e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs($,{children:[e.jsx(I,{}),"Shares your public key"]}),e.jsxs($,{children:[e.jsx(I,{}),"No money moves"]})]});else if(T==="signin")z=e.jsx(it,{}),H="Connect and sign in",W=e.jsx(e.Fragment,{children:M(Le("signin",_,l))}),q=e.jsxs(e.Fragment,{children:[Te&&e.jsxs("div",{className:"flex items-center gap-2.5",children:[e.jsx("div",{"aria-hidden":"true",style:{width:30,height:30,borderRadius:15,background:"conic-gradient(#F5C542, #B8860B, #FFE08A, #F5C542)",flexShrink:0}}),e.jsxs("span",{style:{fontSize:18,fontWeight:600},children:["as ",Te]})]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs($,{children:[e.jsx(I,{}),"No password"]}),e.jsxs($,{children:[e.jsx(I,{}),"No money moves"]})]})]});else{z=e.jsx(ge,{site:s.originator}),H="Wants to connect",W=e.jsx(e.Fragment,{children:M(Le("connect",_,l))});const m=new Set(s.items.map(N=>N.type)),S=[{label:m.has("certificate")?"Your details":"Your name",icon:e.jsx(To,{})}];m.has("protocol")&&S.push({label:"Sign posts",icon:e.jsx(Do,{})}),m.has("basket")&&S.push({label:"Keep items",icon:e.jsx($o,{})}),q=e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"grid",style:{gridTemplateColumns:`repeat(${S.length}, minmax(0, 1fr))`,gap:8},children:S.map(N=>e.jsxs("div",{className:"flex flex-col items-center",style:{gap:8,padding:"14px 6px",borderRadius:16,background:v.chip},children:[N.icon,e.jsx("span",{style:{fontSize:13,fontWeight:600,textAlign:"center"},children:N.label})]},N.label))}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:v.soft},children:[e.jsx(I,{size:18}),"Payments still ask you first"]})]})}return e.jsx(A.div,{className:"flex flex-col w-full h-full",style:{maxHeight:"100vh"},initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{type:"spring",damping:24,stiffness:260},"data-approval-kind":T,onPointerDownCapture:g,children:e.jsxs(vt,{tone:D?"red":"gold",site:s.originator,siteSub:H,onClose:()=>{se("notNow")},closeLabel:"Deny and close",closeDisabled:De,hero:z,title:W,primary:D?st:ot,secondary:D?ot:st,tertiary:D?Kt:void 0,error:Ot||(et?"Scroll to read every line before allowing":""),children:[q,e.jsx("div",{"data-testid":"approval-lines",style:{marginTop:8},children:Vt}),Ze.length>0&&e.jsx("div",{className:"flex flex-col","data-testid":"new-lines",style:{gap:4,marginTop:8},children:Ze.map(m=>xe(m,!0))})]})})},He={"aria-hidden":!0,width:28,height:28,viewBox:"0 0 24 24",fill:"none",stroke:v.gold,strokeWidth:1.8,strokeLinecap:"round",strokeLinejoin:"round"},To=()=>e.jsxs("svg",{...He,children:[e.jsx("circle",{cx:"12",cy:"8",r:"4"}),e.jsx("path",{d:"M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"})]}),Do=()=>e.jsxs("svg",{...He,children:[e.jsx("path",{d:"M12 20h9"}),e.jsx("path",{d:"M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"})]}),$o=()=>e.jsxs("svg",{...He,children:[e.jsx("rect",{x:"3",y:"7",width:"18",height:"13",rx:"2"}),e.jsx("path",{d:"M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"})]}),ft=t=>`${(t/1e8).toFixed(8)} BSV`,be=t=>`$${t.toFixed(2)}`;function Ao(t){const s=t.symbol?`$${t.symbol}`:"tokens",r=`${ft(t.priceSats)} (${be(t.usdAtRate)})`,o=[[t.side==="offer"?"You give":"You get",`${t.tokens} ${s}`],[t.side==="offer"?"You get":"You pay",r],["Contract price",t.terms.priceSats!==void 0?`${t.terms.priceSats.toLocaleString("en-US")} sats`:be(t.terms.priceUsd??0)],["Rate",`$${t.rate.toFixed(2)} per BSV (${t.rateSource})`]];t.overlayFeeSats>0&&o.push(["Indexing fee",ft(t.overlayFeeSats)]),o.push(["Contract",t.terms.ref],["Document hash",`${t.terms.docHash.slice(0,16)}…`]),t.terms.sellerKey&&o.push(["Seller wallet",`${t.terms.sellerKey.slice(0,16)}…`]),t.terms.expiresAt&&o.push(["Offer expires",new Date(t.terms.expiresAt).toISOString().replace("T"," ").slice(0,16)+" UTC"]);const i=t.side==="offer"?`Offer ${t.tokens} ${s} for ${be(t.usdAtRate)}`:`Swap ${be(t.usdAtRate)} for ${t.tokens} ${s}`,n=t.side==="offer"?`${t.split?`First the wallet sets aside exactly ${t.tokens} ${s} (a small token send to yourself). `:""}Then it signs your half only: your tokens move only in the buyer's transaction, which must pay you ${r}. Nothing is broadcast now.`:"One transaction: the tokens come to you and the price goes to the seller, with the contract hash on chain. If it does not broadcast, nothing moves.";return{title:i,rows:o,note:n,action:t.side==="offer"?"Sign offer":"Pay and swap"}}const Lo=({request:t,onResponse:s})=>{const{theme:r}=G(),[o,i]=u.useState(!1),n=Ao(t),d=r.color.global.gray,c=r.color.global.contrast,a=f=>{o||(i(!0),L({action:"SWAP_RESPONSE",requestID:t.requestID,allow:f}),s())};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 gap-3",children:[e.jsx(Rs,{size:32,style:{color:c}}),e.jsx("h2",{className:"m-0 text-lg font-semibold text-center",style:{color:c},children:n.title}),e.jsx("div",{className:"flex flex-col gap-1.5 w-full",style:{maxWidth:"20rem"},"data-testid":"swap-rows",children:n.rows.map(([f,x])=>e.jsxs("div",{className:"flex justify-between gap-3 text-sm",children:[e.jsx("span",{style:{color:d},children:f}),e.jsx("span",{className:"text-right break-all",style:{color:c},children:x})]},f))}),e.jsx("p",{className:"m-0 text-xs leading-relaxed text-center",style:{color:d,maxWidth:"20rem"},children:n.note}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"20rem"},children:[e.jsx(V,{theme:r,type:"primary",label:n.action,disabled:o,onClick:()=>a(!0)}),e.jsx(V,{theme:r,type:"secondary-outline",label:"Decline",disabled:o,onClick:()=>a(!1)})]})]})},Oo=({request:t,onResponse:s})=>{const{theme:r}=G(),[o,i]=u.useState(!1),n=Cs(t),d=r.color.global.gray,c=r.color.global.contrast,a=f=>{o||(i(!0),L({action:"TWETCH_RESPONSE",requestID:t.requestID,allow:f}),s())};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(ys,{size:36,style:{color:c}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:c},children:n.title}),t.kind==="post"&&e.jsx("p",{className:"m-0 text-sm leading-relaxed whitespace-pre-wrap break-words",style:{color:c,maxWidth:"18rem"},"data-testid":"twetch-preview",children:t.preview}),e.jsx("p",{className:"m-0 text-xs leading-relaxed",style:{color:d,maxWidth:"18rem"},children:n.body}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(V,{theme:r,type:"primary",label:n.approve,disabled:o,onClick:()=>a(!0)}),e.jsx(V,{theme:r,type:"secondary-outline",label:"Decline",disabled:o,onClick:()=>a(!1)})]})]})},Fo=t=>{const s=t.sequence,r=s?s.totalPosts:t.posts,o=s?s.totalSats:t.sats,i=s?s.totalTxs:t.txs;return{title:r!==void 0?`Lock ${r.toLocaleString("en")} posts to you`:"Lock your posts to you",site:`${t.originator} is asking`,privacy:"Private: only you can see them. They are encrypted with your wallet’s keys before they leave this device.",cost:`About ${o.toLocaleString("en")} sats in ${i.toLocaleString("en")} transaction${i===1?"":"s"}`,chunks:s?`Sent in ${s.chunks.toLocaleString("en")} parts. One Allow covers the whole run for 2 hours, up to 10% over this estimate. Anything more asks again.`:void 0}},Mo=({request:t,onResponse:s})=>{const{theme:r}=G(),[o,i]=u.useState(!1),n=Fo(t),d=t.sequence?t.sequence.totalSats:t.sats,c=J(d,ve(t.usdPerBsv,!0)),a=r.color.global.gray,f=r.color.global.contrast,x=y=>{o||(i(!0),L({action:"MINT_PRIVATE_RESPONSE",requestID:t.requestID,allow:y}),s())};return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(bs,{size:36,style:{color:f}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:f},children:n.title}),e.jsx("p",{className:"m-0 text-xs",style:{color:a},children:n.site}),e.jsxs("div",{className:"flex flex-col items-center","data-testid":"dollar-amount",children:[e.jsx("span",{style:{fontSize:32,fontWeight:800,lineHeight:1.1,color:f},children:c.main}),e.jsx("span",{className:"text-xs",style:{color:a},children:c.sub})]}),e.jsx("p",{className:"m-0 text-sm",style:{color:f},children:n.cost}),e.jsx("p",{className:"m-0 text-xs leading-relaxed",style:{color:a,maxWidth:"18rem"},children:n.privacy}),n.chunks&&e.jsx("p",{className:"m-0 text-xs leading-relaxed",style:{color:a,maxWidth:"18rem"},children:n.chunks}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(V,{theme:r,type:"primary",label:"Allow",disabled:o,onClick:()=>x(!0)}),e.jsx(V,{theme:r,type:"secondary-outline",label:"Decline",disabled:o,onClick:()=>x(!1)})]})]})},Uo=({request:t,onResponse:s})=>{const{theme:r}=G(),o=t.usdPerBsv,i=t.capSatsPerHour,n=o?i/1e8*o:void 0,[d,c]=u.useState(n!==void 0?n.toFixed(2):""),[a,f]=u.useState(String(i)),[x,y]=u.useState(!1),l=u.useMemo(()=>{const h=o?gt(Number(d),o):Math.floor(Number(a));return Number.isFinite(h)&&h>=1?Math.min(h,i):0},[d,a,o,i]),w=h=>{x||(y(!0),L({action:"STREAM_GRANT_RESPONSE",requestID:t.requestID,capSatsPerHour:h?l:null}),s())},j=r.color.global.gray,p=r.color.global.contrast,b=new Date(t.expiresAt).toLocaleString(),k=J(i,ve(o,!0));return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(vs,{size:36,style:{color:p}}),e.jsxs("h2",{className:"m-0 text-lg font-semibold",style:{color:p},children:["Allow ",t.originator," to stream while you watch, up to"]}),e.jsxs("div",{className:"flex flex-col items-center","data-testid":"dollar-amount",children:[e.jsxs("span",{style:{fontSize:o?40:24,fontWeight:800,lineHeight:1.1,color:p},children:[k.main,e.jsx("span",{style:{fontSize:16,fontWeight:600},children:" an hour"})]}),e.jsx("span",{className:"text-xs",style:{color:j},children:k.sub})]}),t.description&&e.jsx("p",{className:"m-0 text-xs",style:{color:j,maxWidth:"18rem"},children:t.description}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:j,maxWidth:"18rem"},children:["Only “",t.protocolName,"” payments from ",t.originator," go through without asking, until ",b,". Anything else still asks you. Revoke any time in Settings › Streaming permissions."]}),e.jsxs("label",{className:"flex items-center gap-2 text-sm",style:{color:p},children:["Cap per hour ",o?"$":"",o?e.jsx("input",{"aria-label":"Cap in dollars per hour",inputMode:"decimal",value:d,onChange:h=>c(h.target.value),className:"w-24 px-2 py-1 rounded bg-transparent border",style:{color:p}}):e.jsx("input",{"aria-label":"Cap in sats per hour",inputMode:"numeric",value:a,onChange:h=>f(h.target.value),className:"w-28 px-2 py-1 rounded bg-transparent border",style:{color:p}}),!o&&"sats"]}),e.jsxs("p",{className:"m-0 text-xs",style:{color:j},children:[l?o?`${J(l,ve(o,!0)).main} an hour · ${l.toLocaleString()} sats`:`${l.toLocaleString()} sats an hour ${ws}`:"Enter a cap above zero",l===i?" (the most this site asked for)":""]}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(V,{theme:r,type:"primary",label:"Allow",disabled:x||!l,onClick:()=>w(!0)}),e.jsx(V,{theme:r,type:"secondary-outline",label:"Not now",disabled:x,onClick:()=>w(!1)})]})]})},Bo=({request:t,onResponse:s})=>{const r=t.usdPerBsv,[o,i]=u.useState(Eo),[n,d]=u.useState(!1),c=r?gt(o,r):0,a=t.envelope?.balanceSats??0,f=ve(r,!0),x=J(c,f),y=wt(t.originator),l=w=>{n||(d(!0),L({action:"STREAM_GRANT_RESPONSE",requestID:t.requestID,capSatsPerHour:w?c:null}),s())};return e.jsx(vt,{site:t.originator,siteSub:t.description||"Many small payments",onClose:()=>l(!1),closeLabel:"Not now",closeDisabled:n,hero:e.jsx(_e,{amount:r?ue(o):x.main,sub:x.sub,badge:"ENVELOPE"}),title:e.jsxs(e.Fragment,{children:["Put ",r?ue(o):"money"," in ",e.jsx("span",{style:{color:v.gold},children:y}),"'s envelope"]}),primary:{label:r?`Put ${ue(o)} in`:"Price unavailable",onClick:()=>l(!0),disabled:n||!c},secondary:{label:"Not now",onClick:()=>l(!1),disabled:n},testId:"envelope-sheet",children:e.jsxs("div",{className:"flex flex-col",style:{gap:10},children:[e.jsx(Dt,{presetsUsd:No,value:o,onChange:i,disabled:n}),a>0&&e.jsxs("span",{style:{fontSize:13,color:v.muted},"data-testid":"envelope-balance",children:["Already in it: ",J(a,f).main]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8},children:[e.jsxs($,{children:[e.jsx(I,{}),"Stays in your wallet"]}),e.jsxs($,{children:[e.jsx(I,{}),"Only ",y," can spend it"]}),e.jsxs($,{children:[e.jsx(I,{}),"Coin return any time"]})]}),e.jsxs("span",{style:{fontSize:13,color:v.soft},children:["Small payments from ",t.originator," come out of the envelope without asking. When it is empty, it asks you again. Settings › Envelopes shows what is left."]})]})})},Q={bg:"#0B0B0D",text:"#FFFFFF",muted:"#98A2B3",gold:"#F5C542",line:"#2B2F36"};function _o(t){const[s,r]=u.useState(null);return u.useEffect(()=>{if(!t)return;let o=!0;const i=()=>{if(!js(t)){r(null);return}ks(t,{asking:!0,path:Ss(t)}).then(n=>o&&r(n))};return i(),window.addEventListener(lt,i),window.addEventListener("storage",i),()=>{o=!1,window.removeEventListener(lt,i),window.removeEventListener("storage",i)}},[t]),s}const Be=t=>t.replace(/^https?:\/\//,"").replace(/\/.*$/,"").toLowerCase(),zo=(t,s)=>s?.length?`${Be(t)} (inside ${s.map(r=>Be(r)).join(", ")})`:Be(t),Wo=1500,qo=({originator:t,themed:s,embeddedIn:r})=>e.jsxs("div",{"data-testid":"bwx-origin-strip",className:"flex items-center gap-2 px-3",style:{background:Q.bg,color:Q.text,borderBottom:`1px solid ${Q.line}`,minHeight:32,fontFamily:"Inter, system-ui, sans-serif",fontSize:12,flexShrink:0},children:[e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24","aria-hidden":!0,fill:"none",stroke:Q.gold,strokeWidth:"2.5",children:[e.jsx("rect",{x:"4",y:"11",width:"16",height:"10",rx:"2"}),e.jsx("path",{d:"M8 11V7a4 4 0 0 1 8 0v4"})]}),e.jsx("span",{style:{color:Q.muted},children:"bWalletX · request from"}),e.jsx("span",{className:"font-bold truncate",style:{color:Q.text},children:zo(t,r)}),s&&e.jsx("span",{className:"ml-auto whitespace-nowrap",style:{color:Q.muted,fontSize:10},children:"site theme"})]}),Ho=({theme:t,originator:s})=>e.jsxs("div",{"data-testid":"bwx-site-banner",className:"flex items-center gap-3 px-4",style:{background:t.artData?`linear-gradient(90deg, ${t.bg} 35%, ${t.bg}99), url("${t.artData}") center / cover`:`linear-gradient(135deg, ${t.bg}, ${t.surface})`,color:t.text,borderBottom:`3px solid ${t.accent}`,minHeight:60,flexShrink:0},children:[t.logoData?e.jsx("img",{src:t.logoData,alt:"",width:36,height:36,style:{borderRadius:8,objectFit:"contain"}}):e.jsx("span",{"aria-hidden":!0,className:"flex items-center justify-center font-bold",style:{width:36,height:36,borderRadius:8,background:t.accent,color:t.onAccent},children:t.name.slice(0,1).toUpperCase()}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("div",{className:"font-bold truncate",style:{fontSize:15,color:t.text},children:t.name}),e.jsxs("div",{className:"truncate",style:{fontSize:11,color:t.accentHi},children:["Connected with bWalletX · ",Ns(s)]})]})]}),Vo=({originator:t,children:s,theme:r,embeddedIn:o})=>{const i=_o(r===void 0?t:void 0),n=r===void 0?i:r,d=!!o?.length,[c,a]=u.useState(!d);return u.useEffect(()=>{if(!d)return a(!0);a(!1);const f=setTimeout(()=>a(!0),Wo);return()=>clearTimeout(f)},[d,t]),t?e.jsxs("div",{className:"flex flex-col w-full h-full",style:n?{boxShadow:`inset 3px 0 0 ${n.accent}, inset -3px 0 0 ${n.accent}`}:void 0,children:[e.jsx(qo,{originator:t,themed:!!n,embeddedIn:o}),n&&e.jsx(Ho,{theme:n,originator:t}),e.jsx("div",{className:"flex-1 min-h-0 flex items-center justify-center relative","data-testid":"bwx-sheet-body","data-armed":c?"true":"false",style:c?void 0:{pointerEvents:"none"},children:s})]}):e.jsx(e.Fragment,{children:s})};xt.Buffer=ht;xt.process=Zt;window.Buffer=ht;const Go=t=>"payload"in t&&t.payload.originator||void 0,Ko=t=>{const s="payload"in t?t.payload.embeddedIn:void 0;return Array.isArray(s)?s.filter(r=>typeof r=="string"):void 0},Yo=1e4,Xo=2e3,Y=new URLSearchParams(window.location.search).get("inpage"),mt=window.location.protocol==="chrome-extension:"&&window.top!==window&&!Y&&!!window.location.ancestorOrigins?.length&&window.location.ancestorOrigins[0]!==window.location.origin,Jo=(t,s)=>{const[r,o]=u.useState(t?void 0:!0),[i,n]=u.useState(!t),[d,c]=u.useState(!1);return u.useEffect(()=>{t&&X({action:"INPAGE_SHEET_CHECK",token:Y}).then(a=>o(!!a?.success)).catch(()=>o(!1))},[t]),u.useEffect(()=>{if(!t||r!==!0||!s.current)return;let a;const f=new IntersectionObserver(x=>{const y=x[x.length-1];window.clearTimeout(a),y.isVisible&&y.intersectionRatio>=.99?a=window.setTimeout(()=>n(!0),500):n(!1)},{threshold:[0,.99,1],trackVisibility:!0,delay:100});return f.observe(s.current),()=>{window.clearTimeout(a),f.disconnect()}},[t,s,r]),u.useEffect(()=>{if(!t||i){c(!1);return}const a=window.setTimeout(()=>c(!0),1500);return()=>window.clearTimeout(a)},[t,i]),{tokenOk:r,armed:r===!0&&i,stuck:r===!0&&!i&&d}},Zo=()=>{const{theme:t}=G(),{isLocked:s,isReady:r}=ee(),o=u.useRef(null),i=u.useRef(null),n=Jo(!!Y,i),d=!mt&&n.tokenOk===!0,c=u.useRef(d);c.current=d;const[a,f]=u.useState({kind:"loading"}),x=u.useRef(void 0),y=u.useRef(void 0),l=()=>{x.current!==void 0&&(window.clearTimeout(x.current),x.current=void 0)},w=u.useRef(a);w.current=a;const j=u.useCallback(async(h,g)=>{l();const E=w.current;if(h==="bundle"&&E.kind==="bundle"&&E.requestID===g){try{const O=await X({action:"GET_PROMPT_PAYLOAD",kind:h,requestID:g});O?.success&&O.data&&f({kind:"bundle",requestID:g,payload:O.data})}catch{}return}f({kind:"loading"});let C;try{C=await X({action:"GET_PROMPT_PAYLOAD",kind:h,requestID:g})}catch{C=void 0}C?.success&&C.data?f({kind:h,requestID:g,payload:C.data}):(f({kind:"expired"}),window.setTimeout(()=>{y.current?.()},Xo))},[]),p=u.useCallback(async()=>{l();let h;try{h=await X({action:"CLOSE_PROMPT_WINDOW"})}catch{h=void 0}if(h===void 0){window.close();return}const g=h.data?.prompt;g&&(g.kind==="unlock"?f({kind:"unlock"}):g.requestID&&await j(g.kind,g.requestID))},[j]),b=u.useCallback(async()=>{l();let h;try{h=await X({action:"GET_NEXT_PROMPT"})}catch{h=void 0}if(h?.data?.prompt){await j(h.data.prompt.kind,h.data.prompt.requestID);return}if(h?.data?.busy){f({kind:"waiting"}),x.current=window.setTimeout(()=>{p()},Yo);return}await p()},[j,p]);y.current=b,u.useEffect(()=>{if(!r||!d)return;const h=new URLSearchParams(window.location.search),g=h.get("kind"),E=h.get("requestID");if(g==="unlock"){s?f({kind:"unlock"}):b();return}if(g&&E){j(g,E);return}b()},[r,d]),u.useEffect(()=>{const h=g=>{if(!(g?.action!=="SHOW_PROMPT"||!g.kind||!c.current)){if(g.kind==="unlock"){l(),f({kind:"unlock"});return}g.requestID&&j(g.kind,g.requestID)}};return chrome.runtime.onMessage.addListener(h),()=>chrome.runtime.onMessage.removeListener(h)},[j]);const k=t.color.global.walletBackground;return!mt&&Y&&n.tokenOk===void 0?null:d?e.jsxs(as,{children:[Y&&e.jsxs("div",{className:"flex items-center justify-between px-3 py-2",style:{background:k,borderBottom:"1px solid #ffffff14"},children:[e.jsx("span",{className:"text-sm font-bold",style:{color:t.color.global.contrast},children:"bWalletX"}),n.stuck&&e.jsx("button",{type:"button",className:"text-xs font-bold border-0 rounded-full px-3 py-1",style:{background:"#F5C542",color:"#0b0a08"},onClick:()=>chrome.runtime.sendMessage({action:"MOVE_PROMPT_TO_WINDOW"}).catch(()=>{}),children:"Open in bWalletX"}),e.jsx("button",{type:"button","aria-label":"Deny and close",className:"text-sm border-0 bg-transparent p-1",style:{color:t.color.global.gray},onClick:()=>chrome.runtime.sendMessage({action:"DISMISS_PROMPT_PANEL"}).catch(()=>{}),children:"✕"})]}),e.jsxs("div",{ref:o,className:"flex items-center justify-center relative p-0",style:{width:Y?"100%":"var(--wallet-width)",height:Y?"calc(100vh - 41px)":"var(--wallet-height)",backgroundColor:k,pointerEvents:n.armed?void 0:"none"},children:[Y&&e.jsx("div",{ref:i,"aria-hidden":!0,style:{position:"absolute",top:0,left:0,width:24,height:24,pointerEvents:"none"}}),(!r||a.kind==="loading")&&e.jsx(rt,{message:"Loading...",theme:t}),a.kind==="waiting"&&e.jsx(rt,{message:"Waiting for request...",theme:t}),a.kind==="expired"&&e.jsx("p",{className:"text-xs",style:{color:t.color.global.gray},children:"This request expired or was already handled."}),a.kind==="unlock"&&e.jsx(is,{onUnlock:()=>{b()}}),e.jsxs(Vo,{originator:Go(a),embeddedIn:Ko(a),children:[a.kind==="permission"&&e.jsx(io,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="bundle"&&e.jsx(Ro,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="groupedPermission"&&e.jsx(Us,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="counterpartyPermission"&&e.jsx(Ts,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="oneSatPermission"&&e.jsx(no,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="streamGrant"&&(a.payload.envelope?e.jsx(Bo,{request:a.payload,onResponse:()=>{b()}},a.requestID):e.jsx(Uo,{request:a.payload,onResponse:()=>{b()}},a.requestID)),a.kind==="mintPrivate"&&e.jsx(Mo,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="swap"&&e.jsx(Lo,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="twetch"&&e.jsx(Oo,{request:a.payload,onResponse:()=>{b()}},a.requestID),a.kind==="usbCheck"&&e.jsx(lo,{request:a.payload,onResponse:()=>{b()}},a.requestID)]})]})]}):e.jsx("p",{className:"text-xs p-4",style:{color:"#98A2B3"},children:"Open bWalletX to answer this request."})},$t=document.getElementById("root");if(!$t)throw new Error("Root element");Jt.createRoot($t).render(e.jsx(ss,{children:e.jsx(os,{children:e.jsx(ns,{children:e.jsx(rs,{children:e.jsx(Zo,{})})})})}));
//# sourceMappingURL=prompt-tab-CpvzJUk4.js.map
