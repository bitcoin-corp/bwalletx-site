import{r as n}from"./index-t5CcWpUk.js";import{f1 as s}from"./index-CNyUi-To.js";const u=(e,r)=>{const t=n.useRef(r);t.current=r,n.useEffect(()=>{const o=c=>c.detail===e&&t.current();return window.addEventListener(s,o),()=>window.removeEventListener(s,o)},[e])};export{u};
//# sourceMappingURL=useTabHome-SESC_IO3.js.map
