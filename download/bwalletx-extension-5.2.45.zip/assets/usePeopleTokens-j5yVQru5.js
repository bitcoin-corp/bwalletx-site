import{r as t}from"./index-t5CcWpUk.js";import{fetchPeopleTokens as l}from"./people-3-ZQz9nJ.js";const f=()=>{const[s,o]=t.useState(null);return t.useEffect(()=>{let e=!0;return l().then(r=>e&&o(r)),()=>{e=!1}},[]),s};export{f as u};
//# sourceMappingURL=usePeopleTokens-j5yVQru5.js.map
