const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CxOjlJxc.js","./index-CNyUi-To.js","./crypto-D-3Mmd3B.js","./index-t5CcWpUk.js","./index-CArfLaxe.css","./index-DJ-FqeHo.css"])))=>i.map(i=>d[i]);
import{av as e,a8 as t}from"./index-CNyUi-To.js";import"./crypto-D-3Mmd3B.js";import"./index-t5CcWpUk.js";const m=e("Share",{web:()=>t(()=>import("./web-CxOjlJxc.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{m as Share};
//# sourceMappingURL=index-CKsMi5Bg.js.map
