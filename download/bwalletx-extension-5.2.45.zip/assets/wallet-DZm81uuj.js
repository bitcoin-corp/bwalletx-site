import{co as a,Y as s}from"./index-CNyUi-To.js";async function t(){const e=await a({action:s.GET_BALANCE});if(!e.success)throw new Error(e.error||"Failed to get balance");return e.data??0}export{t as g};
//# sourceMappingURL=wallet-DZm81uuj.js.map
