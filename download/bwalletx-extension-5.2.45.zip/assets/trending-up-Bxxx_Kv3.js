import{n as e}from"./crypto-D-3Mmd3B.js";const n=[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]],t=e("trending-up",n);export{t as T};
//# sourceMappingURL=trending-up-Bxxx_Kv3.js.map
