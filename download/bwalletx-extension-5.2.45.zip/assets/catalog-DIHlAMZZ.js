import{b5 as n,kC as e,kD as c,kE as o,h5 as i,kF as f}from"./index-CNyUi-To.js";const r=n?`${n}/api/themes`:"";async function h(s=fetch){try{if(!r)return[...e];const a=await s(r);if(!a.ok)return[...e];const t=c(await a.json());return t.length?t:[...e]}catch{return[...e]}}function l(s,a){const t=o(a);t?i(s,t):f(s,a)}export{l as a,h as f};
//# sourceMappingURL=catalog-DIHlAMZZ.js.map
