import{n as o}from"./crypto-D-3Mmd3B.js";const t=[["path",{d:"M17 7 7 17",key:"15tmo1"}],["path",{d:"M17 17H7V7",key:"1org7z"}]],e=o("arrow-down-left",t);const r=[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]],n=o("arrow-up-right",r);export{n as A,e as a};
//# sourceMappingURL=arrow-up-right-BNmwndtn.js.map
