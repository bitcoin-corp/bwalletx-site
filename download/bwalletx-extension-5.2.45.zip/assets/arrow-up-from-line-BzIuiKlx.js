import{n as o}from"./crypto-D-3Mmd3B.js";const e=[["path",{d:"m18 9-6-6-6 6",key:"kcunyi"}],["path",{d:"M12 3v14",key:"7cf3v8"}],["path",{d:"M5 21h14",key:"11awu3"}]],a=o("arrow-up-from-line",e);export{a as A};
//# sourceMappingURL=arrow-up-from-line-BzIuiKlx.js.map
