import{r as u}from"./index-t5CcWpUk.js";import{a$ as t,a_ as c}from"./sessions-CA39SOiZ.js";function n(r){const[a,s]=u.useState(()=>r?t(r):null);return u.useEffect(()=>{if(!r)return s(null);let e=!0;return s(t(r)),c(r).then(f=>e&&s(f)).catch(()=>{}),()=>{e=!1}},[r]),a}export{n as u};
//# sourceMappingURL=useIssuer-CH72t6wx.js.map
