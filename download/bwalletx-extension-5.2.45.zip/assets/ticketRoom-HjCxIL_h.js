import{b as a}from"./index-CNyUi-To.js";import{cn as e}from"./main-BFEe8pqR.js";const r=(o,t)=>{e(`bsv21:${o}`),t(a("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-HjCxIL_h.js.map
