import{r as s}from"./index-t5CcWpUk.js";import{jG as r,cW as o}from"./index-CNyUi-To.js";const u=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{u};
//# sourceMappingURL=useCalls-i-dT29iR.js.map
