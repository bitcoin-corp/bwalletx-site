import{gv as e}from"./main-CbBtBYhm.js";import{m as i,j as l}from"./identityText-DLjv9Ba2.js";const n=["b0asex"],r=(a,o=n)=>{const[s,t]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!s||!o.includes(s)?!1:!t||t===l.toLowerCase()},A=(a,o=!1)=>o||e(a)||r(i(a??void 0));export{A as c};
//# sourceMappingURL=bulkAccess-nWfwYGwa.js.map
