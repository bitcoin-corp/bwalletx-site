import{c as o}from"./index-DNmxiwYn.js";const e=[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]],c=o("arrow-down",e);export{c as A};
//# sourceMappingURL=arrow-down-HLnrFvMi.js.map
