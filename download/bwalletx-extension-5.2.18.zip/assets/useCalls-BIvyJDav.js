import{r as s}from"./index-Czy6iWQC.js";import{hO as r,hP as o}from"./main-CbBtBYhm.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-BIvyJDav.js.map
