import{cp as a,Y as s}from"./index-D79vGRLQ.js";async function t(){const e=await a({action:s.GET_BALANCE});if(!e.success)throw new Error(e.error||"Failed to get balance");return e.data??0}export{t as g};
//# sourceMappingURL=wallet-DA7_vpfT.js.map
