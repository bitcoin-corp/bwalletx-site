import{r as s}from"./index-C__JlqXq.js";import{jN as r,cX as o}from"./index-D79vGRLQ.js";const u=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{u};
//# sourceMappingURL=useCalls-BIwrUWrt.js.map
