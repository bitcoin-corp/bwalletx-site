import{b6 as n,kM as e,kN as c,kO as o,hb as i,kP as f}from"./index-D79vGRLQ.js";const r=n?`${n}/api/themes`:"";async function h(s=fetch){try{if(!r)return[...e];const a=await s(r);if(!a.ok)return[...e];const t=c(await a.json());return t.length?t:[...e]}catch{return[...e]}}function l(s,a){const t=o(a);t?i(s,t):f(s,a)}export{l as a,h as f};
//# sourceMappingURL=catalog-DPTHYf2I.js.map
