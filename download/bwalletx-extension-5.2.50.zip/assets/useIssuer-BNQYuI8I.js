import{r as u}from"./index-C__JlqXq.js";import{bp as t,bo as c}from"./sessions-Djx1sLs_.js";function o(r){const[f,s]=u.useState(()=>r?t(r):null);return u.useEffect(()=>{if(!r)return s(null);let e=!0;return s(t(r)),c(r).then(a=>e&&s(a)).catch(()=>{}),()=>{e=!1}},[r]),f}export{o as u};
//# sourceMappingURL=useIssuer-BNQYuI8I.js.map
