import{r as t}from"./index-C__JlqXq.js";import{fetchPeopleTokens as l}from"./people-a0Q99XB_.js";const f=()=>{const[s,o]=t.useState(null);return t.useEffect(()=>{let e=!0;return l().then(r=>e&&o(r)),()=>{e=!1}},[]),s};export{f as u};
//# sourceMappingURL=usePeopleTokens-BKGLlqT2.js.map
