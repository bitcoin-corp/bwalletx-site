const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Df5S_zKz.js","./index-D79vGRLQ.js","./crypto-BC5Yk38b.js","./index-C__JlqXq.js","./index-DcdKOWHf.css","./index-Cwn_5ZrG.css"])))=>i.map(i=>d[i]);
import{aw as e,a8 as t}from"./index-D79vGRLQ.js";import"./crypto-BC5Yk38b.js";import"./index-C__JlqXq.js";const m=e("Share",{web:()=>t(()=>import("./web-Df5S_zKz.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{m as Share};
//# sourceMappingURL=index-Cq0CrAIg.js.map
