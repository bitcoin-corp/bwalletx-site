import{i as e}from"./sessions-Djx1sLs_.js";import{bn as i,aP as n,bA as l}from"./index-D79vGRLQ.js";const r=["b0asex"],c=(a,s=r)=>{const[t,o]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!s.includes(t)?!1:!o||o===n.toLowerCase()||(l??[]).includes(o)},m=(a,s=!1)=>s||e(a)||c(i(a??void 0));export{m as c};
//# sourceMappingURL=bulkAccess-BWog-PCB.js.map
