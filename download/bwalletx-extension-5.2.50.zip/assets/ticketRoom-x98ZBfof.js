import{b as a}from"./index-D79vGRLQ.js";import{cl as e}from"./main-BCE92XEX.js";const r=(o,t)=>{e(`bsv21:${o}`),t(a("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-x98ZBfof.js.map
