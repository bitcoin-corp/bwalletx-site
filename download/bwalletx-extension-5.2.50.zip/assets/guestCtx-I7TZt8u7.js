import{r as t}from"./index-C__JlqXq.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-I7TZt8u7.js.map
