import{r as n}from"./index-C__JlqXq.js";import{f7 as s}from"./index-D79vGRLQ.js";const u=(e,r)=>{const t=n.useRef(r);t.current=r,n.useEffect(()=>{const o=c=>c.detail===e&&t.current();return window.addEventListener(s,o),()=>window.removeEventListener(s,o)},[e])};export{u};
//# sourceMappingURL=useTabHome-zJf-8gRC.js.map
