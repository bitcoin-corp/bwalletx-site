import{n as e}from"./crypto-BC5Yk38b.js";const n=[["path",{d:"M9 17H7A5 5 0 0 1 7 7h2",key:"8i5ue5"}],["path",{d:"M15 7h2a5 5 0 1 1 0 10h-2",key:"1b9ql8"}],["line",{x1:"8",x2:"16",y1:"12",y2:"12",key:"1jonct"}]],t=e("link-2",n);export{t as L};
//# sourceMappingURL=link-2-DRjMFu7C.js.map
