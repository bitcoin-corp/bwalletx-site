import{r as s}from"./index-D-CKA__T.js";import{hR as r,hS as o}from"./main-BfBu2fcE.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-DDBneJoP.js.map
