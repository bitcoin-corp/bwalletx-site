import{r as t}from"./index-BhwRQDMp.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-Dgs6mLU_.js.map
