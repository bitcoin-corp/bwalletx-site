import{r as s}from"./index-BhwRQDMp.js";import{hW as r,hX as o}from"./main-Csx1mg0G.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-DfTy7IPe.js.map
