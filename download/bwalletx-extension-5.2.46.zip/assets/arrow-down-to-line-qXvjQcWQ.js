import{n as o}from"./crypto-a_OBSEe4.js";const e=[["path",{d:"M12 17V3",key:"1cwfxf"}],["path",{d:"m6 11 6 6 6-6",key:"12ii2o"}],["path",{d:"M19 21H5",key:"150jfl"}]],t=o("arrow-down-to-line",e);export{t as A};
//# sourceMappingURL=arrow-down-to-line-qXvjQcWQ.js.map
