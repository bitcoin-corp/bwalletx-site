import{b5 as n,kH as e,kI as c,kJ as o,h7 as i,kK as f}from"./index-BJX0OQuB.js";const r=n?`${n}/api/themes`:"";async function h(s=fetch){try{if(!r)return[...e];const a=await s(r);if(!a.ok)return[...e];const t=c(await a.json());return t.length?t:[...e]}catch{return[...e]}}function l(s,a){const t=o(a);t?i(s,t):f(s,a)}export{l as a,h as f};
//# sourceMappingURL=catalog-DwzOGHiu.js.map
