import{b as a}from"./index-BJX0OQuB.js";import{cl as e}from"./main-ScF26uZc.js";const r=(o,t)=>{e(`bsv21:${o}`),t(a("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-CWhTPFXS.js.map
