import{r as u}from"./index-t5CcWpUk.js";import{bn as t,bm as c}from"./sessions-BIjEXUdK.js";function n(r){const[f,s]=u.useState(()=>r?t(r):null);return u.useEffect(()=>{if(!r)return s(null);let e=!0;return s(t(r)),c(r).then(a=>e&&s(a)).catch(()=>{}),()=>{e=!1}},[r]),f}export{n as u};
//# sourceMappingURL=useIssuer-C0CAMG_R.js.map
