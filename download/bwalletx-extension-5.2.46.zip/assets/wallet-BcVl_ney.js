import{co as a,Y as s}from"./index-BJX0OQuB.js";async function t(){const e=await a({action:s.GET_BALANCE});if(!e.success)throw new Error(e.error||"Failed to get balance");return e.data??0}export{t as g};
//# sourceMappingURL=wallet-BcVl_ney.js.map
