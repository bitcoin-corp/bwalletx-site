const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B9irpAAb.js","./index-BJX0OQuB.js","./crypto-a_OBSEe4.js","./index-t5CcWpUk.js","./index-CArfLaxe.css","./index-BHxDmFsW.css"])))=>i.map(i=>d[i]);
import{av as e,a8 as t}from"./index-BJX0OQuB.js";import"./crypto-a_OBSEe4.js";import"./index-t5CcWpUk.js";const m=e("Share",{web:()=>t(()=>import("./web-B9irpAAb.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{m as Share};
//# sourceMappingURL=index-DrckErbQ.js.map
