import{r as x,j as e,b as W,aW as J,W as X,V as ne,aX as ie}from"./index-DWSlSSkS.js";import{a as D,b as B,e as P,a0 as S,bv as $,bi as T,ar as le,U as ce,a1 as G,bt as pe,bu as de,bm as ue,bn as fe,aW as L,bo as xe,P as H,bs as me}from"./index-yuCd4AvZ.js";import{a as M,u as V,U as ge,S as Q}from"./useSnackbar-lO9vX7XZ.js";const he=t=>{const{request:s,onResponse:i}=t,{theme:o}=D(),{handleSelect:c,hideMenu:n}=M(),{addSnackbar:d}=V(),[a,p]=x.useState(!1),[u,m]=x.useState(""),{chromeStorageService:y}=B(),{permissions:r}=s,[f,g]=x.useState(()=>r.protocols.map(()=>!0));x.useEffect(()=>{c("bsv"),n()},[c,n]);const l=()=>{const k=r.protocols.filter((E,R)=>f[R]);return k.length===0?{}:{protocols:k}},j=async()=>{p(!0),m("");try{const k=await $(y);if(!k.ok){m(k.message),p(!1);return}T({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:l()}),i()}catch(k){d(k instanceof Error?k.message:String(k),"error"),p(!1)}},v=async()=>{p(!0),T({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),i()},N=k=>g(E=>E.map((R,O)=>O===k?!R:R)),b=s.counterpartyLabel??`${s.counterparty.slice(0,8)}...${s.counterparty.slice(-8)}`;return e.jsxs(P.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ge,{size:18,style:{color:"#FFD24D"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Counterparty Permission"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","wants to interact with a counterparty"]})]})]}),e.jsxs(P.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all font-mono",style:{color:o.color.global.contrast},children:b})]}),e.jsx(S,{when:!!r.description,children:e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Purpose"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:r.description})]})}),e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),r.protocols.map((k,E)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:E<r.protocols.length-1?"1px solid rgba(255,255,255,0.04)":"none"},children:[e.jsx("input",{type:"checkbox",checked:f[E],onChange:()=>N(E),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[k.protocolID?.[1]," (level ",k.protocolID?.[0],")"]}),k.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:k.description})]})]},`proto-${E}`))]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[u&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:u}),e.jsxs(P.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, #FFD24D 0%, #EAB300 100%)",color:"#010101",opacity:a?.6:1},disabled:a,onClick:j,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[a&&e.jsx(W,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(P.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:a?.5:1},disabled:a,onClick:v,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},ye={"2:3241645161d8":{label:"BRC-29 payment",description:"An application is requesting permission to derive payment addresses for a specific recipient."}},Z=t=>t?ye[`${t[0]}:${t[1]}`]:void 0,ee=t=>Z(t)?.label??t?.[1],be=t=>{switch(t){case 0:return"Level 0 · any app";case 1:return"Level 1 · this app only";case 2:return"Level 2 · this app and this recipient only";default:return`Level ${t??0}`}},ve=t=>{const{request:s,onResponse:i}=t,{theme:o}=D(),{handleSelect:c,hideMenu:n}=M(),{addSnackbar:d}=V(),[a,p]=x.useState(!1),[u,m]=x.useState(""),{chromeStorageService:y}=B(),{permissions:r}=s,[f,g]=x.useState(()=>(r.protocolPermissions??[]).map(()=>!0)),[l,j]=x.useState(()=>(r.basketAccess??[]).map(()=>!0)),[v,N]=x.useState(()=>(r.certificateAccess??[]).map(()=>!0)),[b,k]=x.useState(!1);x.useEffect(()=>{c("bsv"),n()},[c,n]);const E=()=>{const h={},w=(r.protocolPermissions??[]).filter((q,F)=>f[F]);w.length>0&&(h.protocolPermissions=w);const C=(r.basketAccess??[]).filter((q,F)=>l[F]);C.length>0&&(h.basketAccess=C);const A=(r.certificateAccess??[]).filter((q,F)=>v[F]);return A.length>0&&(h.certificateAccess=A),b&&r.spendingAuthorization&&(h.spendingAuthorization=r.spendingAuthorization),h},R=async()=>{p(!0),m("");try{const h=await $(y);if(!h.ok){m(h.message),p(!1);return}T({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:E()}),i()}catch(h){d(h instanceof Error?h.message:String(h),"error"),p(!1)}},O=async()=>{p(!0),T({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),i()},oe=h=>g(w=>w.map((C,A)=>A===h?!C:C)),re=h=>j(w=>w.map((C,A)=>A===h?!C:C)),ae=h=>N(w=>w.map((C,A)=>A===h?!C:C));return e.jsxs(P.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(Q,{size:18,style:{color:"#FFD24D"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Permission Request"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","is requesting the following permissions"]})]})]}),e.jsx(S,{when:!!r.description,children:e.jsx("p",{className:"text-xs mb-3 leading-relaxed",style:{color:o.color.global.gray},children:r.description})}),e.jsx(S,{when:!!r.spendingAuthorization,children:e.jsxs(P.div,{className:"w-full rounded-2xl px-4 py-3 mb-3",style:{background:"rgba(247,144,9,0.08)",border:"1px solid rgba(247,144,9,0.2)"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.06},children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pb-1",style:{color:"#F79009"},children:"Spending Authorization"}),e.jsxs("label",{className:"flex items-start gap-3 py-1 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:b,onChange:()=>k(!b),className:"mt-0.5 accent-orange-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-semibold",style:{color:"#F79009"},children:["This app wants to spend up to ",((r.spendingAuthorization?.amount??0)/1e8).toFixed(8)," BSV"," ","(",(r.spendingAuthorization?.amount??0).toLocaleString()," satoshis)"]}),r.spendingAuthorization?.description&&e.jsxs("span",{className:"text-xs mt-1 opacity-70",style:{color:o.color.global.contrast},children:["App says: “",r.spendingAuthorization.description,"”"]})]})]})]})}),e.jsxs(P.div,{className:"w-full rounded-2xl px-4 py-2 mb-5",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs(S,{when:!!r.protocolPermissions?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),r.protocolPermissions?.map((h,w)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:f[w],onChange:()=>oe(w),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[ee(h.protocolID)," (level ",h.protocolID[0],")",h.counterparty?` — ${h.counterparty.slice(0,10)}...`:""]}),h.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:h.description})]})]},`proto-${w}`))]}),e.jsxs(S,{when:!!r.basketAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Baskets"}),r.basketAccess?.map((h,w)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:l[w],onChange:()=>re(w),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:h.basket}),h.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:h.description})]})]},`basket-${w}`))]}),e.jsxs(S,{when:!!r.certificateAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Certificates"}),r.certificateAccess?.map((h,w)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:v[w],onChange:()=>ae(w),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:h.type}),e.jsxs("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:[h.description," — fields: ",h.fields.join(", ")]})]})]},`cert-${w}`))]})]}),e.jsxs("div",{className:"flex flex-col gap-3",children:[u&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:u}),e.jsxs(P.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, #FFD24D 0%, #EAB300 100%)",color:"#010101",opacity:a?.6:1},disabled:a,onClick:R,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[a&&e.jsx(W,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(P.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:a?.5:1},disabled:a,onClick:O,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},we=2e3;async function I(t,s=we){let i;try{return await Promise.race([t.catch(()=>{}),new Promise(o=>{i=setTimeout(()=>o(void 0),s)})])}catch{return}finally{i&&clearTimeout(i)}}function ke(t,s){return t?.find(i=>i.startsWith(`${s}:`))?.slice(s.length+1)}async function je(t,s,i=[]){const o=t.ordfs;if(typeof o?.bulkMetadata!="function")return{state:"unverified"};const c=`${s}:-2`,n=await I(o.bulkMetadata([c])),d=n?.[c]??n?.[s]??Object.values(n??{}).find(u=>!!u?.contentType);if(!d?.contentType)return{state:"unverified"};const a={contentType:d.contentType,origin:d.origin,name:typeof d.map?.name=="string"?d.map.name:void 0},p=i.find(u=>u.includes("/"));return p&&p!==d.contentType?{state:"mismatch",note:`Content type is ${d.contentType}, not ${p}`,...a}:{state:"verified",...a}}async function Ne(t,s,i){const o=t.opns;if(typeof o?.getOrigin!="function")return{state:"unverified"};const c=await I(o.getOrigin(s));return c?.outpoint?c.outpoint!==i?{state:"mismatch",note:`“${s}” currently resolves to a different output`}:{state:"verified"}:{state:"unverified"}}async function Se(t,s,i,o=[]){const c=t.bsv21;if(typeof c?.getTokenDetails!="function")return{state:"unverified"};const n=await I(c.getTokenDetails(s,{fresh:!0}));if(!n)return{state:"unverified"};if(n.status?.is_active===!1)return{state:"mismatch",note:"Token is not active on the overlay"};const d=n.token?.sym;if(i&&d&&i.toLowerCase()!==d.toLowerCase())return{state:"mismatch",note:`Token symbol is ${d}, not ${i}`};if(o.length>0&&typeof c.getOutputStatus=="function"){const a=await I(c.getOutputStatus(s,o));if(!a)return{state:"unverified"};const p=a.filter(u=>u.state==="spent"||u.state==="unknown");if(p.length>0)return{state:"mismatch",note:p.length===1?"A spent token output is not valid on the overlay":`${p.length} spent token outputs are not valid on the overlay`};if(a.some(u=>u.state==="queued"))return{state:"unverified"}}return{state:"verified",...d?{name:d}:{}}}async function Pe(t,s,i,o,c){if(!t||!s)return{state:"unverified"};const n=s==="purchase"||s.endsWith(".purchase"),d=s==="token-transfer"||s.startsWith("bsv21.");if(!n&&!d)return{state:"unverified"};const a={kindOrIntent:s,hasOrdfs:!!t.ordfs,hasBulk:typeof t.ordfs?.bulkMetadata=="function",inputTagSets:i.map(p=>p.tags),outputTagSets:o.map(p=>p.tags)};try{const p=[...i.map(l=>l.tags),...o.map(l=>l.tags)],u=l=>p.flatMap(j=>j.filter(v=>v.startsWith(`${l}:`)).map(v=>v.slice(l.length+1))),m=l=>{for(const j of p){const v=ke(j,l);if(v)return v}},y=m("bsv21");if(y||s==="bsv21.purchase"||s==="token-transfer"||s.startsWith("bsv21.")){if(!y)return{state:"unverified"};const j=i.filter(N=>N.basket?.includes("bsv21")||N.tags.some(b=>b.startsWith("bsv21:"))).map(N=>N.outpoint).filter(Boolean);let v=m("sym");for(const N of i)if(N.customInstructions)try{const b=JSON.parse(N.customInstructions).sym;if(typeof b=="string"&&b.trim()){v=b.trim();break}}catch{}return await Se(t,y,v,j)}const r=m("name"),f=m("origin");if(a.name=r,a.origin=f,r&&f&&o.some(l=>l.basket?.includes("opns"))||s==="opns.purchase")return!r||!f?{state:"unverified"}:await Ne(t,r,f);if(!f)return a.reason="no-origin-tag",globalThis.__lastVerify=a,{state:"unverified"};const g=await je(t,f,u("type"));if(a.verifyOrdinal=g,g.origin&&c)try{g.contentUrl=c(g.origin)}catch(l){a.contentUrlError=String(l)}return globalThis.__lastVerify=a,g}catch(p){return a.error=String(p),globalThis.__lastVerify=a,{state:"unverified"}}}function te(t){if(!t||typeof t!="object")return!1;const s=t;return Array.isArray(s.panels)&&typeof s.title=="string"}var Ce=`
.opp-root {
  --opp-bg: #ffffff;
  --opp-fg: #111827;
  --opp-muted: #6b7280;
  --opp-card-bg: #f7f8fa;
  --opp-card-border: #eceef2;
  --opp-accent: #E5A920;
  --opp-approve-bg: #E5A920;
  --opp-approve-fg: #ffffff;
  --opp-reject-bg: #ffffff;
  --opp-reject-fg: #111827;
  --opp-reject-border: #d1d5db;
  --opp-status-bg: #FFFBE6;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #ECFDF5;
  --opp-trust-ok-fg: #059669;
  --opp-trust-warn-bg: #FFFBEB;
  --opp-trust-warn-fg: #D97706;
  --opp-trust-bad-bg: #FEF2F2;
  --opp-trust-bad-fg: #DC2626;

  font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--opp-bg);
  color: var(--opp-fg);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 480px;
  min-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
}

.opp-bottom {
  margin-top: auto;
  display: flex;
  flex-direction: column;
}

.opp-root.opp-dark {
  --opp-bg: #0F1117;
  --opp-fg: #F9FAFB;
  --opp-muted: #9ca3af;
  --opp-card-bg: #1A1D27;
  --opp-card-border: #232636;
  --opp-reject-bg: #0F1117;
  --opp-reject-fg: #F9FAFB;
  --opp-reject-border: #2D3142;
  --opp-status-bg: #2A2408;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #0A2E1F;
  --opp-trust-ok-fg: #34D399;
  --opp-trust-warn-bg: #2A2008;
  --opp-trust-warn-fg: #FBBF24;
  --opp-trust-bad-bg: #2A1215;
  --opp-trust-bad-fg: #F87171;
}

.opp-body {
  padding: 24px 20px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
}

.opp-coin {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
}

.opp-title {
  font-size: 16px;
  font-weight: 700;
  margin: 0;
  text-align: center;
}

.opp-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  margin: 0;
  text-align: center;
  line-height: 1.4;
}

.opp-status {
  background: var(--opp-status-bg);
  color: var(--opp-status-fg);
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
  margin-top: 4px;
  border: 1px solid var(--opp-card-border);
}

.opp-card {
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px;
  padding: 16px;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.opp-featured {
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px 8px;
  padding: 16px;
}

/* Subtle danger chrome for burn / destructive token ops */
.opp-featured-danger {
  border-color: rgba(220, 38, 38, 0.45);
  background: color-mix(in srgb, var(--opp-card-bg) 88%, #7f1d1d 12%);
}

.opp-featured-danger .opp-featured-title {
  color: #f87171;
}

.opp-featured-danger .opp-featured-image,
.opp-featured-danger .opp-featured-placeholder {
  border: 1px solid rgba(220, 38, 38, 0.35);
  background: rgba(127, 29, 29, 0.25);
  color: #fca5a5;
}

.opp-dark .opp-featured-danger {
  border-color: rgba(248, 113, 113, 0.4);
  background: color-mix(in srgb, var(--opp-card-bg) 85%, #450a0a 15%);
}

.opp-preview-pair {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.opp-preview-arrow {
  color: var(--opp-muted);
  font-size: 14px;
  line-height: 1;
}

.opp-preview-pair .opp-featured-image {
  width: 64px;
  height: 64px;
}

.opp-featured-image {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-featured-image-token {
  width: 48px;
  height: 48px;
  border-radius: 999px;
}

.opp-featured-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--opp-muted);
  font-size: 18px;
}

.opp-preview-opns {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
}

.opp-preview-opns-avatar {
  width: 36px;
  height: 36px;
  border-radius: 999px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-preview-opns-name {
  font-size: 11px;
  font-weight: 600;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  color: var(--opp-fg, inherit);
}

.opp-preview-text {
  margin: 0;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
  font-size: 9px;
  line-height: 1.25;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  color: var(--opp-muted);
}

.opp-preview-json {
  white-space: pre;
  overflow: auto;
}

.opp-preview-frame {
  border: 0;
  padding: 0;
  overflow: hidden;
  background: #fff;
  pointer-events: none;
}

.opp-preview-value {
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  background: rgba(229, 169, 32, 0.12);
  border: 1px solid rgba(229, 169, 32, 0.35);
  color: var(--opp-fg, inherit);
}

.opp-preview-value-icon {
  width: 32px;
  height: 32px;
  color: #E5A920;
}

/* Amount subtitles must never ellipsis — full sat counts are the point. */
.opp-featured-subtitle-text.opp-amount {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-variant-numeric: tabular-nums;
  white-space: normal;
  overflow: visible;
  text-overflow: unset;
  word-break: keep-all;
}

.opp-featured-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  flex: 1;
}

.opp-featured-title {
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.opp-featured-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.opp-featured-subtitle-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
}

.opp-featured-meta-line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  color: var(--opp-muted);
}

.opp-featured-meta-line-bare {
  align-items: center;
}

.opp-featured-meta-key {
  flex-shrink: 0;
  opacity: 0.75;
  min-width: 2.5em;
}

.opp-featured-meta-value {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  flex: 1;
}

.opp-featured-meta-value-mono {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 11px;
}

.opp-trust-wrap {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0 20px 8px;
}

.opp-trust {
  display: inline-flex;
  align-self: flex-start;
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 600;
}

.opp-trust-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-trust-note {
  padding: 10px;
  border-radius: 8px;
  font-size: 11px;
  line-height: 1.35;
}

.opp-trust-note-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-note-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-note-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.opp-row-key {
  color: var(--opp-muted);
  flex-shrink: 0;
}

.opp-row-value-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 70%;
  justify-content: flex-end;
}

.opp-row-value {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 12px;
  font-weight: 500;
  text-align: right;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.opp-copy {
  flex-shrink: 0;
  width: 22px;
  height: 22px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  border: 1px solid var(--opp-reject-border);
  background: var(--opp-bg);
  color: var(--opp-fg);
  cursor: pointer;
}

.opp-copy:hover {
  border-color: var(--opp-accent);
  color: var(--opp-accent);
}

.opp-fee-note {
  font-size: 11px;
  color: var(--opp-muted);
  line-height: 1.3;
  margin-top: -4px;
}

.opp-actions {
  display: flex;
  gap: 12px;
  padding: 20px 20px 12px;
}

.opp-button {
  flex: 1;
  padding: 0 16px;
  height: 48px;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid transparent;
  transition: opacity 120ms ease;
}

.opp-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.opp-button-reject {
  background: var(--opp-reject-bg);
  color: var(--opp-reject-fg);
  border-color: var(--opp-reject-border);
}

.opp-button-approve {
  background: var(--opp-approve-bg);
  color: var(--opp-approve-fg);
}

.opp-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 20px 16px;
  font-size: 11px;
  font-weight: 500;
  color: var(--opp-muted);
}
`;function Ee({request:t,onApprove:s,onReject:i,theme:o="auto",services:c}){const n=Ie(o),d=Ae(t),[a,p]=x.useState(!1),[u,m]=x.useState(),y=t.kind==="transaction"&&te(t.payload)?t.payload:void 0;x.useEffect(()=>{if(!c||!y?.trust||!y.verify)return;let l=!0;const j=c.ordfs?.getContentUrl?.bind(c.ordfs);return Pe(c,y.verify.kind,y.verify.inputs,y.verify.outputs,j).then(v=>{l&&v&&m(v)}).catch(()=>{}),()=>{l=!1}},[c,y]);const r=u?Te(d,u):d,f=l=>()=>{if(!a){p(!0);try{l==="approve"?s():i()}finally{p(!1)}}};x.useEffect(()=>{const l=j=>{a||(j.key==="Escape"?i():j.key==="Enter"&&s())};return window.addEventListener("keydown",l),()=>window.removeEventListener("keydown",l)},[s,i,a]);const g=`opp-root${n==="dark"?" opp-dark":""}`;return e.jsxs("div",{className:g,children:[e.jsx("style",{children:Ce}),e.jsxs("div",{className:"opp-body",children:[e.jsxs("svg",{className:"opp-coin",viewBox:"0 0 100 100","aria-label":"1Sat Ordinals",children:[e.jsx("circle",{cx:"50",cy:"50",r:"50",fill:"#222"}),e.jsx("circle",{cx:"50",cy:"50",r:"40",fill:"#fff"}),e.jsx("circle",{cx:"50",cy:"50",r:"32",fill:"#E5A920"}),e.jsx("rect",{x:"47",y:"28",width:"6",height:"28",rx:"3",fill:"#fff"})]}),e.jsx("h2",{className:"opp-title",children:r.title}),e.jsx("p",{className:"opp-subtitle",children:r.subtitle}),e.jsx("div",{className:"opp-status",children:"Awaiting Approval"})]}),r.panels.map((l,j)=>{const v=l.variant??"ordinal",N=["opp-featured"];return v==="token"&&N.push("opp-featured-token"),v==="value"&&N.push("opp-featured-value"),l.tone==="danger"&&N.push("opp-featured-danger"),e.jsxs("div",{className:N.join(" "),children:[l.prior?e.jsxs("div",{className:"opp-preview-pair","aria-label":"Previous and new inscription",children:[e.jsx(z,{panel:{...l,previewKind:l.prior.previewKind,imageUrl:l.prior.imageUrl,contentUrl:l.prior.contentUrl,previewText:l.prior.previewText,prior:void 0}}),e.jsx("span",{className:"opp-preview-arrow","aria-hidden":!0,children:"→"}),e.jsx(z,{panel:l})]}):e.jsx(z,{panel:l}),e.jsxs("div",{className:"opp-featured-meta",children:[e.jsx("div",{className:"opp-featured-title",children:l.title}),l.subtitle&&e.jsxs("div",{className:"opp-featured-subtitle",children:[e.jsx("span",{className:l.amountSats!=null?"opp-featured-subtitle-text opp-amount":"opp-featured-subtitle-text",children:l.subtitle}),l.subtitleCopy&&e.jsx(_,{text:l.subtitleCopy})]}),(l.meta??[]).map(b=>e.jsxs("div",{className:`opp-featured-meta-line${b.key?"":" opp-featured-meta-line-bare"}`,children:[b.key?e.jsx("span",{className:"opp-featured-meta-key",children:b.key}):null,e.jsx("span",{className:`opp-featured-meta-value${b.key?"":" opp-featured-meta-value-mono"}`,title:b.copyValue??b.value,children:b.value}),b.copyValue&&e.jsx(_,{text:b.copyValue})]},`${b.key}:${b.value}`))]})]},`panel-${j}-${l.title}`)}),r.trust&&e.jsxs("div",{className:"opp-trust-wrap",children:[e.jsx("span",{className:`opp-trust opp-trust-${r.trust.state}`,children:Be(r.trust.state)}),r.trust.note&&e.jsx("div",{className:`opp-trust-note opp-trust-note-${r.trust.state}`,children:r.trust.note})]}),(r.rows.length>0||r.indexerFee||r.funding)&&e.jsxs("div",{className:"opp-card",children:[r.rows.map(l=>e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:l.key}),e.jsxs("span",{className:"opp-row-value-wrap",children:[e.jsx("span",{className:"opp-row-value",title:l.copyValue??l.value,children:l.value}),l.copyValue&&e.jsx(_,{text:l.copyValue})]})]},`${l.key}:${l.value}`)),r.indexerFee&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"1Sat Overlay Fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[K(r.indexerFee.sats)," sats"]})]}),r.funding?.networkFeeSats!=null&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"Network fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[K(r.funding.networkFeeSats)," sats"]})]}),r.funding?.note&&e.jsx("div",{className:"opp-fee-note",children:r.funding.note})]}),e.jsxs("div",{className:"opp-bottom",children:[e.jsxs("div",{className:"opp-actions",children:[e.jsx("button",{type:"button",className:"opp-button opp-button-reject",onClick:f("reject"),disabled:a,children:"Reject"}),e.jsx("button",{type:"button",className:"opp-button opp-button-approve",onClick:f("approve"),disabled:a,children:"Approve"})]}),e.jsx("div",{className:"opp-footer",children:e.jsx("span",{children:"Secured by 1Sat Ordinals"})})]})]})}function Ae(t){if(t.kind==="transaction"&&te(t.payload))return{title:t.payload.title,subtitle:t.payload.subtitle,panels:t.payload.panels,rows:t.payload.rows,trust:t.payload.trust,indexerFee:t.payload.indexerFee,funding:t.payload.funding};if(t.kind==="basketAccess"){const s=t.payload.baskets??[],i=s.length>0&&s.every(n=>n.scope||n.basket.startsWith("p ")),o=s.filter(n=>n.imageUrl||n.name||n.value).map(n=>({title:n.scope==="collection"?n.name?`Collection · ${n.name}`:"Collection":n.scope?n.scope:"Basket",subtitle:n.value?n.value.length>24?`${n.value.slice(0,10)}…${n.value.slice(-10)}`:n.value:n.basket,subtitleCopy:n.value,...n.imageUrl&&{previewKind:"image",contentUrl:n.imageUrl,imageUrl:n.imageUrl},tone:"default"})),c=s.flatMap(n=>n.scope==="collection"?n.description?[{key:"Access",value:n.description}]:[]:[{key:n.basket,value:n.description??"List, insert, and remove outputs"}]);return{title:i?s.length===1?s[0].scope==="collection"?"Grant Collection View":"Grant Item View":`Grant View (${s.length})`:s.length===1?"Grant Basket Access":`Grant Access to ${s.length} Baskets`,subtitle:i?`${U(t.originator)} wants to view items in your wallet`:`${U(t.originator)} wants to read and write 1Sat baskets`,panels:o,rows:c}}return t.kind==="protocol"?{title:"Protocol Access",subtitle:`${U(t.originator)} wants protocol access`,panels:[],rows:[{key:"Detail",value:t.summary||"Protocol request"}]}:{title:"Signature Request",subtitle:`${U(t.originator)} wants a signature`,panels:[],rows:[{key:"Detail",value:t.summary||"Signature request"}]}}function Te(t,s){const i=t.panels.map((o,c)=>{if(c!==0)return o;const n=o.previewKind==="opns",d=s.contentType?Re(s.contentType):void 0,a=n?"opns":d&&d!=="none"?d:o.previewKind,p=s.contentUrl??o.contentUrl??o.imageUrl;let u=o.subtitle;if(s.name&&!n)if(!u)u=s.name;else{const m=u.trim().split(/\s+/);m.length>=2&&(m[m.length-1]=s.name,u=m.join(" "))}return{...o,previewKind:a,...u?{subtitle:u}:{},...n?{...s.contentUrl&&!o.imageUrl?{imageUrl:s.contentUrl}:o.imageUrl?{imageUrl:o.imageUrl}:{}}:a==="image"?{imageUrl:p,contentUrl:p}:p?{contentUrl:p,imageUrl:void 0}:{}}});return{...t,panels:i,trust:{state:s.state,note:s.note}}}function Re(t){const s=t.toLowerCase();return s==="image/svg+xml"||s==="svg"||s.endsWith("+svg")?"svg":s.startsWith("image/")?"image":s.includes("json")?"json":s.includes("html")||s==="application/xhtml+xml"?"html":s.startsWith("text/")?"text":"none"}function De(t){return`${t.toLocaleString("en-US")} sats`}function K(t){return t.toLocaleString("en-US")}function Be(t){return t==="verified"?"Verified":t==="mismatch"?"Mismatch":"Unverified"}function z({panel:t}){const s=t.variant??"ordinal",i=s==="token"?"opp-featured-image opp-featured-image-token":s==="value"?"opp-featured-image opp-preview-value":"opp-featured-image",o=t.previewKind??(t.imageUrl?"image":"none"),c=t.contentUrl??t.imageUrl,[n,d]=x.useState(!1);if(s==="value"){const a=t.valueIcon??"pay";return e.jsx("div",{className:i,title:t.amountSats!=null?De(t.amountSats):void 0,"aria-hidden":!0,children:e.jsx($e,{kind:a})})}if(o==="opns"){const a=!!t.imageUrl&&!n;return e.jsxs("div",{className:`${i} opp-preview-opns`,"aria-hidden":!t.opnsHero,children:[a?e.jsx("img",{className:"opp-preview-opns-avatar",src:t.imageUrl,alt:"",onError:()=>d(!0)}):e.jsx("div",{className:"opp-preview-opns-avatar opp-featured-placeholder",children:"◈"}),e.jsx("span",{className:"opp-preview-opns-name",title:t.opnsHero,children:t.opnsHero??"OpNS"})]})}return o==="image"&&t.imageUrl&&!n?e.jsx("img",{className:i,src:t.imageUrl,alt:t.title,onError:()=>d(!0)}):o==="image"&&n?e.jsx("div",{className:`${i} opp-featured-placeholder`,"aria-hidden":!0,children:"▭"}):(o==="text"||o==="json"||o==="html")&&t.previewText?e.jsx("pre",{className:`${i} opp-preview-text${o==="json"?" opp-preview-json":""}`,children:t.previewText}):(o==="text"||o==="json")&&c?e.jsx(Ue,{url:c,kind:o,className:i}):(o==="html"||o==="svg")&&c?e.jsx("iframe",{className:`${i} opp-preview-frame`,src:c,title:`${t.title} preview`,sandbox:"",referrerPolicy:"no-referrer"}):e.jsx("div",{className:`${i} opp-featured-placeholder`,"aria-hidden":!0,children:s==="token"?"◎":Fe(o)})}function Fe(t){return t==="text"||t==="json"?"¶":t==="html"||t==="svg"?"⌂":"▭"}function $e({kind:t}){return t==="lock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V8a4 4 0 018 0v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):t==="unlock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V7.5A4 4 0 0116 7",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("path",{d:"M16 4.5v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"9",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M12 7v10M9 10.5c0-1.4 1.3-2.5 3-2.5s3 1.1 3 2.5-1.3 2.5-3 2.5-3 1.1-3 2.5 1.3 2.5 3 2.5 3-1.1 3-2.5",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})}function Ue({url:t,kind:s,className:i}){const[o,c]=x.useState(null),[n,d]=x.useState(!1);return x.useEffect(()=>{let a=!1;return c(null),d(!1),fetch(t).then(async p=>{if(!p.ok)throw new Error(String(p.status));const u=await p.text();if(!a){if(s==="json")try{c(JSON.stringify(JSON.parse(u),null,2));return}catch{}c(u.slice(0,800))}}).catch(()=>{a||d(!0)}),()=>{a=!0}},[t,s]),n?e.jsx("div",{className:`${i} opp-featured-placeholder`,"aria-hidden":!0,children:"¶"}):e.jsx("pre",{className:`${i} opp-preview-text${s==="json"?" opp-preview-json":""}`,children:o??"…"})}function _({text:t}){const[s,i]=x.useState(!1),o=()=>{navigator.clipboard?.writeText(t).then(()=>{i(!0),window.setTimeout(()=>i(!1),1200)})};return e.jsx("button",{type:"button",className:"opp-copy",onClick:o,"aria-label":s?"Copied":"Copy full value",title:s?"Copied":"Copy",children:s?e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:e.jsx("path",{d:"M5 13l4 4L19 7",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round"})}):e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"9",y:"9",width:"11",height:"11",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M5 15V5a2 2 0 012-2h10",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})})}function Ie(t){const[s,i]=x.useState(()=>t==="auto"?Me():t);return x.useEffect(()=>{if(t!=="auto"){i(t);return}const o=window.matchMedia("(prefers-color-scheme: dark)"),c=()=>i(o.matches?"dark":"light");return c(),o.addEventListener("change",c),()=>o.removeEventListener("change",c)},[t]),s}function Me(){return typeof window>"u"||!window.matchMedia?"light":window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function U(t){try{return new URL(t.includes("://")?t:`https://${t}`).host||t}catch{return t.length<=32?t:`${t.slice(0,14)}…${t.slice(-12)}`}}const Oe=({request:t,onResponse:s})=>{const{theme:i}=D(),{handleSelect:o,hideMenu:c}=M(),{apiContext:n,chromeStorageService:d}=B(),a=n?.services;x.useEffect(()=>{o("bsv"),c()},[o,c]);const[p,u]=x.useState(""),m=x.useRef(!1),y=async g=>{if(!m.current){if(m.current=!0,g){u("");const l=await $(d);if(!l.ok){u(l.message),m.current=!1;return}}T({action:"ONE_SAT_PERMISSION_RESPONSE",requestID:t.requestID,approved:g}),s()}},f=i.color.global.walletBackground.toLowerCase()==="#000000"||/^#[01]/.test(i.color.global.walletBackground)?"dark":"light";return e.jsxs("div",{style:{width:"100%",height:"100%",overflowY:"auto",display:"flex",flexDirection:"column",alignItems:"stretch",justifyContent:"center"},children:[p&&e.jsx("p",{className:"text-xs text-center m-0 pt-2",style:{color:"#ef4444"},children:p}),e.jsx(Ee,{request:t.request,onApprove:()=>{y(!0)},onReject:()=>{y(!1)},theme:f,services:a})]})},Le=t=>{switch(t){case"protocol":return"Protocol Permission";case"basket":return"Basket Access";case"certificate":return"Certificate Access";case"spending":return"Spending Authorization";default:return"Permission Request"}},ze=t=>{switch(t.type){case"protocol":{const s=Z(t.protocolID);return s?s.description:`An application is requesting permission to use protocol "${t.protocolID?.[1]||"unknown"}" with security level ${t.protocolID?.[0]||0}.`}case"basket":return`An application is requesting access to basket "${t.basket||"unknown"}".`;case"certificate":return"An application is requesting access to certificate data.";case"spending":return`An application is requesting authorization to spend ${t.spending?.satoshis||0} satoshis.`;default:return"An application is requesting a permission."}},Y=t=>t>=1e8?`${(t/1e8).toFixed(8)} BSV`:`${t.toLocaleString()} satoshis`,_e=t=>{const{request:s,onResponse:i}=t,{theme:o}=D(),{handleSelect:c,hideMenu:n}=M(),{addSnackbar:d}=V(),[a,p]=x.useState(!1),[u,m]=x.useState(""),{chromeStorageService:y}=B();x.useEffect(()=>{c("bsv"),n()},[c,n]);const r=async()=>{p(!0),m("");try{const g=await $(y);if(!g.ok){m(g.message),p(!1);return}T({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!0}),i()}catch(g){const l=g instanceof Error?g.message:String(g);d(l,"error"),p(!1)}},f=async()=>{p(!0),T({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!1}),i()};return e.jsxs(P.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(Q,{size:18,style:{color:"#FFD24D"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:Le(s.type)}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:ze(s)})]})]}),e.jsxs(P.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"12rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Origin"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.displayOriginator||s.originator})]}),e.jsxs(S,{when:s.type==="protocol"&&!!s.protocolID,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Protocol"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:ee(s.protocolID)})]}),e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.counterparty?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Security"}),e.jsx("span",{className:"text-xs",style:{color:o.color.global.contrast},children:be(s.protocolID?.[0])})]}),e.jsx(S,{when:!!s.counterparty,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.counterparty})]})})]}),e.jsx(S,{when:s.type==="basket"&&!!s.basket,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Basket"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.basket})]})}),e.jsxs(S,{when:s.type==="certificate"&&!!s.certificate,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Cert Type"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.certType})]}),e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Fields"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.fields.join(", ")})]})]}),e.jsxs(S,{when:s.type==="spending"&&!!s.spending,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.spending?.lineItems?.length?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Amount"}),e.jsx("span",{className:"text-xs font-semibold",style:{color:"#FFD24D"},children:Y(s.spending?.satoshis||0)})]}),e.jsx(S,{when:!!s.spending?.lineItems?.length,children:s.spending?.lineItems?.map((g,l)=>e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:l<(s.spending?.lineItems?.length??0)-1?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:g.type}),e.jsxs("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:[g.description," (",Y(g.satoshis),")"]})]},l))})]}),e.jsx(S,{when:!!s.reason,children:e.jsxs("div",{className:"flex flex-row py-2",style:{borderTop:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Reason"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.reason})]})})]}),e.jsx(S,{when:!!s.privileged,children:e.jsxs(P.div,{className:"flex items-start gap-2 rounded-xl px-3 py-2.5 mb-4",style:{background:"rgba(245,166,35,0.08)",border:"1px solid rgba(245,166,35,0.15)"},initial:{opacity:0},animate:{opacity:1},transition:{delay:.12},children:[e.jsx(le,{size:14,className:"mt-0.5 flex-shrink-0",style:{color:"#f5a623"}}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:"#f5a623"},children:"This is a privileged operation"})]})}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[u&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:u}),e.jsxs(P.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, #FFD24D 0%, #EAB300 100%)",color:"#010101",opacity:a?.6:1},disabled:a,onClick:r,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[a&&e.jsx(W,{size:14,className:"animate-spin"}),"Allow"]}),e.jsx(P.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:a?.5:1},disabled:a,onClick:f,whileHover:{scale:a?1:1.02},whileTap:{scale:a?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny"})]})]})},We=({request:t,onResponse:s})=>{const{theme:i}=D(),{chromeStorageService:o}=B(),[c,n]=x.useState(""),[d,a]=x.useState(!1),p=async y=>{if(!d){if(a(!0),n(""),y){const r=await $(o);if(!r.ok){n(r.message),a(!1);return}}T({action:"USB_CHECK_RESPONSE",requestID:t.requestID,ok:y}),s()}},u=i.color.global.gray,m=i.color.global.contrast;return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(ce,{size:40,style:{color:m}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:m},children:"Confirm your USB key"}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:u,maxWidth:"18rem"},children:[t.originator?`${t.originator} is asking bWallet to ${t.reason}.`:`A site is asking bWallet to ${t.reason}.`," ","Insert your USB key, then confirm."]}),c&&e.jsx("p",{className:"m-0 text-xs",style:{color:"#ef4444"},children:c}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(G,{theme:i,type:"primary",label:"Confirm USB key",disabled:d,onClick:()=>{p(!0)}}),e.jsx(G,{theme:i,type:"secondary-outline",label:"Cancel",disabled:d,onClick:()=>{p(!1)}})]})]})};X.Buffer=J;X.process=ne;window.Buffer=J;const Ve=1e4,qe=2e3,Ge=()=>{const{theme:t}=D(),{isLocked:s,isReady:i}=B(),[o,c]=x.useState({kind:"loading"}),n=x.useRef(void 0),d=x.useRef(void 0),a=()=>{n.current!==void 0&&(window.clearTimeout(n.current),n.current=void 0)},p=x.useCallback(async(r,f)=>{a(),c({kind:"loading"});let g;try{g=await L({action:"GET_PROMPT_PAYLOAD",kind:r,requestID:f})}catch{g=void 0}g?.success&&g.data?c({kind:r,requestID:f,payload:g.data}):(c({kind:"expired"}),window.setTimeout(()=>{d.current?.()},qe))},[]),u=x.useCallback(async()=>{a();let r;try{r=await L({action:"CLOSE_PROMPT_WINDOW"})}catch{r=void 0}if(r===void 0){window.close();return}const f=r.data?.prompt;f&&(f.kind==="unlock"?c({kind:"unlock"}):f.requestID&&await p(f.kind,f.requestID))},[p]),m=x.useCallback(async()=>{a();let r;try{r=await L({action:"GET_NEXT_PROMPT"})}catch{r=void 0}if(r?.data?.prompt){await p(r.data.prompt.kind,r.data.prompt.requestID);return}if(r?.data?.busy){c({kind:"waiting"}),n.current=window.setTimeout(()=>{u()},Ve);return}await u()},[p,u]);d.current=m,x.useEffect(()=>{if(!i)return;const r=new URLSearchParams(window.location.search),f=r.get("kind"),g=r.get("requestID");if(f==="unlock"){s?c({kind:"unlock"}):m();return}if(f&&g){p(f,g);return}m()},[i]),x.useEffect(()=>{const r=f=>{if(!(f?.action!=="SHOW_PROMPT"||!f.kind)){if(f.kind==="unlock"){a(),c({kind:"unlock"});return}f.requestID&&p(f.kind,f.requestID)}};return chrome.runtime.onMessage.addListener(r),()=>chrome.runtime.onMessage.removeListener(r)},[p]);const y=t.color.global.walletBackground;return e.jsx(xe,{children:e.jsxs("div",{className:"flex items-center justify-center relative p-0",style:{width:"var(--wallet-width)",height:"var(--wallet-height)",backgroundColor:y},children:[(!i||o.kind==="loading")&&e.jsx(H,{message:"Loading...",theme:t}),o.kind==="waiting"&&e.jsx(H,{message:"Waiting for request...",theme:t}),o.kind==="expired"&&e.jsx("p",{className:"text-xs",style:{color:t.color.global.gray},children:"This request expired or was already handled."}),o.kind==="unlock"&&e.jsx(me,{onUnlock:()=>{m()}}),o.kind==="permission"&&e.jsx(_e,{request:o.payload,onResponse:()=>{m()}}),o.kind==="groupedPermission"&&e.jsx(ve,{request:o.payload,onResponse:()=>{m()}}),o.kind==="counterpartyPermission"&&e.jsx(he,{request:o.payload,onResponse:()=>{m()}}),o.kind==="oneSatPermission"&&e.jsx(Oe,{request:o.payload,onResponse:()=>{m()}}),o.kind==="usbCheck"&&e.jsx(We,{request:o.payload,onResponse:()=>{m()}})]})})},se=document.getElementById("root");if(!se)throw new Error("Root element");ie.createRoot(se).render(e.jsx(pe,{children:e.jsx(de,{children:e.jsx(ue,{children:e.jsx(fe,{children:e.jsx(Ge,{})})})})}));
//# sourceMappingURL=prompt-tab-7xGK2QHr.js.map
