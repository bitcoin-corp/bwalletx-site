import{r as d,j as e,b as Te}from"./index-C2axhe3s.js";import{b as X,aT as we,J as ke,H as Re}from"./index-BErvU98S.js";import{a as _,b as L,e as C,aj as D,cc as z,cd as F,aP as Ie,U as $e,ak as xe,bw as M,ca as Be,cb as Fe,c3 as Ue,c4 as Oe,c5 as Me,P as me,c9 as _e}from"./index-C8AedbQx.js";import{a as V,u as J,U as Le,ao as ie,c as qe,i as ze,k as We,d as Ve,C as Ge}from"./identityText-c1urzOxp.js";const He=t=>{const{request:s,onResponse:i}=t,{theme:o}=_(),{handleSelect:r,hideMenu:a}=V(),{addSnackbar:f}=J(),[n,p]=d.useState(!1),[u,y]=d.useState(""),{chromeStorageService:h}=L(),{permissions:c}=s,[g,w]=d.useState(()=>c.protocols.map(()=>!0));d.useEffect(()=>{r("bsv"),a()},[r,a]);const l=()=>{const N=c.protocols.filter((E,R)=>g[R]);return N.length===0?{}:{protocols:N}},m=async()=>{p(!0),y("");try{const N=await z(h);if(!N.ok){y(N.message),p(!1);return}F({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:l()}),i()}catch(N){f(N instanceof Error?N.message:String(N),"error"),p(!1)}},x=async()=>{p(!0),F({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),i()},k=N=>w(E=>E.map((R,$)=>$===N?!R:R)),v=s.counterpartyLabel??`${s.counterparty.slice(0,8)}...${s.counterparty.slice(-8)}`;return e.jsxs(C.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(Le,{size:18,style:{color:"#FFD24D"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Counterparty Permission"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","wants to interact with a counterparty"]})]})]}),e.jsxs(C.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all font-mono",style:{color:o.color.global.contrast},children:v})]}),e.jsx(D,{when:!!c.description,children:e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Purpose"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:c.description})]})}),e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),c.protocols.map((N,E)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:E<c.protocols.length-1?"1px solid rgba(255,255,255,0.04)":"none"},children:[e.jsx("input",{type:"checkbox",checked:g[E],onChange:()=>k(E),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[N.protocolID?.[1]," (level ",N.protocolID?.[0],")"]}),N.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:N.description})]})]},`proto-${E}`))]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[u&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:u}),e.jsxs(C.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, #FFD24D 0%, #EAB300 100%)",color:"#010101",opacity:n?.6:1},disabled:n,onClick:m,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[n&&e.jsx(X,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(C.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:n?.5:1},disabled:n,onClick:x,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},Ke={"2:3241645161d8":{label:"BRC-29 payment",description:"An application is requesting permission to derive payment addresses for a specific recipient."}},je=t=>t?Ke[`${t[0]}:${t[1]}`]:void 0,Ne=t=>je(t)?.label??t?.[1],Ye=t=>{switch(t){case 0:return"Level 0 · any app";case 1:return"Level 1 · this app only";case 2:return"Level 2 · this app and this recipient only";default:return`Level ${t??0}`}},Xe=t=>{const{request:s,onResponse:i}=t,{theme:o}=_(),{handleSelect:r,hideMenu:a}=V(),{addSnackbar:f}=J(),[n,p]=d.useState(!1),[u,y]=d.useState(""),{chromeStorageService:h}=L(),{permissions:c}=s,[g,w]=d.useState(()=>(c.protocolPermissions??[]).map(()=>!0)),[l,m]=d.useState(()=>(c.basketAccess??[]).map(()=>!0)),[x,k]=d.useState(()=>(c.certificateAccess??[]).map(()=>!0)),[v,N]=d.useState(!0);d.useEffect(()=>{r("bsv"),a()},[r,a]);const E=()=>{const b={},S=(c.protocolPermissions??[]).filter((H,B)=>g[B]);S.length>0&&(b.protocolPermissions=S);const A=(c.basketAccess??[]).filter((H,B)=>l[B]);A.length>0&&(b.basketAccess=A);const T=(c.certificateAccess??[]).filter((H,B)=>x[B]);return T.length>0&&(b.certificateAccess=T),v&&c.spendingAuthorization&&(b.spendingAuthorization=c.spendingAuthorization),b},R=async()=>{p(!0),y("");try{const b=await z(h);if(!b.ok){y(b.message),p(!1);return}F({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:E()}),i()}catch(b){f(b instanceof Error?b.message:String(b),"error"),p(!1)}},$=async()=>{p(!0),F({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),i()},G=b=>w(S=>S.map((A,T)=>T===b?!A:A)),U=b=>m(S=>S.map((A,T)=>T===b?!A:A)),Q=b=>k(S=>S.map((A,T)=>T===b?!A:A));return e.jsxs(C.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ie,{size:18,style:{color:"#FFD24D"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Permission Request"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","is requesting the following permissions"]})]})]}),e.jsx(D,{when:!!c.description,children:e.jsx("p",{className:"text-xs mb-3 leading-relaxed",style:{color:o.color.global.gray},children:c.description})}),e.jsx(D,{when:!!c.spendingAuthorization,children:e.jsxs(C.div,{className:"w-full rounded-2xl px-4 py-3 mb-3",style:{background:"rgba(247,144,9,0.08)",border:"1px solid rgba(247,144,9,0.2)"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.06},children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pb-1",style:{color:"#F79009"},children:"Spending Authorization"}),e.jsxs("label",{className:"flex items-start gap-3 py-1 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:v,onChange:()=>N(!v),className:"mt-0.5 accent-orange-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-semibold",style:{color:"#F79009"},children:["This app wants to spend up to ",((c.spendingAuthorization?.amount??0)/1e8).toFixed(8)," BSV"," ","(",(c.spendingAuthorization?.amount??0).toLocaleString()," satoshis)"]}),c.spendingAuthorization?.description&&e.jsxs("span",{className:"text-xs mt-1 opacity-70",style:{color:o.color.global.contrast},children:["App says: “",c.spendingAuthorization.description,"”"]})]})]})]})}),e.jsxs(C.div,{className:"w-full rounded-2xl px-4 py-2 mb-5",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs(D,{when:!!c.protocolPermissions?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),c.protocolPermissions?.map((b,S)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:g[S],onChange:()=>G(S),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[Ne(b.protocolID)," (level ",b.protocolID[0],")",b.counterparty?` — ${b.counterparty.slice(0,10)}...`:""]}),b.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:b.description})]})]},`proto-${S}`))]}),e.jsxs(D,{when:!!c.basketAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Baskets"}),c.basketAccess?.map((b,S)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:l[S],onChange:()=>U(S),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:b.basket}),b.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:b.description})]})]},`basket-${S}`))]}),e.jsxs(D,{when:!!c.certificateAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Certificates"}),c.certificateAccess?.map((b,S)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:x[S],onChange:()=>Q(S),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:b.type}),e.jsxs("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:[b.description," — fields: ",b.fields.join(", ")]})]})]},`cert-${S}`))]})]}),e.jsxs("div",{className:"flex flex-col gap-3",children:[u&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:u}),e.jsxs(C.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, #FFD24D 0%, #EAB300 100%)",color:"#010101",opacity:n?.6:1},disabled:n,onClick:R,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[n&&e.jsx(X,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(C.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:n?.5:1},disabled:n,onClick:$,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},Je=2e3;async function Y(t,s=Je){let i;try{return await Promise.race([t.catch(()=>{}),new Promise(o=>{i=setTimeout(()=>o(void 0),s)})])}catch{return}finally{i&&clearTimeout(i)}}function Qe(t,s){return t?.find(i=>i.startsWith(`${s}:`))?.slice(s.length+1)}async function Ze(t,s,i=[]){const o=t.ordfs;if(typeof o?.bulkMetadata!="function")return{state:"unverified"};const r=`${s}:-2`,a=await Y(o.bulkMetadata([r])),f=a?.[r]??a?.[s]??Object.values(a??{}).find(u=>!!u?.contentType);if(!f?.contentType)return{state:"unverified"};const n={contentType:f.contentType,origin:f.origin,name:typeof f.map?.name=="string"?f.map.name:void 0},p=i.find(u=>u.includes("/"));return p&&p!==f.contentType?{state:"mismatch",note:`Content type is ${f.contentType}, not ${p}`,...n}:{state:"verified",...n}}async function et(t,s,i){const o=t.opns;if(typeof o?.getOrigin!="function")return{state:"unverified"};const r=await Y(o.getOrigin(s));return r?.outpoint?r.outpoint!==i?{state:"mismatch",note:`“${s}” currently resolves to a different output`}:{state:"verified"}:{state:"unverified"}}async function tt(t,s,i,o=[]){const r=t.bsv21;if(typeof r?.getTokenDetails!="function")return{state:"unverified"};const a=await Y(r.getTokenDetails(s,{fresh:!0}));if(!a)return{state:"unverified"};if(a.status?.is_active===!1)return{state:"mismatch",note:"Token is not active on the overlay"};const f=a.token?.sym;if(i&&f&&i.toLowerCase()!==f.toLowerCase())return{state:"mismatch",note:`Token symbol is ${f}, not ${i}`};if(o.length>0&&typeof r.getOutputStatus=="function"){const n=await Y(r.getOutputStatus(s,o));if(!n)return{state:"unverified"};const p=n.filter(u=>u.state==="spent"||u.state==="unknown");if(p.length>0)return{state:"mismatch",note:p.length===1?"A spent token output is not valid on the overlay":`${p.length} spent token outputs are not valid on the overlay`};if(n.some(u=>u.state==="queued"))return{state:"unverified"}}return{state:"verified",...f?{name:f}:{}}}async function st(t,s,i,o,r){if(!t||!s)return{state:"unverified"};const a=s==="purchase"||s.endsWith(".purchase"),f=s==="token-transfer"||s.startsWith("bsv21.");if(!a&&!f)return{state:"unverified"};const n={kindOrIntent:s,hasOrdfs:!!t.ordfs,hasBulk:typeof t.ordfs?.bulkMetadata=="function",inputTagSets:i.map(p=>p.tags),outputTagSets:o.map(p=>p.tags)};try{const p=[...i.map(l=>l.tags),...o.map(l=>l.tags)],u=l=>p.flatMap(m=>m.filter(x=>x.startsWith(`${l}:`)).map(x=>x.slice(l.length+1))),y=l=>{for(const m of p){const x=Qe(m,l);if(x)return x}},h=y("bsv21");if(h||s==="bsv21.purchase"||s==="token-transfer"||s.startsWith("bsv21.")){if(!h)return{state:"unverified"};const m=i.filter(k=>k.basket?.includes("bsv21")||k.tags.some(v=>v.startsWith("bsv21:"))).map(k=>k.outpoint).filter(Boolean);let x=y("sym");for(const k of i)if(k.customInstructions)try{const v=JSON.parse(k.customInstructions).sym;if(typeof v=="string"&&v.trim()){x=v.trim();break}}catch{}return await tt(t,h,x,m)}const c=y("name"),g=y("origin");if(n.name=c,n.origin=g,c&&g&&o.some(l=>l.basket?.includes("opns"))||s==="opns.purchase")return!c||!g?{state:"unverified"}:await et(t,c,g);if(!g)return n.reason="no-origin-tag",globalThis.__lastVerify=n,{state:"unverified"};const w=await Ze(t,g,u("type"));if(n.verifyOrdinal=w,w.origin&&r)try{w.contentUrl=r(w.origin)}catch(l){n.contentUrlError=String(l)}return globalThis.__lastVerify=n,w}catch(p){return n.error=String(p),globalThis.__lastVerify=n,{state:"unverified"}}}function Se(t){if(!t||typeof t!="object")return!1;const s=t;return Array.isArray(s.panels)&&typeof s.title=="string"}var ot=`
.opp-root {
  --opp-bg: #ffffff;
  --opp-fg: #111827;
  --opp-muted: #6b7280;
  --opp-card-bg: #f7f8fa;
  --opp-card-border: #eceef2;
  --opp-accent: #E5A920;
  --opp-approve-bg: #E5A920;
  --opp-approve-fg: #ffffff;
  --opp-reject-bg: #ffffff;
  --opp-reject-fg: #111827;
  --opp-reject-border: #d1d5db;
  --opp-status-bg: #FFFBE6;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #ECFDF5;
  --opp-trust-ok-fg: #059669;
  --opp-trust-warn-bg: #FFFBEB;
  --opp-trust-warn-fg: #D97706;
  --opp-trust-bad-bg: #FEF2F2;
  --opp-trust-bad-fg: #DC2626;

  font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--opp-bg);
  color: var(--opp-fg);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 480px;
  min-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
}

.opp-bottom {
  margin-top: auto;
  display: flex;
  flex-direction: column;
}

.opp-root.opp-dark {
  --opp-bg: #0F1117;
  --opp-fg: #F9FAFB;
  --opp-muted: #9ca3af;
  --opp-card-bg: #1A1D27;
  --opp-card-border: #232636;
  --opp-reject-bg: #0F1117;
  --opp-reject-fg: #F9FAFB;
  --opp-reject-border: #2D3142;
  --opp-status-bg: #2A2408;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #0A2E1F;
  --opp-trust-ok-fg: #34D399;
  --opp-trust-warn-bg: #2A2008;
  --opp-trust-warn-fg: #FBBF24;
  --opp-trust-bad-bg: #2A1215;
  --opp-trust-bad-fg: #F87171;
}

.opp-body {
  padding: 24px 20px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
}

.opp-coin {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
}

.opp-title {
  font-size: 16px;
  font-weight: 700;
  margin: 0;
  text-align: center;
}

.opp-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  margin: 0;
  text-align: center;
  line-height: 1.4;
}

.opp-status {
  background: var(--opp-status-bg);
  color: var(--opp-status-fg);
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
  margin-top: 4px;
  border: 1px solid var(--opp-card-border);
}

.opp-card {
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px;
  padding: 16px;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.opp-featured {
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px 8px;
  padding: 16px;
}

/* Subtle danger chrome for burn / destructive token ops */
.opp-featured-danger {
  border-color: rgba(220, 38, 38, 0.45);
  background: color-mix(in srgb, var(--opp-card-bg) 88%, #7f1d1d 12%);
}

.opp-featured-danger .opp-featured-title {
  color: #f87171;
}

.opp-featured-danger .opp-featured-image,
.opp-featured-danger .opp-featured-placeholder {
  border: 1px solid rgba(220, 38, 38, 0.35);
  background: rgba(127, 29, 29, 0.25);
  color: #fca5a5;
}

.opp-dark .opp-featured-danger {
  border-color: rgba(248, 113, 113, 0.4);
  background: color-mix(in srgb, var(--opp-card-bg) 85%, #450a0a 15%);
}

.opp-preview-pair {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.opp-preview-arrow {
  color: var(--opp-muted);
  font-size: 14px;
  line-height: 1;
}

.opp-preview-pair .opp-featured-image {
  width: 64px;
  height: 64px;
}

.opp-featured-image {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-featured-image-token {
  width: 48px;
  height: 48px;
  border-radius: 999px;
}

.opp-featured-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--opp-muted);
  font-size: 18px;
}

.opp-preview-opns {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
}

.opp-preview-opns-avatar {
  width: 36px;
  height: 36px;
  border-radius: 999px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-preview-opns-name {
  font-size: 11px;
  font-weight: 600;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  color: var(--opp-fg, inherit);
}

.opp-preview-text {
  margin: 0;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
  font-size: 9px;
  line-height: 1.25;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  color: var(--opp-muted);
}

.opp-preview-json {
  white-space: pre;
  overflow: auto;
}

.opp-preview-frame {
  border: 0;
  padding: 0;
  overflow: hidden;
  background: #fff;
  pointer-events: none;
}

.opp-preview-value {
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  background: rgba(229, 169, 32, 0.12);
  border: 1px solid rgba(229, 169, 32, 0.35);
  color: var(--opp-fg, inherit);
}

.opp-preview-value-icon {
  width: 32px;
  height: 32px;
  color: #E5A920;
}

/* Amount subtitles must never ellipsis — full sat counts are the point. */
.opp-featured-subtitle-text.opp-amount {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-variant-numeric: tabular-nums;
  white-space: normal;
  overflow: visible;
  text-overflow: unset;
  word-break: keep-all;
}

.opp-featured-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  flex: 1;
}

.opp-featured-title {
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.opp-featured-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.opp-featured-subtitle-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
}

.opp-featured-meta-line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  color: var(--opp-muted);
}

.opp-featured-meta-line-bare {
  align-items: center;
}

.opp-featured-meta-key {
  flex-shrink: 0;
  opacity: 0.75;
  min-width: 2.5em;
}

.opp-featured-meta-value {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  flex: 1;
}

.opp-featured-meta-value-mono {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 11px;
}

.opp-trust-wrap {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0 20px 8px;
}

.opp-trust {
  display: inline-flex;
  align-self: flex-start;
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 600;
}

.opp-trust-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-trust-note {
  padding: 10px;
  border-radius: 8px;
  font-size: 11px;
  line-height: 1.35;
}

.opp-trust-note-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-note-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-note-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.opp-row-key {
  color: var(--opp-muted);
  flex-shrink: 0;
}

.opp-row-value-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 70%;
  justify-content: flex-end;
}

.opp-row-value {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 12px;
  font-weight: 500;
  text-align: right;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.opp-copy {
  flex-shrink: 0;
  width: 22px;
  height: 22px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  border: 1px solid var(--opp-reject-border);
  background: var(--opp-bg);
  color: var(--opp-fg);
  cursor: pointer;
}

.opp-copy:hover {
  border-color: var(--opp-accent);
  color: var(--opp-accent);
}

.opp-fee-note {
  font-size: 11px;
  color: var(--opp-muted);
  line-height: 1.3;
  margin-top: -4px;
}

.opp-actions {
  display: flex;
  gap: 12px;
  padding: 20px 20px 12px;
}

.opp-button {
  flex: 1;
  padding: 0 16px;
  height: 48px;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid transparent;
  transition: opacity 120ms ease;
}

.opp-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.opp-button-reject {
  background: var(--opp-reject-bg);
  color: var(--opp-reject-fg);
  border-color: var(--opp-reject-border);
}

.opp-button-approve {
  background: var(--opp-approve-bg);
  color: var(--opp-approve-fg);
}

.opp-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 20px 16px;
  font-size: 11px;
  font-weight: 500;
  color: var(--opp-muted);
}
`;function rt({request:t,onApprove:s,onReject:i,theme:o="auto",services:r}){const a=ft(o),f=nt(t),[n,p]=d.useState(!1),[u,y]=d.useState(),h=t.kind==="transaction"&&Se(t.payload)?t.payload:void 0;d.useEffect(()=>{if(!r||!h?.trust||!h.verify)return;let l=!0;const m=r.ordfs?.getContentUrl?.bind(r.ordfs);return st(r,h.verify.kind,h.verify.inputs,h.verify.outputs,m).then(x=>{l&&x&&y(x)}).catch(()=>{}),()=>{l=!1}},[r,h]);const c=u?at(f,u):f,g=l=>()=>{if(!n){p(!0);try{l==="approve"?s():i()}finally{p(!1)}}};d.useEffect(()=>{const l=m=>{n||(m.key==="Escape"?i():m.key==="Enter"&&s())};return window.addEventListener("keydown",l),()=>window.removeEventListener("keydown",l)},[s,i,n]);const w=`opp-root${a==="dark"?" opp-dark":""}`;return e.jsxs("div",{className:w,children:[e.jsx("style",{children:ot}),e.jsxs("div",{className:"opp-body",children:[e.jsxs("svg",{className:"opp-coin",viewBox:"0 0 100 100","aria-label":"1Sat Ordinals",children:[e.jsx("circle",{cx:"50",cy:"50",r:"50",fill:"#222"}),e.jsx("circle",{cx:"50",cy:"50",r:"40",fill:"#fff"}),e.jsx("circle",{cx:"50",cy:"50",r:"32",fill:"#E5A920"}),e.jsx("rect",{x:"47",y:"28",width:"6",height:"28",rx:"3",fill:"#fff"})]}),e.jsx("h2",{className:"opp-title",children:c.title}),e.jsx("p",{className:"opp-subtitle",children:c.subtitle}),e.jsx("div",{className:"opp-status",children:"Awaiting Approval"})]}),c.panels.map((l,m)=>{const x=l.variant??"ordinal",k=["opp-featured"];return x==="token"&&k.push("opp-featured-token"),x==="value"&&k.push("opp-featured-value"),l.tone==="danger"&&k.push("opp-featured-danger"),e.jsxs("div",{className:k.join(" "),children:[l.prior?e.jsxs("div",{className:"opp-preview-pair","aria-label":"Previous and new inscription",children:[e.jsx(se,{panel:{...l,previewKind:l.prior.previewKind,imageUrl:l.prior.imageUrl,contentUrl:l.prior.contentUrl,previewText:l.prior.previewText,prior:void 0}}),e.jsx("span",{className:"opp-preview-arrow","aria-hidden":!0,children:"→"}),e.jsx(se,{panel:l})]}):e.jsx(se,{panel:l}),e.jsxs("div",{className:"opp-featured-meta",children:[e.jsx("div",{className:"opp-featured-title",children:l.title}),l.subtitle&&e.jsxs("div",{className:"opp-featured-subtitle",children:[e.jsx("span",{className:l.amountSats!=null?"opp-featured-subtitle-text opp-amount":"opp-featured-subtitle-text",children:l.subtitle}),l.subtitleCopy&&e.jsx(oe,{text:l.subtitleCopy})]}),(l.meta??[]).map(v=>e.jsxs("div",{className:`opp-featured-meta-line${v.key?"":" opp-featured-meta-line-bare"}`,children:[v.key?e.jsx("span",{className:"opp-featured-meta-key",children:v.key}):null,e.jsx("span",{className:`opp-featured-meta-value${v.key?"":" opp-featured-meta-value-mono"}`,title:v.copyValue??v.value,children:v.value}),v.copyValue&&e.jsx(oe,{text:v.copyValue})]},`${v.key}:${v.value}`))]})]},`panel-${m}-${l.title}`)}),c.trust&&e.jsxs("div",{className:"opp-trust-wrap",children:[e.jsx("span",{className:`opp-trust opp-trust-${c.trust.state}`,children:ct(c.trust.state)}),c.trust.note&&e.jsx("div",{className:`opp-trust-note opp-trust-note-${c.trust.state}`,children:c.trust.note})]}),(c.rows.length>0||c.indexerFee||c.funding)&&e.jsxs("div",{className:"opp-card",children:[c.rows.map(l=>e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:l.key}),e.jsxs("span",{className:"opp-row-value-wrap",children:[e.jsx("span",{className:"opp-row-value",title:l.copyValue??l.value,children:l.value}),l.copyValue&&e.jsx(oe,{text:l.copyValue})]})]},`${l.key}:${l.value}`)),c.indexerFee&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"1Sat Overlay Fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[ge(c.indexerFee.sats)," sats"]})]}),c.funding?.networkFeeSats!=null&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"Network fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[ge(c.funding.networkFeeSats)," sats"]})]}),c.funding?.note&&e.jsx("div",{className:"opp-fee-note",children:c.funding.note})]}),e.jsxs("div",{className:"opp-bottom",children:[e.jsxs("div",{className:"opp-actions",children:[e.jsx("button",{type:"button",className:"opp-button opp-button-reject",onClick:g("reject"),disabled:n,children:"Reject"}),e.jsx("button",{type:"button",className:"opp-button opp-button-approve",onClick:g("approve"),disabled:n,children:"Approve"})]}),e.jsx("div",{className:"opp-footer",children:e.jsx("span",{children:"Secured by 1Sat Ordinals"})})]})]})}function nt(t){if(t.kind==="transaction"&&Se(t.payload))return{title:t.payload.title,subtitle:t.payload.subtitle,panels:t.payload.panels,rows:t.payload.rows,trust:t.payload.trust,indexerFee:t.payload.indexerFee,funding:t.payload.funding};if(t.kind==="basketAccess"){const s=t.payload.baskets??[],i=s.length>0&&s.every(a=>a.scope||a.basket.startsWith("p ")),o=s.filter(a=>a.imageUrl||a.name||a.value).map(a=>({title:a.scope==="collection"?a.name?`Collection · ${a.name}`:"Collection":a.scope?a.scope:"Basket",subtitle:a.value?a.value.length>24?`${a.value.slice(0,10)}…${a.value.slice(-10)}`:a.value:a.basket,subtitleCopy:a.value,...a.imageUrl&&{previewKind:"image",contentUrl:a.imageUrl,imageUrl:a.imageUrl},tone:"default"})),r=s.flatMap(a=>a.scope==="collection"?a.description?[{key:"Access",value:a.description}]:[]:[{key:a.basket,value:a.description??"List, insert, and remove outputs"}]);return{title:i?s.length===1?s[0].scope==="collection"?"Grant Collection View":"Grant Item View":`Grant View (${s.length})`:s.length===1?"Grant Basket Access":`Grant Access to ${s.length} Baskets`,subtitle:i?`${K(t.originator)} wants to view items in your wallet`:`${K(t.originator)} wants to read and write 1Sat baskets`,panels:o,rows:r}}return t.kind==="protocol"?{title:"Protocol Access",subtitle:`${K(t.originator)} wants protocol access`,panels:[],rows:[{key:"Detail",value:t.summary||"Protocol request"}]}:{title:"Signature Request",subtitle:`${K(t.originator)} wants a signature`,panels:[],rows:[{key:"Detail",value:t.summary||"Signature request"}]}}function at(t,s){const i=t.panels.map((o,r)=>{if(r!==0)return o;const a=o.previewKind==="opns",f=s.contentType?it(s.contentType):void 0,n=a?"opns":f&&f!=="none"?f:o.previewKind,p=s.contentUrl??o.contentUrl??o.imageUrl;let u=o.subtitle;if(s.name&&!a)if(!u)u=s.name;else{const y=u.trim().split(/\s+/);y.length>=2&&(y[y.length-1]=s.name,u=y.join(" "))}return{...o,previewKind:n,...u?{subtitle:u}:{},...a?{...s.contentUrl&&!o.imageUrl?{imageUrl:s.contentUrl}:o.imageUrl?{imageUrl:o.imageUrl}:{}}:n==="image"?{imageUrl:p,contentUrl:p}:p?{contentUrl:p,imageUrl:void 0}:{}}});return{...t,panels:i,trust:{state:s.state,note:s.note}}}function it(t){const s=t.toLowerCase();return s==="image/svg+xml"||s==="svg"||s.endsWith("+svg")?"svg":s.startsWith("image/")?"image":s.includes("json")?"json":s.includes("html")||s==="application/xhtml+xml"?"html":s.startsWith("text/")?"text":"none"}function lt(t){return`${t.toLocaleString("en-US")} sats`}function ge(t){return t.toLocaleString("en-US")}function ct(t){return t==="verified"?"Verified":t==="mismatch"?"Mismatch":"Unverified"}function se({panel:t}){const s=t.variant??"ordinal",i=s==="token"?"opp-featured-image opp-featured-image-token":s==="value"?"opp-featured-image opp-preview-value":"opp-featured-image",o=t.previewKind??(t.imageUrl?"image":"none"),r=t.contentUrl??t.imageUrl,[a,f]=d.useState(!1);if(s==="value"){const n=t.valueIcon??"pay";return e.jsx("div",{className:i,title:t.amountSats!=null?lt(t.amountSats):void 0,"aria-hidden":!0,children:e.jsx(dt,{kind:n})})}if(o==="opns"){const n=!!t.imageUrl&&!a;return e.jsxs("div",{className:`${i} opp-preview-opns`,"aria-hidden":!t.opnsHero,children:[n?e.jsx("img",{className:"opp-preview-opns-avatar",src:t.imageUrl,alt:"",onError:()=>f(!0)}):e.jsx("div",{className:"opp-preview-opns-avatar opp-featured-placeholder",children:"◈"}),e.jsx("span",{className:"opp-preview-opns-name",title:t.opnsHero,children:t.opnsHero??"OpNS"})]})}return o==="image"&&t.imageUrl&&!a?e.jsx("img",{className:i,src:t.imageUrl,alt:t.title,onError:()=>f(!0)}):o==="image"&&a?e.jsx("div",{className:`${i} opp-featured-placeholder`,"aria-hidden":!0,children:"▭"}):(o==="text"||o==="json"||o==="html")&&t.previewText?e.jsx("pre",{className:`${i} opp-preview-text${o==="json"?" opp-preview-json":""}`,children:t.previewText}):(o==="text"||o==="json")&&r?e.jsx(ut,{url:r,kind:o,className:i}):(o==="html"||o==="svg")&&r?e.jsx("iframe",{className:`${i} opp-preview-frame`,src:r,title:`${t.title} preview`,sandbox:"",referrerPolicy:"no-referrer"}):e.jsx("div",{className:`${i} opp-featured-placeholder`,"aria-hidden":!0,children:s==="token"?"◎":pt(o)})}function pt(t){return t==="text"||t==="json"?"¶":t==="html"||t==="svg"?"⌂":"▭"}function dt({kind:t}){return t==="lock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V8a4 4 0 018 0v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):t==="unlock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V7.5A4 4 0 0116 7",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("path",{d:"M16 4.5v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"9",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M12 7v10M9 10.5c0-1.4 1.3-2.5 3-2.5s3 1.1 3 2.5-1.3 2.5-3 2.5-3 1.1-3 2.5 1.3 2.5 3 2.5 3-1.1 3-2.5",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})}function ut({url:t,kind:s,className:i}){const[o,r]=d.useState(null),[a,f]=d.useState(!1);return d.useEffect(()=>{let n=!1;return r(null),f(!1),fetch(t).then(async p=>{if(!p.ok)throw new Error(String(p.status));const u=await p.text();if(!n){if(s==="json")try{r(JSON.stringify(JSON.parse(u),null,2));return}catch{}r(u.slice(0,800))}}).catch(()=>{n||f(!0)}),()=>{n=!0}},[t,s]),a?e.jsx("div",{className:`${i} opp-featured-placeholder`,"aria-hidden":!0,children:"¶"}):e.jsx("pre",{className:`${i} opp-preview-text${s==="json"?" opp-preview-json":""}`,children:o??"…"})}function oe({text:t}){const[s,i]=d.useState(!1),o=()=>{navigator.clipboard?.writeText(t).then(()=>{i(!0),window.setTimeout(()=>i(!1),1200)})};return e.jsx("button",{type:"button",className:"opp-copy",onClick:o,"aria-label":s?"Copied":"Copy full value",title:s?"Copied":"Copy",children:s?e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:e.jsx("path",{d:"M5 13l4 4L19 7",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round"})}):e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"9",y:"9",width:"11",height:"11",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M5 15V5a2 2 0 012-2h10",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})})}function ft(t){const[s,i]=d.useState(()=>t==="auto"?xt():t);return d.useEffect(()=>{if(t!=="auto"){i(t);return}const o=window.matchMedia("(prefers-color-scheme: dark)"),r=()=>i(o.matches?"dark":"light");return r(),o.addEventListener("change",r),()=>o.removeEventListener("change",r)},[t]),s}function xt(){return typeof window>"u"||!window.matchMedia?"light":window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function K(t){try{return new URL(t.includes("://")?t:`https://${t}`).host||t}catch{return t.length<=32?t:`${t.slice(0,14)}…${t.slice(-12)}`}}const mt=({request:t,onResponse:s})=>{const{theme:i}=_(),{handleSelect:o,hideMenu:r}=V(),{apiContext:a,chromeStorageService:f}=L(),n=a?.services;d.useEffect(()=>{o("bsv"),r()},[o,r]);const[p,u]=d.useState(""),y=d.useRef(!1),h=async w=>{if(!y.current){if(y.current=!0,w){u("");const l=await z(f);if(!l.ok){u(l.message),y.current=!1;return}}F({action:"ONE_SAT_PERMISSION_RESPONSE",requestID:t.requestID,approved:w}),s()}},g=i.color.global.walletBackground.toLowerCase()==="#000000"||/^#[01]/.test(i.color.global.walletBackground)?"dark":"light";return e.jsxs("div",{style:{width:"100%",height:"100%",overflowY:"auto",display:"flex",flexDirection:"column",alignItems:"stretch",justifyContent:"center"},children:[p&&e.jsx("p",{className:"text-xs text-center m-0 pt-2",style:{color:"#ef4444"},children:p}),e.jsx(rt,{request:t.request,onApprove:()=>{h(!0)},onReject:()=>{h(!1)},theme:g,services:n})]})},gt=t=>{switch(t){case"protocol":return"Protocol Permission";case"basket":return"Basket Access";case"certificate":return"Certificate Access";case"spending":return"Spending Authorization";default:return"Permission Request"}},ht=t=>{switch(t.type){case"protocol":{const s=je(t.protocolID);return s?s.description:`An application is requesting permission to use protocol "${t.protocolID?.[1]||"unknown"}" with security level ${t.protocolID?.[0]||0}.`}case"basket":return`An application is requesting access to basket "${t.basket||"unknown"}".`;case"certificate":return"An application is requesting access to certificate data.";case"spending":return`An application is requesting authorization to spend ${t.spending?.satoshis||0} satoshis.`;default:return"An application is requesting a permission."}},he=t=>t>=1e8?`${(t/1e8).toFixed(8)} BSV`:`${t.toLocaleString()} satoshis`,yt=t=>{const{request:s,onResponse:i}=t,{theme:o}=_(),{handleSelect:r,hideMenu:a}=V(),{addSnackbar:f}=J(),[n,p]=d.useState(!1),[u,y]=d.useState(""),{chromeStorageService:h}=L();d.useEffect(()=>{r("bsv"),a()},[r,a]);const c=async()=>{p(!0),y("");try{const w=await z(h);if(!w.ok){y(w.message),p(!1);return}F({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!0}),i()}catch(w){const l=w instanceof Error?w.message:String(w);f(l,"error"),p(!1)}},g=async()=>{p(!0),F({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!1}),i()};return e.jsxs(C.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ie,{size:18,style:{color:"#FFD24D"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:gt(s.type)}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:ht(s)})]})]}),e.jsxs(C.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"12rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Origin"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.displayOriginator||s.originator})]}),e.jsxs(D,{when:s.type==="protocol"&&!!s.protocolID,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Protocol"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:Ne(s.protocolID)})]}),e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.counterparty?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Security"}),e.jsx("span",{className:"text-xs",style:{color:o.color.global.contrast},children:Ye(s.protocolID?.[0])})]}),e.jsx(D,{when:!!s.counterparty,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.counterparty})]})})]}),e.jsx(D,{when:s.type==="basket"&&!!s.basket,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Basket"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.basket})]})}),e.jsxs(D,{when:s.type==="certificate"&&!!s.certificate,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Cert Type"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.certType})]}),e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Fields"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.fields.join(", ")})]})]}),e.jsxs(D,{when:s.type==="spending"&&!!s.spending,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.spending?.lineItems?.length?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Amount"}),e.jsx("span",{className:"text-xs font-semibold",style:{color:"#FFD24D"},children:he(s.spending?.satoshis||0)})]}),e.jsx(D,{when:!!s.spending?.lineItems?.length,children:s.spending?.lineItems?.map((w,l)=>e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:l<(s.spending?.lineItems?.length??0)-1?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:w.type}),e.jsxs("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:[w.description," (",he(w.satoshis),")"]})]},l))})]}),e.jsx(D,{when:!!s.reason,children:e.jsxs("div",{className:"flex flex-row py-2",style:{borderTop:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Reason"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.reason})]})})]}),e.jsx(D,{when:!!s.privileged,children:e.jsxs(C.div,{className:"flex items-start gap-2 rounded-xl px-3 py-2.5 mb-4",style:{background:"rgba(245,166,35,0.08)",border:"1px solid rgba(245,166,35,0.15)"},initial:{opacity:0},animate:{opacity:1},transition:{delay:.12},children:[e.jsx(Ie,{size:14,className:"mt-0.5 flex-shrink-0",style:{color:"#f5a623"}}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:"#f5a623"},children:"This is a privileged operation"})]})}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[u&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:u}),e.jsxs(C.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, #FFD24D 0%, #EAB300 100%)",color:"#010101",opacity:n?.6:1},disabled:n,onClick:c,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[n&&e.jsx(X,{size:14,className:"animate-spin"}),"Allow"]}),e.jsx(C.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:n?.5:1},disabled:n,onClick:g,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny"})]})]})},bt=({request:t,onResponse:s})=>{const{theme:i}=_(),{chromeStorageService:o}=L(),[r,a]=d.useState(""),[f,n]=d.useState(!1),p=async h=>{if(!f){if(n(!0),a(""),h){const c=await z(o);if(!c.ok){a(c.message),n(!1);return}}F({action:"USB_CHECK_RESPONSE",requestID:t.requestID,ok:h}),s()}},u=i.color.global.gray,y=i.color.global.contrast;return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx($e,{size:40,style:{color:y}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:y},children:"Confirm your USB key"}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:u,maxWidth:"18rem"},children:[t.originator?`${t.originator} is asking bWallet to ${t.reason}.`:`A site is asking bWallet to ${t.reason}.`," ","Insert your USB key, then confirm."]}),r&&e.jsx("p",{className:"m-0 text-xs",style:{color:"#ef4444"},children:r}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(xe,{theme:i,type:"primary",label:"Confirm USB key",disabled:f,onClick:()=>{p(!0)}}),e.jsx(xe,{theme:i,type:"secondary-outline",label:"Cancel",disabled:f,onClick:()=>{p(!1)}})]})]})},ye=5,re=[0,1,5,20],vt=/e-?mail|phone|mobile|kyc|passport|licen[cs]e|birth|dob|address|ssn|national|tax|id_?number/i,wt=t=>String(t.protocolID?.[1]??"unknown"),le=t=>Number(t.protocolID?.[0]??0),Ee=t=>!!(t.privileged||t.type==="certificate"&&(t.certificate?.fields??[]).some(s=>vt.test(s))),kt=t=>{switch(t.type){case"protocol":return t.counterparty==="anyone"?"Prove it's you (a signature anyone can check)":le(t)===2&&t.counterparty&&t.counterparty!=="self"?"Sign and share keys with one named person or service":"Sign in and sign its messages";case"basket":return"Keep its tickets and tokens in your wallet";case"certificate":{const s=t.certificate?.fields??[];return s.length?`See your certificate details (${s.join(", ")})`:"See your certificates"}default:return"Spend from your wallet"}},ne=t=>{const s=[];switch(t.type){case"protocol":s.push(`protocol "${wt(t)}" level ${le(t)}`),t.counterparty&&s.push(`counterparty ${t.counterparty}`);break;case"basket":s.push(`basket "${t.basket??""}"`);break;case"certificate":s.push(`certificate ${t.certificate?.certType??""}`,`verifier ${t.certificate?.verifier??""}`);break;case"spending":s.push(`${t.spending?.satoshis??0} sats`);break}return t.privileged&&s.push("privileged"),t.reason&&s.push(`reason: ${t.reason}`),s.join(" · ")},jt=t=>{const s=[];let i;for(const r of t.items){if(r.type==="spending"){const f=r.spending?.satoshis??0;i?s.push({requestID:r.requestID,text:`Also pay ${f.toLocaleString()} sats`,detail:ne(r),risky:!0,checked:!1}):i={requestID:r.requestID,satoshis:f,description:r.spending?.lineItems?.find(n=>n.description)?.description??r.reason,detail:ne(r)};continue}const a=Ee(r);s.push({requestID:r.requestID,text:kt(r),detail:ne(r),risky:a,checked:!a})}const o=i?s.length?"connectAndPay":"pay":"connect";return{originator:t.originator,lines:s,payment:i,mode:o}},Nt="bwalletx.trust-site",St=t=>{if(Ee(t)||t.type==="protocol"&&t.counterparty==="anyone")return!1;if(t.type==="basket")return!!t.basket&&t.basket!==Nt;if(t.type!=="protocol")return!1;const s=le(t);return s<=1?!0:s===2&&(t.counterparty==="self"||t.counterparty===void 0)},Et=t=>t.items.some(s=>St(s)),be="#F04438",ae="#FFD24D",ve=t=>t<1?`${Math.round(t*100)}¢`:`$${t.toFixed(2)}`,Ct=t=>t>=1e8?`${(t/1e8).toFixed(8)} BSV`:`${t.toLocaleString()} sats`,Pt=t=>{const{request:s,onResponse:i,armed:o=!0}=t,{theme:r}=_(),{handleSelect:a,hideMenu:f}=V(),{addSnackbar:n}=J(),{chromeStorageService:p}=L(),u=p.getCurrentAccountObject().account,y=qe(u?.addresses?.identityAddress,u?.name??"",u?.settings?.socialProfile?.displayName??"",!1),h=ze(y.displayName,y.paymail,y.handle).tag,c=We(u?.pubKeys?.identityPubKey),g=d.useMemo(()=>jt(s),[s]),[w,l]=d.useState({}),m=d.useRef(s.items.length),x=Math.max(0,s.items.length-m.current),k=(j,P)=>w[j]??P,[v,N]=d.useState(),[E,R]=d.useState(ye),[$,G]=d.useState(!0),[U,Q]=d.useState(!0),b=d.useMemo(()=>Et(s),[s]),[S,A]=d.useState(!0),[T,H]=d.useState(!1),[B,Z]=d.useState(!1),[ce,pe]=d.useState("");d.useEffect(()=>{a("bsv"),f()},[a,f]),d.useEffect(()=>{M({action:"GET_BUNDLE_ALLOWANCE",originator:s.originator}).then(j=>{!j?.success||!j.data||(N(j.data),R(j.data.defaultUsd))}).catch(()=>{})},[s.originator]);const ee=!!v?.usdPerBsv&&v.existingSats===void 0,de=g.payment&&v?.usdPerBsv?g.payment.satoshis/1e8*v.usdPerBsv:void 0,ue=async j=>{Z(!0),pe("");try{if(j){const q=await z(p);if(!q.ok){pe(q.message),Z(!1);return}}const P={};for(const q of g.lines)P[q.requestID]=j&&k(q.requestID,q.checked);g.payment&&(P[g.payment.requestID]=j),await M({action:"BUNDLE_PERMISSION_RESPONSE",bundleID:s.bundleID,decisions:P,allowanceUsd:j&&ee&&$?E:0,remember:U,trustSite:j&&U&&b&&S}),i()}catch(P){n(P instanceof Error?P.message:String(P),"error"),Z(!1)}},Pe=g.mode==="pay"?"asks you to pay":"wants to connect",fe=g.lines.length+(g.payment?1:0)>1,De=g.mode==="pay"?"Pay":g.mode==="connectAndPay"?fe?"Allow all & pay":"Connect & pay":fe?"Allow all":"Connect",Ae=()=>{const j=re.indexOf(E),P=re[(j+1)%re.length];R(P),G(P>0)},te=B||!o,W=r.color.global.contrast,I=r.color.global.gray;return e.jsxs(C.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(ie,{size:18,style:{color:ae}})}),e.jsxs("p",{className:"text-sm leading-snug m-0",style:{color:I},children:[e.jsx("span",{className:"font-bold",style:{color:W},children:s.originator})," ",Pe]})]}),(h||c)&&e.jsxs("p",{className:"text-xs mb-3 m-0",style:{color:I},"data-testid":"signing-as",children:["Signing in as"," ",e.jsx("span",{className:"font-semibold",style:{color:W},children:h||"this account"}),c&&e.jsxs("span",{className:"font-mono select-none",style:{userSelect:"none"},children:[" ","· ",c]})]}),x>0&&e.jsxs("p",{className:"text-xs mb-2 m-0",style:{color:ae},children:["+",x," more added while this was open"]}),e.jsxs("div",{className:"w-full rounded-2xl px-3 py-1 mb-3",style:{background:r.color.global.row,border:"1px solid rgba(255,255,255,0.06)"},children:[g.lines.map(j=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:k(j.requestID,j.checked),onChange:()=>l(P=>({...P,[j.requestID]:!k(j.requestID,j.checked)})),className:"mt-0.5 accent-green-400"}),e.jsx("span",{className:"text-xs",style:{color:j.risky?be:W},children:j.text})]},j.requestID)),ee&&e.jsxs("div",{className:"flex items-start gap-3 py-2",children:[e.jsx("input",{type:"checkbox",checked:$&&E>0,onChange:()=>{E===0&&R(ye),G(!($&&E>0))},className:"mt-0.5 accent-green-400","aria-label":"Monthly allowance"}),e.jsx("span",{className:"text-xs flex-1",style:{color:W},children:E>0?`Spend up to ${ve(E)} a month without asking`:"Ask me before every payment"}),e.jsx("button",{type:"button",className:"text-xs border-0 bg-transparent p-0 underline",style:{color:I},onClick:Ae,children:"change"})]})]}),g.payment&&e.jsxs("div",{className:"w-full rounded-2xl px-3 py-2 mb-3",style:{background:"rgba(161,255,139,0.06)",border:"1px solid rgba(161,255,139,0.2)"},children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider m-0 pb-1",style:{color:I},children:"Pay now"}),e.jsxs("p",{className:"text-sm font-semibold m-0",style:{color:ae},children:[de!==void 0?ve(de):Ct(g.payment.satoshis)," ",e.jsxs("span",{className:"font-normal",style:{color:W},children:["to ",s.originator]})]}),g.payment.description&&e.jsxs("p",{className:"text-xs m-0 mt-0.5",style:{color:I},children:["“",g.payment.description,"”"]})]}),e.jsxs("label",{className:"flex items-center gap-2 mb-3 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:U,onChange:()=>Q(!U),className:"accent-green-400"}),e.jsx("span",{className:"text-xs",style:{color:I},children:"Remember this site"})]}),b&&U&&e.jsxs("label",{className:"flex items-start gap-2 mb-3 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:S,onChange:()=>A(!S),className:"mt-0.5 accent-green-400"}),e.jsxs("span",{className:"text-xs",style:{color:I},children:["Don't ask again on ",s.originator," for sign-in and signing. Payments stay within the allowance; your personal details always ask."]})]}),ce&&e.jsx("p",{className:"text-xs text-center m-0 mb-2",style:{color:be},children:ce}),e.jsxs("div",{className:"flex gap-3",children:[e.jsx("button",{type:"button",className:"flex-1 py-3 rounded-xl font-semibold text-sm",style:{background:"transparent",color:I,border:"1px solid rgba(255,255,255,0.1)"},disabled:te,onClick:()=>{ue(!1)},children:"Deny"}),e.jsxs("button",{type:"button",className:"flex-[2] py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, #FFD24D 0%, #EAB300 100%)",color:"#010101",opacity:te?.6:1},disabled:te,onClick:()=>{ue(!0)},children:[B&&e.jsx(X,{size:14,className:"animate-spin"}),De]})]}),e.jsxs("button",{type:"button",className:"flex items-center gap-1 mt-3 text-xs border-0 bg-transparent p-0",style:{color:I},onClick:()=>H(!T),children:[T?e.jsx(Ve,{size:12}):e.jsx(Ge,{size:12}),"Details"]}),T&&e.jsxs("ul",{className:"text-[11px] mt-1 pl-4 break-all",style:{color:I},children:[g.payment&&e.jsxs("li",{children:["pay: ",g.payment.detail]}),g.lines.map(j=>e.jsx("li",{children:j.detail},j.requestID)),ee&&$&&E>0&&e.jsxs("li",{children:["allowance: monthly spending cap for ",s.originator]})]})]})};ke.Buffer=we;ke.process=Re;window.Buffer=we;const Dt=1e4,At=2e3,O=new URLSearchParams(window.location.search).get("inpage"),Tt=window.location.protocol==="chrome-extension:"&&window.top!==window&&!O&&!!window.location.ancestorOrigins?.length&&window.location.ancestorOrigins[0]!==window.location.origin,Rt=(t,s)=>{const[i,o]=d.useState(t?void 0:!0),[r,a]=d.useState(!t),[f,n]=d.useState(!1);return d.useEffect(()=>{t&&M({action:"INPAGE_SHEET_CHECK",token:O}).then(p=>o(!!p?.success)).catch(()=>o(!1))},[t]),d.useEffect(()=>{if(!t||!s.current)return;let p;const u=new IntersectionObserver(y=>{const h=y[y.length-1];window.clearTimeout(p),h.isVisible&&h.intersectionRatio>=.99?p=window.setTimeout(()=>a(!0),500):a(!1)},{threshold:[0,.99,1],trackVisibility:!0,delay:100});return u.observe(s.current),()=>{window.clearTimeout(p),u.disconnect()}},[t,s]),d.useEffect(()=>{if(!t||r){n(!1);return}const p=window.setTimeout(()=>n(!0),1500);return()=>window.clearTimeout(p)},[t,r]),{tokenOk:i,armed:i===!0&&r,stuck:i===!0&&!r&&f}},It=()=>{const{theme:t}=_(),{isLocked:s,isReady:i}=L(),[o,r]=d.useState({kind:"loading"}),a=d.useRef(void 0),f=d.useRef(void 0),n=()=>{a.current!==void 0&&(window.clearTimeout(a.current),a.current=void 0)},p=d.useRef(o);p.current=o;const u=d.useCallback(async(m,x)=>{n();const k=p.current;if(m==="bundle"&&k.kind==="bundle"&&k.requestID===x){try{const N=await M({action:"GET_PROMPT_PAYLOAD",kind:m,requestID:x});N?.success&&N.data&&r({kind:"bundle",requestID:x,payload:N.data})}catch{}return}r({kind:"loading"});let v;try{v=await M({action:"GET_PROMPT_PAYLOAD",kind:m,requestID:x})}catch{v=void 0}v?.success&&v.data?r({kind:m,requestID:x,payload:v.data}):(r({kind:"expired"}),window.setTimeout(()=>{f.current?.()},At))},[]),y=d.useCallback(async()=>{n();let m;try{m=await M({action:"CLOSE_PROMPT_WINDOW"})}catch{m=void 0}if(m===void 0){window.close();return}const x=m.data?.prompt;x&&(x.kind==="unlock"?r({kind:"unlock"}):x.requestID&&await u(x.kind,x.requestID))},[u]),h=d.useCallback(async()=>{n();let m;try{m=await M({action:"GET_NEXT_PROMPT"})}catch{m=void 0}if(m?.data?.prompt){await u(m.data.prompt.kind,m.data.prompt.requestID);return}if(m?.data?.busy){r({kind:"waiting"}),a.current=window.setTimeout(()=>{y()},Dt);return}await y()},[u,y]);f.current=h,d.useEffect(()=>{if(!i)return;const m=new URLSearchParams(window.location.search),x=m.get("kind"),k=m.get("requestID");if(x==="unlock"){s?r({kind:"unlock"}):h();return}if(x&&k){u(x,k);return}h()},[i]),d.useEffect(()=>{const m=x=>{if(!(x?.action!=="SHOW_PROMPT"||!x.kind)){if(x.kind==="unlock"){n(),r({kind:"unlock"});return}x.requestID&&u(x.kind,x.requestID)}};return chrome.runtime.onMessage.addListener(m),()=>chrome.runtime.onMessage.removeListener(m)},[u]);const c=t.color.global.walletBackground,g=d.useRef(null),w=d.useRef(null),l=Rt(!!O,w);return Tt||l.tokenOk===!1?e.jsx("p",{className:"text-xs p-4",style:{color:"#98A2B3"},children:"Open bWalletX to answer this request."}):e.jsxs(Me,{children:[O&&e.jsxs("div",{className:"flex items-center justify-between px-3 py-2",style:{background:c,borderBottom:"1px solid #ffffff14"},children:[e.jsx("span",{className:"text-sm font-bold",style:{color:t.color.global.contrast},children:"bWalletX"}),l.stuck&&e.jsx("button",{type:"button",className:"text-xs font-bold border-0 rounded-full px-3 py-1",style:{background:"#F5C542",color:"#0b0a08"},onClick:()=>chrome.runtime.sendMessage({action:"MOVE_PROMPT_TO_WINDOW"}).catch(()=>{}),children:"Open in bWalletX"}),e.jsx("button",{type:"button","aria-label":"Deny and close",className:"text-sm border-0 bg-transparent p-1",style:{color:t.color.global.gray},onClick:()=>chrome.runtime.sendMessage({action:"DISMISS_PROMPT_PANEL"}).catch(()=>{}),children:"✕"})]}),e.jsxs("div",{ref:g,className:"flex items-center justify-center relative p-0",style:{width:O?"100%":"var(--wallet-width)",height:O?"calc(100vh - 41px)":"var(--wallet-height)",backgroundColor:c,pointerEvents:l.armed?void 0:"none"},children:[O&&e.jsx("div",{ref:w,"aria-hidden":!0,style:{position:"absolute",top:0,left:0,width:24,height:24,pointerEvents:"none"}}),(!i||o.kind==="loading")&&e.jsx(me,{message:"Loading...",theme:t}),o.kind==="waiting"&&e.jsx(me,{message:"Waiting for request...",theme:t}),o.kind==="expired"&&e.jsx("p",{className:"text-xs",style:{color:t.color.global.gray},children:"This request expired or was already handled."}),o.kind==="unlock"&&e.jsx(_e,{onUnlock:()=>{h()}}),o.kind==="permission"&&e.jsx(yt,{request:o.payload,onResponse:()=>{h()}},o.requestID),o.kind==="bundle"&&e.jsx(Pt,{request:o.payload,onResponse:()=>{h()}},o.requestID),o.kind==="groupedPermission"&&e.jsx(Xe,{request:o.payload,onResponse:()=>{h()}},o.requestID),o.kind==="counterpartyPermission"&&e.jsx(He,{request:o.payload,onResponse:()=>{h()}},o.requestID),o.kind==="oneSatPermission"&&e.jsx(mt,{request:o.payload,onResponse:()=>{h()}},o.requestID),o.kind==="usbCheck"&&e.jsx(bt,{request:o.payload,onResponse:()=>{h()}},o.requestID)]})]})},Ce=document.getElementById("root");if(!Ce)throw new Error("Root element");Te.createRoot(Ce).render(e.jsx(Be,{children:e.jsx(Fe,{children:e.jsx(Ue,{children:e.jsx(Oe,{children:e.jsx(It,{})})})})}));
//# sourceMappingURL=prompt-tab-DX-x19D9.js.map
