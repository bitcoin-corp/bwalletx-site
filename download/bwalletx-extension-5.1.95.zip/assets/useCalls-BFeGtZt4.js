import{r as s}from"./index-C2axhe3s.js";import{hF as r,hG as o}from"./main-D8P4DOmF.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-BFeGtZt4.js.map
