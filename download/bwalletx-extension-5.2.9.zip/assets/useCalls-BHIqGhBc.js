import{r as s}from"./index-6aYTlIpW.js";import{hy as r,hz as o}from"./main-sVKzVhAA.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-BHIqGhBc.js.map
