import{r as t}from"./index-t5CcWpUk.js";import{fetchPeopleTokens as l}from"./people-DBm3Bsz5.js";const f=()=>{const[s,o]=t.useState(null);return t.useEffect(()=>{let e=!0;return l().then(r=>e&&o(r)),()=>{e=!1}},[]),s};export{f as u};
//# sourceMappingURL=usePeopleTokens-KExsB437.js.map
