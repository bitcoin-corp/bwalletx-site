const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BSkOcDii.js","./index-nshoUh0Q.js","./crypto-CKYsQejp.js","./index-t5CcWpUk.js","./index-CArfLaxe.css","./index-BOBuLWQj.css"])))=>i.map(i=>d[i]);
import{av as e,a8 as t}from"./index-nshoUh0Q.js";import"./crypto-CKYsQejp.js";import"./index-t5CcWpUk.js";const m=e("Share",{web:()=>t(()=>import("./web-BSkOcDii.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{m as Share};
//# sourceMappingURL=index-D3FqG6_D.js.map
