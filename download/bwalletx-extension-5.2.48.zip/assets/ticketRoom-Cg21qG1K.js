import{b as a}from"./index-nshoUh0Q.js";import{cl as e}from"./main-jT1s7n_1.js";const r=(o,t)=>{e(`bsv21:${o}`),t(a("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-Cg21qG1K.js.map
