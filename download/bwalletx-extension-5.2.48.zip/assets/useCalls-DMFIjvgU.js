import{r as s}from"./index-t5CcWpUk.js";import{jI as r,cW as o}from"./index-nshoUh0Q.js";const u=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{u};
//# sourceMappingURL=useCalls-DMFIjvgU.js.map
