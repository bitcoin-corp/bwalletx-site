import{r as s}from"./index-BzS4xxnF.js";import{hG as r,hH as o}from"./main-W60nvWBq.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-CWDRcoHf.js.map
