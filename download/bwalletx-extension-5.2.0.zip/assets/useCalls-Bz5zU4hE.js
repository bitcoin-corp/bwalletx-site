import{r as s}from"./index-BzS4xxnF.js";import{hH as r,hI as o}from"./main-Dl1_rEF9.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-Bz5zU4hE.js.map
