const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-D7d0Jet7.js","./index-BswaqcRZ.js","./crypto-Cmuwf21b.js","./index-numRYSTi.js","./index-DU2cSw24.css","./extensionMedia-Rm_l9uoo.js","./index-C5QTh572.css"])))=>i.map(i=>d[i]);
import{ai as e,_ as t}from"./index-BswaqcRZ.js";import"./crypto-Cmuwf21b.js";import"./index-numRYSTi.js";import"./extensionMedia-Rm_l9uoo.js";const _=e("Share",{web:()=>t(()=>import("./web-D7d0Jet7.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-D_YrkzNA.js.map
