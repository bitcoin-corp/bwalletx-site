const r="bwallet:open-partner-request";let t=null;const s=(e,n)=>{t={ticker:e,id:n};try{window.dispatchEvent(new Event(r))}catch{}},a=()=>t!==null,o=e=>{if(!t||t.ticker!==e.toUpperCase())return;const{id:n}=t;return t=null,n};export{r as P,a as p,s as r,o as t};
//# sourceMappingURL=openRequest-CutiJDbs.js.map
