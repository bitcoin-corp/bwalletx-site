import{r as d,j as e,b as et}from"./index-numRYSTi.js";import{m as je,bq as Oe,br as Fe,bs as tt}from"./crypto-Cmuwf21b.js";import{j as H,k as q,r as A,bp as R,gV as V,gW as B,bq as st,U as ot,br as Re,B as z,gT as rt,gU as nt,gL as at,gM as it,gN as lt,P as Te,gR as ct}from"./index-BswaqcRZ.js";import{a as se,u as le,U as pt,n as Me,S as dt,f as ut,c as ft,i as xt,k as ht,C as P,o as ge,P as mt,p as gt,d as ne,q as yt,A as bt,r as vt,g as wt,e as Ie}from"./themeSites-uB_Vivc3.js";import{a as kt,s as jt}from"./approvalKind-BQjbcmk8.js";import"./extensionMedia-Rm_l9uoo.js";const Nt=t=>{const{request:s,onResponse:a}=t,{theme:o}=H(),{handleSelect:r,hideMenu:i}=se(),{addSnackbar:f}=le(),[n,c]=d.useState(!1),[u,b]=d.useState(""),{chromeStorageService:m}=q(),{permissions:l}=s,[g,j]=d.useState(()=>l.protocols.map(()=>!0));d.useEffect(()=>{r("bsv"),i()},[r,i]);const p=()=>{const w=l.protocols.filter((T,D)=>g[D]);return w.length===0?{}:{protocols:w}},h=async()=>{c(!0),b("");try{const w=await V(m);if(!w.ok){b(w.message),c(!1);return}B({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:p()}),a()}catch(w){f(w instanceof Error?w.message:String(w),"error"),c(!1)}},x=async()=>{c(!0),B({action:"COUNTERPARTY_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),a()},k=w=>j(T=>T.map((D,W)=>W===w?!D:D)),N=s.counterpartyLabel??`${s.counterparty.slice(0,8)}...${s.counterparty.slice(-8)}`;return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(pt,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Counterparty Permission"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","wants to interact with a counterparty"]})]})]}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all font-mono",style:{color:o.color.global.contrast},children:N})]}),e.jsx(R,{when:!!l.description,children:e.jsxs("div",{className:"flex flex-row py-2.5",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-24 flex-shrink-0",style:{color:o.color.global.gray},children:"Purpose"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:l.description})]})}),e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),l.protocols.map((w,T)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:T<l.protocols.length-1?"1px solid rgba(255,255,255,0.04)":"none"},children:[e.jsx("input",{type:"checkbox",checked:g[T],onChange:()=>k(T),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:[w.protocolID?.[1]," (level ",w.protocolID?.[0],")"]}),w.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:w.description})]})]},`proto-${T}`))]}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[u&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:u}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:n?.6:1},disabled:n,onClick:h,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[n&&e.jsx(je,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:n?.5:1},disabled:n,onClick:x,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},St={"2:3241645161d8":{label:"BRC-29 payment",description:"An application is requesting permission to derive payment addresses for a specific recipient."}},Le=t=>t?St[`${t[0]}:${t[1]}`]:void 0,_e=t=>Le(t)?.label??t?.[1],Ct=t=>{switch(t){case 0:return"Level 0 · any app";case 1:return"Level 1 · same keys for any app using this protocol";case 2:return"Level 2 · same keys for any app using this protocol with this recipient";default:return`Level ${t??0}`}},ze=t=>`${t[0]}:${t[1].trim().toLowerCase()}`,Pt=new Set([2532803679,1545534606,3968644154,2559579298,983045898,2744301556,111268922,3445661247,2334321181,4156441831,3583153857,2398265928,1065214202,2451633495,1587406450,3495424783,2196479044,3172368687,3977290595,2110695608,2486468533,3947228137,3114316294,3407865888,2095595255,927149303,1269930738,2919298931,2255687340].map(t=>t>>>0)),Et=[[2,"3241645161d8"]],At=t=>{let s=2166136261;for(const a of new TextEncoder().encode(ze(t)))s=Math.imul(s^a,16777619)>>>0;return s>>>0};new Set(Et.map(ze));const Rt=t=>Array.isArray(t)&&t.length===2&&typeof t[0]=="number"&&typeof t[1]=="string"?[t[0],t[1]]:null,De=t=>{const s=Rt(t);return!!s&&Pt.has(At(s))},Tt=t=>{const{request:s,onResponse:a}=t,{theme:o}=H(),{handleSelect:r,hideMenu:i}=se(),{addSnackbar:f}=le(),[n,c]=d.useState(!1),[u,b]=d.useState(""),{chromeStorageService:m}=q(),l=m.getCurrentAccountObject().account?.pubKeys?.identityPubKey??"",{permissions:g}=s,[j,p]=d.useState(()=>(g.protocolPermissions??[]).map(()=>!1)),[h,x]=d.useState(()=>(g.basketAccess??[]).map(()=>!0)),[k,N]=d.useState(()=>(g.certificateAccess??[]).map(()=>!0)),[w,T]=d.useState(!0);d.useEffect(()=>{r("bsv"),i()},[r,i]);const D=()=>{const v={},C=(g.protocolPermissions??[]).filter((O,F)=>j[F]&&!De(O.protocolID));C.length>0&&(v.protocolPermissions=C);const I=(g.basketAccess??[]).filter((O,F)=>h[F]);I.length>0&&(v.basketAccess=I);const $=(g.certificateAccess??[]).filter((O,F)=>k[F]);return $.length>0&&(v.certificateAccess=$),w&&g.spendingAuthorization&&(v.spendingAuthorization=g.spendingAuthorization),v},W=async()=>{c(!0),b("");try{const v=await V(m);if(!v.ok){b(v.message),c(!1);return}B({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:D()}),a()}catch(v){f(v instanceof Error?v.message:String(v),"error"),c(!1)}},U=async()=>{c(!0),B({action:"GROUPED_PERMISSION_RESPONSE",requestID:s.requestID,granted:null}),a()},ce=v=>p(C=>C.map((I,$)=>$===v?!I:I)),oe=v=>x(C=>C.map((I,$)=>$===v?!I:I)),G=v=>N(C=>C.map((I,$)=>$===v?!I:I));return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-3",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(Me,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:"Permission Request"}),e.jsxs("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:[e.jsx("span",{className:"font-semibold",style:{color:o.color.global.contrast},children:s.originator})," ","is requesting the following permissions"]})]})]}),e.jsx(dt,{site:ut(s.originator),account:l,style:{marginBottom:12}}),e.jsx(R,{when:!!g.description,children:e.jsx("p",{className:"text-xs mb-3 leading-relaxed",style:{color:o.color.global.gray},children:g.description})}),e.jsx(R,{when:!!g.spendingAuthorization,children:e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-3",style:{background:"rgba(247,144,9,0.08)",border:"1px solid rgba(247,144,9,0.2)"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.06},children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pb-1",style:{color:"#F79009"},children:"Spending Authorization"}),e.jsxs("label",{className:"flex items-start gap-3 py-1 cursor-pointer",children:[e.jsx("input",{type:"checkbox",checked:w,onChange:()=>T(!w),className:"mt-0.5 accent-orange-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-semibold",style:{color:"#F79009"},children:["This app wants to spend up to ",((g.spendingAuthorization?.amount??0)/1e8).toFixed(8)," BSV"," ","(",(g.spendingAuthorization?.amount??0).toLocaleString()," satoshis)"]}),g.spendingAuthorization?.description&&e.jsxs("span",{className:"text-xs mt-1 opacity-70",style:{color:o.color.global.contrast},children:["App says: “",g.spendingAuthorization.description,"”"]})]})]})]})}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-2 mb-5",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"16rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs(R,{when:!!g.protocolPermissions?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Protocols"}),g.protocolPermissions?.map((v,C)=>De(v.protocolID)?e.jsxs("p",{className:"text-xs py-2",style:{color:o.color.global.gray},children:["Refused: “",v.protocolID[1],"” is used only by bWalletX itself."]},`proto-${C}`):e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:j[C],onChange:()=>ce(C),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsxs("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:["Let this app sign and encrypt with your keys for “",_e(v.protocolID),"”",v.counterparty?` (shared with ${v.counterparty.slice(0,10)}…)`:""]}),e.jsxs("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:["Any app that asks for this protocol gets the same keys (level ",v.protocolID[0],")."]}),v.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:v.description})]})]},`proto-${C}`))]}),e.jsxs(R,{when:!!g.basketAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Baskets"}),g.basketAccess?.map((v,C)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:h[C],onChange:()=>oe(C),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:v.basket}),v.description&&e.jsx("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:v.description})]})]},`basket-${C}`))]}),e.jsxs(R,{when:!!g.certificateAccess?.length,children:[e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider pt-3 pb-1",style:{color:o.color.global.gray},children:"Certificates"}),g.certificateAccess?.map((v,C)=>e.jsxs("label",{className:"flex items-start gap-3 py-2 cursor-pointer",style:{borderBottom:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("input",{type:"checkbox",checked:k[C],onChange:()=>G(C),className:"mt-0.5 accent-green-400"}),e.jsxs("div",{className:"flex flex-col min-w-0",children:[e.jsx("span",{className:"text-xs font-medium",style:{color:o.color.global.contrast},children:v.type}),e.jsxs("span",{className:"text-xs mt-0.5 opacity-60",style:{color:o.color.global.contrast},children:[v.description," — fields: ",v.fields.join(", ")]})]})]},`cert-${C}`))]})]}),e.jsxs("div",{className:"flex flex-col gap-3",children:[u&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:u}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:n?.6:1},disabled:n,onClick:W,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[n&&e.jsx(je,{size:14,className:"animate-spin"}),"Allow Selected"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:n?.5:1},disabled:n,onClick:U,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny All"})]})]})},It=2e3;async function ie(t,s=It){let a;try{return await Promise.race([t.catch(()=>{}),new Promise(o=>{a=setTimeout(()=>o(void 0),s)})])}catch{return}finally{a&&clearTimeout(a)}}function Dt(t,s){return t?.find(a=>a.startsWith(`${s}:`))?.slice(s.length+1)}async function $t(t,s,a=[]){const o=t.ordfs;if(typeof o?.bulkMetadata!="function")return{state:"unverified"};const r=`${s}:-2`,i=await ie(o.bulkMetadata([r])),f=i?.[r]??i?.[s]??Object.values(i??{}).find(u=>!!u?.contentType);if(!f?.contentType)return{state:"unverified"};const n={contentType:f.contentType,origin:f.origin,name:typeof f.map?.name=="string"?f.map.name:void 0},c=a.find(u=>u.includes("/"));return c&&c!==f.contentType?{state:"mismatch",note:`Content type is ${f.contentType}, not ${c}`,...n}:{state:"verified",...n}}async function Bt(t,s,a){const o=t.opns;if(typeof o?.getOrigin!="function")return{state:"unverified"};const r=await ie(o.getOrigin(s));return r?.outpoint?r.outpoint!==a?{state:"mismatch",note:`“${s}” currently resolves to a different output`}:{state:"verified"}:{state:"unverified"}}async function Ut(t,s,a,o=[]){const r=t.bsv21;if(typeof r?.getTokenDetails!="function")return{state:"unverified"};const i=await ie(r.getTokenDetails(s,{fresh:!0}));if(!i)return{state:"unverified"};if(i.status?.is_active===!1)return{state:"mismatch",note:"Token is not active on the overlay"};const f=i.token?.sym;if(a&&f&&a.toLowerCase()!==f.toLowerCase())return{state:"mismatch",note:`Token symbol is ${f}, not ${a}`};if(o.length>0&&typeof r.getOutputStatus=="function"){const n=await ie(r.getOutputStatus(s,o));if(!n)return{state:"unverified"};const c=n.filter(u=>u.state==="spent"||u.state==="unknown");if(c.length>0)return{state:"mismatch",note:c.length===1?"A spent token output is not valid on the overlay":`${c.length} spent token outputs are not valid on the overlay`};if(n.some(u=>u.state==="queued"))return{state:"unverified"}}return{state:"verified",...f?{name:f}:{}}}async function Ot(t,s,a,o,r){if(!t||!s)return{state:"unverified"};const i=s==="purchase"||s.endsWith(".purchase"),f=s==="token-transfer"||s.startsWith("bsv21.");if(!i&&!f)return{state:"unverified"};const n={kindOrIntent:s,hasOrdfs:!!t.ordfs,hasBulk:typeof t.ordfs?.bulkMetadata=="function",inputTagSets:a.map(c=>c.tags),outputTagSets:o.map(c=>c.tags)};try{const c=[...a.map(p=>p.tags),...o.map(p=>p.tags)],u=p=>c.flatMap(h=>h.filter(x=>x.startsWith(`${p}:`)).map(x=>x.slice(p.length+1))),b=p=>{for(const h of c){const x=Dt(h,p);if(x)return x}},m=b("bsv21");if(m||s==="bsv21.purchase"||s==="token-transfer"||s.startsWith("bsv21.")){if(!m)return{state:"unverified"};const h=a.filter(k=>k.basket?.includes("bsv21")||k.tags.some(N=>N.startsWith("bsv21:"))).map(k=>k.outpoint).filter(Boolean);let x=b("sym");for(const k of a)if(k.customInstructions)try{const N=JSON.parse(k.customInstructions).sym;if(typeof N=="string"&&N.trim()){x=N.trim();break}}catch{}return await Ut(t,m,x,h)}const l=b("name"),g=b("origin");if(n.name=l,n.origin=g,l&&g&&o.some(p=>p.basket?.includes("opns"))||s==="opns.purchase")return!l||!g?{state:"unverified"}:await Bt(t,l,g);if(!g)return n.reason="no-origin-tag",globalThis.__lastVerify=n,{state:"unverified"};const j=await $t(t,g,u("type"));if(n.verifyOrdinal=j,j.origin&&r)try{j.contentUrl=r(j.origin)}catch(p){n.contentUrlError=String(p)}return globalThis.__lastVerify=n,j}catch(c){return n.error=String(c),globalThis.__lastVerify=n,{state:"unverified"}}}function qe(t){if(!t||typeof t!="object")return!1;const s=t;return Array.isArray(s.panels)&&typeof s.title=="string"}var Ft=`
.opp-root {
  --opp-bg: #ffffff;
  --opp-fg: #111827;
  --opp-muted: #6b7280;
  --opp-card-bg: #f7f8fa;
  --opp-card-border: #eceef2;
  --opp-accent: #E5A920;
  --opp-approve-bg: #E5A920;
  --opp-approve-fg: #ffffff;
  --opp-reject-bg: #ffffff;
  --opp-reject-fg: #111827;
  --opp-reject-border: #d1d5db;
  --opp-status-bg: #FFFBE6;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #ECFDF5;
  --opp-trust-ok-fg: #059669;
  --opp-trust-warn-bg: #FFFBEB;
  --opp-trust-warn-fg: #D97706;
  --opp-trust-bad-bg: #FEF2F2;
  --opp-trust-bad-fg: #DC2626;

  font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--opp-bg);
  color: var(--opp-fg);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 480px;
  min-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;
}

.opp-bottom {
  margin-top: auto;
  display: flex;
  flex-direction: column;
}

.opp-root.opp-dark {
  --opp-bg: #0F1117;
  --opp-fg: #F9FAFB;
  --opp-muted: #9ca3af;
  --opp-card-bg: #1A1D27;
  --opp-card-border: #232636;
  --opp-reject-bg: #0F1117;
  --opp-reject-fg: #F9FAFB;
  --opp-reject-border: #2D3142;
  --opp-status-bg: #2A2408;
  --opp-status-fg: #E5A920;
  --opp-trust-ok-bg: #0A2E1F;
  --opp-trust-ok-fg: #34D399;
  --opp-trust-warn-bg: #2A2008;
  --opp-trust-warn-fg: #FBBF24;
  --opp-trust-bad-bg: #2A1215;
  --opp-trust-bad-fg: #F87171;
}

.opp-body {
  padding: 24px 20px 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
}

.opp-coin {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
}

.opp-title {
  font-size: 16px;
  font-weight: 700;
  margin: 0;
  text-align: center;
}

.opp-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  margin: 0;
  text-align: center;
  line-height: 1.4;
}

.opp-status {
  background: var(--opp-status-bg);
  color: var(--opp-status-fg);
  padding: 4px 12px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
  margin-top: 4px;
  border: 1px solid var(--opp-card-border);
}

.opp-card {
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px;
  padding: 16px;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.opp-featured {
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--opp-card-bg);
  border: 1px solid var(--opp-card-border);
  border-radius: 10px;
  margin: 0 20px 8px;
  padding: 16px;
}

/* Subtle danger chrome for burn / destructive token ops */
.opp-featured-danger {
  border-color: rgba(220, 38, 38, 0.45);
  background: color-mix(in srgb, var(--opp-card-bg) 88%, #7f1d1d 12%);
}

.opp-featured-danger .opp-featured-title {
  color: #f87171;
}

.opp-featured-danger .opp-featured-image,
.opp-featured-danger .opp-featured-placeholder {
  border: 1px solid rgba(220, 38, 38, 0.35);
  background: rgba(127, 29, 29, 0.25);
  color: #fca5a5;
}

.opp-dark .opp-featured-danger {
  border-color: rgba(248, 113, 113, 0.4);
  background: color-mix(in srgb, var(--opp-card-bg) 85%, #450a0a 15%);
}

.opp-preview-pair {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.opp-preview-arrow {
  color: var(--opp-muted);
  font-size: 14px;
  line-height: 1;
}

.opp-preview-pair .opp-featured-image {
  width: 64px;
  height: 64px;
}

.opp-featured-image {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-featured-image-token {
  width: 48px;
  height: 48px;
  border-radius: 999px;
}

.opp-featured-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--opp-muted);
  font-size: 18px;
}

.opp-preview-opns {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
}

.opp-preview-opns-avatar {
  width: 36px;
  height: 36px;
  border-radius: 999px;
  object-fit: cover;
  background: rgba(0, 0, 0, 0.08);
  flex-shrink: 0;
}

.opp-preview-opns-name {
  font-size: 11px;
  font-weight: 600;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  color: var(--opp-fg, inherit);
}

.opp-preview-text {
  margin: 0;
  padding: 6px;
  box-sizing: border-box;
  overflow: hidden;
  font-size: 9px;
  line-height: 1.25;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  color: var(--opp-muted);
}

.opp-preview-json {
  white-space: pre;
  overflow: auto;
}

.opp-preview-frame {
  border: 0;
  padding: 0;
  overflow: hidden;
  background: #fff;
  pointer-events: none;
}

.opp-preview-value {
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  background: rgba(229, 169, 32, 0.12);
  border: 1px solid rgba(229, 169, 32, 0.35);
  color: var(--opp-fg, inherit);
}

.opp-preview-value-icon {
  width: 32px;
  height: 32px;
  color: #E5A920;
}

/* Amount subtitles must never ellipsis — full sat counts are the point. */
.opp-featured-subtitle-text.opp-amount {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-variant-numeric: tabular-nums;
  white-space: normal;
  overflow: visible;
  text-overflow: unset;
  word-break: keep-all;
}

.opp-featured-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  flex: 1;
}

.opp-featured-title {
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.opp-featured-subtitle {
  font-size: 12px;
  color: var(--opp-muted);
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.opp-featured-subtitle-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
}

.opp-featured-meta-line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  color: var(--opp-muted);
}

.opp-featured-meta-line-bare {
  align-items: center;
}

.opp-featured-meta-key {
  flex-shrink: 0;
  opacity: 0.75;
  min-width: 2.5em;
}

.opp-featured-meta-value {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
  flex: 1;
}

.opp-featured-meta-value-mono {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 11px;
}

.opp-trust-wrap {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0 20px 8px;
}

.opp-trust {
  display: inline-flex;
  align-self: flex-start;
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 600;
}

.opp-trust-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-trust-note {
  padding: 10px;
  border-radius: 8px;
  font-size: 11px;
  line-height: 1.35;
}

.opp-trust-note-verified {
  background: var(--opp-trust-ok-bg);
  color: var(--opp-trust-ok-fg);
}

.opp-trust-note-unverified {
  background: var(--opp-trust-warn-bg);
  color: var(--opp-trust-warn-fg);
}

.opp-trust-note-mismatch {
  background: var(--opp-trust-bad-bg);
  color: var(--opp-trust-bad-fg);
}

.opp-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.opp-row-key {
  color: var(--opp-muted);
  flex-shrink: 0;
}

.opp-row-value-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 70%;
  justify-content: flex-end;
}

.opp-row-value {
  font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, monospace;
  font-size: 12px;
  font-weight: 500;
  text-align: right;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.opp-copy {
  flex-shrink: 0;
  width: 22px;
  height: 22px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  border: 1px solid var(--opp-reject-border);
  background: var(--opp-bg);
  color: var(--opp-fg);
  cursor: pointer;
}

.opp-copy:hover {
  border-color: var(--opp-accent);
  color: var(--opp-accent);
}

.opp-fee-note {
  font-size: 11px;
  color: var(--opp-muted);
  line-height: 1.3;
  margin-top: -4px;
}

.opp-actions {
  display: flex;
  gap: 12px;
  padding: 20px 20px 12px;
}

.opp-button {
  flex: 1;
  padding: 0 16px;
  height: 48px;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid transparent;
  transition: opacity 120ms ease;
}

.opp-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.opp-button-reject {
  background: var(--opp-reject-bg);
  color: var(--opp-reject-fg);
  border-color: var(--opp-reject-border);
}

.opp-button-approve {
  background: var(--opp-approve-bg);
  color: var(--opp-approve-fg);
}

.opp-footer {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 20px 16px;
  font-size: 11px;
  font-weight: 500;
  color: var(--opp-muted);
}
`;function Mt({request:t,onApprove:s,onReject:a,theme:o="auto",services:r}){const i=Kt(o),f=Lt(t),[n,c]=d.useState(!1),[u,b]=d.useState(),m=t.kind==="transaction"&&qe(t.payload)?t.payload:void 0;d.useEffect(()=>{if(!r||!m?.trust||!m.verify)return;let p=!0;const h=r.ordfs?.getContentUrl?.bind(r.ordfs);return Ot(r,m.verify.kind,m.verify.inputs,m.verify.outputs,h).then(x=>{p&&x&&b(x)}).catch(()=>{}),()=>{p=!1}},[r,m]);const l=u?_t(f,u):f,g=p=>()=>{if(!n){c(!0);try{p==="approve"?s():a()}finally{c(!1)}}};d.useEffect(()=>{const p=h=>{n||(h.key==="Escape"?a():h.key==="Enter"&&s())};return window.addEventListener("keydown",p),()=>window.removeEventListener("keydown",p)},[s,a,n]);const j=`opp-root${i==="dark"?" opp-dark":""}`;return e.jsxs("div",{className:j,children:[e.jsx("style",{children:Ft}),e.jsxs("div",{className:"opp-body",children:[e.jsxs("svg",{className:"opp-coin",viewBox:"0 0 100 100","aria-label":"1Sat Ordinals",children:[e.jsx("circle",{cx:"50",cy:"50",r:"50",fill:"#222"}),e.jsx("circle",{cx:"50",cy:"50",r:"40",fill:"#fff"}),e.jsx("circle",{cx:"50",cy:"50",r:"32",fill:"#E5A920"}),e.jsx("rect",{x:"47",y:"28",width:"6",height:"28",rx:"3",fill:"#fff"})]}),e.jsx("h2",{className:"opp-title",children:l.title}),e.jsx("p",{className:"opp-subtitle",children:l.subtitle}),e.jsx("div",{className:"opp-status",children:"Awaiting Approval"})]}),l.panels.map((p,h)=>{const x=p.variant??"ordinal",k=["opp-featured"];return x==="token"&&k.push("opp-featured-token"),x==="value"&&k.push("opp-featured-value"),p.tone==="danger"&&k.push("opp-featured-danger"),e.jsxs("div",{className:k.join(" "),children:[p.prior?e.jsxs("div",{className:"opp-preview-pair","aria-label":"Previous and new inscription",children:[e.jsx(ye,{panel:{...p,previewKind:p.prior.previewKind,imageUrl:p.prior.imageUrl,contentUrl:p.prior.contentUrl,previewText:p.prior.previewText,prior:void 0}}),e.jsx("span",{className:"opp-preview-arrow","aria-hidden":!0,children:"→"}),e.jsx(ye,{panel:p})]}):e.jsx(ye,{panel:p}),e.jsxs("div",{className:"opp-featured-meta",children:[e.jsx("div",{className:"opp-featured-title",children:p.title}),p.subtitle&&e.jsxs("div",{className:"opp-featured-subtitle",children:[e.jsx("span",{className:p.amountSats!=null?"opp-featured-subtitle-text opp-amount":"opp-featured-subtitle-text",children:p.subtitle}),p.subtitleCopy&&e.jsx(be,{text:p.subtitleCopy})]}),(p.meta??[]).map(N=>e.jsxs("div",{className:`opp-featured-meta-line${N.key?"":" opp-featured-meta-line-bare"}`,children:[N.key?e.jsx("span",{className:"opp-featured-meta-key",children:N.key}):null,e.jsx("span",{className:`opp-featured-meta-value${N.key?"":" opp-featured-meta-value-mono"}`,title:N.copyValue??N.value,children:N.value}),N.copyValue&&e.jsx(be,{text:N.copyValue})]},`${N.key}:${N.value}`))]})]},`panel-${h}-${p.title}`)}),l.trust&&e.jsxs("div",{className:"opp-trust-wrap",children:[e.jsx("span",{className:`opp-trust opp-trust-${l.trust.state}`,children:Wt(l.trust.state)}),l.trust.note&&e.jsx("div",{className:`opp-trust-note opp-trust-note-${l.trust.state}`,children:l.trust.note})]}),(l.rows.length>0||l.indexerFee||l.funding)&&e.jsxs("div",{className:"opp-card",children:[l.rows.map(p=>e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:p.key}),e.jsxs("span",{className:"opp-row-value-wrap",children:[e.jsx("span",{className:"opp-row-value",title:p.copyValue??p.value,children:p.value}),p.copyValue&&e.jsx(be,{text:p.copyValue})]})]},`${p.key}:${p.value}`)),l.indexerFee&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"1Sat Overlay Fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[$e(l.indexerFee.sats)," sats"]})]}),l.funding?.networkFeeSats!=null&&e.jsxs("div",{className:"opp-row",children:[e.jsx("span",{className:"opp-row-key",children:"Network fee"}),e.jsxs("span",{className:"opp-row-value opp-amount",children:[$e(l.funding.networkFeeSats)," sats"]})]}),l.funding?.note&&e.jsx("div",{className:"opp-fee-note",children:l.funding.note})]}),e.jsxs("div",{className:"opp-bottom",children:[e.jsxs("div",{className:"opp-actions",children:[e.jsx("button",{type:"button",className:"opp-button opp-button-reject",onClick:g("reject"),disabled:n,children:"Reject"}),e.jsx("button",{type:"button",className:"opp-button opp-button-approve",onClick:g("approve"),disabled:n,children:"Approve"})]}),e.jsx("div",{className:"opp-footer",children:e.jsx("span",{children:"Secured by 1Sat Ordinals"})})]})]})}function Lt(t){if(t.kind==="transaction"&&qe(t.payload))return{title:t.payload.title,subtitle:t.payload.subtitle,panels:t.payload.panels,rows:t.payload.rows,trust:t.payload.trust,indexerFee:t.payload.indexerFee,funding:t.payload.funding};if(t.kind==="basketAccess"){const s=t.payload.baskets??[],a=s.length>0&&s.every(i=>i.scope||i.basket.startsWith("p ")),o=s.filter(i=>i.imageUrl||i.name||i.value).map(i=>({title:i.scope==="collection"?i.name?`Collection · ${i.name}`:"Collection":i.scope?i.scope:"Basket",subtitle:i.value?i.value.length>24?`${i.value.slice(0,10)}…${i.value.slice(-10)}`:i.value:i.basket,subtitleCopy:i.value,...i.imageUrl&&{previewKind:"image",contentUrl:i.imageUrl,imageUrl:i.imageUrl},tone:"default"})),r=s.flatMap(i=>i.scope==="collection"?i.description?[{key:"Access",value:i.description}]:[]:[{key:i.basket,value:i.description??"List, insert, and remove outputs"}]);return{title:a?s.length===1?s[0].scope==="collection"?"Grant Collection View":"Grant Item View":`Grant View (${s.length})`:s.length===1?"Grant Basket Access":`Grant Access to ${s.length} Baskets`,subtitle:a?`${ae(t.originator)} wants to view items in your wallet`:`${ae(t.originator)} wants to read and write 1Sat baskets`,panels:o,rows:r}}return t.kind==="protocol"?{title:"Protocol Access",subtitle:`${ae(t.originator)} wants protocol access`,panels:[],rows:[{key:"Detail",value:t.summary||"Protocol request"}]}:{title:"Signature Request",subtitle:`${ae(t.originator)} wants a signature`,panels:[],rows:[{key:"Detail",value:t.summary||"Signature request"}]}}function _t(t,s){const a=t.panels.map((o,r)=>{if(r!==0)return o;const i=o.previewKind==="opns",f=s.contentType?zt(s.contentType):void 0,n=i?"opns":f&&f!=="none"?f:o.previewKind,c=s.contentUrl??o.contentUrl??o.imageUrl;let u=o.subtitle;if(s.name&&!i)if(!u)u=s.name;else{const b=u.trim().split(/\s+/);b.length>=2&&(b[b.length-1]=s.name,u=b.join(" "))}return{...o,previewKind:n,...u?{subtitle:u}:{},...i?{...s.contentUrl&&!o.imageUrl?{imageUrl:s.contentUrl}:o.imageUrl?{imageUrl:o.imageUrl}:{}}:n==="image"?{imageUrl:c,contentUrl:c}:c?{contentUrl:c,imageUrl:void 0}:{}}});return{...t,panels:a,trust:{state:s.state,note:s.note}}}function zt(t){const s=t.toLowerCase();return s==="image/svg+xml"||s==="svg"||s.endsWith("+svg")?"svg":s.startsWith("image/")?"image":s.includes("json")?"json":s.includes("html")||s==="application/xhtml+xml"?"html":s.startsWith("text/")?"text":"none"}function qt(t){return`${t.toLocaleString("en-US")} sats`}function $e(t){return t.toLocaleString("en-US")}function Wt(t){return t==="verified"?"Verified":t==="mismatch"?"Mismatch":"Unverified"}function ye({panel:t}){const s=t.variant??"ordinal",a=s==="token"?"opp-featured-image opp-featured-image-token":s==="value"?"opp-featured-image opp-preview-value":"opp-featured-image",o=t.previewKind??(t.imageUrl?"image":"none"),r=t.contentUrl??t.imageUrl,[i,f]=d.useState(!1);if(s==="value"){const n=t.valueIcon??"pay";return e.jsx("div",{className:a,title:t.amountSats!=null?qt(t.amountSats):void 0,"aria-hidden":!0,children:e.jsx(Vt,{kind:n})})}if(o==="opns"){const n=!!t.imageUrl&&!i;return e.jsxs("div",{className:`${a} opp-preview-opns`,"aria-hidden":!t.opnsHero,children:[n?e.jsx("img",{className:"opp-preview-opns-avatar",src:t.imageUrl,alt:"",onError:()=>f(!0)}):e.jsx("div",{className:"opp-preview-opns-avatar opp-featured-placeholder",children:"◈"}),e.jsx("span",{className:"opp-preview-opns-name",title:t.opnsHero,children:t.opnsHero??"OpNS"})]})}return o==="image"&&t.imageUrl&&!i?e.jsx("img",{className:a,src:t.imageUrl,alt:t.title,onError:()=>f(!0)}):o==="image"&&i?e.jsx("div",{className:`${a} opp-featured-placeholder`,"aria-hidden":!0,children:"▭"}):(o==="text"||o==="json"||o==="html")&&t.previewText?e.jsx("pre",{className:`${a} opp-preview-text${o==="json"?" opp-preview-json":""}`,children:t.previewText}):(o==="text"||o==="json")&&r?e.jsx(Gt,{url:r,kind:o,className:a}):(o==="html"||o==="svg")&&r?e.jsx("iframe",{className:`${a} opp-preview-frame`,src:r,title:`${t.title} preview`,sandbox:"",referrerPolicy:"no-referrer"}):e.jsx("div",{className:`${a} opp-featured-placeholder`,"aria-hidden":!0,children:s==="token"?"◎":Ht(o)})}function Ht(t){return t==="text"||t==="json"?"¶":t==="html"||t==="svg"?"⌂":"▭"}function Vt({kind:t}){return t==="lock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V8a4 4 0 018 0v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):t==="unlock"?e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"5",y:"11",width:"14",height:"10",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M8 11V7.5A4 4 0 0116 7",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"}),e.jsx("path",{d:"M16 4.5v3",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]}):e.jsxs("svg",{className:"opp-preview-value-icon",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("circle",{cx:"12",cy:"12",r:"9",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M12 7v10M9 10.5c0-1.4 1.3-2.5 3-2.5s3 1.1 3 2.5-1.3 2.5-3 2.5-3 1.1-3 2.5 1.3 2.5 3 2.5 3-1.1 3-2.5",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})}function Gt({url:t,kind:s,className:a}){const[o,r]=d.useState(null),[i,f]=d.useState(!1);return d.useEffect(()=>{let n=!1;return r(null),f(!1),fetch(t).then(async c=>{if(!c.ok)throw new Error(String(c.status));const u=await c.text();if(!n){if(s==="json")try{r(JSON.stringify(JSON.parse(u),null,2));return}catch{}r(u.slice(0,800))}}).catch(()=>{n||f(!0)}),()=>{n=!0}},[t,s]),i?e.jsx("div",{className:`${a} opp-featured-placeholder`,"aria-hidden":!0,children:"¶"}):e.jsx("pre",{className:`${a} opp-preview-text${s==="json"?" opp-preview-json":""}`,children:o??"…"})}function be({text:t}){const[s,a]=d.useState(!1),o=()=>{navigator.clipboard?.writeText(t).then(()=>{a(!0),window.setTimeout(()=>a(!1),1200)})};return e.jsx("button",{type:"button",className:"opp-copy",onClick:o,"aria-label":s?"Copied":"Copy full value",title:s?"Copied":"Copy",children:s?e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:e.jsx("path",{d:"M5 13l4 4L19 7",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round"})}):e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none","aria-hidden":!0,children:[e.jsx("rect",{x:"9",y:"9",width:"11",height:"11",rx:"2",stroke:"currentColor",strokeWidth:"2"}),e.jsx("path",{d:"M5 15V5a2 2 0 012-2h10",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})]})})}function Kt(t){const[s,a]=d.useState(()=>t==="auto"?Yt():t);return d.useEffect(()=>{if(t!=="auto"){a(t);return}const o=window.matchMedia("(prefers-color-scheme: dark)"),r=()=>a(o.matches?"dark":"light");return r(),o.addEventListener("change",r),()=>o.removeEventListener("change",r)},[t]),s}function Yt(){return typeof window>"u"||!window.matchMedia?"light":window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function ae(t){try{return new URL(t.includes("://")?t:`https://${t}`).host||t}catch{return t.length<=32?t:`${t.slice(0,14)}…${t.slice(-12)}`}}const Xt=({request:t,onResponse:s})=>{const{theme:a}=H(),{handleSelect:o,hideMenu:r}=se(),{apiContext:i,chromeStorageService:f}=q(),n=i?.services;d.useEffect(()=>{o("bsv"),r()},[o,r]);const[c,u]=d.useState(""),b=d.useRef(!1),m=async j=>{if(!b.current){if(b.current=!0,j){u("");const p=await V(f);if(!p.ok){u(p.message),b.current=!1;return}}B({action:"ONE_SAT_PERMISSION_RESPONSE",requestID:t.requestID,approved:j}),s()}},g=a.color.global.walletBackground.toLowerCase()==="#000000"||/^#[01]/.test(a.color.global.walletBackground)?"dark":"light";return e.jsxs("div",{style:{width:"100%",height:"100%",overflowY:"auto",display:"flex",flexDirection:"column",alignItems:"stretch",justifyContent:"center"},children:[c&&e.jsx("p",{className:"text-xs text-center m-0 pt-2",style:{color:"#ef4444"},children:c}),e.jsx(Mt,{request:t.request,onApprove:()=>{m(!0)},onReject:()=>{m(!1)},theme:g,services:n})]})},Jt=t=>{switch(t){case"protocol":return"Protocol Permission";case"basket":return"Basket Access";case"certificate":return"Certificate Access";case"spending":return"Spending Authorization";default:return"Permission Request"}},Zt=t=>{switch(t.type){case"protocol":{const s=Le(t.protocolID);return s?s.description:`An application is requesting permission to use protocol "${t.protocolID?.[1]||"unknown"}" with security level ${t.protocolID?.[0]||0}.`}case"basket":return`An application is requesting access to basket "${t.basket||"unknown"}".`;case"certificate":return"An application is requesting access to certificate data.";case"spending":return`An application is requesting authorization to spend ${t.spending?.satoshis||0} satoshis.`;default:return"An application is requesting a permission."}},Be=t=>t>=1e8?`${(t/1e8).toFixed(8)} BSV`:`${t.toLocaleString()} satoshis`,Qt=t=>{const{request:s,onResponse:a}=t,{theme:o}=H(),{handleSelect:r,hideMenu:i}=se(),{addSnackbar:f}=le(),[n,c]=d.useState(!1),[u,b]=d.useState(""),{chromeStorageService:m}=q();d.useEffect(()=>{r("bsv"),i()},[r,i]);const l=async()=>{c(!0),b("");try{const j=await V(m);if(!j.ok){b(j.message),c(!1);return}B({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!0}),a()}catch(j){const p=j instanceof Error?j.message:String(j);f(p,"error"),c(!1)}},g=async()=>{c(!0),B({action:"PERMISSION_RESPONSE",requestID:s.requestID,granted:!1}),a()};return e.jsxs(A.div,{className:"flex flex-col w-full px-4 pt-5 pb-4 overflow-y-auto",style:{maxHeight:"100vh"},initial:{opacity:0,y:20,scale:.97},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",damping:24,stiffness:260},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:"rgba(161,255,139,0.12)"},children:e.jsx(Me,{size:18,style:{color:"var(--bw-accent-hi)"}})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-base font-bold leading-tight",style:{color:o.color.global.contrast},children:Jt(s.type)}),e.jsx("p",{className:"text-xs mt-0.5",style:{color:o.color.global.gray},children:Zt(s)})]})]}),e.jsxs(A.div,{className:"w-full rounded-2xl px-4 py-3 mb-4",style:{background:o.color.global.row,border:"1px solid rgba(255,255,255,0.06)",maxHeight:"12rem",overflowY:"auto"},initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:.08},children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Origin"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.displayOriginator||s.originator})]}),e.jsxs(R,{when:s.type==="protocol"&&!!s.protocolID,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Protocol"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:_e(s.protocolID)})]}),e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.counterparty?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Security"}),e.jsx("span",{className:"text-xs",style:{color:o.color.global.contrast},children:Ct(s.protocolID?.[0])})]}),e.jsx(R,{when:!!s.counterparty,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Counterparty"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.counterparty})]})})]}),e.jsx(R,{when:s.type==="basket"&&!!s.basket,children:e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Basket"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.basket})]})}),e.jsxs(R,{when:s.type==="certificate"&&!!s.certificate,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Cert Type"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.certType})]}),e.jsxs("div",{className:"flex flex-row py-2",children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Fields"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.certificate?.fields.join(", ")})]})]}),e.jsxs(R,{when:s.type==="spending"&&!!s.spending,children:[e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:s.spending?.lineItems?.length?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Amount"}),e.jsx("span",{className:"text-xs font-semibold",style:{color:"var(--bw-accent-hi)"},children:Be(s.spending?.satoshis||0)})]}),e.jsx(R,{when:!!s.spending?.lineItems?.length,children:s.spending?.lineItems?.map((j,p)=>e.jsxs("div",{className:"flex flex-row py-2",style:{borderBottom:p<(s.spending?.lineItems?.length??0)-1?"1px solid rgba(255,255,255,0.06)":"none"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:j.type}),e.jsxs("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:[j.description," (",Be(j.satoshis),")"]})]},p))})]}),e.jsx(R,{when:!!s.reason,children:e.jsxs("div",{className:"flex flex-row py-2",style:{borderTop:"1px solid rgba(255,255,255,0.06)"},children:[e.jsx("span",{className:"text-xs font-semibold w-20 flex-shrink-0",style:{color:o.color.global.gray},children:"Reason"}),e.jsx("span",{className:"text-xs break-all",style:{color:o.color.global.contrast},children:s.reason})]})})]}),e.jsx(R,{when:!!s.privileged,children:e.jsxs(A.div,{className:"flex items-start gap-2 rounded-xl px-3 py-2.5 mb-4",style:{background:"rgba(245,166,35,0.08)",border:"1px solid rgba(245,166,35,0.15)"},initial:{opacity:0},animate:{opacity:1},transition:{delay:.12},children:[e.jsx(st,{size:14,className:"mt-0.5 flex-shrink-0",style:{color:"#f5a623"}}),e.jsx("p",{className:"text-xs leading-relaxed",style:{color:"#f5a623"},children:"This is a privileged operation"})]})}),e.jsxs("div",{className:"flex flex-col gap-3 mt-auto",children:[u&&e.jsx("p",{className:"text-xs text-center m-0",style:{color:"#ef4444"},children:u}),e.jsxs(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2",style:{background:"linear-gradient(135deg, var(--bw-accent-hi) 0%, var(--bw-accent-lo) 100%)",color:"#010101",opacity:n?.6:1},disabled:n,onClick:l,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:[n&&e.jsx(je,{size:14,className:"animate-spin"}),"Allow"]}),e.jsx(A.button,{className:"w-full py-3.5 rounded-xl font-semibold text-sm",style:{background:"transparent",color:o.color.global.gray,border:"1px solid rgba(255,255,255,0.1)",opacity:n?.5:1},disabled:n,onClick:g,whileHover:{scale:n?1:1.02},whileTap:{scale:n?1:.97},transition:{type:"spring",damping:20,stiffness:400},children:"Deny"})]})]})},es=({request:t,onResponse:s})=>{const{theme:a}=H(),{chromeStorageService:o}=q(),[r,i]=d.useState(""),[f,n]=d.useState(!1),c=async m=>{if(!f){if(n(!0),i(""),m){const l=await V(o);if(!l.ok){i(l.message),n(!1);return}}B({action:"USB_CHECK_RESPONSE",requestID:t.requestID,ok:m}),s()}},u=a.color.global.gray,b=a.color.global.contrast;return e.jsxs("div",{className:"flex flex-col items-center justify-center w-full h-full px-6 text-center gap-3",children:[e.jsx(ot,{size:40,style:{color:b}}),e.jsx("h2",{className:"m-0 text-lg font-semibold",style:{color:b},children:"Confirm your USB key"}),e.jsxs("p",{className:"m-0 text-xs leading-relaxed",style:{color:u,maxWidth:"18rem"},children:[t.originator?`${t.originator} is asking bWallet to ${t.reason}.`:`A site is asking bWallet to ${t.reason}.`," ","Insert your USB key, then confirm."]}),r&&e.jsx("p",{className:"m-0 text-xs",style:{color:"#ef4444"},children:r}),e.jsxs("div",{className:"flex flex-col gap-2 w-full mt-2",style:{maxWidth:"18rem"},children:[e.jsx(Re,{theme:a,type:"primary",label:"Confirm USB key",disabled:f,onClick:()=>{c(!0)}}),e.jsx(Re,{theme:a,type:"secondary-outline",label:"Cancel",disabled:f,onClick:()=>{c(!1)}})]})]})},Ue=5,ve=[0,1,5,20],ts=/e-?mail|phone|mobile|kyc|passport|licen[cs]e|birth|dob|address|ssn|national|tax|id_?number/i,ke=t=>String(t.protocolID?.[1]??"unknown"),We=t=>Number(t.protocolID?.[0]??0),He=t=>!!(t.privileged||t.type==="certificate"&&(t.certificate?.fields??[]).some(s=>ts.test(s))),Ve=t=>t.type==="protocol"&&!t.privileged&&t.protocolID?.[1]==="identity key retrieval"&&(t.counterparty===void 0||t.counterparty==="self"),ss=t=>{switch(t.type){case"protocol":return Ve(t)?"See your public identity (the key that names you)":t.counterparty==="anyone"?"Prove it's you (a signature anyone can check)":We(t)===2&&t.counterparty&&t.counterparty!=="self"?`Sign and encrypt with your "${ke(t)}" keys, shared with one named person or service`:`Sign and encrypt anything with your "${ke(t)}" keys`;case"basket":return"Keep its tickets and tokens in your wallet";case"certificate":{const s=t.certificate?.fields??[];return s.length?`See your certificate details (${s.join(", ")})`:"See your certificates"}default:return"Spend from your wallet"}},we=t=>{const s=[];switch(t.type){case"protocol":s.push(`protocol "${ke(t)}" level ${We(t)}`),t.counterparty&&s.push(`counterparty ${t.counterparty}`);break;case"basket":s.push(`basket "${t.basket??""}"`);break;case"certificate":s.push(`certificate ${t.certificate?.certType??""}`,`verifier ${t.certificate?.verifier??""}`);break;case"spending":s.push(`${t.spending?.satoshis??0} sats`);break}return t.privileged&&s.push("privileged"),t.reason&&s.push(`reason: ${t.reason}`),s.join(" · ")},os=t=>{const s=[];let a;for(const r of t.items){if(r.type==="spending"){const n=r.spending?.satoshis??0;a?s.push({requestID:r.requestID,text:`Also pay ${n.toLocaleString()} sats`,detail:we(r),risky:!0,checked:!1}):a={requestID:r.requestID,satoshis:n,description:r.spending?.lineItems?.find(c=>c.description)?.description??r.reason,detail:we(r)};continue}const i=He(r),f=!i&&(r.type!=="protocol"||r.counterparty==="anyone"||Ve(r));s.push({requestID:r.requestID,text:ss(r),detail:we(r),risky:i,checked:f})}const o=a?s.length?"connectAndPay":"pay":"connect";return{originator:t.originator,lines:s,payment:a,mode:o}},rs="bwalletx.trust-site",ns=t=>He(t)||t.type==="protocol"&&t.counterparty==="anyone"?!1:t.type==="basket"?!!t.basket&&t.basket!==rs:!1,as=t=>t.items.some(s=>ns(s)),te=t=>t<1?`${Math.round(t*100)}¢`:`$${t.toFixed(2)}`,is=t=>t>=1e8?`${(t/1e8).toFixed(8)} BSV`:`${t.toLocaleString()} sats`,ls=t=>{const{request:s,onResponse:a,armed:o=!0}=t,{handleSelect:r,hideMenu:i}=se(),{addSnackbar:f}=le(),{chromeStorageService:n}=q(),c=n.getCurrentAccountObject().account,u=ft(c?.addresses?.identityAddress,c?.name??"",c?.settings?.socialProfile?.displayName??"",!1),b=xt(u.displayName,u.paymail,u.handle).tag,m=ht(c?.pubKeys?.identityPubKey),l=d.useMemo(()=>os(s),[s]),[g,j]=d.useState({}),p=d.useRef(s.items.length),h=Math.max(0,s.items.length-p.current),x=(y,S)=>g[y]??S,[k,N]=d.useState(),[w,T]=d.useState(Ue),[D,W]=d.useState(!0),[U,ce]=d.useState(!0),oe=d.useMemo(()=>as(s),[s]),[G,v]=d.useState(!0),[C,I]=d.useState(!1),[$,O]=d.useState(!1),[F,Se]=d.useState("");d.useEffect(()=>{r("bsv"),i()},[r,i]),d.useEffect(()=>{z({action:"GET_BUNDLE_ALLOWANCE",originator:s.originator}).then(y=>{!y?.success||!y.data||(N(y.data),T(y.data.defaultUsd))}).catch(()=>{})},[s.originator]);const pe=!!k?.usdPerBsv&&k.existingSats===void 0,de=l.payment&&k?.usdPerBsv?l.payment.satoshis/1e8*k.usdPerBsv:void 0,ue=async y=>{O(!0),Se("");try{if(y){const E=await V(n);if(!E.ok){Se(E.message),O(!1);return}}const S={};for(const E of l.lines)S[E.requestID]=y&&x(E.requestID,E.checked);l.payment&&(S[l.payment.requestID]=y),await z({action:"BUNDLE_PERMISSION_RESPONSE",bundleID:s.bundleID,decisions:S,allowanceUsd:y&&pe&&D?w:0,remember:U,trustSite:y&&U&&oe&&G}),a()}catch(S){f(S instanceof Error?S.message:String(S),"error"),O(!1)}},M=kt(l,{existingAllowanceSats:k?.existingSats}),fe=jt(s.originator),Ke=l.lines.length+(l.payment?1:0)>1,K=de!==void 0?te(de):l.payment?is(l.payment.satoshis):"",Y=pe&&D&&w>0?w:0,Ce=k?.existingSats!==void 0&&k.usdPerBsv?k.existingSats/1e8*k.usdPerBsv:void 0,Ye=M==="signin"?"Sign in":M==="pay"?l.mode==="connectAndPay"?`Connect & pay ${K}`:`Pay ${K}`:Ke?"Allow all":"Connect",Xe=()=>{const y=ve.indexOf(w),S=ve[(y+1)%ve.length];T(S),W(S>0)},xe=$||!o,X=M==="careful",re=l.lines.filter(y=>y.risky),Je=(y,S)=>j(E=>({...E,[y]:!x(y,S)})),Pe=(y,S=!1)=>e.jsxs("label",{className:"flex items-center gap-3 cursor-pointer",style:{minHeight:44,padding:S?"10px 14px":"6px 0",borderRadius:S?14:0,background:S?P.redChip:void 0,fontSize:S?14:13},children:[e.jsx("input",{type:"checkbox",checked:x(y.requestID,y.checked),onChange:()=>Je(y.requestID,y.checked),style:{width:18,height:18,accentColor:y.risky?P.red:P.gold,flexShrink:0}}),e.jsx("span",{style:{color:y.risky?"#FF6B6B":void 0},children:y.text})]},y.requestID),he=(b||m)&&e.jsxs("span",{children:[e.jsx("span",{style:{color:P.gold},children:b||"this account"}),m&&e.jsxs("span",{className:"font-mono",style:{userSelect:"none",fontSize:12,color:P.muted},children:[" ","· ",m]})]}),Ze=e.jsxs("div",{className:"flex flex-col",style:{gap:4},children:[(b||m)&&e.jsxs("p",{className:"m-0","data-testid":"signing-as",style:{fontSize:12},children:["Signing in as ",he]}),h>0&&e.jsxs("p",{className:"m-0",style:{fontSize:12,color:P.green},children:["+",h," more added while this was open"]}),l.lines.map(y=>Pe(y)),l.payment&&e.jsxs("p",{className:"m-0",style:{padding:"6px 0"},children:["Pay now: ",e.jsx("span",{style:{color:P.gold,fontWeight:600},children:K})," to ",s.originator,l.payment.description&&e.jsxs(e.Fragment,{children:[" “",l.payment.description,"”"]})]}),pe&&e.jsxs("div",{className:"flex items-center gap-3",style:{minHeight:44},children:[e.jsx("input",{type:"checkbox",checked:D&&w>0,onChange:()=>{w===0&&T(Ue),W(!(D&&w>0))},style:{width:18,height:18,accentColor:P.gold,flexShrink:0},"aria-label":"Monthly allowance"}),e.jsx("span",{className:"flex-1",children:w>0?`Spend up to ${te(w)} a month without asking`:"Ask me before every payment"}),e.jsx("button",{type:"button",className:"border-0 bg-transparent underline",style:{color:P.gold,minHeight:44,padding:"0 4px",fontSize:13},onClick:Xe,children:"change"})]}),e.jsxs("label",{className:"flex items-center gap-3 cursor-pointer",style:{minHeight:44},children:[e.jsx("input",{type:"checkbox",checked:U,onChange:()=>ce(!U),style:{width:18,height:18,accentColor:P.gold,flexShrink:0}}),e.jsx("span",{children:"Remember this site"})]}),oe&&U&&e.jsxs("label",{className:"flex items-start gap-3 cursor-pointer",style:{padding:"6px 0"},children:[e.jsx("input",{type:"checkbox",checked:G,onChange:()=>v(!G),style:{width:18,height:18,accentColor:P.gold,flexShrink:0,marginTop:1}}),e.jsxs("span",{children:["Don't ask again on ",s.originator," for sign-in and signing. Payments stay within the allowance; your personal details always ask."]})]}),e.jsxs("ul",{className:"m-0 mt-1 pl-4 break-all",style:{fontSize:11,color:P.muted},children:[l.payment&&e.jsxs("li",{children:["pay: ",l.payment.detail]}),l.lines.map(y=>e.jsx("li",{children:y.detail},y.requestID)),Y>0&&e.jsxs("li",{children:["allowance: monthly spending cap for ",s.originator]})]})]}),Ee={label:X?"No, block it":"Not now",onClick:()=>{ue(!1)},disabled:xe},Ae={label:X?"I trust it, allow":Ye,onClick:()=>{ue(!0)},disabled:xe,busy:$};let J,Z,Q=null,ee;const me=y=>e.jsx("span",{style:{color:P.gold},children:y});if(M==="careful"){J=e.jsx(vt,{}),ee="Check this carefully";const y=s.items.some(L=>L.privileged),S=re.some(L=>s.items.find(Qe=>Qe.requestID===L.requestID)?.type==="certificate"),E=L=>e.jsx("span",{style:{color:"#FF6B6B"},children:L});Z=y?e.jsxs(e.Fragment,{children:["Wants ",E("full control")," of your keys"]}):S?e.jsxs(e.Fragment,{children:["Wants your ",E("private details")]}):l.payment&&re.length===0?e.jsxs(e.Fragment,{children:[E(K)," is over your allowance"]}):e.jsxs(e.Fragment,{children:["Wants ",E("more than usual")]}),Q=e.jsxs("div",{className:"flex flex-col",style:{gap:8},children:[y&&e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:P.redChip,fontSize:14},children:[e.jsx(ge,{}),"Could move your money"]}),re.length===0&&l.payment&&e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:P.redChip,fontSize:14},children:[e.jsx(ge,{}),Ce!==void 0?`Your allowance here is ${te(Ce)} a month`:"More than this site may spend"]}),re.map(L=>Pe(L,!0)),e.jsxs("div",{className:"flex items-center gap-2.5",style:{padding:"12px 14px",borderRadius:14,background:P.redChip,fontSize:14},children:[e.jsx(ge,{}),"Only allow apps you trust"]})]})}else if(M==="pay")J=e.jsx(mt,{amount:K,sub:de!==void 0&&l.payment?`${l.payment.satoshis.toLocaleString()} sats`:void 0}),ee=l.payment?.description||"Asks you to pay",Z=e.jsxs(e.Fragment,{children:["Pay ",me(fe)]}),Q=e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex items-center gap-3",style:{padding:14,borderRadius:16,background:P.chip},children:[e.jsx(gt,{site:s.originator,size:44}),e.jsxs("div",{className:"flex flex-col min-w-0",style:{gap:2,lineHeight:1.25},children:[e.jsxs("span",{className:"truncate",style:{fontSize:15,fontWeight:600},children:["To ",s.originator]}),e.jsx("span",{className:"truncate",style:{fontSize:13,color:P.muted},children:l.payment?.description?`“${l.payment.description}”`:"Straight from your wallet"})]})]}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:P.soft},children:[e.jsx(ne,{size:18}),Y>0?`Then up to ${te(Y)} a month without asking`:"Every payment asks you first"]})]});else if(M==="signin")J=e.jsx(wt,{}),ee="Sign-in request",Z=e.jsxs(e.Fragment,{children:["Sign in to ",me(fe)]}),Q=e.jsxs(e.Fragment,{children:[he&&e.jsxs("div",{className:"flex items-center gap-2.5",children:[e.jsx("div",{"aria-hidden":"true",style:{width:30,height:30,borderRadius:15,background:"conic-gradient(#F5C542, #B8860B, #FFE08A, #F5C542)",flexShrink:0}}),e.jsxs("span",{style:{fontSize:18,fontWeight:600},children:["as ",he]})]}),e.jsxs("div",{className:"flex flex-wrap",style:{gap:8,marginTop:4},children:[e.jsxs(Ie,{children:[e.jsx(ne,{}),"No password"]}),e.jsxs(Ie,{children:[e.jsx(ne,{}),"No money moves"]})]})]});else{J=e.jsx(yt,{site:s.originator}),ee="Wants to connect",Z=e.jsxs(e.Fragment,{children:["Use ",me("bWalletX")," on ",fe]});const y=new Set(s.items.map(E=>E.type)),S=[{label:y.has("certificate")?"Your details":"Your name",icon:e.jsx(cs,{})}];y.has("protocol")&&S.push({label:"Sign posts",icon:e.jsx(ps,{})}),y.has("basket")&&S.push({label:"Keep items",icon:e.jsx(ds,{})}),Q=e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"grid",style:{gridTemplateColumns:`repeat(${S.length}, minmax(0, 1fr))`,gap:8},children:S.map(E=>e.jsxs("div",{className:"flex flex-col items-center",style:{gap:8,padding:"14px 6px",borderRadius:16,background:P.chip},children:[E.icon,e.jsx("span",{style:{fontSize:13,fontWeight:600,textAlign:"center"},children:E.label})]},E.label))}),e.jsxs("div",{className:"flex items-center gap-2",style:{fontSize:14,color:P.soft},children:[e.jsx(ne,{size:18}),Y>0?`Payments over ${te(Y)} a month ask you first`:"Payments still ask you first"]})]})}return e.jsx(A.div,{className:"flex flex-col w-full h-full",style:{maxHeight:"100vh"},initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{type:"spring",damping:24,stiffness:260},"data-approval-kind":M,children:e.jsx(bt,{tone:X?"red":"gold",site:s.originator,siteSub:ee,onClose:()=>{ue(!1)},closeLabel:"Deny and close",closeDisabled:xe,hero:J,title:Z,primary:X?Ee:Ae,secondary:X?Ae:Ee,details:Ze,detailsOpen:C,onToggleDetails:()=>I(!C),error:F,children:Q})})},Ne={"aria-hidden":!0,width:28,height:28,viewBox:"0 0 24 24",fill:"none",stroke:P.gold,strokeWidth:1.8,strokeLinecap:"round",strokeLinejoin:"round"},cs=()=>e.jsxs("svg",{...Ne,children:[e.jsx("circle",{cx:"12",cy:"8",r:"4"}),e.jsx("path",{d:"M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"})]}),ps=()=>e.jsxs("svg",{...Ne,children:[e.jsx("path",{d:"M12 20h9"}),e.jsx("path",{d:"M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"})]}),ds=()=>e.jsxs("svg",{...Ne,children:[e.jsx("rect",{x:"3",y:"7",width:"18",height:"13",rx:"2"}),e.jsx("path",{d:"M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"})]});Fe.Buffer=Oe;Fe.process=tt;window.Buffer=Oe;const us=1e4,fs=2e3,_=new URLSearchParams(window.location.search).get("inpage"),xs=window.location.protocol==="chrome-extension:"&&window.top!==window&&!_&&!!window.location.ancestorOrigins?.length&&window.location.ancestorOrigins[0]!==window.location.origin,hs=(t,s)=>{const[a,o]=d.useState(t?void 0:!0),[r,i]=d.useState(!t),[f,n]=d.useState(!1);return d.useEffect(()=>{t&&z({action:"INPAGE_SHEET_CHECK",token:_}).then(c=>o(!!c?.success)).catch(()=>o(!1))},[t]),d.useEffect(()=>{if(!t||!s.current)return;let c;const u=new IntersectionObserver(b=>{const m=b[b.length-1];window.clearTimeout(c),m.isVisible&&m.intersectionRatio>=.99?c=window.setTimeout(()=>i(!0),500):i(!1)},{threshold:[0,.99,1],trackVisibility:!0,delay:100});return u.observe(s.current),()=>{window.clearTimeout(c),u.disconnect()}},[t,s]),d.useEffect(()=>{if(!t||r){n(!1);return}const c=window.setTimeout(()=>n(!0),1500);return()=>window.clearTimeout(c)},[t,r]),{tokenOk:a,armed:a===!0&&r,stuck:a===!0&&!r&&f}},ms=()=>{const{theme:t}=H(),{isLocked:s,isReady:a}=q(),[o,r]=d.useState({kind:"loading"}),i=d.useRef(void 0),f=d.useRef(void 0),n=()=>{i.current!==void 0&&(window.clearTimeout(i.current),i.current=void 0)},c=d.useRef(o);c.current=o;const u=d.useCallback(async(h,x)=>{n();const k=c.current;if(h==="bundle"&&k.kind==="bundle"&&k.requestID===x){try{const w=await z({action:"GET_PROMPT_PAYLOAD",kind:h,requestID:x});w?.success&&w.data&&r({kind:"bundle",requestID:x,payload:w.data})}catch{}return}r({kind:"loading"});let N;try{N=await z({action:"GET_PROMPT_PAYLOAD",kind:h,requestID:x})}catch{N=void 0}N?.success&&N.data?r({kind:h,requestID:x,payload:N.data}):(r({kind:"expired"}),window.setTimeout(()=>{f.current?.()},fs))},[]),b=d.useCallback(async()=>{n();let h;try{h=await z({action:"CLOSE_PROMPT_WINDOW"})}catch{h=void 0}if(h===void 0){window.close();return}const x=h.data?.prompt;x&&(x.kind==="unlock"?r({kind:"unlock"}):x.requestID&&await u(x.kind,x.requestID))},[u]),m=d.useCallback(async()=>{n();let h;try{h=await z({action:"GET_NEXT_PROMPT"})}catch{h=void 0}if(h?.data?.prompt){await u(h.data.prompt.kind,h.data.prompt.requestID);return}if(h?.data?.busy){r({kind:"waiting"}),i.current=window.setTimeout(()=>{b()},us);return}await b()},[u,b]);f.current=m,d.useEffect(()=>{if(!a)return;const h=new URLSearchParams(window.location.search),x=h.get("kind"),k=h.get("requestID");if(x==="unlock"){s?r({kind:"unlock"}):m();return}if(x&&k){u(x,k);return}m()},[a]),d.useEffect(()=>{const h=x=>{if(!(x?.action!=="SHOW_PROMPT"||!x.kind)){if(x.kind==="unlock"){n(),r({kind:"unlock"});return}x.requestID&&u(x.kind,x.requestID)}};return chrome.runtime.onMessage.addListener(h),()=>chrome.runtime.onMessage.removeListener(h)},[u]);const l=t.color.global.walletBackground,g=d.useRef(null),j=d.useRef(null),p=hs(!!_,j);return xs||p.tokenOk===!1?e.jsx("p",{className:"text-xs p-4",style:{color:"#98A2B3"},children:"Open bWalletX to answer this request."}):e.jsxs(lt,{children:[_&&e.jsxs("div",{className:"flex items-center justify-between px-3 py-2",style:{background:l,borderBottom:"1px solid #ffffff14"},children:[e.jsx("span",{className:"text-sm font-bold",style:{color:t.color.global.contrast},children:"bWalletX"}),p.stuck&&e.jsx("button",{type:"button",className:"text-xs font-bold border-0 rounded-full px-3 py-1",style:{background:"#F5C542",color:"#0b0a08"},onClick:()=>chrome.runtime.sendMessage({action:"MOVE_PROMPT_TO_WINDOW"}).catch(()=>{}),children:"Open in bWalletX"}),e.jsx("button",{type:"button","aria-label":"Deny and close",className:"text-sm border-0 bg-transparent p-1",style:{color:t.color.global.gray},onClick:()=>chrome.runtime.sendMessage({action:"DISMISS_PROMPT_PANEL"}).catch(()=>{}),children:"✕"})]}),e.jsxs("div",{ref:g,className:"flex items-center justify-center relative p-0",style:{width:_?"100%":"var(--wallet-width)",height:_?"calc(100vh - 41px)":"var(--wallet-height)",backgroundColor:l,pointerEvents:p.armed?void 0:"none"},children:[_&&e.jsx("div",{ref:j,"aria-hidden":!0,style:{position:"absolute",top:0,left:0,width:24,height:24,pointerEvents:"none"}}),(!a||o.kind==="loading")&&e.jsx(Te,{message:"Loading...",theme:t}),o.kind==="waiting"&&e.jsx(Te,{message:"Waiting for request...",theme:t}),o.kind==="expired"&&e.jsx("p",{className:"text-xs",style:{color:t.color.global.gray},children:"This request expired or was already handled."}),o.kind==="unlock"&&e.jsx(ct,{onUnlock:()=>{m()}}),o.kind==="permission"&&e.jsx(Qt,{request:o.payload,onResponse:()=>{m()}},o.requestID),o.kind==="bundle"&&e.jsx(ls,{request:o.payload,onResponse:()=>{m()}},o.requestID),o.kind==="groupedPermission"&&e.jsx(Tt,{request:o.payload,onResponse:()=>{m()}},o.requestID),o.kind==="counterpartyPermission"&&e.jsx(Nt,{request:o.payload,onResponse:()=>{m()}},o.requestID),o.kind==="oneSatPermission"&&e.jsx(Xt,{request:o.payload,onResponse:()=>{m()}},o.requestID),o.kind==="usbCheck"&&e.jsx(es,{request:o.payload,onResponse:()=>{m()}},o.requestID)]})]})},Ge=document.getElementById("root");if(!Ge)throw new Error("Root element");et.createRoot(Ge).render(e.jsx(rt,{children:e.jsx(nt,{children:e.jsx(at,{children:e.jsx(it,{children:e.jsx(ms,{})})})})}));
//# sourceMappingURL=prompt-tab-DBY9k0j7.js.map
