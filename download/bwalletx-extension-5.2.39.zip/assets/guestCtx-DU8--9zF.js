import{r as t}from"./index-numRYSTi.js";const e=t.createContext(null);export{e as G};
//# sourceMappingURL=guestCtx-DU8--9zF.js.map
