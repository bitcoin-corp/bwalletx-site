import{r as s}from"./index-numRYSTi.js";import{jv as r,aU as a}from"./index-BswaqcRZ.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-Ch7VA_cO.js.map
