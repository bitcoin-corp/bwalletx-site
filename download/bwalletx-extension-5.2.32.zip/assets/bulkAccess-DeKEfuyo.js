import{gx as e}from"./main-PKTUetbC.js";import{bF as i,b8 as l}from"./index-SUiut1Lp.js";const n=["b0asex"],r=(a,o=n)=>{const[s,t]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!s||!o.includes(s)?!1:!t||t===l.toLowerCase()},A=(a,o=!1)=>o||e(a)||r(i(a??void 0));export{A as c};
//# sourceMappingURL=bulkAccess-DeKEfuyo.js.map
