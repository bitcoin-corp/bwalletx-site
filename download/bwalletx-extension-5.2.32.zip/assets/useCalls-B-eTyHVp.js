import{r as s}from"./index-BCfd9xtL.js";import{iI as r,aS as a}from"./index-SUiut1Lp.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-B-eTyHVp.js.map
