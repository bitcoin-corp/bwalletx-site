import{c as o}from"./crypto-u1BT7_E5.js";const e=[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]],c=o("arrow-down",e);export{c as A};
//# sourceMappingURL=arrow-down-NDumBA7F.js.map
