import{r as s}from"./index-6aYTlIpW.js";import{hx as r,hy as o}from"./main-CBddH12J.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-CN9wdIED.js.map
