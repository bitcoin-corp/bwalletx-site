import{a1 as n,aw as e,ax as c,ay as o,az as i,aA as f}from"./index-B-yvYgAm.js";const r=n?`${n}/api/themes`:"";async function l(s=fetch){try{if(!r)return[...e];const a=await s(r);if(!a.ok)return[...e];const t=c(await a.json());return t.length?t:[...e]}catch{return[...e]}}function p(s,a){const t=o(a);t?i(s,t):f(s,a)}export{p as a,l as f};
//# sourceMappingURL=catalog-yGUGbx6C.js.map
