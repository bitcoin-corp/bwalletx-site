import{r as u}from"./wocLimiter-CB1baL7K.js";import{c as t,v as c}from"./sessions-CVXt2GSa.js";function n(r){const[f,s]=u.useState(()=>r?t(r):null);return u.useEffect(()=>{if(!r)return s(null);let e=!0;return s(t(r)),c(r).then(a=>e&&s(a)).catch(()=>{}),()=>{e=!1}},[r]),f}export{n as u};
//# sourceMappingURL=useIssuer-ZMeiyqWU.js.map
