import{i as e}from"./sessions-CVXt2GSa.js";import{aP as i,aQ as l,aR as n}from"./index-B-yvYgAm.js";const r=["b0asex"],c=(a,s=r)=>{const[t,o]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!s.includes(t)?!1:!o||o===l.toLowerCase()||(n??[]).includes(o)},m=(a,s=!1)=>s||e(a)||c(i(a??void 0));export{m as c};
//# sourceMappingURL=bulkAccess-_CuL0YLI.js.map
