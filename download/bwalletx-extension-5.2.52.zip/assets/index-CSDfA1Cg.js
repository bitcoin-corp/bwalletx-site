const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-C7CSxmWq.js","./index-B-yvYgAm.js","./crypto-KcxRl6yv.js","./wocLimiter-CB1baL7K.js","./wocLimiter-BZfJYSu4.css","./index-A-Fxjxty.css"])))=>i.map(i=>d[i]);
import{n as e,_ as t}from"./index-B-yvYgAm.js";import"./crypto-KcxRl6yv.js";import"./wocLimiter-CB1baL7K.js";const a=e("Share",{web:()=>t(()=>import("./web-C7CSxmWq.js"),__vite__mapDeps([0,1,2,3,4,5]),import.meta.url).then(r=>new r.ShareWeb)});export{a as Share};
//# sourceMappingURL=index-CSDfA1Cg.js.map
