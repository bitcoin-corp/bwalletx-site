import{e}from"./index-B-yvYgAm.js";import{j as a}from"./main-D_kzob7G.js";const r=(o,t)=>{a(`bsv21:${o}`),t(e("chat"))};export{r as o};
//# sourceMappingURL=ticketRoom-CHluEA9_.js.map
