import{c}from"./index-J_PtkWR-.js";const e=[["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}],["circle",{cx:"19",cy:"12",r:"1",key:"1wjl8i"}],["circle",{cx:"5",cy:"12",r:"1",key:"1pcz8c"}]],r=c("ellipsis",e);export{r as E};
//# sourceMappingURL=ellipsis-4O8RG_-z.js.map
