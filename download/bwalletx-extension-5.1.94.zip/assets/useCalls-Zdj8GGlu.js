import{r as s}from"./index-x8aVCVeJ.js";import{hK as r,hL as o}from"./main-CSLmWjS6.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-Zdj8GGlu.js.map
