import{A as o}from"./index-o3u4KYrs.js";const t=`${o()} (beta) by The Bitcoin Corporation Ltd. Based on the open-source Yours Wallet (MIT licence); not affiliated with or endorsed by its authors.`;export{t as U};
//# sourceMappingURL=brandText-fQcyC4pP.js.map
