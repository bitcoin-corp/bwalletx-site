import{r as s}from"./index-DQNqBtot.js";import{hP as r,hQ as o}from"./main-Bnp7h-jZ.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>o(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-Bki-AMsi.js.map
