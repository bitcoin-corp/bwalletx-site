const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DqYSf2WW.js","./index-NrgEgtuG.js","./index-CJqBZJ04.js","./index-UUJpKimX.js","./index-BDtJ2amF.css","./extensionMedia-Rm_l9uoo.js","./index-ihaHLE2d.css"])))=>i.map(i=>d[i]);
import{a7 as e,_ as t}from"./index-NrgEgtuG.js";import"./index-CJqBZJ04.js";import"./index-UUJpKimX.js";import"./extensionMedia-Rm_l9uoo.js";const _=e("Share",{web:()=>t(()=>import("./web-DqYSf2WW.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url).then(r=>new r.ShareWeb)});export{_ as Share};
//# sourceMappingURL=index-BymBmdpX.js.map
