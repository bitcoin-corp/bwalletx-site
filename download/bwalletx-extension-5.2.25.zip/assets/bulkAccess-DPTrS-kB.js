import{fn as r}from"./main-Cg-Xb7CP.js";import{g as e}from"./ApprovalHeroes-Bt50qzCM.js";import{aY as i}from"./index-NrgEgtuG.js";const n=["b0asex"],l=(a,o=n)=>{const[t,s]=a.trim().toLowerCase().replace(/^\$/,"").split("@");return!t||!o.includes(t)?!1:!s||s===i.toLowerCase()},p=(a,o=!1)=>o||r(a)||l(e(a??void 0));export{p as c};
//# sourceMappingURL=bulkAccess-DPTrS-kB.js.map
