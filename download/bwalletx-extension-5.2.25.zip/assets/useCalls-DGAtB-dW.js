import{r as s}from"./index-UUJpKimX.js";import{g_ as r,aG as a}from"./index-NrgEgtuG.js";const c=()=>{const[t,e]=s.useState(r);return s.useEffect(()=>a(e),[]),t};export{c as u};
//# sourceMappingURL=useCalls-DGAtB-dW.js.map
